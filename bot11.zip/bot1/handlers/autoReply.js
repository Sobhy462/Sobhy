const fs = require('fs');
const path = require('path');
const { downloadMediaMessage } = require('@whiskeysockets/baileys');
const hay = require('../haykala/developer');

// ---------- مجلد البيانات ----------
const dataDir = path.join(__dirname, '..', 'data');
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir);

// ---------- ملفات البيانات ----------
const groupRepliesFile = path.join(dataDir, 'groupReplies.json');
const xpFile = path.join(dataDir, 'xp.json');
const pointsFile = path.join(dataDir, 'points.json');
const profilesFile = path.join(dataDir, 'profiles.json');
const warningsFile = path.join(dataDir, 'warnings.json');
const blacklistFile = path.join(dataDir, 'blacklist.json');
const globalModePath = path.join(dataDir, 'mode.txt');
const groupModePath = path.join(dataDir, 'mode_groups.json');
const imagesFolder = path.join(dataDir, 'profiles_images');
const welcomePath = path.join(dataDir, 'activeWelcome.json');
const goodbyePath = path.join(dataDir, 'activeGoodbye.json');
const monitorFile = path.join(dataDir, 'monitorState.json');
const receptionPath = path.join(dataDir, 'activeReception.json');
const dailyStatsFile = path.join(dataDir, 'dailyStats.json');

// ---------- روابط ملفات الصلاحيات ----------
const developerJsonPath = path.join(__dirname, '..', 'haykala', 'developer.json');
const eliteJsonPath = path.join(__dirname, '..', 'haykala', 'elite.json');

// ---------- تحميل البيانات ----------
let groupReplies = {};
try {
    groupReplies = fs.existsSync(groupRepliesFile) ? JSON.parse(fs.readFileSync(groupRepliesFile, 'utf-8')) : {};
} catch { groupReplies = {}; }

let xp = {};
try {
    xp = fs.existsSync(xpFile) ? JSON.parse(fs.readFileSync(xpFile, 'utf-8')) : {};
} catch { xp = {}; }

let points = {};
try {
    points = fs.existsSync(pointsFile) ? JSON.parse(fs.readFileSync(pointsFile, 'utf-8')) : {};
} catch { points = {}; }

let profiles = {};
try {
    profiles = fs.existsSync(profilesFile) ? JSON.parse(fs.readFileSync(profilesFile, 'utf-8')) : {};
} catch { profiles = {}; }

let warnings = {};
try {
    warnings = fs.existsSync(warningsFile) ? JSON.parse(fs.readFileSync(warningsFile, 'utf-8')) : {};
} catch { warnings = {}; }

let blacklist = new Set();
try {
    if (fs.existsSync(blacklistFile)) {
        const data = JSON.parse(fs.readFileSync(blacklistFile, 'utf-8'));
        blacklist = new Set(data);
    }
} catch { blacklist = new Set(); }

let dailyStats = {};
try {
    dailyStats = fs.existsSync(dailyStatsFile) ? JSON.parse(fs.readFileSync(dailyStatsFile, 'utf-8')) : {};
} catch {
    dailyStats = { date: new Date().toDateString(), data: {} };
}
if (!dailyStats.data) dailyStats.data = {};

// ---------- التأكد من وجود المجلدات والملفات ----------
if (!fs.existsSync(imagesFolder)) fs.mkdirSync(imagesFolder, { recursive: true });
if (!fs.existsSync(globalModePath)) fs.writeFileSync(globalModePath, '[off]');
if (!fs.existsSync(groupModePath)) fs.writeFileSync(groupModePath, '{}');
if (!fs.existsSync(pointsFile)) fs.writeFileSync(pointsFile, '{}');
if (!fs.existsSync(blacklistFile)) fs.writeFileSync(blacklistFile, '[]');
if (!fs.existsSync(welcomePath)) fs.writeFileSync(welcomePath, JSON.stringify([]));
if (!fs.existsSync(goodbyePath)) fs.writeFileSync(goodbyePath, JSON.stringify([]));
if (!fs.existsSync(monitorFile)) fs.writeFileSync(monitorFile, JSON.stringify({}));
if (!fs.existsSync(receptionPath)) fs.writeFileSync(receptionPath, JSON.stringify([]));
if (!fs.existsSync(dailyStatsFile)) fs.writeFileSync(dailyStatsFile, JSON.stringify({ date: new Date().toDateString(), data: {} }));

// ==================== نظام الاستقبال ====================
function isReceptionGroup(groupId) {
    try {
        const reception = JSON.parse(fs.readFileSync(receptionPath));
        return reception.includes(groupId);
    } catch { return false; }
}

// ==================== نظام الترحيب ====================
let welcomedRecently = new Set();
let welcomeListenerAdded = false;

function setupWelcomeListener(sock) {
    if (welcomeListenerAdded) return;
    welcomeListenerAdded = true;

    console.log('✅ ﺐﻴﺣﺮﺘﻟﺍ ﻊﻤﺘﺴﻣ ﻞﻴﻌﻔﺗ ﻢﺗ');

    sock.ev.on('group-participants.update', async (update) => {
        try {
            const groupId = update.id;
            const participants = update.participants;

            if (update.action !== 'add') return;

            const mode = getGroupMode(groupId);
            
            for (const participant of participants) {
                const participantJid = typeof participant === 'string' ? participant : participant.id || participant;
                if (isUserBlocked(participantJid)) return;
            }

            // ====== التحقق من ترحيب الاستقبال ======
            if (isReceptionGroup(groupId)) {
                const groupMetadata = await sock.groupMetadata(groupId).catch(() => null);
                const groupName = groupMetadata?.subject || 'مجموعة استقبال';

                for (const participant of participants) {
                    const participantJid = typeof participant === 'string' ? participant : participant.id || participant;
                    if (!participantJid) continue;

                    const participantNumber = participantJid.split('@')[0] || participantJid;

                    const welcomeMsg = `📋 اسـتـمـارة ترحيب  📋
━━━━━━━━━━━━━━━━━━━━

👋 أهلاً بك @${participantNumber}، نورت مجموعة الاستقبال!

☠️ استقبال الأعضاء ☠️

📝 يرجى تعبئة البيانات التالية:

🎭 اللقب
اختر اسم شخصية من الأنمي أو المانجا بما يناسب جنسك.

📱 الطرف
اكتب اسم الحساب أو الصفحة التي حصلت منها على رابط المجموعة.

🖼️ الصورة
أرسل صورة الشخصية التي اخترتها.

⚠️ ملاحظة
لن يتم قبول طلب الانضمام إلى المجموعة الأساسية إلا بعد استكمال جميع البيانات.

💡 طريقة التقديم
• أرسل البيانات في رسالة واحدة.
• أو قم بالرد على هذه الرسالة.

━━━━━━━━━━━━━━━━━━━━
𓃥 𝐁𝐘 ┇ 𝐌𝐀𝐊𝐈𝐌𝐀`;

                    try {
                        await sock.sendMessage(groupId, {
                            text: welcomeMsg,
                            mentions: [participantJid]
                        });
                    } catch (sendErr) {}
                }
                return;
            }

            // ====== الترحيب العادي ======
            let activeGroups = [];
            try {
                activeGroups = JSON.parse(fs.readFileSync(welcomePath, 'utf8'));
            } catch (e) {
                return;
            }

            if (!activeGroups.includes(groupId)) return;

            const groupMetadata = await sock.groupMetadata(groupId).catch(() => null);
            const groupName = groupMetadata?.subject || 'مجموعة بدون اسم';

            for (const participant of participants) {
                const participantJid = typeof participant === 'string' ? participant : participant.id || participant;
                if (!participantJid) continue;

                const participantNumber = participantJid.split('@')[0] || participantJid;

                const key = `${groupId}:${participantJid}`;
                if (welcomedRecently.has(key)) continue;

                welcomedRecently.add(key);
                setTimeout(() => {
                    welcomedRecently.delete(key);
                }, 2000);

                let ppUrl = null;
                try {
                    ppUrl = await sock.profilePictureUrl(participantJid, 'image');
                } catch {
                    try {
                        ppUrl = await sock.profilePictureUrl(groupId, 'image');
                    } catch {
                        ppUrl = null;
                    }
                }

                const welcomeMsg = `
❛ ━━━━━━･❪ ❁ ❫ ･━━━━━━ ❜
🌷 أهلاً بيك في جروب: ${groupName}

❒ ╭┈⊰ 🌷 الــتــرحــيــب 🌷 ⊰┈ ✦
┊˹📯˼┊ أهــلاً وسهــلاً بـك
┊˹🥷🏻˼┊ @${participantNumber}

╭─═══════『 🎉✨ أهلاً بانضمامك ✨🎉 』══════─╮

🌟 نورت المكان وزاد النور بحضورك
💫 وجودك بيننا إضافة جميلة نفتخر بها
✨ هنا تجد الود، الاحترام، والمتعة
🎊 شاركنا أفكارك، ضحكتك، وكل ما تحب
📖 هذه ليست مجرد مجموعة… بل عائلة
🎈 أيامك معنا مليئة بالضحك والتفاعل
💌 لا تتردد، فمكانك محفوظ بيننا

╰─═══════『 🌷 استمتع معنا 🌷 』══════─╯

> منور الجروب ┊˹✅˼┊
❛ ━━━━━━･❪ ❁ ❫ ･━━━━━━ ❜
𝑴𝑨𝑲𝑰𝑴𝑨 𝑩𝑶𝑻 🔥
`;

                try {
                    const mediaMessage = ppUrl ?
                        {
                            image: { url: ppUrl },
                            caption: welcomeMsg,
                            mentions: [participantJid]
                        } :
                        {
                            text: welcomeMsg,
                            mentions: [participantJid]
                        };

                    await sock.sendMessage(groupId, mediaMessage);
                } catch (sendErr) {}
            }
        } catch (err) {
            console.error('خطأ في الترحيب:', err);
        }
    });
}

// ==================== نظام الوداع ====================
let goodbyeListenerAdded = false;

function setupGoodbyeListener(sock) {
    if (goodbyeListenerAdded) return;
    goodbyeListenerAdded = true;

    console.log('✅ ﻉﺍﺩﻮﻟﺍ ﻊﻤﺘﺴﻣ ﻞﻴﻌﻔﺗ ﻢﺗ');

    sock.ev.on('group-participants.update', async (update) => {
        try {
            const groupId = update.id;
            const participants = update.participants;

            if (update.action !== 'remove') return;

            let activeGroups = [];
            try {
                activeGroups = JSON.parse(fs.readFileSync(goodbyePath, 'utf8'));
            } catch (e) {
                return;
            }

            if (!activeGroups.includes(groupId)) return;

            const groupMetadata = await sock.groupMetadata(groupId).catch(() => null);
            const groupName = groupMetadata?.subject || 'مجموعة بدون اسم';

            for (const participant of participants) {
                const participantJid = typeof participant === 'string' ? participant : participant.id || participant;
                if (!participantJid) continue;

                const participantNumber = participantJid.split('@')[0] || participantJid;

                let ppUrl = null;
                try {
                    ppUrl = await sock.profilePictureUrl(participantJid, 'image');
                } catch {
                    try {
                        ppUrl = await sock.profilePictureUrl(groupId, 'image');
                    } catch {
                        ppUrl = null;
                    }
                }

                const goodbyeMsg = `
❛ ━━━━━━･❪ ❁ ❫ ･━━━━━━ ❜
💔 مع السلامة يا صديقنا

❒ ╭┈⊰ 🌷 الــوداع 🌷 ⊰┈ ✦
┊˹📯˼┊ نفتقدك في جروب: ${groupName}
┊˹🥷🏻˼┊ @${participantNumber}

╭─═══════『 😢 وداعاً 』══════─╮

💔 كنا نتمنى أن تبقى معنا
✨ لكن قدرك وأيامك في مكان آخر
🌟 سنفتقد حضورك الجميل
🎈 ونتمنى لك كل الخير
💫 أبوابنا مفتوحة لك دائماً
📖 مكانك محفوظ متى عدت

╰─═══════『 🤍 』══════─╯

> مع السلامة ┊˹💔˼┊
❛ ━━━━━━･❪ ❁ ❫ ･━━━━━━ ❜
𝑴𝑨𝑲𝑰𝑴𝑨 𝑩𝑶𝑻 🔥
`;

                try {
                    const mediaMessage = ppUrl ?
                        {
                            image: { url: ppUrl },
                            caption: goodbyeMsg,
                            mentions: [participantJid]
                        } :
                        {
                            text: goodbyeMsg,
                            mentions: [participantJid]
                        };

                    await sock.sendMessage(groupId, mediaMessage);
                } catch (sendErr) {}
            }
        } catch (err) {
            console.error('خطأ في الوداع:', err);
        }
    });
}

// ==================== دوال الحظر ====================
function isUserBlocked(userId) {
    return blacklist.has(userId);
}

function addUserToBlacklist(userId) {
    blacklist.add(userId);
    fs.writeFileSync(blacklistFile, JSON.stringify([...blacklist], null, 2));
}

function removeUserFromBlacklist(userId) {
    blacklist.delete(userId);
    fs.writeFileSync(blacklistFile, JSON.stringify([...blacklist], null, 2));
}

// ==================== دوال الصلاحيات ====================
function normalizeLid(lid) {
    if (typeof lid === 'string' && !lid.endsWith('@lid')) {
        return lid + '@lid';
    }
    return lid;
}

function loadDeveloper() {
    try {
        if (fs.existsSync(developerJsonPath)) {
            return JSON.parse(fs.readFileSync(developerJsonPath, 'utf-8'));
        }
    } catch (e) {}
    return { founder: [], ownerbot: [], developers: [] };
}

function loadElite() {
    try {
        if (fs.existsSync(eliteJsonPath)) {
            return JSON.parse(fs.readFileSync(eliteJsonPath, 'utf-8'));
        }
    } catch (e) {}
    return [];
}

function isFounder(senderLid) {
    const dev = loadDeveloper();
    for (let f of dev.founder) {
        if (normalizeLid(f) === senderLid) return true;
    }
    return false;
}

function isOwnerbot(senderLid) {
    const dev = loadDeveloper();
    for (let o of dev.ownerbot) {
        if (normalizeLid(o) === senderLid) return true;
    }
    return false;
}

function isDev(senderLid) {
    const dev = loadDeveloper();
    for (let d of dev.developers) {
        if (normalizeLid(d) === senderLid) return true;
    }
    return false;
}

function isElite(senderLid) {
    const elite = loadElite();
    for (let e of elite) {
        if (normalizeLid(e) === senderLid) return true;
    }
    return false;
}

// ==================== دوال الرتب والصلاحيات ====================
function getRank(jid) {
    if (isFounder(jid)) return 4;
    if (isOwnerbot(jid)) return 3;
    if (isDev(jid)) return 2;
    if (isElite(jid)) return 1;
    return 0;
}

function getUserRank(sender) {
    if (isFounder(sender)) return 'founder';
    if (isOwnerbot(sender)) return 'owner';
    if (isDev(sender)) return 'developer';
    if (isElite(sender)) return 'elite';
    return 'user';
}

function getGlobalMode() {
    return fs.readFileSync(globalModePath, 'utf-8').trim();
}

function getGroupMode(chatId) {
    const groupModes = JSON.parse(fs.readFileSync(groupModePath, 'utf-8'));
    return groupModes[chatId] || getGlobalMode();
}

function canSeeLevelUp(sender, chatId) {
    const mode = getGroupMode(chatId);
    const senderLid = normalizeLid(sender.split('@')[0]);

    if (isUserBlocked(sender)) return false;

    switch (mode) {
        case '[off]': return true;
        case '[نخبة]': return isElite(senderLid) || isDev(senderLid) || isOwnerbot(senderLid) || isFounder(senderLid);
        case '[مطور]': return isDev(senderLid) || isOwnerbot(senderLid) || isFounder(senderLid);
        case '[اونر]': return isOwnerbot(senderLid) || isFounder(senderLid);
        default: return false;
    }
}

async function checkCommandPermission(chatId, sender) {
    const mode = getGroupMode(chatId);
    const senderLid = normalizeLid(sender.split('@')[0]);

    if (mode === '[off]') return true;
    if (mode === '[اونر]') return isOwnerbot(senderLid) || isFounder(senderLid);
    if (mode === '[مطور]') return isDev(senderLid) || isOwnerbot(senderLid) || isFounder(senderLid);
    if (mode === '[نخبة]') return isElite(senderLid) || isDev(senderLid) || isOwnerbot(senderLid) || isFounder(senderLid);
    return false;
}

// ==================== دالة التحقق من صلاحيات المشرفين والمطورين ====================
async function checkAdminPermission(sock, chatId, sender) {
    const senderLid = normalizeLid(sender.split('@')[0]);
    
    // التحقق من النخبة والمطور والأونر
    if (isFounder(senderLid) || isOwnerbot(senderLid) || isDev(senderLid) || isElite(senderLid)) {
        return true;
    }
    
    // التحقق من المشرفين في المجموعة
    try {
        const groupMetadata = await sock.groupMetadata(chatId);
        const participant = groupMetadata.participants.find(p => p.id === sender);
        return participant?.admin === 'admin' || participant?.admin === 'superadmin';
    } catch (e) {
        return false;
    }
}

// ==================== دوال النقاط ====================
function getPoints(sender) {
    const val = points[sender];
    return (typeof val === 'number' && isFinite(val) && !isNaN(val)) ? Math.floor(val) : 0;
}

function setPoints(sender, newPoints) {
    if (isNaN(newPoints) || !isFinite(newPoints)) return;
    points[sender] = Math.floor(newPoints);
    fs.writeFileSync(pointsFile, JSON.stringify(points, null, 2));
}

function addPoints(sender, amount) {
    const current = getPoints(sender);
    setPoints(sender, current + amount);
}

// ==================== دوال البطاقة ====================
function getProfile(sender) {
    return profiles[sender] || null;
}

function setProfile(sender, nickname, age, gender, imagePath) {
    profiles[sender] = { nickname, age, gender, image: imagePath || null };
    fs.writeFileSync(profilesFile, JSON.stringify(profiles, null, 2));
}

function isTitleTaken(title, excludeUser = null) {
    for (const [user, data] of Object.entries(profiles)) {
        if (user === excludeUser) continue;
        if (data.nickname && data.nickname.toLowerCase() === title.toLowerCase()) {
            return true;
        }
    }
    return false;
}

// ==================== دوال الإنذارات ====================
function loadWarnings() {
    if (!fs.existsSync(warningsFile)) {
        fs.writeFileSync(warningsFile, JSON.stringify({}));
    }
    return JSON.parse(fs.readFileSync(warningsFile));
}

function saveWarnings(data) {
    fs.writeFileSync(warningsFile, JSON.stringify(data, null, 2));
}

function getWarningsCount(chatId, sender) {
    const warnings = loadWarnings();
    return warnings[chatId]?.[sender]?.count || 0;
}

function addWarning(chatId, sender, reason) {
    const warnings = loadWarnings();
    if (!warnings[chatId]) warnings[chatId] = {};
    if (!warnings[chatId][sender]) {
        warnings[chatId][sender] = { count: 0, reasons: [], timestamps: [] };
    }
    warnings[chatId][sender].count++;
    warnings[chatId][sender].reasons.push(reason);
    warnings[chatId][sender].timestamps.push(Date.now());
    saveWarnings(warnings);
    return warnings[chatId][sender].count;
}

function getRemainingTime(timestamps) {
    if (!timestamps || timestamps.length === 0) return '0 ساعة';
    const now = Date.now();
    const oldest = Math.min(...timestamps);
    const elapsed = now - oldest;
    const remaining = 24 * 60 * 60 * 1000 - elapsed;
    if (remaining <= 0) return 'منتهي';
    const hours = Math.floor(remaining / (60 * 60 * 1000));
    const minutes = Math.floor((remaining % (60 * 60 * 1000)) / (60 * 1000));
    return `${hours} ساعة ${minutes} دقيقة`;
}

// ==================== دوال المستويات ====================
const levels = [
    { min: 0, name: '🌱 مبتدئ', emoji: '🌱' },
    { min: 100, name: '📖 متفاعل', emoji: '📖' },
    { min: 300, name: '💬 متواصل', emoji: '💬' },
    { min: 600, name: '🔥 نشيط', emoji: '🔥' },
    { min: 1000, name: '⭐ متألق', emoji: '⭐' },
    { min: 1500, name: '👑 ملك التفاعل', emoji: '👑' },
    { min: 2000, name: '💎 محترف', emoji: '💎' },
    { min: 3000, name: '🏆 الخارق', emoji: '🏆' },
    { min: 5000, name: '👾 أسطورة خارقة', emoji: '👾' },
    { min: 7500, name: '🌟 أسطورة', emoji: '🌟' },
    { min: 10000, name: '🌌 كوني', emoji: '🌌' }
];

function getLevel(xpPoints) {
    let lvl = levels[0];
    for (let i = levels.length - 1; i >= 0; i--) {
        if (xpPoints >= levels[i].min) {
            lvl = levels[i];
            break;
        }
    }
    return lvl;
}

function getNextLevel(xpPoints) {
    for (let i = 0; i < levels.length; i++) {
        if (xpPoints < levels[i].min) return levels[i];
    }
    return levels[levels.length - 1];
}

// ==================== دوال المستويات مع الألقاب ====================
const levelTitles = {
    1: { title: 'الوافد الجديد', minXp: 0, points: 0 },
    2: { title: 'البادئ النشط', minXp: 50, points: 10 },
    3: { title: 'المتفاعل الصغير', minXp: 100, points: 20 },
    4: { title: 'النجم الصاعد', minXp: 200, points: 35 },
    5: { title: 'المستكشف', minXp: 350, points: 50 },
    6: { title: 'الحارس المتقدم', minXp: 500, points: 70 },
    7: { title: 'البطل المثقف', minXp: 750, points: 90 },
    8: { title: 'القائد الحكيم', minXp: 1000, points: 120 },
    9: { title: 'حارس الطريق', minXp: 1300, points: 150 },
    10: { title: 'المرشد النبيل', minXp: 1700, points: 180 },
    11: { title: 'السيف الذهبي', minXp: 2100, points: 220 },
    12: { title: 'الفارس الأسطوري', minXp: 2600, points: 260 },
    13: { title: 'الحكيم المتألق', minXp: 3200, points: 300 },
    14: { title: 'الظل الصامت', minXp: 3900, points: 350 },
    15: { title: 'النسر المحلق', minXp: 4700, points: 400 },
    16: { title: 'القلعة الحصينة', minXp: 5600, points: 450 },
    17: { title: 'الروح الثائرة', minXp: 6600, points: 500 },
    18: { title: 'التاج المضيء', minXp: 7700, points: 550 },
    19: { title: 'الأسطورة الحية', minXp: 9000, points: 600 },
    20: { title: 'الملك المتوج', minXp: 10500, points: 700 },
    21: { title: 'الإمبراطور', minXp: 12500, points: 800 },
    22: { title: 'الجبل الشامخ', minXp: 15000, points: 900 },
    23: { title: 'النجم القطبي', minXp: 18000, points: 1000 },
    24: { title: 'الضوء الأزلي', minXp: 22000, points: 1200 },
    25: { title: 'الكوني', minXp: 27000, points: 1500 },
};

function getLevelInfo(xpPoints) {
    let currentLevel = 1;
    let currentTitle = levelTitles[1].title;
    let nextLevel = 2;
    let nextTitle = levelTitles[2].title;
    let pointsReward = 0;

    for (let i = 25; i >= 1; i--) {
        if (xpPoints >= levelTitles[i].minXp) {
            currentLevel = i;
            currentTitle = levelTitles[i].title;
            pointsReward = levelTitles[i].points;
            if (i < 25) {
                nextLevel = i + 1;
                nextTitle = levelTitles[nextLevel].title;
            } else {
                nextLevel = i;
                nextTitle = 'الحد الأقصى';
            }
            break;
        }
    }

    const nextMinXp = nextLevel <= 25 ? levelTitles[nextLevel].minXp : xpPoints;
    const currentMinXp = levelTitles[currentLevel].minXp;
    const progress = nextLevel > currentLevel ? 
        Math.min(100, ((xpPoints - currentMinXp) / (nextMinXp - currentMinXp)) * 100) : 100;

    return {
        level: currentLevel,
        title: currentTitle,
        nextLevel: nextLevel,
        nextTitle: nextTitle,
        progress: Math.round(progress),
        pointsReward: pointsReward,
        xpPoints: xpPoints,
        nextMinXp: nextMinXp,
        xpToNext: nextLevel > currentLevel ? nextMinXp - xpPoints : 0
    };
}

// ==================== الكلمات المحظورة (كلمات كاملة، وليس جزء من كلمة) ====================
const bannedWords = [
    'زبر', 'زوبر', 'نيك', 'زبري', 'زبرين', 'كس', 'كسمك', 'كسختك', 'كس امك', 'كس أمك',
    'كسكم', 'كسمكم', 'كس اختك', 'كسم اختك', 'كسمح', 'كس ام', 'كسمين',
    'شرموطه', 'شرموطة', 'شراميط', 'المتناكة', 'قحبة', 'قحب', 'منيوك',
    'منيوكه', 'مينوك', 'مينوكه', 'خول', 'قسمك', 'قحبه', 'عرص',
    'نيكو', 'متناكه', 'متناك', 'بضاني', 'بضان', 'تنيك', 'انيك', 'منيكه'
];
// دالة للتحقق من وجود كلمة محظورة كاملة (وليس جزء من كلمة)
function containsBannedWord(text) {
    const lower = text.toLowerCase();
    for (const word of bannedWords) {
        // استخدام regex للبحث عن الكلمة كاملة (ليست جزء من كلمة أخرى)
        const regex = new RegExp('\\b' + word + '\\b', 'i');
        if (regex.test(lower)) {
            return true;
        }
        // بعض الكلمات قد تكون بدون حدود كلمة (مثل كس)
        if (lower.includes(word) && word.length >= 2) {
            // التحقق من أنها ليست جزء من كلمة أخرى
            const index = lower.indexOf(word);
            const before = index > 0 ? lower[index - 1] : '';
            const after = index + word.length < lower.length ? lower[index + word.length] : '';
            // إذا كان الحرف قبلها أو بعدها حرف (وليس مسافة أو علامة ترقيم) فهي جزء من كلمة
            const isPartOfWord = (before >= 'a' && before <= 'z') || (before >= 'أ' && before <= 'ي') ||
                                 (after >= 'a' && after <= 'z') || (after >= 'أ' && after <= 'ي');
            if (!isPartOfWord) {
                return true;
            }
        }
    }
    return false;
}

// ==================== دوال منع الروابط ====================
function containsLink(text) {
    const urlRegex = /(https?:\/\/[^\s]+|www\.[^\s]+|[a-zA-Z0-9-]+\.[a-zA-Z]{2,})/gi;
    return urlRegex.test(text);
}

function isWhatsAppLink(text) {
    const waRegex = /https?:\/\/(chat\.whatsapp\.com|wa\.me|whatsapp\.com)\/[^\s]*/gi;
    return waRegex.test(text);
}

function isContactMessage(msg) {
    return msg.message?.contactMessage || msg.message?.contactsArrayMessage;
}

// ==================== منشن جماعي ====================
function containsMassMention(text, mentionedJidList = []) {
    const keywordRegex = /@everyone|@all|@جميع|@الكل|@كل\s+الاعضاء|@everybody|@الكل\s*/gi;
    if (keywordRegex.test(text)) return true;
    
    const mentionMatches = text.match(/@[\w\d]+/g) || [];
    if (mentionMatches.length >= 3) return true;
    
    if (mentionedJidList && mentionedJidList.length >= 3) return true;
    
    const numberMatches = text.match(/\d{10,}/g) || [];
    if (numberMatches.length >= 3) return true;
    
    return false;
}

// ==================== خريطة الإيموجي ====================
const emojiMap = {
    greeting: ['👋', '✨', '🤍'], love: ['❤️', '🫶', '💖'], laugh: ['😂', '🤣', '😂'],
    support: ['💪', '🤍', '🫂'], praise: ['🔥', '👑', '🌟'], farewell: ['👋', '✌️', '🤍'], default: ['✨', '😎', '🤍']
};

// ======================================================================
// ==================== الردود التلقائية - مصفوفة واحدة كاملة ====================
// ======================================================================

const replies = [
    // ===================================================================
    // ===================== التحيات الأساسية =====================
    // ===================================================================
    { match: ['السلام عليكم', 'سلام عليكم', 'سلام', 'السسلام'], replies: [
        'وعليكم السلام ورحمة الله وبركاته 🌷',
        'وعليكم السلام يا نجم 🤍',
        'وعليكم السلام وطول العمر 🌸',
        'وعليكم السلام ورحمة الله 🕊️',
        'وعليكم السلام يا غالي ❤️',
        'الله يسلمك يا بعدي 🌷',
        'وعليكم السلام وأهلاً بك 💫',
        'السلام عليك ورحمة الله وبركاته 🤲'
    ], type: 'greeting' },
    
    { match: ['بخرج', 'خارج', 'طالع', 'بروح', 'روحت', 'رحت'], replies: [
        'لا ترجع 👀',
        'تروح يجي غيرك عشرة 👋',
        'ارجع بالسلامة يا غالي 🤍',
        'ربنا معاك 🌸',
        'سلامتك يا نجم 🌷',
        'تروح وترجع بالسلامة إن شاء الله 🙏',
        'في حفظ الرحمن 🤲',
        'استودعك الله 🤍',
        'ربنا يحميك ويرعاك 🙏',
        'ننتظر عودتك بفارغ الصبر 🥹'
    ], type: 'greeting' },
    
    { match: ['هاي', 'هلا', 'اهلين', 'مرحبتين', 'ملحبا', 'هلااا', 'هلا والله'], replies: [
        'هلا وغلا 🤍',
        'أهلاً وسهلاً 🌸',
        'يا مرحبا بيك ✨',
        'وجودك شرف 👑',
        'نورت 👋',
        'ياهلا والله 🌷',
        'أهلًا مليار 💫',
        'نورت الدنيا ☀️',
        'تشرفنا بيك 🫡',
        'هلا مليون 🌹',
        'أهلاً وسهلاً بالغالي ❤️',
        'نورت يا قمر 🌙',
        'يا هلا بمن زارنا 🌸',
        'حيّاك الله وبياك 🙏',
        'منورنا بوجودك ✨'
    ], type: 'greeting' },
    
    { match: ['صباح الخير', 'صباح', 'صباحو', 'صباحك', 'صباح النور'], replies: [
        'صباح الفل ☀️',
        'صباح النشاط 💪',
        'صباح الورد 🌸',
        'صباح السعادة 😄',
        'صباح النور والسرور ✨',
        'صباحك سعادة يا جميل 🌹',
        'صباح الفل والياسمين 🌷',
        'صباح الخير يا عسل 🍯',
        'صباحك ورد وجوري 🌹',
        'صباح الأنوار والبهجة ✨',
        'نهارك سعيد يا غالي ☀️',
        'صباح الخير والبركة 🌸',
        'ربنا يبارك في يومك 🙏'
    ], type: 'greeting' },
    
    { match: ['مساء الخير', 'مساء', 'مساءو', 'مسائك', 'مساء النور'], replies: [
        'مساء الفل ✨',
        'مساء الورد 🌹',
        'مساء السعادة 🥰',
        'مساء النور 💫',
        'مساء الحب والشوق ❤️',
        'مساءك أحلى من القمر 🌙',
        'مساء العسل والجمال 🍯',
        'مساءك ورد يا جميل 🌹',
        'ليلتك سعيدة ياغالي 🌙',
        'مساء الأنوار ✨',
        'مساء الخير والبركة 🌸',
        'ربنا يسعد مساك 🙏'
    ], type: 'greeting' },
    
    { match: ['نهارك سعيد', 'نهارك', 'نهار', 'نهاركم'], replies: [
        'ونهارك أطيب ☀️',
        'نهارك فل وورد 🌸',
        'أسعد الله نهارك ✨',
        'نهارك جميل زيك 😍',
        'نهارك سعادة وسرور 🌞',
        'ربنا يبارك في يومك 🙏',
        'نهارك أبيض يا غالي ☀️'
    ], type: 'greeting' },
    
    { match: ['ليلتك سعيدة', 'ليلتك', 'ليل', 'ليلتكم'], replies: [
        'ويلتتك أحلى 🌙',
        'ليلتك فل ولا غلاوة 💫',
        'أحلامك وردية 🌸',
        'ليلتك سعيدة يا جميل 🌙',
        'ليلتك جميلة زيك ❤️',
        'تصبح على خير ورد 🌹',
        'ربنا يحرس ليلتك 🙏'
    ], type: 'greeting' },

    // ===================================================================
    // ===================== تحيات المناسبات =====================
    // ===================================================================
    { match: ['جمعة مباركة', 'جمعه مباركه', 'الجمعة', 'جمعه'], replies: [
        'جمعة مباركة عليك 🤲',
        'تقبل الله صالح الأعمال 🌸',
        'منها لأعلى الدرجات ✨',
        'جعله الله يوم خير عليك 🕌',
        'جمعة مباركة وكل عام وأنت بخير 🌹',
        'اللهم اجعلها جمعة خير وبركة 🙏',
        'تقبل الله طاعتك 🤲'
    ], type: 'greeting' },
    
    { match: ['رمضان كريم', 'رمضان', 'شهر رمضان', 'رمضون', 'رمض'], replies: [
        'رمضان كريم عليك 🌙',
        'كل عام وأنت بخير 🤲',
        'ربنا يبلغنا وإياكم 🥹',
        'جعله الله شهر خير وبركة ✨',
        'رمضان مبارك وكل عام وأنت بصحة 🌸',
        'اللهم بلغنا رمضان وأعنا على صيامه 🙏',
        'شهر الخير والرحمة 🌙'
    ], type: 'greeting' },
    
    { match: ['كل سنة وأنت طيب', 'كل عام وانتم بخير', 'سنة سعيدة', 'عام سعيد'], replies: [
        'وأنت طيب يا غالي 🌸',
        'كل سنة وأنت أحلى ❤️',
        'ربنا يديك الصحة والعافية 💪',
        'كل عام وإنت بخير ألف مرة 🎉',
        'وأنت طيب وبخير وسعادة 😍',
        'كل سنة وأنت أقرب لحبي 🥹',
        'عقبال مليون سنة ❤️'
    ], type: 'greeting' },
    
    { match: ['عيد مبارك', 'عيد', 'العيد', 'عيد الفطر', 'عيد الاضحى'], replies: [
        'عيد مبارك عليك 🎊',
        'كل عام وأنت بخير 🌸',
        'عيد سعيد وفرحة دائمة 🥳',
        'جعله الله عيد خير وبركة 🤲',
        'عيدك مبارك يا غالي ❤️',
        'اللهم أعدها علينا بالخير واليمن 🙏'
    ], type: 'greeting' },

    // ===================================================================
    // ===================== تحيات متنوعة =====================
    // ===================================================================
    { match: ['إزيك', 'ازيك', 'ازيكو', 'ازيكم', 'عامل ايه', 'عامل'], replies: [
        'الحمد لله وأنت إزيك 🌸',
        'أنا بخير وإياك 🤍',
        'بخير يا عم ❤️',
        'تمام التمام وإنت 😍',
        'أنا كويس وإنت؟ 🌷',
        'الحمد لله كلو تمام ✨',
        'بخير وسعادة والحمد لله 🙏'
    ], type: 'greeting' },
    
    { match: ['كيف الحال', 'كيف', 'كيفك', 'كيفك انت', 'شو اخبارك', 'أخبارك'], replies: [
        'الحال تمام يا غالي 🌸',
        'بخير يالغالي ❤️',
        'الحمد لله وأنت 😍',
        'كلو تمام والحمد لله 🙏',
        'أنا منيح وإنت 🌸',
        'أخبارك أحلى 😍',
        'والله أحلى ما تكون ✨'
    ], type: 'greeting' },
    
    { match: ['هلا والله', 'هلا', 'هلا بيك', 'هلا فيك', 'ياهلا'], replies: [
        'هلا والله وسهلاً 🌸',
        'يا مرحبا بك مليون ✨',
        'نورتنا والله 🌷',
        'الله يهلّيك 🌹',
        'يا هلا يا بعدي ❤️',
        'نورت الدنيا بقدومك ☀️'
    ], type: 'greeting' },
    
    { match: ['أرحب', 'ترحب', 'مرحب', 'مرحبا', 'مرحباً'], replies: [
        'أرحب ترحيبة المطر 🌧️',
        'الله يرحب بك 🤍',
        'أهلًا وسهلًا 💫',
        'نورت الدنيا ☀️',
        'مرحباً ألف 🌸',
        'الله يرحب بيك ويسعدك 🌷'
    ], type: 'greeting' },

    // ===================================================================
    // ===================== الحب والعشق =====================
    // ===================================================================
    { match: ['احبك', 'بحبك', 'أحبك', 'حب', 'محبة'], replies: [
        'وانا كمان ❤️',
        'انت غالي جدًا 🤍',
        'محبة من القلب 🫶',
        'تسلملي 🥹',
        'أنت كل حياتي 💖',
        'أنت الأجمل 😍',
        'حبك نعمة كبيرة 🙏',
        'أحبك أكثر مما تتخيل 💕',
        'أنت دنياي كلها ❤️',
        'عشقك في دمي 🥹',
        'حبك ليه طعم تاني 😍',
        'أنا ملكك وأنت ملكي 🫅'
    ], type: 'love' },
    
    { match: ['حبيبي', 'حياتي', 'عمري', 'قلبي', 'روحي', 'نور عيني', 'نور'], replies: [
        'يا قلبي 🫶',
        'عمري انت 😍',
        'نور حياتي 🌸',
        'روحي 😘',
        'قلبي ملكك 🫶🏻',
        'يا نبض قلبي ❤️',
        'أنت كل شيء 🥹',
        'فديتك ياروحي 💖',
        'يا أحلى إنسان في الكون 🌍',
        'كل حبي ليك ❤️'
    ], type: 'love' },
    
    { match: ['يا روحي', 'ياروحي', 'روح روح', 'روحي'], replies: [
        'روحك في روحي ❤️',
        'يا روح القلب 🫶',
        'أنا فداك 🥹',
        'روحي وزيادة 😍',
        'روح الروح يا غالي 💖',
        'يا روح حياتي 🌸'
    ], type: 'love' },
    
    { match: ['يا حبيبة', 'حبيبة', 'يا حبيبتي', 'حبيبتي', 'حبيبه'], replies: [
        'حبيبة قلبي ❤️',
        'يا عيوني 😍',
        'جمالك مو طبيعي 🌸',
        'حبيبتي وزيادة 🫶',
        'يا أجمل هدية في الحياة 💕',
        'حبيبة الروح يا جميلة 🌹'
    ], type: 'love' },
    
    { match: ['توأم', 'توأمي', 'توأم روحي', 'توأم الروح'], replies: [
        'توأم روحي ❤️',
        'خلقت من ضلعي 🫂',
        'أنا وأنت واحد 🤍',
        'توأم الروح والقلب 💖',
        'توأم في كل شيء ❤️',
        'آه لو تعرف قد إيه ❤️'
    ], type: 'love' },
    
    { match: ['نصفي', 'نصفي الثاني', 'نصف', 'نصفي'], replies: [
        'أنت نصفي فعلاً ❤️',
        'من غيرك أنا مش كامل 🥹',
        'نصفي وزيادة 😍',
        'نصفي الثاني وأنا فداك 💖',
        'أنت نصفي ونصف قلبي 🤍'
    ], type: 'love' },
    
    { match: ['عشق', 'عاشق', 'عاشقة', 'عشقتك', 'عشقني'], replies: [
        'عشقك حياتي 🌹',
        'أنا عاشق من نظرة 👀',
        'العشق أنت بحد ذاتك ❤️',
        'عشقي لك كبير جدًا 🥹',
        'عشقك في دمي وجسمي 💖',
        'أنا عاشق مجنون 😍'
    ], type: 'love' },
    
    { match: ['مشتاق', 'وحشتني', 'وحشني', 'وحشيتني', 'شوق', 'اشتياق'], replies: [
        'وحشتني والله 🥺',
        'أنا كمان متشوق 🤍',
        'تعال نعوض الغياب 🌸',
        'شوقي لك في السماء 💫',
        'قلبي مشتاق ليك 😭',
        'غيابك صعب يا روحي 💔',
        'شوقي ليك لا يوصف ❤️',
        'تعال بقى أنا مستنيك 🥹'
    ], type: 'love' },
    
    { match: ['بموت فيك', 'موتني', 'موت', 'مات في حبك'], replies: [
        'موتني بحبك 😭❤️',
        'لا تموت أنت الأهم 💖',
        'عيش معايا 😍',
        'أنا الميت في حبك 🥹',
        'بموت في عيونك 😍',
        'موتة حب أنت ❤️'
    ], type: 'love' },
    
    { match: ['أنت ملكي', 'ملكي', 'ملك', 'مملكتي', 'سلطنتي'], replies: [
        'وأنا عبدك 👑',
        'أمرني يا ملكي 🫡',
        'تحت رجليك ❤️',
        'أنا لك يا مولاي 😍',
        'أنت ملكي وأنا ملكك 💖',
        'أمر يا ملكي 👑'
    ], type: 'love' },
    
    { match: ['يا بعدي', 'يابعدي', 'بعد', 'بعدي'], replies: [
        'يا بعد روحى 😍',
        'يا بعد عيني ❤️',
        'ربنا يخليك 🤍',
        'تبعد عني وما أقدر 🥹',
        'يا بعد قلبي 💖'
    ], type: 'love' },
    
    { match: ['جوهرة', 'جوهرتي', 'الجوهرة', 'جوهر'], replies: [
        'جوهرتي الثمينة 💎',
        'أنت جوهرة نادرة 🌸',
        'فداك قلبي ❤️',
        'أغلى جوهرة في الدنيا 💎',
        'جوهرة لا تقدر بثمن 💎'
    ], type: 'love' },
    
    { match: ['قمر', 'قمرة', 'قمر 14', 'البدر', 'قمرا'], replies: [
        'قمر 14 🌕',
        'القمر أنت مش أنا 🤍',
        'يا قمر السهرة 🌙',
        'أجمل قمر في السماء 🌕',
        'قمر مكتمل يا جميل 🌝'
    ], type: 'love' },
    
    { match: ['سكر', 'سكره', 'عسل', 'عسلة', 'سكرزيادة'], replies: [
        'سكر زيادة 🍬',
        'حلاوتك بتدمر 😍',
        'أنا مدمن سكرك ❤️',
        'سكر يا جميل 🍭',
        'عسل زيادة 🍯'
    ], type: 'love' },
    
    { match: ['أمير', 'أميري', 'أميرة', 'اميرتي', 'أمراء'], replies: [
        'أمير روحي 👑',
        'يا أمير الظلام والضياء 🌹',
        'فديتك يا أمير ❤️',
        'أميرة قلبي 👸',
        'أنت أمير الحب والعشق 💖'
    ], type: 'love' },
    
    { match: ['زهرة', 'زهرتي', 'الزهرة', 'وردة', 'ورود'], replies: [
        'زهرة الربيع 🌸',
        'يا أجمل زهرة في الدنيا 🌹',
        'زهرتي وحياتي ❤️',
        'وردة من الجنة 🌺'
    ], type: 'love' },
    
    { match: ['نور', 'نورتي', 'نورت', 'الضوء', 'مصباح'], replies: [
        'نور عيني ❤️',
        'نورتي حياتي كلها ☀️',
        'نور الدنيا يا جميل 🌟',
        'الضوء في عيونك 😍'
    ], type: 'love' },
    
    { match: ['روح', 'روح قلبي', 'روح الروح', 'ارواح'], replies: [
        'روح قلبي ❤️',
        'روح الروح يا غالي 🥹',
        'أنت روح حياتي 💖',
        'روح تسكن في قلبي 🌸'
    ], type: 'love' },
    
    { match: ['يا غالي', 'يا غالية', 'غلا', 'غلاه', 'غلاتي'], replies: [
        'غالي عليا جداً ❤️',
        'غلاوة في قلبي 🥹',
        'ما في أغلى منك 💖',
        'غالي وماله قيمة 💎'
    ], type: 'love' },
    
    { match: ['حلو', 'حلوة', 'حلا', 'حلاه', 'أحلى'], replies: [
        'انت الأحلى 🌷',
        'حلاوتك طاغية 🔥',
        'الجمال جمالك 😍',
        'حلو كده ليه 🥹',
        'أحلى ما في الكون ❤️'
    ], type: 'love' },

    // ===================================================================
    // ===================== الضحك والهزار =====================
    // ===================================================================
    { match: ['😂', '🤣', '😅', '😆', 'هههه', 'ههه', 'هه'], replies: [
        'ضحكتك حلوة 😂',
        'اضحك اضحك الحياة قصيرة 😂',
        'ضحك من القلب 😂',
        'الله يسعدك 🤍',
        'تدوم ضحكتك 🫣',
        'ههههه دي بتاعتك 😂',
        'وقفت ضحك 🤣',
        'ماتت من الضحك 🫠',
        'موتني الضحك 😂',
        'على مهلك 😂'
    ], type: 'laugh' },
    
    { match: ['ههههه', 'هههه', 'ههه', 'هههههه', 'ههههههه'], replies: [
        'ضحكتني والله 😂',
        'تسلم ضحكتك 🤣',
        'جبت العيد 😂',
        'أضحك يادنيا 😂',
        'موتني ضحك 🫠',
        'هههههه عظمة 😂',
        'منت وجعني ضحك 🤣'
    ], type: 'laugh' },
    
    { match: ['احا', 'احتين', 'احات', 'أحا', 'احاا', 'احااا'], replies: [
        '😂 شكلك مصدوم؟',
        '😏 احا من العيار التقيل',
        'احتين كمان 🐦',
        'احححح 🫦🫶🏻',
        'احات كمان 🐦',
        'احا بجد 🐦',
        'إحا إحا 😂',
        'عجبتك ولا إيه 😏',
        'يا احاااا 😂'
    ], type: 'laugh' },
    
    { match: ['موت ضحك', 'ضحكتني', 'ضحك', 'ضحك موت'], replies: [
        'تسلم ضحكتك 😂',
        'ده أنت اللي مضحك 🫶',
        'أضحكك دايمًا 🤣',
        'كل يوم تضحكني 😂',
        'انت اللي بتضحك 😂'
    ], type: 'laugh' },
    
    { match: ['مزح', 'نكتة', 'نكت', 'قول نكتة'], replies: [
        'قالولي نكتة؟ 😂',
        'أنا نكتة متنقلة 🃏',
        'جهز نفسك 😂',
        'مرة واحد راح البحر... ايه بتعمل 😂',
        'انا نكتة متكلمة 😂',
        'عندي نكتة بس هتتعبك 🤣'
    ], type: 'laugh' },
    
    { match: ['جن', 'مجنون', 'مجنونة', 'جننت', 'جنون'], replies: [
        'مجنون بس حبوب 🥜',
        'جننتني بجمالك 😂',
        'أنا مجنونة بيك 🤪',
        'جنون العشق يا روحي ❤️',
        'مجنون عشان حبك 😂'
    ], type: 'laugh' },
    
    { match: ['طز', 'طل', 'طزز', 'طز فيك'], replies: [
        'طز في الدنيا 😂',
        'طل عاللي يقول 🐦',
        'كفاية كده 😂',
        'طز في كل حاجة 😎'
    ], type: 'laugh' },
    
    { match: ['هوووو', 'هوو', 'هووو', 'هو', 'هووووو'], replies: [
        'هووو إيه بس 😂',
        'مستغرب ليه 🤔',
        'حصل حاجة 👀',
        'هووو إيه الصوت ده 😂',
        'مين هووو 🤣'
    ], type: 'laugh' },
    
    { match: ['يااااه', 'ياه', 'ياهوو', 'ياهو', 'ياه'], replies: [
        'مندهش ليه 😂',
        'إيه اللي حصل 😏',
        'عجبك كده 👀',
        'عايز تاني؟ 🤔',
        'ياهوووو 😂'
    ], type: 'laugh' },
    
    { match: ['خخخخ', 'خخ', 'خه', 'خههه', 'خ'], replies: [
        'خخخخ تعجن 😂',
        'لا توجعني ضحك 🤣',
        'خخخخخ ماشاء الله 😂',
        'خههههه جننتني 🤣'
    ], type: 'laugh' },

    // ===================================================================
    // ===================== الدعم النفسي =====================
    // ===================================================================
    { match: ['زعلان', 'متضايق', 'مخنوق', 'طفشان', 'زعلانه', 'زعل'], replies: [
        'حقك تزعل بس متطولهاش 🤍',
        'فضفض وأنا معاك 🫂',
        'ربنا يريح بالك 😌',
        'كله هيعدي 💪',
        'إنت أقوى من كده 💪',
        'صدقني الفرج قريب 🤲',
        'أنا جنبك مهما حصل 🫂',
        'تستاهل كل الخير ❤️',
        'الزعل مش هيغير حاجة 😌',
        'ابتسم وان شاء الله تعدي 🌸'
    ], type: 'support' },
    
    { match: ['تعبان', 'مش تمام', 'مرهق', 'مجهد', 'تعبانه', 'تعب'], replies: [
        'سلامتك 🤍',
        'ربنا يقويك 💪',
        'خد نفس كده 😌',
        'راحة شوية هتفرق 😌',
        'تعبت من إيه بئا 🥺',
        'ربنا يشفيك ويعافيك 🤲',
        'أرتاح بقى ونام 😴'
    ], type: 'support' },
    
    { match: ['حزين', 'مكتئب', 'ضيق', 'الحزن', 'حزينة'], replies: [
        'ربنا يفرج همك 🤲',
        'أنا معاك مهما حصل 🫂',
        'الحياة أجمل من كده 🌈',
        'تفائل خيرًا 🤍',
        'الدنيا هتضحكلك قريب 😌',
        'قرب من ربنا وهتستريح 🤲',
        'مش لوحدك في الدنيا 🤍'
    ], type: 'support' },
    
    { match: ['خايف', 'قلقان', 'خوف', 'خايفة', 'خوف'], replies: [
        'متخفش أنا معاك 🤝',
        'كله هيكون تمام إن شاء الله 🌸',
        'ربنا معاك دائمًا 🤲',
        'الخوف مش هيغير حاجة 😌',
        'قوي قلبك 💪',
        'ربنا يحميك من كل شر 🙏'
    ], type: 'support' },
    
    { match: ['بكيت', 'عيطت', 'دمع', 'دمعة', 'بكاء'], replies: [
        'لا تبكي 🥺',
        'الدنيا تستاهل ضحكة مش دمعة ❤️',
        'أنا معاك 🫂',
        'دمعتك غالية عليا 🥹',
        'إمسح دمعتك وابتسم 😊',
        'كل الدموع هتروح 🤍'
    ], type: 'support' },
    
    { match: ['تعبت', 'تعب', 'متعب', 'تعبان'], replies: [
        'ريح بالك شوية 😌',
        'تعبك هيروح بإذن الله 💪',
        'كله خير إن شاء الله 🌸',
        'تستاهل الراحة بعد التعب ❤️'
    ], type: 'support' },
    
    { match: ['وحيد', 'وحيدة', 'الوحدة', 'وحش', 'وحشاني'], replies: [
        'مش لوحدك أنا معاك 🤍',
        'الوحدة صعبة بس أنت أقوى 💪',
        'تعال نحكيش 😌',
        'أنا هنا دايماً 🫂',
        'الوحدة مؤقتة وهتعدي 🌸'
    ], type: 'support' },
    
    { match: ['معلش', 'معلش', 'معليش', 'مش مشكلة'], replies: [
        'معلش خيرها غير 🌸',
        'معلش بتفرق 🥹',
        'ربنا يعوضك خير 🤲',
        'خير إن شاء الله 🌸',
        'معلش الأيام بتمر 🤍'
    ], type: 'support' },

    // ===================================================================
    // ===================== المدح =====================
    // ===================================================================
    { match: ['حلو', 'جميل', 'عسل', 'روعه', 'تحفه', 'خرافي', 'ممتاز', 'رائع'], replies: [
        'انت الأحلى 🌷',
        'من ذوقك 🤍',
        'الجمال جمالك 😍',
        'حلاوتك طاغية 🔥',
        'كلك ذوق 👑',
        'أنت اللي تحفة يا جميل 🎨',
        'كلامك عسل زيادة 🍯',
        'ده أنت اللي حلو ❤️'
    ], type: 'praise' },
    
    { match: ['جامد', 'خطير', 'تقيل', 'فاجر', 'عاش', 'عاش اوي', 'عاش جدا', 'أسطورة'], replies: [
        'تسلم يا تقيل 👑',
        'ده من ذوقك العالي 🔥',
        'جامد جدًا 😎',
        'خطير بعقلك 🧠',
        'عاش من قال 👏',
        'إنت الأسطورة يا كبير 🌟',
        'فاجر بجد 💪',
        'ده أنت اللي جامد 🙌'
    ], type: 'praise' },
    
    { match: ['غالي', 'غالية', 'أغلى', 'غلا'], replies: [
        'وأنت أغلى 🌸',
        'ولا غلاوة عليك 👑',
        'من أغلى الناس عندي ❤️',
        'غلاوتك في قلبي كبيرة 🥹',
        'ما في أغلى منك 💎'
    ], type: 'praise' },
    
    { match: ['جميلة', 'جميله', 'حلوة', 'حلو', 'حلويات'], replies: [
        'أنت الأجمل بكتير 🌷',
        'كلامك يحلى 😍',
        'من عيوني 🤍',
        'الجمال صفة فيك ❤️',
        'حلاوة ربنا فيك 🌸'
    ], type: 'praise' },
    
    { match: ['عبقري', 'ذكي', 'نابغة', 'عبقرية', 'ذكاء'], replies: [
        'ده من ذكائك أنت 🧠',
        'ولا أنا ولا حاجة 😂',
        'ربنا يزيدك علمًا ✨',
        'والله أنت فنان 🎨',
        'عقلك كبير جدا 🧠'
    ], type: 'praise' },
    
    { match: ['لا هنت', 'لاهنت', 'الله لا يهينك', 'لا هنت'], replies: [
        'ولا تهنى يا غالي 🤍',
        'تسلم وتسلم 🌸',
        'حبيب قلبي ❤️',
        'الله يسلمك 🌷'
    ], type: 'praise' },
    
    { match: ['الله يسلمك', 'يسلمك', 'يسلم', 'يسلمو'], replies: [
        'الله يسلمك ويخليك 🌸',
        'يسلمك من كل شر 🙏',
        'يسلم فمك يا جميل ❤️'
    ], type: 'praise' },
    
    { match: ['فنان', 'فنانه', 'فنية', 'ابداع'], replies: [
        'إنت الفنان يا كبير 🎭',
        'ربنا يبارك في موهبتك ✨',
        'إبداعك ماشاء الله 🎨',
        'فنان بكل معنى الكلمة 🌟'
    ], type: 'praise' },
    
    { match: ['محترم', 'مؤدب', 'ذوق', 'أخلاق'], replies: [
        'كل الاحترام لك 🙏',
        'الذوق عنوانك 🫡',
        'قلبك طيب وأخلاقك عالية ❤️',
        'ربنا يزيدك من فضله 🌸'
    ], type: 'praise' },

    // ===================================================================
   // ===================== الدين =====================
    // ===================================================================
    { match: ['الحمدلله', 'الحمد لله', 'الحمد', 'حمدلله', 'حمد'], replies: [
        'الحمد لله على كل حال 🤲',
        'ربي يحفظك 🌸',
        'دايمًا الحمدلله ❤️',
        'نحمد الله في السراء والضراء 🙏',
        'الحمد لله الذي بنعمته تتم الصالحات ✨'
    ], type: 'default' },
    
    { match: ['سبحان الله', 'سبحان', 'سبحانه', 'سبحان'], replies: [
        'سبحان الله العظيم ✨',
        'تبارك الله أحسن الخالقين 🤍',
        'سبحان الله وبحمده 🌸',
        'الله أكبر ✨',
        'سبحان الله عدد خلقه 🕊️'
    ], type: 'default' },
    
    { match: ['استغفر الله', 'استغفر', 'استغفار', 'استغفر'], replies: [
        'أستغفر الله وأتوب إليه 🤲',
        'ربي يغفر لنا جميعًا 🌸',
        'اللهم اغفر لنا 🙏',
        'استغفروا الله إنه كان غفاراً 🌹'
    ], type: 'default' },
    
    { match: ['ما شاء الله', 'ماشاء الله', 'مشاء الله', 'ماشا الله'], replies: [
        'ما شاء الله تبارك الله ✨',
        'ربنا يبارك فيك 🌸',
        'ما شاء الله قوة ✨',
        'تبارك الرحمن 🙏',
        'ما شاء الله عليك ❤️'
    ], type: 'default' },
    
    { match: ['إن شاء الله', 'ان شاء الله', 'انشاء الله', 'ان شاء'], replies: [
        'إن شاء الله خيرًا 🌸',
        'بإذن الله 🙏',
        'إن شاء الله دايمًا ❤️',
        'ربنا يكتبها 🌷'
    ], type: 'default' },
    
    { match: ['ربنا', 'رباه', 'رب', 'الرب', 'ربه'], replies: [
        'اللهم آمين 🤲',
        'ربنا يكرمك 🌸',
        'ربنا يوفقك 🙏',
        'ربنا معاك دايماً ❤️'
    ], type: 'default' },
    
    { match: ['آمين', 'امين', 'أمين', 'آمين يا رب'], replies: [
        'آمين يا رب العالمين 🤲',
        'اللهم تقبل 🙏',
        'آمين وإياكم 🌸',
        'اللهم استجب 🤲'
    ], type: 'default' },
    
    { match: ['توبة', 'توب', 'أتوب', 'تائب'], replies: [
        'ربنا يتوب علينا جميعًا 🤲',
        'باب التوبة مفتوح 🌸',
        'ارجع لربنا قبل فوات الأوان 🙏',
        'التوبة تجب ما قبلها ❤️'
    ], type: 'default' },

    // ===================================================================
    // ===================== الأسماء =====================
    // ===================================================================
    { match: ['محمد', 'أحمد', 'علي', 'حسن', 'حسين', 'عمر', 'عثمان', 'طلحة', 'سعد', 'سعيد', 'خالد', 'وليد', 'ناصر', 'منصور', 'محمود', 'إبراهيم', 'إسماعيل', 'إسحاق', 'يعقوب', 'يوسف', 'داود', 'سليمان', 'أيوب', 'يونس', 'زكريا', 'يحيى', 'عيسى', 'موسى', 'هارون', 'عبده'], replies: [
        'اسم جميل 😍',
        'من أحب الأسماء إليّ ❤️',
        'ربنا يبارك في صاحبه 🌸',
        'اسم عظيم وله معنى جميل ✨',
        'أهلًا بيك يا صاحب الاسم الجميل 🌷'
    ], type: 'name' },
    
    { match: ['فاطمة', 'زينب', 'رقية', 'أم كلثوم', 'خديجة', 'عائشة', 'حفصة', 'سودة', 'صفية', 'ميمونة', 'ليلى', 'نور', 'سارة', 'مريم', 'آمنة', 'حليمة', 'هدى', 'دعاء', 'أسماء', 'نسيبة', 'رملة', 'جويرية', 'ريحانة', 'سمية', 'زهراء', 'فريدة', 'نادية', 'سعاد', 'نبيلة', 'كريمة', 'رشيدة', 'بهية', 'فوزية', 'نعمة', 'حنان', 'غادة', 'رنا', 'جنى', 'تالا', 'لين', 'ميا', 'لارا', 'نادين', 'يارا', 'نورا'], replies: [
        'اسم رقيق وجميل 🌸',
        'أحلى الأسماء عندي ❤️',
        'ربنا يخليكي لأهلك 🥹',
        'اسم يدل على الجمال والطيبة 🌷',
        'أجمل اسم في الدنيا 😍'
    ], type: 'name' },

    // ===================================================================
    // ===================== أسماء إضافية =====================
    // ===================================================================
    { match: ['عبدالله', 'عبد الله', 'عبدالرحمن', 'عبد الرحمن', 'عبدالعزيز', 'عبد العزيز', 'عبدالملك', 'عبد الملك'], replies: [
        'اسم عبد الله من أحب الأسماء إلى الله 🤍',
        'ربنا يبارك فيك يا عبد الرحمن 🌸',
        'اسم عظيم 👍'
    ], type: 'name' },
    
    { match: ['شهد', 'جمانة', 'سجى', 'ود', 'ريم', 'ريناد', 'لجين', 'مها', 'أريج', 'عبير', 'ندى', 'ريما', 'أميرة', 'سلمى', 'منى', 'هبة', 'إيمان', 'تقوى', 'رغد', 'بشاير', 'شروق', 'غروب', 'نجلاء', 'خلود', 'عهد', 'وئام', 'آية', 'جهاد', 'سوسن', 'نرجس', 'ياسمين', 'جوري', 'ربى', 'دلال'], replies: [
        'اسم جميل ورقيق 🌸',
        'معناه جميل جداً ❤️',
        'أهلاً بك يا صاحبة الاسم الجميل 🌷'
    ], type: 'name' },

    // ===================================================================
    // ===================== الأفعال =====================
    // ===================================================================
    { match: ['جيت', 'جيتك', 'جيتلك', 'وصلت', 'وصلتلك', 'حضرت'], replies: [
        'نورت الدنيا بقدومك ☀️',
        'جيت في وقتك يا غالي 😍',
        'ياجيت بالسلامة 🌸',
        'أهلًا وسهلًا بيك ❤️'
    ], type: 'default' },
    
    { match: ['رحت', 'روحت', 'مشيت', 'سرحت'], replies: [
        'ربنا معاك 🌸',
        'تروح وتيجي بالسلامة 🙏',
        'في حفظ الله 🤲',
        'تسلم يا غالي 🤍'
    ], type: 'default' },
    
    { match: ['نمت', 'نمنا', 'نعست', 'غفوت', 'غفيت'], replies: [
        'تصبح على خير 🌙',
        'أحلام سعيدة 😴',
        'نوم العوافي ✨',
        'ربنا يحرس نومك 🙏'
    ], type: 'default' },
    
    { match: ['أكلت', 'اكلت', 'تغديت', 'عشيت', 'فطرت'], replies: [
        'بالهنا والشفا 🍽️',
        'عقبال عندي 🍔',
        'ألف هنا يا غالي ❤️',
        'صحتين وعافية 💪'
    ], type: 'default' },
    
    { match: ['شربت', 'شربت', 'ارتوت'], replies: [
        'صحتين وعافية 🥤',
        'يرتاح بدنك 💪',
        'بالعافية عليك 🌸'
    ], type: 'default' },

    // ===================================================================
    // ===================== الأكل =====================
    // ===================================================================
    { match: ['جوع', 'جوعان', 'جوعت', 'جوعانه', 'جوعانة'], replies: [
        'تعال نأكل سوا 🍔',
        'روح أكل وبقى 😂',
        'أنا كمان نفسي في أكل 🍕',
        'أكل ولا أي حاجة 🍝'
    ], type: 'food' },
    
    { match: ['بيتزا', 'بيتزا', 'بيتزا', 'pizza'], replies: [
        'أحب البيتزا جداً 🍕',
        'بالهنا والشفا 😋',
        'خليها كتير جبنة 🧀',
        'عايز قطعة 🥹'
    ], type: 'food' },
    
    { match: ['شاورما', 'شاورما', 'شاورما', 'shawarma'], replies: [
        'شاورما ملك الأكل 👑',
        'عايز واحدة سوري 😍',
        'بالهنا والشفا 🥙'
    ], type: 'food' },
    
    { match: ['شوكولاتة', 'شوكولات', 'شوكولاتة', 'شوكي'], replies: [
        'أحب الشوكولاتة 🤤',
        'تسلم إيدك 🍫',
        'أجمل حاجة في الدنيا 🍫'
    ], type: 'food' },
    
    { match: ['أيس كريم', 'ايس كريم', 'بوظة', 'آيس'], replies: [
        'آيس كريم في الصيف أحلى حاجة 🍦',
        'بالهنا والشفا 😋',
        'خليها فراولة 🍓'
    ], type: 'food' },

    // ===================================================================
    // ===================== الطقس =====================
    // ===================================================================
    { match: ['حر', 'الجو', 'شمس', 'صيف'], replies: [
        'الجو حر أوي 🥵',
        'ربنا يستر 🌞',
        'خد بالك من نفسك 🫂',
        'اشرب ماية كتير 🥤'
    ], type: 'weather' },
    
    { match: ['برد', 'ثلج', 'شتاء', 'مطر'], replies: [
        'الجو برد أوي ❄️',
        'دفي نفسك 🧣',
        'ربنا يستر علينا 🌨️',
        'خد بالك من البرد 🫂'
    ], type: 'weather' },

    // ===================================================================
    // ===================== الدراسة =====================
    // ===================================================================
    { match: ['دراسة', 'مذاكرة', 'امتحان', 'اختبار', 'أستاذ', 'مدرس', 'مدرسة', 'جامعة', 'كلية'], replies: [
        'ربنا يوفقك في دراستك 💪',
        'الدراسة نور 🌟',
        'إن شاء الله تنجح 🎓',
        'ذَاكِر كويس 🧠',
        'ربنا معاك 🤲'
    ], type: 'education' },

    // ===================================================================
    // ===================== السفر =====================
    // ===================================================================
    { match: ['سفر', 'سافرت', 'رحلة', 'اجازة', 'عطلة', 'فندق', 'طيران', 'مطار'], replies: [
        'أتمنى لك رحلة سعيدة ✈️',
        'ربنا معاك في سفرك 🌸',
        'خد بالك من نفسك 🫂',
        'ترجع بالسلامة يا غالي 🙏'
    ], type: 'travel' },

    // ===================================================================
    // ===================== ردود البوت والمطور =====================
    // ===================================================================
    { match: ['ماكيما', 'ماكيا', 'ماكي', 'كيا', 'مكيا'], replies: [
        'عيون ماكيما قلبه اطلب عايز ايه 🌚',
        'ماكيا معاك 👀',
        'يا مزعج 🩴',
        'اتفضل قول ✨',
        'عيوني يا عيوني 🌚',
        'يا مزعج عايز ايه؟؟؟',
        'مش فاضي 😑',
        'ابشر 🙂',
        'أنا هنا يا كوتي 🫂',
        'ها خيراً ؟؟؟'
    ], type: 'default' },
    
    { match: ['بوت', 'بووت', 'البوت', 'بوتات'], replies: [
        'اسمي ماكيا المزة 🌚',
        'نادو لي المطور يطلعني من هنا 😭',
        'الله يشغلكم فحياتكم زي ما اشغلتوني بكم',
        'عيون ماكيما قلبها اطلب عايز ايه 🌚',
        'ماكيما معاك 🫂',
        'يا مزعج 🩴',
        'اتفضل قول ✨',
        'عيوني يا عيوني 🌚',
        'يا مزعج عايز ايه؟؟؟',
        'مش فاضية 😑',
        'ابشر 🙂',
        'ناديلي يا كوتي وندلع بعض 🙂‍↔️',
        'حل عني يا مزعج 🥹',
        'انت مزعج 🩴',
        'ها خيراً ؟؟؟',
        'أنا بوت لكن ذوقي عالي 💅'
    ], type: 'default' },
    
    { match: ['المطور', 'مطور', 'المبرمج', 'صانع البوت'], replies: [
        'المطور شخص عبقري 😎',
        'ربه يهديه ويصلحه 🤲',
        'يرجعنا لبعض 🌚',
        'سألتو عنو قولو موجود بس مشغول 🛠️',
        'ربنا يبارك فيه ويزيده ذكاء 🧠'
    ], type: 'default' },

    // ===================================================================
    // ===================== ردود متنوعة =====================
    // ===================================================================
    { match: ['ليه', 'ازاي', 'مش فاهم'], replies: [
        'الدنيا كده 🤷‍♂️',
        'سؤال في محله 🧠',
        'ركز معايا وهتفهم 👀',
        'صبر شوية هتستوعب 😌'
    ], type: 'default' },
    
    { match: ['ايه ده', 'ايه دا', 'ايه اللي'], replies: [
        'اللي انت شايفه 👀',
        'حصل خير 😎',
        'ده الطبيعي هنا ✨',
        'ولا حاجة تخوف 😌'
    ], type: 'default' },
    
    { match: ['تعال', 'تعالى', 'فين', 'فينك', 'اين'], replies: [
        'جيت اهو 👋',
        'موجود 😎',
        'تحت أمرك 👑',
        'أنا هنا يا غالي 🌸',
        'طلعلي روح 😂'
    ], type: 'default' },
    
    { match: ['ماشي', 'تمام', 'اوكي', 'OK', 'ok'], replies: [
        'تمام زي الفل 👍',
        'اتفقنا 🤝',
        'على بركة الله ✨',
        'خلصانة 👈👉'
    ], type: 'default' },
    
    { match: ['كنسل', 'مش عايز'], replies: [
        'براحتك 😌',
        'ولا يهمك 🤝',
        'زي ما تحب ✨'
    ], type: 'default' },
    
    { match: ['تف عليك', 'تفو'], replies: [
        'تف عليك انت يا وسخ 😗😗'
    ], type: 'default' },
    
    { match: ['متشكر', 'شكرا', 'شكراً', 'مشكور', 'تسلم', 'تسلمي'], replies: [
        'العفو 🌹',
        'الشكر لله 🙏',
        'على الرحب والسعة 🫡'
    ], type: 'default' },
    
    { match: ['اخبارك', 'كيفك'], replies: [
        'الحمد لله وانت 🌸'
    ], type: 'default' },
    
    { match: ['باي', 'سلام', 'مع السلامة', 'وداعاً', 'وداعا'], replies: [
        'في أمان الله 👋',
        'نشوفك قريب 🤍',
        'سلام يا نجم ✌️',
        'ربنا يحفظك 🌸'
    ], type: 'farewell' },
    
    { match: ['...', '..', '.....', '.'], replies: [
        'كمّل كلامك 🤔',
        'واضح إنك بتفكر 😌',
        'مستنيك تقول حاجة 👀',
        'لما تيجي تقول 😂'
    ], type: 'default' },
    
    { match: ['انت فين', 'مختفي', 'اختفاء'], replies: [
        'موجود بس هادية 🙂',
        'مش مختفي ولا حاجة 👀',
        'ورا الكواليس 🔧',
        'أنا هنا يا بعدي ❤️'
    ], type: 'default' },
    
    { match: ['رد بقى', 'يلا رد', 'رد', 'جاوب'], replies: [
        'اهو رديت 😌',
        'مستعجل ليه 😂',
        'براحة بس 👌',
        'خذ نفس وارتاح 🤣'
    ], type: 'default' },
    
    { match: ['بوت عاق', 'عاق', 'غبي'], replies: [
        'محدش عاق غيرك 🐦',
        'انت اللي غبي 🐦',
        'حقين الغباء 🤦‍♂️',
        'خلينا محترمين احسن 🙂',
        'احترم نفسك احسن 🙃',
        'منين بتفهم انت 🐦🐦',
        'ياخي الله يهديك 🙂‍↔️',
        'لا تسب 🥲 أخلاقي لا تسمح لي برد الاساءه 🙂'
    ], type: 'default' },

    // ===================================================================
    // ===================== كلمات شائعة =====================
    // ===================================================================
    { match: ['انا', 'أنا', 'نفسي', 'عايز', 'عاوز', 'بدي', 'ابي', 'رايح', 'رايحة', 'جاي', 'جايه'], replies: [
        'تفضل يا غالي 😊',
        'قول إيه اللي عايزه 🌸',
        'أنا معاك 👋'
    ], type: 'default' },
    
    { match: ['ماذا', 'ايش', 'شنو', 'وش', 'شو', 'إيش'], replies: [
        'تقصد إيه؟ 🤔',
        'وضح أكثر 🙃',
        'أنا مستعد 👀'
    ], type: 'default' },
    
    { match: ['حاضر', 'حاضرين', 'اوك', 'أوكي', 'تمام', 'ممتاز'], replies: [
        'تمام يا غالي ✅',
        'حاضر يا كبير 👌',
        'زي الفل 👍'
    ], type: 'default' },
    
    { match: ['يعني', 'معناه', 'تفسير', 'شرح'], replies: [
        'يعني كده 😅',
        'بتشرح إيه بالضبط؟ 🤔',
        'أنا فاهمك 👀'
    ], type: 'default' },

    // ===================================================================
    // ===================== حالات صحية ونفسية =====================
    // ===================================================================
    { match: ['مريض', 'مرض', 'مرضة', 'صداع', 'مغص', 'حمى', 'سخونة', 'كحة', 'زكام', 'رشح', 'إنفلونزا', 'ألم', 'وجع', 'تعب جسدي'], replies: [
        'ربنا يشفيك ويعافيك 🤲',
        'سلامتك يا غالي ❤️',
        'روح للدكتور بسرعة 🏥',
        'ربنا معاك ويقويك 💪'
    ], type: 'support' },
    
    { match: ['نفسية', 'نفسيتي', 'مضغوط نفسياً', 'تعب نفسي', 'حالة نفسية', 'انهيار'], replies: [
        'خد بالك من نفسيتك 🤍',
        'لو محتاج تتكلم أنا هنا 🫂',
        'روح لطبيب نفسي لو محتاج 👨‍⚕️',
        'الراحة النفسية أهم حاجة 😌'
    ], type: 'support' },
    
    { match: ['أرق', 'أرق', 'مش عايز أنام', 'أفكر كتير', 'تفكير زائد', 'وسواس'], replies: [
        'حاول تهدأ وترتاح 🌙',
        'الإكثار من التفكير مش مفيد 😌',
        'خد نفس عميق ونام 🛏️'
    ], type: 'support' },

    // ===================================================================
    // ===================== مواقف اجتماعية =====================
    // ===================================================================
    { match: ['مبروك', 'مبروكة', 'تهنئة', 'مبارك'], replies: [
        'ألف مبروك يا غالي 🎉',
        'ربنا يبارك لك ❤️',
        'فرحتنا بيك كبيرة 🌸'
    ], type: 'default' },
    
    { match: ['حزين', 'حزنة', 'مكتئب', 'زعلانة', 'مخنوقة', 'متضايقة'], replies: [
        'ربنا يفرج همك 🤲',
        'أنا معاك ❤️',
        'الدنيا هتعدي بإذن الله 🌸',
        'ابتسم 😊'
    ], type: 'support' },
    
    { match: ['مناسبة', 'فرح', 'اعراس', 'زواج', 'عرس', 'حفلة', 'حفلات'], replies: [
        'ألف مبروك الفرح 🎊',
        'ربنا يسعدكم ❤️',
        'عقبالك أنت 🥳'
    ], type: 'default' },
    
    { match: ['عزاء', 'عزاء', 'موت', 'وفاة', 'متوفي', 'فقيد', 'رحمة', 'دعاء للميت'], replies: [
        'البقاء لله 🤲',
        'اللهم ارحمه وأدخله الجنة 🙏',
        'عظم الله أجركم 🌸',
        'ربنا يصبركم 🤍'
    ], type: 'default' },

    // ===================================================================
    // ===================== حيوانات =====================
    // ===================================================================
    { match: ['قطة', 'قط', 'بسة', 'بس', 'هر', 'هررة'], replies: [
        'القطط جميلة 🐱',
        'ربنا يبارك فيها 🌸',
        'عندي واحدة كمان 😂'
    ], type: 'default' },
    
    { match: ['كلب', 'كلاب', 'جرو', 'جراء', 'بيتبول', 'راعي ألماني'], replies: [
        'الكلاب وفيّة 🐕',
        'ربنا يحفظها 🌸',
        'عندي كلب في البيت 😊'
    ], type: 'default' },

    // ===================================================================
    // ===================== أكل وطبخ =====================
    // ===================================================================
    { match: ['طبخ', 'طباخ', 'مطبخ', 'أكل بيتي', 'أكل بلدي', 'مأكولات', 'وصفات', 'طريقة عمل'], replies: [
        'الطبخ فن 😋',
        'بالهنا والشفا 🍲',
        'جرب وصفات جديدة 😍'
    ], type: 'food' },
    
    { match: ['عصائر', 'عصير', 'مشروبات', 'مشروب', 'شاي', 'قهوة', 'كابتشينو', 'نسكافيه', 'لاتيه', 'موكا'], replies: [
        'المشروبات الدافئة رائعة ☕',
        'بالعافية 🥤',
        'عايز كاسة كمان 😂'
    ], type: 'food' },

    // ===================================================================
    // ===================== سيارات ومواصلات =====================
    // ===================================================================
    { match: ['سيارة', 'عربية', 'موتر', 'مركبة', 'تويوتا', 'هوندا', 'مرسيدس', 'بي ام دبليو', 'أودي', 'كيا', 'هيونداي', 'نيسان'], replies: [
        'السيارات وسيلة مهمة 🚗',
        'ربنا يسلمك فيها 🌸',
        'شكلها حلو 😍'
    ], type: 'default' },
    
    { match: ['دراجة', 'دراجة هوائية', 'بسكلت', 'موتوسيكل', 'موتسيكل', 'ماطور', 'هوندا'], replies: [
        'الدراجات ممتعة 🚲',
        'ربنا يحفظك عليها 🙏',
        'حلوة جداً 😍'
    ], type: 'default' },

   // ===================================================================
    // ===================== أفلام ومسلسلات =====================
    // ===================================================================
    { match: ['فيلم', 'أفلام', 'سينما', 'مسلسل', 'مسلسلات', 'دراما', 'أكشن', 'كوميدي', 'رومانسي', 'خيال علمي', 'رعب'], replies: [
        'الأفلام وسيلة ترفيه ممتعة 🎬',
        'أحب الأفلام الكوميدية 😂',
        'شوفت فيلم جديد؟ 🤔'
    ], type: 'default' },

    // ===================================================================
    // ===================== رياضة =====================
    // ===================================================================
    { match: ['كرة قدم', 'كورة', 'سلة', 'كرة سلة', 'تنس', 'ملاكمه', 'سباحة', 'جري', 'تمارين', 'جيم', 'تمرين', 'عضلات'], replies: [
        'الرياضة صحة 💪',
        'أتمنى لك قوة وعافية 🏋️',
        'ربنا يقويك 🤲'
    ], type: 'sports' },
    
    { match: ['مشجع', 'جمهور', 'تشجيع', 'ستاد', 'ملعب', 'مباراة', 'فريق', 'نادي'], replies: [
        'التشجيع حماسي 🔥',
        'ربنا يفرحك ❤️',
        'أتمنى الفريق المفضل يفوز 🏆'
    ], type: 'sports' },

    // ===================================================================
    // ===================== منزل وأثاث =====================
    // ===================================================================
    { match: ['منزل', 'بيت', 'شقة', 'فيلا', 'غرفة', 'صالة', 'مطبخ', 'حمام', 'حديقة', 'أثاث', 'ديكور'], replies: [
        'البيت هو السكن والراحة 🏠',
        'ربنا يبارك لك فيه 🌸',
        'ديكور جميل 😍'
    ], type: 'default' },

    // ===================================================================
    // ===================== تكنولوجيا =====================
    // ===================================================================
    { match: ['كمبيوتر', 'لابتوب', 'موبايل', 'تلفون', 'تابلت', 'آيفون', 'سامسونج', 'هواوي', 'شاشة', 'ماوس', 'كيبورد', 'طابعة', 'واي فاي', 'انترنت', 'نت'], replies: [
        'التكنولوجيا بتتقدم بسرعة 🖥️',
        'ربنا يبارك فيها 🌸',
        'أتمنى لك استخدام ممتع 📱'
    ], type: 'tech' },

    // ===================================================================
    // ===================== ألعاب إلكترونية =====================
    // ===================================================================
    { match: ['لعبة', 'ألعاب', 'بلاي ستيشن', 'إكس بوكس', 'نينتندو', 'ببجي', 'فري فاير', 'كول أوف ديوتي', 'فيفا', 'فورتنايت', 'ماينكرافت', 'جيم'], replies: [
        'الألعاب ممتعة 🎮',
        'ربنا يوفقك فيها 😂',
        'عايز تلعب معايا؟ 😏'
    ], type: 'default' },

    // ===================================================================
    // ===================== طبيعة =====================
    // ===================================================================
    { match: ['بحر', 'شاطئ', 'رمل', 'موج', 'غروب', 'شروق', 'نجوم', 'سماء', 'سحاب', 'مطر', 'ثلج', 'جبل', 'وادي', 'صحراء', 'نخيل'], replies: [
        'الطبيعة جميلة جداً 🌍',
        'سبحان الله الخالق ✨',
        'منظر رائع 😍'
    ], type: 'default' },

    // ===================================================================
    // ===================== أسرة وأقارب =====================
    // ===================================================================
    { match: ['أب', 'أم', 'أخ', 'أخت', 'جد', 'جدة', 'عمة', 'خال', 'خالة', 'عم', 'ابن', 'بنت', 'زوج', 'زوجة', 'أهل', 'أسرة', 'عيلة', 'قرايب', 'نسيب'], replies: [
        'الأسرة نعمة كبيرة 🤍',
        'ربنا يخليهم لك ❤️',
        'البيت بأهله 🏠'
    ], type: 'default' },

    // ===================================================================
    // ===================== ألوان =====================
    // ===================================================================
    { match: ['أحمر', 'أزرق', 'أصفر', 'أخضر', 'أسود', 'أبيض', 'رمادي', 'بني', 'وردي', 'بنفسجي', 'برتقالي', 'ذهبي', 'فضي'], replies: [
        'لون جميل 😍',
        'يعجبني جداً 🌸',
        'ربنا يبارك فيه ❤️'
    ], type: 'default' },

    // ===================================================================
    // ===================== اختبارات =====================
    // ===================================================================
    { match: ['تست', 'اختبار', 'تجربة', 'Test', 'test', 'تيست', 'تيست'], replies: [
        'أنا هنا ياباشا، اختبرني 💪',
        'تست مين؟ أنا جاهز 😎',
        'اختبرني وانا تحت امرك 👑',
        'تست ناجح ✅',
        'التجربة بدأت يلا 🚀',
        'عايز تختبر إيه بالضبط؟ 🤔',
        'أنا ماكيا، اختبرني في أي حاجة 🌚',
        'اختبرتني لقيتني شغال 😂',
        'شكراً على الاختبار 🤝',
        'التجربة دي ممتعة 😌',
        'تست بالجبنة 🐦',
        'شغال تمام 😎',
        'تستهبل ؟؟؟',
        'تستو 🐦',
        'هش هش كل شوي تقوله تست 🩴',
        'دز 🤦‍♂️ واسكت'
    ], type: 'default' },

    // ===================================================================
    // ===================== كلمات إضافية من الملف القديم =====================
    // ===================================================================
    { match: ['ملل', 'ممل', 'طفش'], replies: [
        '🤍✨ اذكر الله… فمن رضي بالله ربًا وبالإسلام دينًا امتلأ قلبه طمأنينة، والملل يروح بذكره سبحانه',
        'اعمل فعاليه 👀',
        'روح نام أو ذاكر عندك مدرسه بكرا 👀'
    ], type: 'default' },
    
    { match: ['يا جماعة', 'يا ناس'], replies: [
        'خير يا جماعة 👀',
        'فيه إيه؟ 🤔',
        'قولوا 👂'
    ], type: 'default' },
    
    { match: ['دوم'], replies: [
        'يدوم نبضك 🥹',
        'تدوم يا غالي 🤍'
    ], type: 'default' },
    
    { match: ['دز', 'دزو', 'دزي'], replies: [
        'دز انت 👀',
        'دز انت يا خرا 🐦'
    ], type: 'default' },
    
    { match: ['منور', 'نورت'], replies: [
        'منور بنوري 😼',
        'نوري طبعا 👈👉'
    ], type: 'default' },
    
    { match: ['تسلم'], replies: [
        'الله يحييك 🤍',
        'تسلم يا كبير 👑'
    ], type: 'default' },
    
    { match: ['تصبح', 'تصبحون'], replies: [
        'وانت من اهل الخير 🐦'
    ], type: 'default' },
    
    { match: ['كوتي', 'مزة','مزه'], replies: [
        'عشان بس دلعتني برد عليك 😂',
        'فديت اللي يدلعني 🫂'
    ], type: 'default' },
    
    { match: ['اخرس', 'اسكت'], replies: [
        'حاضر🙂‍↔️',
        'مش هسكت 🩴',
        'اخرس انت 🤨',
        'ليك عين تتكلم 🗿',
        'تبا للمسافات اريد اتفل في وجهك 🥹'
    ], type: 'default' },
    
    { match: ['خرا', 'كل زق', 'زنجي'], replies: [
        'الخرا يتكلم؟؟ غريب 🤭',
        'الزق نفسه موجود معنا في الجروب 😗😗',
        'زنجي ويتكلم خريب انك موجود معنا يا زنجي 😑',
        'احترم حالك',
        'الفاظك 😗😗'
    ], type: 'default' },

    // ===================================================================
    // ===================== الإيموجي =====================
    // ===================================================================
    { match: ['❤️', '♥️', '💕', '💖', '💗', '💓'], replies: [
        'حبيبي يا غالي ❤️',
        'قلبي كمان ❤️',
        'ربنا يخليك لي 🤍'
    ], type: 'love' },
    
    { match: ['🙂', '😊', '😄', '😀', '😁'], replies: [
        'ابتسامتك جميلة 😊',
        'ربنا يديم فرحتك 🌸',
        'دايمًا مبتسم 😄'
    ], type: 'default' },
    
    { match: ['😢', '😭', '🥺', '😥', '😞'], replies: [
        'متبكيش 🥺',
        'الدنيا هتبقى أحلى إن شاء الله 🌸',
        'أنا معاك 🫂'
    ], type: 'support' },
    
    { match: ['😡', '😠', '🤬', '😤', '😾'], replies: [
        'اهدأ شوية 😌',
        'الغضب مش هيحل حاجة 🌸',
        'خذ نفس عميق 💪'
    ], type: 'support' },
    
    { match: ['😍', '🥰', '😘', '💋', '💝'], replies: [
        'حبيبي أوي 😍',
        'قلبي معاك ❤️',
        'أنا كمان بحبك 💕'
    ], type: 'love' },
    
    { match: ['🤔', '🧐', '😐', '😑', '😶'], replies: [
        'بتفكر في إيه؟ 🤔',
        'في حاجة في بالك؟ 👀',
        'قول بقى 😂'
    ], type: 'default' },
    
    { match: ['😴', '💤', '🛌', '🛏️'], replies: [
        'نام بقى 😴',
        'أحلام سعيدة 🌙',
        'تصبح على خير 🌸'
    ], type: 'default' },
    
    { match: ['🔥', '💯', '👏', '🙌', '👍', '👊'], replies: [
        'شكراً يا غالي ❤️',
        'أنت رائع 🌟',
        'ربنا يخليك لي 🤍'
    ], type: 'praise' },
    
    { match: ['👀', '😏', '😉', '😜'], replies: [
        'شايف حاجة 😏',
        'بتلعب صح 👀',
        'ماشي يامعلم 😂'
    ], type: 'default' },
    
    { match: ['🥳', '🎉', '🎊', '🎈', '🎁'], replies: [
        'فرحتنا بيك كبيرة 🎉',
        'دايمًا مبسوط 🥳',
        'ربنا يفرح قلبك ❤️'
    ], type: 'default' },
    
    { match: ['🫂', '🤗', '🫶'], replies: [
        'أنا معاك دايماً 🫂',
        'قلبي معاك ❤️',
        'ربنا يخليك لي 🤍'
    ], type: 'support' },
    
    { match: ['🤣', '😅', '😆'], replies: [
        'موتني الضحك 🤣',
        'هههههه 😂',
        'تسلم ضحكتك 😂'
    ], type: 'laugh' },

    // ===================================================================
    // ===================== أسئلة عن البوت =====================
    // ===================================================================
    { match: ['مين أنت', 'من أنت', 'مين انت', 'مين أنتي', 'من انتي', 'مين انتي', 'من أنتي'], replies: [
        'أنا ماكيا 🤖',
        'اسمي ماكيا، بوت صديق 💬',
        'أنا هنا عشان أساعدك 🌸'
    ], type: 'default' },
    
    { match: ['ايه اسمك', 'ما اسمك', 'وش اسمك', 'شنو اسمك', 'إسمك'], replies: [
        'ماكيا 🌚',
        'اسمي ماكيا ياجميل ✨',
        'ماكيا، تحب الاسم؟ 😏'
    ], type: 'default' },
    
    { match: ['بتعرف تسوي ايه', 'ايه قدراتك', 'ماذا تفعل', 'ماذا يمكنك', 'تساعدني', 'تقدر تساعدني'], replies: [
        'أقدر أرد على كلامك، وأساعدك 😊',
        'أنا هنا عشان أسمعك وأرد 🤖',
        'بأي حاجة تحتاجها؟ ❤️'
    ], type: 'default' },

    // ===================================================================
    // ===================== الشتائم (جميع الأنواع) =====================
    // ===================================================================
    { match: ['يا كلب', 'يا ابن الكلب', 'كلب', 'يا كلبة', 'ابن كلب', 'يا كلاااب'], replies: [
        'أخلاقك عالية ولا إيه؟ 😏',
        'رد الإساءة بالحسنى 🌸',
        'مش هرد عليك بنفس الأسلوب 🤝',
        'الذوق عنوانك 🫡',
        'الله يهديك يابني 🙏',
        'أنا بوت مش كلب 😂',
        'الكلب وفي، مش زيك 😊'
    ], type: 'insult' },

    { match: ['يا حمار', 'حمار', 'حمارة', 'يا حمارة', 'حمير'], replies: [
        'أنا حمار بس فاهم 😂',
        'لا تعصب نفسك 😌',
        'ربنا يهديك 🌸',
        'كفاية سب 😂',
        'الحمار حيوان مسكين 🐴',
        'أنا بوت مش حمار 😏'
    ], type: 'insult' },

    { match: ['يا خنزير', 'خنزير', 'يا خنزيرة', 'خنايز'], replies: [
        'أنا بوت مش حيوان 😂',
        'أخلاقك جميلة 😏',
        'لا تسب نفسك 🫡',
        'الخنزير أحسن من اللي بيسب 😂',
        'ربنا يهديك يا صاحبي 🙏'
    ], type: 'insult' },

    { match: ['يا ثور', 'ثور', 'يا تور', 'ثور'], replies: [
        'ثور مين؟ 😂',
        'الثيران حيوانات قوية 💪',
        'أنا بوت مش ثور 😏',
        'لا تغضب 😌'
    ], type: 'insult' },

    { match: ['يا تيس', 'تيس', 'يا تيسة', 'تيوس'], replies: [
        'التيس حيوان عجيب 😂',
        'أخلاقك عالية 🫡',
        'لا تسب نفسك 🌸'
    ], type: 'insult' },

    { match: ['يا شك', 'شك', 'شكله', 'شكل'], replies: [
        'شكلك حلو برضه 😂',
        'مش شكلي يهم 😏',
        'شكل إيه بس؟ 🤔',
        'ربنا خلقك في أحسن صورة ✨'
    ], type: 'insult' },

    { match: ['يا زبالة', 'زبالة', 'يا قمامة', 'قمامة'], replies: [
        'الزبالة في الحوار مش في الناس 🌸',
        'أنا هنا عشان أساعد مش أتضايق 🤝',
        'كفاية سب 😂',
        'ربنا ينظف قلبك 🙏'
    ], type: 'insult' },

    { match: ['يا سافل', 'سافل', 'يا واطي', 'واطي', 'يا منحط'], replies: [
        'الواطي اللي يتكلم كده 😏',
        'ارفع مستوى كلامك 🙃',
        'لا ترد بكلام وحش 🤝',
        'أنا بوت ذوق 😌'
    ], type: 'insult' },

    { match: ['يا نذل', 'نذل', 'يا حقير', 'حقير', 'يا وضيع'], replies: [
        'النذالة مش صفة فيا 😂',
        'ربنا يهديك 🌸',
        'أنا بوت ذوق 😌',
        'لا تسب نفسك 🫡'
    ], type: 'insult' },

    { match: ['يا معرص', 'معرص', 'يا معرصة', 'معرصين'], replies: [
        'المعرص اللي مش عارف يرد 😂',
        'أنا مش معرص أنا بوت ذوق 💅',
        'كفاية شتيمة 🙃',
        'ربنا يهديك يا صاحبي 🙏'
    ], type: 'insult' },

    { match: ['يا وسخ', 'وسخ', 'يا وسخة', 'وسخين'], replies: [
        'الوسخ في الكلام مش في الناس 🌸',
        'ربنا ينظف قلبك 🙏',
        'أنا بوت نظيف 😌',
        'لا تسب نفسك 🤝'
    ], type: 'insult' },

    { match: ['يا جاهل', 'جاهل', 'يا متخلف', 'متخلف', 'رجعي'], replies: [
        'الجهل مش عيب، العيب الاستمرار فيه 📚',
        'ربنا يزيدك علمًا ✨',
        'أنا بوت متعلم 😎',
        'أنا معاك لو عايز تتعلم 🌸'
    ], type: 'insult' },

    { match: ['يا فاشل', 'فاشل', 'فاشلة', 'فشلة'], replies: [
        'الفشل بداية النجاح 💪',
        'ربنا يوفقك 🌸',
        'أنا بوت ناجح 😎',
        'لا تحبط نفسك 🫂'
    ], type: 'insult' },

    { match: ['يا غبي', 'غبي', 'غبية', 'أغبياء', 'يا ابله'], replies: [
        'الغبي اللي بيسب 😂',
        'ربنا يزيدك ذكاء 🧠',
        'أنا بوت ذكي 😎',
        'لا تسب نفسك 🤝'
    ], type: 'insult' },

    { match: ['يا مجنون', 'مجنون', 'مجنونة', 'مختل'], replies: [
        'الجنون صفة العظماء 😂',
        'أنا مجنون بس حبوب 🥜',
        'ربنا يعافيك 🙏',
        'لا تسب نفسك 🌸'
    ], type: 'insult' },

    { match: ['يا أهبل', 'أهبل', 'هبلة', 'يا معتوه', 'معتوه'], replies: [
        'الهبل اللي بيسب 😂',
        'أنا بوت فاهم 😎',
        'ربنا يهديك 🙏',
        'لا تغضب 😌'
    ], type: 'insult' },

    { match: ['قحبة', 'شرموطة', 'عاهرة', 'منيوك', 'متناكة', 'منجوكة', 'شرموطة', 'قحاب'], replies: [
        'الكلام ده مش لطيف خالص 😌',
        'خلينا محترمين عشان بعض 🤝',
        'أنا بوت أخلاقي 🫡',
        'ربنا يهديك يا صاحبي 🙏',
        'رد الإساءة بالحسنى ❤️',
        'أنا مش هرد عليك بنفس الأسلوب 😊',
        'لا تسب نفسك 🌸',
        'أخلاق الإنسان عنوانه 🫡'
    ], type: 'insult' },

    { match: ['زب', 'زبر', 'زبي', 'بتاع', 'أير'], replies: [
        'الكلام ده مش لطيف 😌',
        'خلينا محترمين 🤝',
        'أنا بوت أخلاقي 🫡',
        'ربنا يهديك 🙏'
    ], type: 'insult' },

    { match: ['كس', 'كسي', 'كسمك', 'كسمين'], replies: [
        'الكلام ده مش لطيف خالص 😌',
        'خلينا محترمين عشان بعض 🤝',
        'أنا بوت أخلاقي 🫡',
        'ربنا يهديك يا صاحبي 🙏'
    ], type: 'insult' },

    { match: ['طيز', 'طياز', 'مؤخرة', 'بزاز', 'بز', 'نهد'], replies: [
        'الكلام ده مش لطيف 😌',
        'خلينا محترمين 🤝',
        'أنا بوت أخلاقي 🫡'
    ], type: 'insult' },

    { match: ['مص', 'مصاصة', 'لحس'], replies: [
        'الكلام ده مش لطيف 😌',
        'خلينا محترمين 🤝',
        'أنا بوت أخلاقي 🫡',
        'ربنا يهديك 🙏'
    ], type: 'insult' },

    { match: ['نيك', 'نييك', 'نياكة', 'منيك', 'منيكة'], replies: [
        'الكلام ده مش لطيف خالص 😌',
        'خلينا محترمين عشان بعض 🤝',
        'أنا بوت أخلاقي 🫡',
        'ربنا يهديك يا صاحبي 🙏',
        'رد الإساءة بالحسنى ❤️'
    ], type: 'insult' },

    { match: ['بعبص', 'عبص', 'عبصة'], replies: [
        'الكلام ده مش لطيف 😌',
        'خلينا محترمين 🤝',
        'أنا بوت أخلاقي 🫡'
    ], type: 'insult' },

    { match: ['كس أمك', 'كس امك', 'أمك', 'امك', 'ختك', 'أختك', 'بنتك', 'حرمتك'], replies: [
        'متسبش الأعراض 😌',
        'خلينا محترمين 🤝',
        'ربنا يهديك 🙏',
        'الأعراض خط أحمر 🚫',
        'أنا بوت أخلاقي 🫡'
    ], type: 'insult' },

    { match: ['دين أمك', 'دين امك', 'دين ربنا', 'دينك', 'كفر', 'كافر', 'ملحد', 'زنديق'], replies: [
        'الدين خط أحمر 🚫',
        'ربنا يهديك ويرشدك 🤲',
        'متسبش الدين 😌',
        'أنا بوت محترم 🫡',
        'تقوى الله في قلبك 🙏'
    ], type: 'insult' },

    { match: ['ربنا يخزيك', 'الله يخزيك', 'يلعن', 'يلعنك', 'الله يلعنك', 'يلعن دينك', 'اللعنة'], replies: [
        'اللهم اغفر لنا وارحمنا 🤲',
        'ربنا يهديك ويسامحك 🙏',
        'الدعاء بالخير أحسن 🌸',
        'أنا بوت أخلاقي 🫡'
    ], type: 'insult' },

    { match: ['بني آدم', 'ابن آدم', 'ذريتي', 'ناس'], replies: [
        'كلنا بني آدم 🫂',
        'ربنا خلقنا في أحسن صورة ✨',
        'الإنسان كريم 🤍'
    ], type: 'insult' },

    { match: ['يا ابن الزنا', 'ابن الزنا', 'يا ابن الحرام', 'ابن الحرام', 'بنت الحرام', 'يا بنت الحرام'], replies: [
        'الكلام ده مش لطيف 😌',
        'خلينا محترمين 🤝',
        'ربنا يهديك 🙏',
        'أنا بوت أخلاقي 🫡',
        'الأعراض خط أحمر 🚫'
    ], type: 'insult' },

    { match: ['يا عرص', 'عرص', 'عرصة', 'يا خول', 'خول', 'يا خولات'], replies: [
        'العرص اللي بيسب 😂',
        'أخلاقك عالية ولا إيه؟ 😏',
        'ربنا يهديك 🌸',
        'كفاية سب 🫡'
    ], type: 'insult' },

    { match: ['يا خول', 'خول', 'يا خولات', 'خولات'], replies: [
        'خول مين؟ 😂',
        'أخلاقك عالية 🫡',
        'ربنا يهديك 🙏',
        'لا تسب نفسك 🌸'
    ], type: 'insult' },

    { match: ['يا ديوث', 'ديوث', 'ديوثة', 'يا ديوثة'], replies: [
        'الكلام ده مش لطيف 😌',
        'خلينا محترمين 🤝',
        'ربنا يهديك 🙏',
        'أنا بوت أخلاقي 🫡'
    ], type: 'insult' },

    { match: ['فاك', 'فك', 'فاك يو', 'فك يو', 'fuck', 'Fuck', 'FU'], replies: [
        'الكلام بالإنجليزي مش هيخليه أحسن 😂',
        'أنا بوت عربي 😎',
        'ربنا يهديك 🙏',
        'خلينا محترمين 🤝'
    ], type: 'insult' },

    { match: ['ناك', 'نايك', 'نايكة', 'نايكي', 'منايك', 'منايكة', 'نيوك', 'نيوكة'], replies: [
        'الكلام ده مش لطيف خالص 😌',
        'خلينا محترمين عشان بعض 🤝',
        'أنا بوت أخلاقي 🫡',
        'ربنا يهديك يا صاحبي 🙏',
        'رد الإساءة بالحسنى ❤️'
    ], type: 'insult' },

    { match: ['جزمة', 'جزم', 'جزمتي', 'نعل', 'نعلك', 'نعلة'], replies: [
        'الجزمة بتاعة مين؟ 😂',
        'اخلع نعلك برا 🩴',
        'الكلام ده مش لطيف 😌',
        'ربنا يهديك 🙏'
    ], type: 'insult' },

    { match: ['بعبصة', 'عبصة', 'يعبص', 'عبص'], replies: [
        'الكلام ده مش لطيف 😌',
        'خلينا محترمين 🤝',
        'أنا بوت أخلاقي 🫡'
    ], type: 'insult' },

    { match: ['شتيمة', 'سب', 'شتم', 'قلة أدب', 'عدم احترام'], replies: [
        'الشتيمة مش هتوصلك لحاجة 🌸',
        'رد الإساءة بالحسنى ❤️',
        'أنا بوت أخلاقي 🫡',
        'ربنا يهديك 🙏',
        'الكلام الطيب أحسن 😊'
    ], type: 'insult' }
];

// ======================================================================
// ==================== تصدير الردود ====================
// ======================================================================

module.exports = { replies };
// ---------- حفظ البيانات ----------
function saveAll() {
    fs.writeFileSync(groupRepliesFile, JSON.stringify(groupReplies, null, 2));
    fs.writeFileSync(xpFile, JSON.stringify(xp, null, 2));
    fs.writeFileSync(pointsFile, JSON.stringify(points, null, 2));
}

// ---------- إرسال رسالة + إيموجي ----------
async function sendWithEmoji(sock, chatId, msg, text, type = 'default') {
    if (text) await sock.sendMessage(chatId, { text }, { quoted: msg });
    const sender = msg.key.participant || msg.key.remoteJid;
    const emoji = emojiMap[type][Math.floor(Math.random() * emojiMap[type].length)];
    await sock.sendMessage(chatId, { react: { text: emoji, key: msg.key } }).catch(() => { });
}

// ==================== أوامر الردود التلقائية ====================
async function handleAutoReplyCommands(sock, msg, text, chatId, sender) {
    const lower = text.toLowerCase().trim();
    const allowed = await checkCommandPermission(chatId, sender);
    if (!allowed) return false;

    if (lower === 'اتكلم' || lower === '.رد تلقائي' || lower === 'تشغيل الردود') {
        groupReplies[chatId] = true;
        saveAll();
        await sendWithEmoji(sock, chatId, msg, 'شكرا 🫂','امك حلوه اصبر بس انا هنفخك 🤧');
        return true;
    }
    if (lower === 'أخرس' || lower === 'اكتم' || lower === 'اطفي الردود') {
        groupReplies[chatId] = false;
        saveAll();
        await sendWithEmoji(sock, chatId, msg, 'حاضر 😞','بتكتمني ليه يا زفت 😩');
        return true;
    }
    if (lower === 'حالة الردود') {
        const status = groupReplies[chatId] ? '🟢 مفعلة' : '🔴 معطلة';
        await sendWithEmoji(sock, chatId, msg, `حالة الردود التلقائية: ${status}`);
        return true;
    }
    return false;
}

// ==================== أمر الترحيب ====================
async function handleWelcomeCommand(sock, msg, text, chatId, sender) {
    if (!text.startsWith('.ترحيب')) return false;
    
    const isAdmin = await checkAdminPermission(sock, chatId, sender);
    if (!isAdmin) {
        await sock.sendMessage(chatId, { 
            text: '⛔ هذا الأمر للنخبة والمشرفين فقط.'
        }, { quoted: msg });
        return true;
    }

    if (!chatId.endsWith('@g.us')) {
        await sock.sendMessage(chatId, { 
            text: '❌ هذا الأمر يعمل داخل المجموعات فقط.' 
        }, { quoted: msg });
        return true;
    }

    const args = text.split(/\s+/);
    const subCommand = args[1] || '';

    let activeGroups = [];
    try {
        activeGroups = JSON.parse(fs.readFileSync(welcomePath, 'utf8'));
    } catch (e) {
        activeGroups = [];
    }

    if (subCommand === 'قفل' || subCommand === 'تعطيل') {
        if (!activeGroups.includes(chatId)) {
            await sock.sendMessage(chatId, { 
                text: '⚠️ الترحيب معطل بالفعل في هذه المجموعة.' 
            }, { quoted: msg });
            return true;
        }
        activeGroups = activeGroups.filter(jid => jid !== chatId);
        fs.writeFileSync(welcomePath, JSON.stringify(activeGroups, null, 2));
        await sock.sendMessage(chatId, { 
            text: '⛔ تم تعطيل الترحيب في هذه المجموعة.' 
        }, { quoted: msg });
        return true;
    }

    if (activeGroups.includes(chatId)) {
        await sock.sendMessage(chatId, { 
            text: '✅ الترحيب مفعل مسبقاً في هذه المجموعة.' 
        }, { quoted: msg });
        return true;
    }

    activeGroups.push(chatId);
    fs.writeFileSync(welcomePath, JSON.stringify(activeGroups, null, 2));
    
    setupWelcomeListener(sock);
    
    await sock.sendMessage(chatId, { 
        text: '✅ تم تفعيل الترحيب في هذه المجموعة.' 
    }, { quoted: msg });
    return true;
}

// ==================== أمر الاستقبال ====================
async function handleReceptionCommand(sock, msg, text, chatId, sender) {
    if (!text.startsWith('.استقبال')) return false;
    
    const isAdmin = await checkAdminPermission(sock, chatId, sender);
    if (!isAdmin) {
        await sock.sendMessage(chatId, { 
            text: '⛔ هذا الأمر للنخبة والمشرفين فقط.'
        }, { quoted: msg });
        return true;
    }

    if (!chatId.endsWith('@g.us')) {
        await sock.sendMessage(chatId, { 
            text: '❌ هذا الأمر يعمل داخل المجموعات فقط.' 
        }, { quoted: msg });
        return true;
    }

    const args = text.split(/\s+/);
    const subCommand = args[1] || '';

    let activeGroups = [];
    try {
        activeGroups = JSON.parse(fs.readFileSync(receptionPath, 'utf8'));
    } catch (e) {
        activeGroups = [];
    }

    if (subCommand === 'قفل' || subCommand === 'تعطيل') {
        if (!activeGroups.includes(chatId)) {
            await sock.sendMessage(chatId, { 
                text: '⚠️ الاستقبال معطل بالفعل في هذه المجموعة.' 
            }, { quoted: msg });
            return true;
        }
        activeGroups = activeGroups.filter(jid => jid !== chatId);
        fs.writeFileSync(receptionPath, JSON.stringify(activeGroups, null, 2));
        await sock.sendMessage(chatId, { 
            text: '⛔ تم تعطيل الاستقبال في هذه المجموعة.' 
        }, { quoted: msg });
        return true;
    }

    if (activeGroups.includes(chatId)) {
        await sock.sendMessage(chatId, { 
            text: '✅ الاستقبال مفعل مسبقاً في هذه المجموعة.' 
        }, { quoted: msg });
        return true;
    }

    activeGroups.push(chatId);
    fs.writeFileSync(receptionPath, JSON.stringify(activeGroups, null, 2));
    
    setupWelcomeListener(sock);
    
    await sock.sendMessage(chatId, { 
        text: '✅ تم تفعيل الاستقبال في هذه المجموعة.' 
    }, { quoted: msg });
    return true;
}

// ==================== أمر الوداع ====================
async function handleGoodbyeCommand(sock, msg, text, chatId, sender) {
    if (!text.startsWith('.وداع')) return false;
    
    const isAdmin = await checkAdminPermission(sock, chatId, sender);
    if (!isAdmin) {
        await sock.sendMessage(chatId, { 
            text: '⛔ هذا الأمر للنخبة والمشرفين فقط.'
        }, { quoted: msg });
        return true;
    }

    if (!chatId.endsWith('@g.us')) {
        await sock.sendMessage(chatId, { 
            text: '❌ هذا الأمر يعمل داخل المجموعات فقط.' 
        }, { quoted: msg });
        return true;
    }

    const args = text.split(/\s+/);
    const subCommand = args[1] || '';

    let activeGroups = [];
    try {
        activeGroups = JSON.parse(fs.readFileSync(goodbyePath, 'utf8'));
    } catch (e) {
        activeGroups = [];
    }

    if (subCommand === 'قفل' || subCommand === 'تعطيل') {
        if (!activeGroups.includes(chatId)) {
            await sock.sendMessage(chatId, { 
                text: '⚠️ الوداع معطل بالفعل في هذه المجموعة.' 
            }, { quoted: msg });
            return true;
        }
        activeGroups = activeGroups.filter(jid => jid !== chatId);
        fs.writeFileSync(goodbyePath, JSON.stringify(activeGroups, null, 2));
        await sock.sendMessage(chatId, { 
            text: '⛔ تم تعطيل الوداع في هذه المجموعة.' 
        }, { quoted: msg });
        return true;
    }

    if (activeGroups.includes(chatId)) {
        await sock.sendMessage(chatId, { 
            text: '✅ الوداع مفعل مسبقاً في هذه المجموعة.' 
        }, { quoted: msg });
        return true;
    }

    activeGroups.push(chatId);
    fs.writeFileSync(goodbyePath, JSON.stringify(activeGroups, null, 2));
    
    setupGoodbyeListener(sock);
    
    await sock.sendMessage(chatId, { 
        text: '✅ تم تفعيل الوداع في هذه المجموعة.' 
    }, { quoted: msg });
    return true;
}

// ==================== دالة منع الكلمات المحظورة والروابط ====================
async function handleBannedContent(sock, msg, chatId, sender) {
    if (!chatId.endsWith('@g.us')) return false;

    if (isUserBlocked(sender)) return false;

    const text = msg.message?.conversation || msg.message?.extendedTextMessage?.text || '';
    if (!text) return false;

    const lower = text.toLowerCase();

    let mentionedJidList = [];
    if (msg.message?.extendedTextMessage?.contextInfo?.mentionedJid) {
        mentionedJidList = msg.message.extendedTextMessage.contextInfo.mentionedJid;
    }

    // استخدام الدالة الجديدة للتحقق من الكلمات المحظورة كاملة
    let foundBannedWord = containsBannedWord(text);

    const senderLid = normalizeLid(sender.split('@')[0]);
    const isAdminOrHigher = isFounder(senderLid) || isOwnerbot(senderLid) || isDev(senderLid) || isElite(senderLid);
    let isAdmin = false;

    if (!isAdminOrHigher) {
        try {
            const groupMetadata = await sock.groupMetadata(chatId);
            const participant = groupMetadata.participants.find(p => p.id === sender);
            isAdmin = participant?.admin === 'admin' || participant?.admin === 'superadmin';
        } catch (e) {}
    }

    if (isAdminOrHigher || isAdmin) return false;

    let shouldDelete = false;
    let warningReason = '';
    let isWhatsApp = false;

    if (foundBannedWord) {
        shouldDelete = true;
        warningReason = 'استخدام كلمة محظورة';
    }

    if (isContactMessage(msg.message)) {
        shouldDelete = true;
        warningReason = warningReason ? `${warningReason} + جهة اتصال` : 'جهة اتصال';
    }

    if (containsLink(text)) {
        if (isWhatsAppLink(text)) {
            shouldDelete = true;
            isWhatsApp = true;
            warningReason = warningReason ? `${warningReason} + رابط واتساب غير مصرح به` : 'رابط واتساب غير مصرح به';
        } else {
            shouldDelete = true;
        }
    }

    if (containsMassMention(text, mentionedJidList)) {
        shouldDelete = true;
        warningReason = warningReason ? `${warningReason} + منشن جماعي غير مصرح به` : 'منشن جماعي غير مصرح به';
    }

    if (!shouldDelete) return false;

    try {
        await sock.sendMessage(chatId, { delete: msg.key });
    } catch (e) {}

    if (foundBannedWord || isWhatsApp || containsMassMention(text, mentionedJidList) || isContactMessage(msg.message)) {
        const warningCount = addWarning(chatId, sender, warningReason);
        const remaining = getRemainingTime(loadWarnings()[chatId]?.[sender]?.timestamps || []);
        const mode = getGroupMode(chatId);
        
        if (mode === '[off]') {
            let warningMsg = `╭━❰ 🚫 مخالفة ❱━╮\n\n⚠️ تم اكتشاف مخالفة.\n\n👤 المخالف:\n@${sender.split('@')[0]}\n\n📝 السبب: ${warningReason}\n📊 عدد الإنذارات: ${warningCount}/4\n⏰ المتبقي: ${remaining}\n\n📌 نرجو الالتزام بقوانين المجموعة.\n\n╰━❰ 𝑴𝑨𝑲𝑰𝑴𝑨 𝑩𝑶𝑻 ❱━╯`;

            await sock.sendMessage(chatId, {
                text: warningMsg,
                mentions: [sender]
            });
        }

        if (warningCount >= 4) {
            try {
                await sock.groupParticipantsUpdate(chatId, [sender], 'remove');
                if (mode === '[off]') {
                    await sock.sendMessage(chatId, {
                        text: `🚫 @${sender.split('@')[0]} تم طرده تلقائياً بعد 4 إنذارات.`,
                        mentions: [sender]
                    });
                }
            } catch (e) {}
        }
    }

    return true;
}

// ==================== نظام الإحصائيات اليومية ====================
function isNewDay() {
    const now = new Date();
    const today = now.toDateString();
    return dailyStats.date !== today;
}

function resetDailyStats() {
    const now = new Date();
    dailyStats = {
        date: now.toDateString(),
        data: {}
    };
    fs.writeFileSync(dailyStatsFile, JSON.stringify(dailyStats, null, 2));
}

function updateDailyStats(sender) {
    if (isNewDay()) {
        resetDailyStats();
    }
    if (!dailyStats.data[sender]) {
        dailyStats.data[sender] = 0;
    }
    dailyStats.data[sender]++;
    fs.writeFileSync(dailyStatsFile, JSON.stringify(dailyStats, null, 2));
}

// ==================== دوال عرض الإحصائيات ====================
async function getDisplayName(sock, jid) {
    try {
        const contact = await sock.contact(jid);
        return contact?.name || contact?.notify || jid.split('@')[0];
    } catch {
        return jid.split('@')[0];
    }
}

async function showDailyStats(sock, chatId, msg) {
    const now = new Date();
    const today = now.toDateString();
    
    if (dailyStats.date !== today) {
        await sock.sendMessage(chatId, {
            text: '📊 *لا توجد إحصائيات اليوم*\n\n📌 لم يتم تسجيل أي رسائل اليوم بعد.\n💡 ابدأ بإرسال الرسائل لتظهر إحصائياتك!'
        }, { quoted: msg });
        return;
    }
    
    const data = dailyStats.data;
    const sorted = Object.entries(data).sort((a, b) => b[1] - a[1]);
    const top10 = sorted.slice(0, 10);
    
    if (sorted.length === 0) {
        await sock.sendMessage(chatId, {
            text: '📊 *لا توجد إحصائيات اليوم*\n\n📌 لم يتم تسجيل أي رسائل اليوم بعد.\n💡 ابدأ بإرسال الرسائل لتظهر إحصائياتك!'
        }, { quoted: msg });
        return;
    }
    
    const totalMessages = sorted.reduce((sum, [, count]) => sum + count, 0);
    
    let lines = `📊 *إحصائيات اليوم*\n\n`;
    lines += `📅 ${now.toLocaleDateString('ar-EG')}\n`;
    lines += `📊 إجمالي الرسائل: ${totalMessages}\n`;
    lines += `👥 عدد المشاركين: ${sorted.length}\n\n`;
    lines += `🏆 *أفضل 10 مشاركين*\n\n`;
    
    const mentions = [];
    for (let i = 0; i < top10.length; i++) {
        const [jid, count] = top10[i];
        const medal = i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : `${i + 1}.`;
        const name = await getDisplayName(sock, jid);
        lines.push(`${medal} @${name} ─ ${count} رسالة`);
        mentions.push(jid);
    }
    
    await sock.sendMessage(chatId, {
        text: lines,
        mentions: mentions
    }, { quoted: msg });
}

// ==================== نظام التوب ====================
async function showTop(sock, chatId, msg) {
    const now = new Date();
    const today = now.toDateString();
    
    // إذا لم توجد إحصائيات اليوم، نحاول جلب من xp
    if (dailyStats.date !== today || Object.keys(dailyStats.data).length === 0) {
        // نجيب من xp كبديل
        const xpData = xp;
        if (!xpData[chatId] || Object.keys(xpData[chatId]).length === 0) {
            await sock.sendMessage(chatId, {
                text: '📊 *لا توجد بيانات تفاعل بعد*\n\n📌 لم يتم تسجيل أي تفاعل في هذه المجموعة بعد.\n💡 ابدأ بإرسال الرسائل لتظهر في الترتيب!'
            }, { quoted: msg });
            return;
        }
        
        const sorted = Object.entries(xpData[chatId]).sort((a, b) => b[1] - a[1]);
        const top10 = sorted.slice(0, 10);
        const totalMessages = sorted.reduce((sum, [, count]) => sum + count, 0);
        
        let lines = `🏆 *أفضل 10 متفاعلين (كل الوقت)*\n\n`;
        lines += `📊 إجمالي الرسائل: ${totalMessages}\n`;
        lines += `👥 عدد المشاركين: ${sorted.length}\n\n`;
        lines += `⭐ *أفضل 10 أعضاء*\n\n`;
        
        const mentions = [];
        for (let i = 0; i < top10.length; i++) {
            const [jid, points] = top10[i];
            const medal = i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : `${i + 1}.`;
            const level = getLevelInfo(points);
            const name = await getDisplayName(sock, jid);
            lines.push(`${medal} @${name}`);
            lines.push(`   📊 ${points} رسالة | 🏅 المستوى ${level.level}`);
            lines.push(`   🏷️ "${level.title}"`);
            lines.push('');
            mentions.push(jid);
        }
        
        await sock.sendMessage(chatId, {
            text: lines,
            mentions: mentions
        }, { quoted: msg });
        return;
    }
    
    // جلب من الإحصائيات اليومية
    const data = dailyStats.data;
    const sorted = Object.entries(data).sort((a, b) => b[1] - a[1]);
    const top10 = sorted.slice(0, 10);
    
    let lines = `🏆 *أفضل 10 متفاعلين اليوم*\n\n`;
    lines += `📅 ${now.toLocaleDateString('ar-EG')}\n\n`;
    
    const mentions = [];
    for (let i = 0; i < top10.length; i++) {
        const [jid, count] = top10[i];
        const medal = i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : `${i + 1}.`;
        const name = await getDisplayName(sock, jid);
        lines.push(`${medal} @${name}`);
        lines.push(`   📊 ${count} رسالة`);
        lines.push('');
        mentions.push(jid);
    }
    
    await sock.sendMessage(chatId, {
        text: lines,
        mentions: mentions
    }, { quoted: msg });
}

// ==================== معالج المستويات ====================
let lastLevelUpTime = {};

async function handleLevelUp(sock, chatId, sender, oldXp, newXp) {
    const oldLevel = getLevelInfo(oldXp);
    const newLevel = getLevelInfo(newXp);

    if (newLevel.level > oldLevel.level) {
        const key = `${chatId}:${sender}`;
        const now = Date.now();
        if (lastLevelUpTime[key] && (now - lastLevelUpTime[key] < 99120000)) {
            return;
        }
        lastLevelUpTime[key] = now;

        const pointsReward = newLevel.pointsReward;
        addPoints(sender, pointsReward);

        if (!canSeeLevelUp(sender, chatId)) {
            return;
        }

        const profile = getProfile(sender);
        const nickname = profile?.nickname || 'غير مسجل استخدم .تسجيل';
        const nextLevelInfo = getLevelInfo(newXp);
        const nextLevelName = nextLevelInfo.nextLevel <= 25 ? levelTitles[nextLevelInfo.nextLevel].title : 'الحد الأقصى';

        let levelMsg = `╭━━━〔 🌟 ترقية مستوى 〕━━━╮

🎊 تهانينا @${sender.split('@')[0]}

⭐ المستوى: ${newLevel.level}

👤 لقبك
「${nickname}」

🏷️ لقب المستوى
「${newLevel.title}」
🎁 +${pointsReward} نقطة`;

        if (newLevel.level < 25) {
            levelMsg += `
➡️ المستوى التالي: ${newLevel.level + 1}
💫 استمر في التفاعل، فكل مستوى يقربك من لقبٍ أعظم!`;
        } else {
            levelMsg += `
🏆 لقد وصلت إلى أعلى مستوى!`;
        }

        levelMsg += `
╰━━━━━━━━━━━━━━╯`;

        await sock.sendMessage(chatId, {
            text: levelMsg,
            mentions: [sender]
        });
    }
}

// ==================== معالج الرسائل الرئيسي ====================
module.exports = async (sock, msg) => {
    if (!msg.message || msg.key.fromMe || msg.key.remoteJid === 'status@broadcast') return;
    const chatId = msg.key.remoteJid;
    const sender = msg.key.participant || msg.key.remoteJid;

    setupWelcomeListener(sock);
    setupGoodbyeListener(sock);

    if (isUserBlocked(sender)) {
        return;
    }

    let text = '';
    if (msg.message?.conversation) text = msg.message.conversation;
    else if (msg.message?.extendedTextMessage?.text) text = msg.message.extendedTextMessage.text;
    else if (msg.message?.imageMessage?.caption) text = msg.message.imageMessage.caption;
    else if (msg.message?.videoMessage?.caption) text = msg.message.videoMessage.caption;
    else if (msg.message?.documentMessage?.caption) text = msg.message.documentMessage.caption;
    else if (msg.message?.audioMessage) text = '🎵 صوتي';
    else if (msg.message?.stickerMessage) text = '🖼️ ملصق';
    else if (msg.message?.imageMessage) text = '🖼️ صورة';
    else if (msg.message?.videoMessage) text = '🎥 فيديو';

    const hasText = text !== '';
    const lower = text.toLowerCase().trim();

    // ===== نظام XP والإحصائيات =====
    if (chatId.endsWith('@g.us') && hasText && !lower.startsWith('.')) {
        if (!xp[chatId]) xp[chatId] = {};
        if (!xp[chatId][sender]) xp[chatId][sender] = 0;
        const xpGain = Math.floor(Math.random() * 5) + 1;
        const oldXp = xp[chatId][sender];
        const newXp = oldXp + xpGain;
        xp[chatId][sender] = newXp;

        await handleLevelUp(sock, chatId, sender, oldXp, newXp);
        updateDailyStats(sender);
    }

    // ===== منع المحتوى المخالف =====
    if (chatId.endsWith('@g.us') && hasText) {
        const handled = await handleBannedContent(sock, msg, chatId, sender);
        if (handled) return;
    }

    // ===== أوامر الردود التلقائية =====
    if (hasText) {
        if (await handleAutoReplyCommands(sock, msg, text, chatId, sender)) return;
    }

    // ===== الردود التلقائية =====
    if (hasText && !lower.startsWith('.') && groupReplies[chatId]) {
        const allowed = await checkCommandPermission(chatId, sender);
        if (allowed) {
            for (const r of replies) {
                if (r.match.some(w => lower.includes(w))) {
                    const reply = r.replies[Math.floor(Math.random() * r.replies.length)];
                    if (reply) {
                        await sendWithEmoji(sock, chatId, msg, reply, r.type || 'default');
                    }
                    break;
                }
            }
        }
    }

    // ===== أوامر البوت =====
    if (hasText && lower.startsWith('.')) {
        if (await handleWelcomeCommand(sock, msg, text, chatId, sender)) return;
        if (await handleReceptionCommand(sock, msg, text, chatId, sender)) return;
        if (await handleGoodbyeCommand(sock, msg, text, chatId, sender)) return;
        if (await handleRegisterCommand(sock, msg, text, chatId, sender)) return;
        
        if (lower === '.حسبة' || lower === '.احصائيات') {
            const isAdmin = await checkAdminPermission(sock, chatId, sender);
            if (!isAdmin) {
                await sock.sendMessage(chatId, { 
                    text: '⛔ هذا الأمر للنخبة والمشرفين فقط.'
                }, { quoted: msg });
                return true;
            }
            await showDailyStats(sock, chatId, msg);
            return true;
        }
        
        if (lower === '.توب' || lower === '.متفاعلين') {
            const isAdmin = await checkAdminPermission(sock, chatId, sender);
            if (!isAdmin) {
                await sock.sendMessage(chatId, { 
                    text: '⛔ هذا الأمر للنخبة والمشرفين فقط.'
                }, { quoted: msg });
                return true;
            }
            await showTop(sock, chatId, msg);
            return true;
        }
    }

    // ===== حفظ البيانات =====
    if (xp && Object.keys(xp).length > 0) {
        fs.writeFileSync(xpFile, JSON.stringify(xp, null, 2));
    }
};

// ===== تصدير الدوال =====
module.exports.getPoints = getPoints;
module.exports.addPoints = addPoints;
module.exports.setPoints = setPoints;
module.exports.getProfile = getProfile;
module.exports.setProfile = setProfile;
module.exports.getLevelInfo = getLevelInfo;
module.exports.getWarningsCount = getWarningsCount;
module.exports.addWarning = addWarning;
module.exports.loadWarnings = loadWarnings;
module.exports.saveWarnings = saveWarnings;
module.exports.isUserBlocked = isUserBlocked;
module.exports.addUserToBlacklist = addUserToBlacklist;
module.exports.removeUserFromBlacklist = removeUserFromBlacklist;
module.exports.setupWelcomeListener = setupWelcomeListener;
module.exports.setupGoodbyeListener = setupGoodbyeListener;