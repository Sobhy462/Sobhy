const fs = require('fs-extra');
const path = require('path');
const chalk = require('chalk');

const ZARF_STATE_FILE = path.join(__dirname, '../data/zarf_state.json');

let loadedPlugins = {};
let normalCount = 0;
let zarfCount = 0;

// ==================== أنيميشن سريع ====================
let animationInterval = null;
let animationActive = false;

function startLoadingAnimation() {
    if (animationActive) return;
    animationActive = true;
    
    const waveFrames = [
        '▰▰▰▰▰▰▰▰▰▰', '▰▰▰▰▰▰▰▰▰▱', '▰▰▰▰▰▰▰▰▱▱',
        '▰▰▰▰▰▰▰▱▱▱', '▰▰▰▰▰▰▱▱▱▱', '▰▰▰▰▰▱▱▱▱▱',
        '▰▰▰▰▱▱▱▱▱▱', '▰▰▰▱▱▱▱▱▱▱', '▰▰▱▱▱▱▱▱▱▱',
        '▰▱▱▱▱▱▱▱▱▱', '▱▱▱▱▱▱▱▱▱▱'
    ];
    
    const purple = chalk.hex('#8A2BE2');
    const gold = chalk.hex('#FFD700');
    
    console.log('');
    console.log(purple('╔══════════════════════════════════╗'));
    console.log(gold('      📦 LOADING PLUGINS'));
    console.log(purple('╚══════════════════════════════════╝'));
    console.log('');

    let i = 0;
    animationInterval = setInterval(() => {
        const frame = waveFrames[i];
        let coloredFrame = '';
        for (let j = 0; j < frame.length; j++) {
            const colors = ['#FFD700', '#8A2BE2', '#FF69B4', '#00CED1'];
            const colorIndex = (j + i) % colors.length;
            coloredFrame += chalk.hex(colors[colorIndex])(frame[j]);
        }
        process.stdout.write(`\r  ${coloredFrame} ${chalk.hex('#FFFFFF').bold('LOADING')} ${chalk.hex('#FFD700')('✦')}${chalk.hex('#8A2BE2')('✦')}${chalk.hex('#FF69B4')('✦')}`);
        i = (i + 1) % waveFrames.length;
    }, 60);
}

function stopLoadingAnimation() {
    if (animationInterval) {
        clearInterval(animationInterval);
        animationInterval = null;
        process.stdout.write('\r' + ' '.repeat(55) + '\r');
    }
    animationActive = false;
}

async function loadPlugins() {
    // بدء الأنيميشن
    startLoadingAnimation();
    
    // محاكاة وقت تحميل صغير
    await new Promise(resolve => setTimeout(resolve, 500));
    
    const pluginsDir = path.join(__dirname, '../plugins');
    const zarfDir = path.join(__dirname, '../زرف');
    await fs.ensureDir(pluginsDir);
    await fs.ensureDir(zarfDir);

    loadedPlugins = {};
    normalCount = 0;
    zarfCount = 0;

    // Plugins عادية
    const pluginFiles = (await fs.readdir(pluginsDir)).filter(f => f.endsWith('.js'));
    for (const file of pluginFiles) {
        try {
            delete require.cache[require.resolve(path.join(pluginsDir, file))];
            const plugin = require(path.join(pluginsDir, file));
            const cmds = Array.isArray(plugin.command) ? plugin.command : [plugin.command];
            if (cmds.length > 0 && typeof plugin.execute === 'function') {
                for (const c of cmds) loadedPlugins[c.toLowerCase()] = plugin;
                normalCount++;
            }
        } catch {}
    }

    // الزرف
    const zarfFiles = (await fs.readdir(zarfDir)).filter(f => f.endsWith('.js'));
    for (const file of zarfFiles) {
        try {
            delete require.cache[require.resolve(path.join(zarfDir, file))];
            const plugin = require(path.join(zarfDir, file));
            const cmds = Array.isArray(plugin.command) ? plugin.command : [plugin.command];
            if (cmds.length > 0 && typeof plugin.execute === 'function') {
                plugin.isZarfPlugin = true;
                for (const c of cmds) loadedPlugins[c.toLowerCase()] = plugin;
                zarfCount++;
            }
        } catch {}
    }

    const autoReplyCount = 28;
    const total = normalCount + zarfCount + autoReplyCount;

    // إيقاف الأنيميشن
    stopLoadingAnimation();

    const purple = chalk.hex('#8A2BE2');
    const gold = chalk.hex('#FFD700');
    const green = chalk.hex('#00FF00');
    const cyan = chalk.hex('#00CED1');
    const pink = chalk.hex('#FF69B4');

    console.log('');
    console.log(purple('╔══════════════════════════════════╗'));
    console.log(gold('      📦 PLUGINS LOADED'));
    console.log(purple('╠══════════════════════════════════╣'));
    console.log(green('║ ✅ Normal : ' + normalCount + ' ﺮﻣﺍﻭﺃ'));
    console.log(cyan('║ 🌀 Zarf   : ' + zarfCount + ' ﻑﺮﺯ'));
    console.log(pink('║ 🤖 AutoRpl: ' + autoReplyCount + ' ﺔﺻﺎﺧ'));
    console.log(purple('╠══════════════════════════════════╣'));
    console.log(gold('║ 📊 Total  : ' + total + ' ﻉﻮﻤﺠﻤﻟﺍ'));
    console.log(purple('╚══════════════════════════════════╝'));
    console.log('');

    return loadedPlugins;
}

function checkZarfStatus() {
    try {
        if (fs.existsSync(ZARF_STATE_FILE)) {
            return !!JSON.parse(fs.readFileSync(ZARF_STATE_FILE, 'utf8')).enabled;
        }
    } catch {}
    return false;
}

module.exports = { loadPlugins, getPlugins: () => loadedPlugins, checkZarfStatus };