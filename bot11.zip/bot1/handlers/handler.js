// handlers/handler.js - CommonJS Version (كامل)

const { loadPlugins } = require('./plugins.js');
const config = require('../config.js');
const logger = require('../utils/console.js');
const fs = require('fs-extra');
const path = require('path');
const { isElite } = require('../haykala/elite.js');
const dev = require('../haykala/developer.js');
const { formatMessage, formatError, formatBotStatus } = require('../utils/consoleFormat.js');

const commands = new Map();

// ==================== بيانات التفاعل الشخصي ====================
const userReactionsFile = path.join(__dirname, '../data/user_reactions.json');
let userReactions = {};

function loadUserReactions() {
    try {
        if (fs.existsSync(userReactionsFile)) {
            userReactions = JSON.parse(fs.readFileSync(userReactionsFile, 'utf8'));
        } else {
            userReactions = {};
            fs.writeFileSync(userReactionsFile, JSON.stringify({}, null, 2));
        }
    } catch (e) {
        logger.warn('فشل تحميل userReactions:', e.message);
        userReactions = {};
    }
}
function saveUserReactions() {
    try {
        fs.writeFileSync(userReactionsFile, JSON.stringify(userReactions, null, 2));
    } catch (e) {
        logger.warn('فشل حفظ userReactions:', e.message);
    }
}
loadUserReactions();

// ==================== بيانات القفل العام ====================
const globalLockedCommandsFile = path.join(__dirname, '../data/global_locked_commands.json');
let globalLockedCommands = new Set();

function loadGlobalLockedCommands() {
    try {
        if (fs.existsSync(globalLockedCommandsFile)) {
            const data = JSON.parse(fs.readFileSync(globalLockedCommandsFile, 'utf8'));
            globalLockedCommands = new Set(data);
        } else {
            globalLockedCommands = new Set();
            fs.writeFileSync(globalLockedCommandsFile, JSON.stringify([], null, 2));
        }
    } catch (e) {
        logger.warn('فشل تحميل globalLockedCommands:', e.message);
        globalLockedCommands = new Set();
    }
}
function saveGlobalLockedCommands() {
    try {
        fs.writeFileSync(globalLockedCommandsFile, JSON.stringify([...globalLockedCommands], null, 2));
    } catch (e) {
        logger.warn('فشل حفظ globalLockedCommands:', e.message);
    }
}
loadGlobalLockedCommands();

// ==================== بيانات الحظر ====================
const blacklistFile = path.join(__dirname, '../data/blacklist.json');
let blacklist = new Set();

function loadBlacklist() {
    try {
        if (fs.existsSync(blacklistFile)) {
            const data = JSON.parse(fs.readFileSync(blacklistFile, 'utf8'));
            blacklist = new Set(data);
        } else {
            blacklist = new Set();
            fs.writeFileSync(blacklistFile, JSON.stringify([], null, 2));
        }
    } catch (e) {
        logger.warn('فشل تحميل blacklist:', e.message);
        blacklist = new Set();
    }
}
function saveBlacklist() {
    try {
        fs.writeFileSync(blacklistFile, JSON.stringify([...blacklist], null, 2));
    } catch (e) {
        logger.warn('ﻆﻔﺣ ﻞﺸﻓ blacklist:', e.message);
    }
}
loadBlacklist();

// ==================== بيانات حالة المجلدات ====================
const zarfStatePath = path.join(__dirname, '../data/zarf_state.json');
const tansibStatePath = path.join(__dirname, '../data/tansib_state.json');

function getFolderState(folderPath) {
    try {
        if (fs.existsSync(folderPath)) {
            const state = JSON.parse(fs.readFileSync(folderPath, 'utf8'));
            return state.enabled === true;
        }
        return false;
    } catch (e) {
        return false;
    }
}

function setFolderState(folderPath, enabled) {
    try {
        fs.writeFileSync(folderPath, JSON.stringify({ enabled }, null, 2));
    } catch (e) {
        logger.warn('ﺕﺍﺪﻠﺠﻤﻟﺍ ﺔﻟﺎﺣ ﻆﻔﺣ ﻞﺸﻓ', e.message);
    }
}

function isZarfEnabled() {
    return getFolderState(zarfStatePath);
}

function isTansibEnabled() {
    return getFolderState(tansibStatePath);
}

// ==================== جمع الأوامر من المجلدات ====================
function loadCommandsFromFolder(folderPath) {
    const commandsList = [];
    try {
        if (!fs.existsSync(folderPath)) return commandsList;
        const items = fs.readdirSync(folderPath);
        for (const item of items) {
            const fullPath = path.join(folderPath, item);
            const stat = fs.statSync(fullPath);
            if (stat.isDirectory()) {
                const subCommands = loadCommandsFromFolder(fullPath);
                commandsList.push(...subCommands);
                continue;
            }
            if (item.endsWith('.js')) {
                try {
                    const module = require(fullPath);
                    let found = false;
                    
                    if (module.command && typeof module.command === 'string') {
                        commandsList.push(module.command);
                        found = true;
                    }
                    if (module.command && Array.isArray(module.command)) {
                        commandsList.push(...module.command);
                        found = true;
                    }
                    
                    if (module.commands && Array.isArray(module.commands)) {
                        commandsList.push(...module.commands);
                        found = true;
                    }
                    if (module.cmd && module.cmd.name) {
                        commandsList.push(module.cmd.name);
                        found = true;
                    }
                    if (module.name && typeof module.name === 'string') {
                        commandsList.push(module.name);
                        found = true;
                    }
                    if (module.execute && module.command) {
                        commandsList.push(module.command);
                        found = true;
                    }
                    if (module.plugin && module.plugin.name) {
                        commandsList.push(module.plugin.name);
                        found = true;
                    }
                    if (module.default) {
                        const def = module.default;
                        if (def.command && typeof def.command === 'string') {
                            commandsList.push(def.command);
                            found = true;
                        }
                        if (def.command && Array.isArray(def.command)) {
                            commandsList.push(...def.command);
                            found = true;
                        }
                        if (def.commands && Array.isArray(def.commands)) {
                            commandsList.push(...def.commands);
                            found = true;
                        }
                        if (def.name) {
                            commandsList.push(def.name);
                            found = true;
                        }
                        if (def.cmd && def.cmd.name) {
                            commandsList.push(def.cmd.name);
                            found = true;
                        }
                        if (def.plugin && def.plugin.name) {
                            commandsList.push(def.plugin.name);
                            found = true;
                        }
                    }
                    if (!found) {
                        if (typeof module === 'function' || module.execute || module.handler) {
                            const cmdName = item.replace('.js', '').toLowerCase();
                            commandsList.push(cmdName);
                        } else if (module.default && (typeof module.default === 'function' || module.default.execute)) {
                            const cmdName = item.replace('.js', '').toLowerCase();
                            commandsList.push(cmdName);
                        }
                    }
                } catch (e) {
                    logger.warn(`فشل تحميل الأوامر من ${item}:`, e.message);
                }
            }
        }
    } catch (e) {
        logger.warn(`خطأ في قراءة المجلد ${folderPath}:`, e.message);
    }
    return commandsList;
}

let allowedLockCommands = [];

function refreshAllowedLockCommands() {
    const pluginsPath = path.join(__dirname, '../plugins');
    const zarfPath = path.join(__dirname, '../zarf');
    const tansibPath = path.join(__dirname, '../تنصيب');
    let autoCommands = [];
    try {
        const autoReplyMod = require('./autoReply.js');
        if (autoReplyMod.autoReplyCommands && Array.isArray(autoReplyMod.autoReplyCommands)) {
            autoCommands = autoReplyMod.autoReplyCommands;
        }
    } catch (e) {
        logger.warn('فشل تحميل autoReplyCommands:', e.message);
    }

    const pluginCommands = loadCommandsFromFolder(pluginsPath);
    const zarfCommands = loadCommandsFromFolder(zarfPath);
    const tansibCommands = loadCommandsFromFolder(tansibPath);
    
    const systemCommands = ['تفاعل', 'المقفولة', 'بان', 'فك', 'زرف', 'تفعيل', 'تعطيل', 'مود', 'وضع', 'تنصيب'];
    const all = [...new Set([...pluginCommands, ...zarfCommands, ...tansibCommands, ...autoCommands, ...systemCommands])];
    allowedLockCommands = all;
    formatBotStatus('ready', `ﺮﻣﺃ ${allowedLockCommands.length} :ﻞﻔﻘﻠﻟ ﺔﻠﺑﺎﻘﻟﺍ ﺮﻣﺍﻭﻷﺍ ﺔﻤﺋﺎﻗ ﺚﻳﺪﺤﺗ ﻢﺗ`);
    logger.info('ﻞﻔﻘﻠﻟ ﺔﻠﺑﺎﻗ ﺮﻣﺍﻭﺃ :', allowedLockCommands.join(', '));
}
refreshAllowedLockCommands();

// ==================== دوال القفل العام ====================
function isCommandLocked(commandName) {
    return globalLockedCommands.has(commandName);
}

function lockCommand(commandName) {
    globalLockedCommands.add(commandName);
    saveGlobalLockedCommands();
}

function unlockCommand(commandName) {
    globalLockedCommands.delete(commandName);
    saveGlobalLockedCommands();
}

function getLockedCommandsList() {
    return [...globalLockedCommands];
}

// ==================== دوال الحظر ====================
function isUserBlocked(userId) {
    return blacklist.has(userId);
}

function addUserToBlacklist(userId) {
    blacklist.add(userId);
    saveBlacklist();
}

function removeUserFromBlacklist(userId) {
    blacklist.delete(userId);
    saveBlacklist();
}

function getBlacklist() {
    return [...blacklist];
}

// ==================== دوال الرتب ====================
function getUserRank(userId) {
    if (dev.isFounder(userId)) return 'founder';
    if (dev.isOwnerbot(userId)) return 'owner';
    if (dev.isDeveloper(userId)) return 'developer';
    return 'user';
}

function canBan(executorId, targetId) {
    if (executorId === targetId) return false;
    const executorRank = getUserRank(executorId);
    const targetRank = getUserRank(targetId);

    if (executorRank === 'founder') return true;
    if (executorRank === 'owner') {
        if (targetRank === 'founder' || targetRank === 'owner') return false;
        return true;
    }
    if (executorRank === 'developer') {
        if (targetRank === 'founder' || targetRank === 'owner' || targetRank === 'developer') return false;
        return true;
    }
    return false;
}

// ==================== تسجيل الأوامر ====================
function cmd(options = {}) {
    if (!options.name || !options.exec) {
        throw new Error('يجب تحديد اسم الأمر ودالة التنفيذ');
    }
    commands.set(options.name.toLowerCase(), {
        name: options.name,
        exec: options.exec,
        description: options.description || '',
        usage: options.usage || '',
        category: options.category || 'عام',
        cooldown: options.cooldown || 0,
        owner: options.owner || false,
        group: options.group || false,
        elite: options.elite || false,
        developer: options.developer || false,
    });
    logger.info(`تم تسجيل الأمر: ${options.name}`);
}

// ==================== قراءة الوضع ====================
const globalModePath = path.join(__dirname, '../data/mode.txt');
const groupModePath = path.join(__dirname, '../data/mode_groups.json');

function getCurrentMode(chatId) {
    try {
        if (chatId && chatId.endsWith('@g.us')) {
            const groupModes = JSON.parse(fs.readFileSync(groupModePath, 'utf8'));
            if (groupModes[chatId]) return groupModes[chatId];
        }
        if (fs.existsSync(globalModePath)) {
            return fs.readFileSync(globalModePath, 'utf8').trim() || '[off]';
        }
        return '[off]';
    } catch (e) {
        logger.warn('خطأ قراءة الوضع:', e.message);
        return '[off]';
    }
}

// ==================== الصلاحيات ====================
function hasPermission(sender, mode, handler = {}) {
    const founder = dev.isFounder(sender);
    const owner = dev.isOwnerbot(sender);
    const developer = dev.isDeveloper(sender);
    const elite = isElite(sender);
    
    if (founder) return true;
    
    if (handler.developer && !(developer || owner)) return false;
    if (handler.elite && !(elite || developer || owner)) return false;
    if (handler.owner && !(owner)) return false;
    
    switch (mode) {
        case '[off]': return true;
        case '[نخبة]': return elite || developer || owner;
        case '[مطور]': return developer || owner;
        case '[اونر]': return owner;
        default: return true;
    }
}

function isOwnerOrFounder(sender) {
    return dev.isFounder(sender) || dev.isOwnerbot(sender);
}

function isHighRank(sender) {
    return dev.isFounder(sender) || dev.isDeveloper(sender) || dev.isOwnerbot(sender);
}

function isAuthorizedForFolder(sender) {
    return dev.isFounder(sender) || dev.isOwnerbot(sender) || dev.isDeveloper(sender);
}

// ==================== مستمع التفاعل بالإيموجي ====================
if (!global.reactEnabled) global.reactEnabled = {};
if (!global.reactMembers) global.reactMembers = {};
if (!global.reactListenerAdded) {
    global.reactListenerAdded = true;
    process.nextTick(() => {
        if (!global.conn) return;
        global.conn.ev.on('messages.upsert', async ({ messages }) => {
            try {
                const msg = messages?.[0];
                if (!msg || !msg.message || msg.key.fromMe) return;

                const from = msg.key.remoteJid;
                const sender = msg.key.participant || msg.key.remoteJid;

                if (isUserBlocked(sender)) return;

                const mode = getCurrentMode(from);
                const senderNumber = sender.split('@')[0];

                if (global.reactEnabled[from]) {
                    const memberEmoji = global.reactMembers[from]?.[sender];
                    if (memberEmoji) {
                        const hasReactPermission = hasPermission(senderNumber, mode, {});
                        if (hasReactPermission) {
                            try {
                                await global.conn.sendMessage(from, {
                                    react: { text: memberEmoji, key: msg.key }
                                });
                            } catch {}
                        }
                    }
                }

                if (userReactions[sender]) {
                    const hasReactPermission = hasPermission(senderNumber, mode, {});
                    if (hasReactPermission) {
                        try {
                            await global.conn.sendMessage(from, {
                                react: { text: userReactions[sender], key: msg.key }
                            });
                        } catch {}
                    }
                }
            } catch (err) {
                logger.error('خطأ في مستمع التفاعل:', err);
            }
        });
    });
}

// ==================== أمر التفاعل ====================
async function handleReactionCommand(sock, msg, chatId, sender, args, mode) {
    const senderNumber = sender.split('@')[0];

    if (!hasPermission(senderNumber, mode, {})) {
        return;
    }

    if (!args || args.length === 0) {
        await sock.sendMessage(chatId, {
            text: 'اكتب ايموجي بعد الأمر\nمثال: .تفاعل 🔥\nوايقاف: .تفاعل ايقاف'
        }, { quoted: msg });
        return true;
    }

    const emoji = args[0];
    if (emoji === 'ايقاف') {
        delete userReactions[sender];
        saveUserReactions();
        await sock.sendMessage(chatId, { text: '✅ تم إيقاف التفاعل الخاص بك.' }, { quoted: msg });
        return true;
    }

    userReactions[sender] = emoji;
    saveUserReactions();
    await sock.sendMessage(chatId, { text: `✅ تم تعيين التفاعل لك بـ ${emoji} 😎` }, { quoted: msg });
    return true;
}

// ==================== أوامر القفل والفتح ====================
async function handleLockCommand(sock, msg, chatId, sender, targetCmd) {
    const senderNumber = sender.split('@')[0];
    if (!isOwnerOrFounder(senderNumber)) return;
    
    if (!allowedLockCommands.includes(targetCmd)) {
        await sock.sendMessage(chatId, { text: `⚠️ الأمر "${targetCmd}" غير موجود أو غير مسموح بقفله.` }, { quoted: msg });
        return true;
    }
    lockCommand(targetCmd);
    await sock.sendMessage(chatId, { text: `🔒 تم قفل الأمر "${targetCmd}" عالمياً.` }, { quoted: msg });
    return true;
}

async function handleUnlockCommand(sock, msg, chatId, sender, targetCmd) {
    const senderNumber = sender.split('@')[0];
    if (!isOwnerOrFounder(senderNumber)) return;
    
    if (!allowedLockCommands.includes(targetCmd)) {
        await sock.sendMessage(chatId, { text: `⚠️ الأمر "${targetCmd}" غير معروف.` }, { quoted: msg });
        return true;
    }
    if (isCommandLocked(targetCmd)) {
        unlockCommand(targetCmd);
        await sock.sendMessage(chatId, { text: `🔓 تم فتح الأمر "${targetCmd}" عالمياً.` }, { quoted: msg });
    } else {
        await sock.sendMessage(chatId, { text: `⚠️ الأمر "${targetCmd}" غير مقفل.` }, { quoted: msg });
    }
    return true;
}

async function handleListLockedCommands(sock, msg, chatId, sender) {
    const senderNumber = sender.split('@')[0];
    if (!isOwnerOrFounder(senderNumber)) return;
    
    const cmds = getLockedCommandsList();
    if (cmds.length === 0) {
        await sock.sendMessage(chatId, { text: "📭 لا توجد أوامر مقفولة عالمياً." }, { quoted: msg });
    } else {
        await sock.sendMessage(chatId, { text: `🔒 الأوامر المقفولة عالمياً:\n${cmds.map(c => `• ${c}`).join('\n')}` }, { quoted: msg });
    }
    return true;
}

// ==================== أوامر الحظر ====================
async function handleBanCommand(sock, msg, chatId, sender, args, mentionedJidList, quotedMsg) {
    const senderNumber = sender.split('@')[0];
    const rank = getUserRank(senderNumber);
    if (!['developer', 'owner', 'founder'].includes(rank)) return;

    let targetUser = null;
    if (mentionedJidList && mentionedJidList.length > 0) {
        targetUser = mentionedJidList[0];
    } else if (quotedMsg) {
        const quotedSender = quotedMsg.key?.participant || quotedMsg.key?.remoteJid;
        if (quotedSender) targetUser = quotedSender;
    } else if (args && args.length > 0) {
        let possibleNumber = args[0].replace(/[^0-9]/g, '');
        if (possibleNumber.startsWith('0')) possibleNumber = '966' + possibleNumber.slice(1);
        if (possibleNumber.length >= 10) targetUser = possibleNumber + '@s.whatsapp.net';
    }

    if (!targetUser) {
        await sock.sendMessage(chatId, { text: '⚠️ يجب منشن المستخدم أو الرد على رسالته أو كتابة رقمه.' }, { quoted: msg });
        return true;
    }

    if (!canBan(senderNumber, targetUser)) {
        await sock.sendMessage(chatId, { text: '⛔ لا يمكنك حظر هذا المستخدم (صلاحية أعلى أو نفس الرتبة).' }, { quoted: msg });
        return true;
    }

    if (isUserBlocked(targetUser)) {
        await sock.sendMessage(chatId, { text: `⚠️ المستخدم محظور بالفعل.` }, { quoted: msg });
        return true;
    }

    addUserToBlacklist(targetUser);
    await sock.sendMessage(chatId, { text: `✅ تم حظر المستخدم بنجاح.` }, { quoted: msg });
    return true;
}

async function handleUnbanCommand(sock, msg, chatId, sender, args, mentionedJidList, quotedMsg) {
    const senderNumber = sender.split('@')[0];
    const rank = getUserRank(senderNumber);
    if (!['developer', 'owner', 'founder'].includes(rank)) return;

    let targetUser = null;
    if (mentionedJidList && mentionedJidList.length > 0) {
        targetUser = mentionedJidList[0];
    } else if (quotedMsg) {
        const quotedSender = quotedMsg.key?.participant || quotedMsg.key?.remoteJid;
        if (quotedSender) targetUser = quotedSender;
    } else if (args && args.length > 0) {
        let possibleNumber = args[0].replace(/[^0-9]/g, '');
        if (possibleNumber.startsWith('0')) possibleNumber = '966' + possibleNumber.slice(1);
        if (possibleNumber.length >= 10) targetUser = possibleNumber + '@s.whatsapp.net';
    }

    if (!targetUser) {
        await sock.sendMessage(chatId, { text: '⚠️ يجب منشن المستخدم أو الرد على رسالته أو كتابة رقمه.' }, { quoted: msg });
        return true;
    }

    if (!isUserBlocked(targetUser)) {
        await sock.sendMessage(chatId, { text: `⚠️ المستخدم ليس محظوراً.` }, { quoted: msg });
        return true;
    }

    removeUserFromBlacklist(targetUser);
    await sock.sendMessage(chatId, { text: `✅ تم فك الحظر عن المستخدم` }, { quoted: msg });
    return true;
}

// ==================== أوامر تفعيل/تعطيل المجلدات ====================
async function handleFolderCommand(sock, msg, chatId, sender, args, commandName) {
    const senderNumber = sender.split('@')[0];
    
    if (!isAuthorizedForFolder(senderNumber)) return;

    if (!args || args.length === 0) {
        const zarfStatus = isZarfEnabled() ? '✅ مفعل' : '❌ معطل';
        const tansibStatus = isTansibEnabled() ? '👽' : '👽';
        
        await sock.sendMessage(chatId, { 
            text: `📊 *حالة الاوامر*\n\n` +
                  `📁 *اوامر زرف*: ${zarfStatus}\n` +
                  
                  `الاستخدام:\n` +
                  `.تفعيل زرف - تشغيل اوامر زرف\n` +
                  `.تعطيل زرف - إيقاف اوامر زرف`
        }, { quoted: msg });
        return true;
    }

    const target = args[0].toLowerCase();
    const isEnable = commandName === 'تفعيل';

    if (target === 'زرف') {
        setFolderState(zarfStatePath, isEnable);
        await sock.sendMessage(chatId, { 
            text: `✅ تم ${isEnable ? 'تفعيل' : 'تعطيل'} اوامر زرف.` 
        }, { quoted: msg });
        try {
            await loadPlugins();
        } catch (e) {}
        return true;
    }

    if (target === 'تنصيب') {
        setFolderState(tansibStatePath, isEnable);
        await sock.sendMessage(chatId, { 
            text: `✅ تم ${isEnable ? 'تفعيل' : 'تعطيل'} اوامر تنصيب.` 
        }, { quoted: msg });
        try {
            await loadPlugins();
        } catch (e) {}
        return true;
    }

    await sock.sendMessage(chatId, { 
        text: `⚠️ اوامر غير معروفة. الاوامر المتاحة: زرف،` 
    }, { quoted: msg });
    return true;
}

// ==================== معالج الرسائل الرئيسي ====================
async function handleMessages(sock, update) {
    try {
        if (!update || !update.messages) {
            console.log('⚠️ لا توجد رسائل في التحديث');
            return;
        }
        
        const { messages } = update;
        const message = messages?.[0];
        if (!message) return;

        const chatId = message.key?.remoteJid;
        if (!chatId) return;

        global.conn = sock;

        if (chatId.endsWith('@g.us')) {
            if (!global.groupMetadata) global.groupMetadata = {};
            if (!global.groupMetadata[chatId]) {
                try {
                    const metadata = await sock.groupMetadata(chatId);
                    global.groupMetadata[chatId] = metadata;
                } catch (e) {
                    logger.warn(`  ${chatId} ﻦﻣ ﺮﻣﺍﻭﺃ ﻞﻴﻤﺤﺗ ﻞﺸﻓ:`, e.message);
                }
            }
        }

        // ✅ استخراج body مع التحقق
        const body =
            message.message?.conversation ||
            message.message?.extendedTextMessage?.text ||
            message.message?.imageMessage?.caption ||
            message.message?.videoMessage?.caption ||
            '';

        const mode = getCurrentMode(chatId);
        const zarfStatus = isZarfEnabled() ? 'ﺔﻠﻌﻔﻣ' : 'ﺔﻠﻄﻌﻣ';
        const tansibStatus = isTansibEnabled() ? 'مفعل' : 'معطل';
        const botStatus = '𝑺𝑨𝑻𝑼𝑹𝑵';

        let finalOptions = {
            mode,
            botStatus,
            zarf: zarfStatus,
            tansib: tansibStatus,
            handled: false,
            success: false,
            command: null,
            duration: null,
            reason: null
        };

        try {
            const autoReplyMod = require('./autoReply.js');
            await autoReplyMod(sock, message);
        } catch (e) {}

        let plugins = {};
        try {
            plugins = await loadPlugins();
            for (const name in plugins) {
                const plugin = plugins[name];
                if (plugin?.onMessage && typeof plugin.execute === 'function') {
                    await plugin.execute(sock, message);
                }
            }
        } catch (e) {
            logger.warn('Auto plugin error:', e.message);
        }

        let sender = '';
        if (chatId.endsWith('@g.us')) {
            sender = message.key.participant || '';
        } else {
            sender = chatId;
        }
        if (isUserBlocked(sender)) return;

        // ✅ التأكد من وجود body
        if (!body || typeof body !== 'string' || body.trim() === '') {
            finalOptions.reason = 'no_text';
            formatMessage(message, sock, finalOptions);
            return;
        }

        // ✅ التأكد من وجود prefix
        const prefix = config.prefix || '.';
        if (!body.toLowerCase().startsWith(prefix.toLowerCase())) {
            finalOptions.reason = 'not_command';
            formatMessage(message, sock, finalOptions);
            return;
        }

        const parts = body.slice(prefix.length).trim().split(/\s+/);
        const commandRaw = parts[0]?.toLowerCase();
        const args = parts.slice(1);
        if (!commandRaw) {
            finalOptions.reason = 'invalid_command';
            formatMessage(message, sock, finalOptions);
            return;
        }

        const commandWithoutPrefix = commandRaw.replace(prefix, '');
        finalOptions.command = commandWithoutPrefix;

        let senderNumber = sender.split('@')[0] || '';

        // ====== التحقق من مجلد الزرف ======
        if (commandWithoutPrefix !== 'تفعيل' && commandWithoutPrefix !== 'تعطيل') {
            const handler = plugins[commandWithoutPrefix];
            if (handler && handler.category === '𝑴𝑨𝑲𝑰𝑴𝑨') {
                if (!isZarfEnabled()) {
                    finalOptions.handled = true;
                    finalOptions.success = false;
                    finalOptions.reason = 'zarf_disabled';
                    formatMessage(message, sock, finalOptions);
                    return;
                }
            }
        }

        // ====== التحقق من مجلد تنصيب ======
        if (commandWithoutPrefix !== 'تفعيل' && commandWithoutPrefix !== 'تعطيل') {
            const handler = plugins[commandWithoutPrefix];
            if (handler && handler.category === 'تنصيب') {
                if (!isTansibEnabled()) {
                    finalOptions.handled = true;
                    finalOptions.success = false;
                    finalOptions.reason = 'tansib_disabled';
                    formatMessage(message, sock, finalOptions);
                    return;
                }
            }
        }

        // ====== التحقق من القفل العام ======
        if (isCommandLocked(commandWithoutPrefix)) {
            if (!isOwnerOrFounder(senderNumber)) {
                finalOptions.handled = true;
                finalOptions.success = false;
                finalOptions.reason = 'command_locked_global';
                formatMessage(message, sock, finalOptions);
                return;
            }
        }

        let mentionedJidList = [];
        let quotedMsg = null;
        if (message.message?.extendedTextMessage) {
            const ext = message.message.extendedTextMessage;
            if (ext.contextInfo) {
                if (ext.contextInfo.mentionedJid) {
                    mentionedJidList = ext.contextInfo.mentionedJid;
                }
                if (ext.contextInfo.quotedMessage) {
                    quotedMsg = {
                        key: ext.contextInfo.stanzaId ? { remoteJid: chatId, id: ext.contextInfo.stanzaId, participant: ext.contextInfo.participant } : null,
                        message: ext.contextInfo.quotedMessage,
                        participant: ext.contextInfo.participant
                    };
                }
            }
        }

        // ====== أوامر النظام ======
        if (commandWithoutPrefix === 'تفاعل') {
            await handleReactionCommand(sock, message, chatId, sender, args, mode);
            finalOptions.handled = true;
            finalOptions.success = true;
            finalOptions.duration = 0;
            formatMessage(message, sock, finalOptions);
            return;
        }
        if (commandWithoutPrefix === 'اقفل' && args.length > 0) {
            await handleLockCommand(sock, message, chatId, sender, args[0]);
            finalOptions.handled = true;
            finalOptions.success = true;
            finalOptions.duration = 0;
            formatMessage(message, sock, finalOptions);
            return;
        }
        if (commandWithoutPrefix === 'افتح' && args.length > 0) {
            await handleUnlockCommand(sock, message, chatId, sender, args[0]);
            finalOptions.handled = true;
            finalOptions.success = true;
            finalOptions.duration = 0;
            formatMessage(message, sock, finalOptions);
            return;
        }
        if (commandWithoutPrefix === 'المقفولة') {
            await handleListLockedCommands(sock, message, chatId, sender);
            finalOptions.handled = true;
            finalOptions.success = true;
            finalOptions.duration = 0;
            formatMessage(message, sock, finalOptions);
            return;
        }
        if (commandWithoutPrefix === 'بان') {
            if (args.length > 0 && args[0] === 'فك') {
                await handleUnbanCommand(sock, message, chatId, sender, args.slice(1), mentionedJidList, quotedMsg);
            } else {
                await handleBanCommand(sock, message, chatId, sender, args, mentionedJidList, quotedMsg);
            }
            finalOptions.handled = true;
            finalOptions.success = true;
            finalOptions.duration = 0;
            formatMessage(message, sock, finalOptions);
            return;
        }
        if (commandWithoutPrefix === 'فك') {
            await handleUnbanCommand(sock, message, chatId, sender, args, mentionedJidList, quotedMsg);
            finalOptions.handled = true;
            finalOptions.success = true;
            finalOptions.duration = 0;
            formatMessage(message, sock, finalOptions);
            return;
        }
        if (commandWithoutPrefix === 'تفعيل' || commandWithoutPrefix === 'تعطيل') {
            await handleFolderCommand(sock, message, chatId, sender, args, commandWithoutPrefix);
            finalOptions.handled = true;
            finalOptions.success = true;
            finalOptions.duration = 0;
            formatMessage(message, sock, finalOptions);
            return;
        }

        // ====== أوامر plugins ======
        const handler = plugins[commandWithoutPrefix];
        if (!handler) {
            finalOptions.handled = true;
            finalOptions.success = false;
            finalOptions.reason = 'command_not_found';
            formatMessage(message, sock, finalOptions);
            return;
        }

        if (!hasPermission(senderNumber, mode, handler)) {
            logger.warn(`⛔ ﺽﺭﻷﺍ ﺾﻓﺭ ${commandWithoutPrefix}`);
            finalOptions.handled = true;
            finalOptions.success = false;
            finalOptions.reason = 'permission_denied';
            formatMessage(message, sock, finalOptions);
            return;
        }

        if (handler.group && !chatId.endsWith('@g.us')) {
            await sock.sendMessage(chatId, { text: config.messages.groupOnly });
            finalOptions.handled = true;
            finalOptions.success = false;
            finalOptions.reason = 'group_only';
            formatMessage(message, sock, finalOptions);
            return;
        }

        message.args = args;
        message.command = commandWithoutPrefix;
        message.prefix = prefix;

        const start = Date.now();
        try {
            if (typeof handler.execute === 'function') {
                await handler.execute(sock, message);
            } else if (typeof handler === 'function') {
                await handler(sock, message);
            }
            const duration = Date.now() - start;
            finalOptions.handled = true;
            finalOptions.success = true;
            finalOptions.duration = duration;
            formatMessage(message, sock, finalOptions);
        } catch (execErr) {
            finalOptions.handled = true;
            finalOptions.success = false;
            finalOptions.reason = 'execution_error';
            finalOptions.error = execErr.message;
            formatMessage(message, sock, finalOptions);
            throw execErr;
        }

    } catch (err) {
        logger.error('Handler Error (caught):', err.stack);
        try {
            if (message?.key?.remoteJid) {
                await sock.sendMessage(message.key.remoteJid, {
                    text: config.messages.error
                }).catch(() => {});
            }
        } catch (e) {}
    }
}

function handleMessagesLoader() {
    formatBotStatus('ready', 'Handler ready');
    logger.info('✅ handler ﺍًﺰﻫﺎﺟ');
}

module.exports = {
    handleMessages,
    handleMessagesLoader,
    cmd,
    commands,
    getCurrentMode,
    hasPermission,
    isHighRank,
    isCommandLocked,
    lockCommand,
    unlockCommand,
    getLockedCommandsList,
    refreshAllowedLockCommands,
    isOwnerOrFounder,
    isUserBlocked,
    addUserToBlacklist,
    removeUserFromBlacklist,
    getBlacklist,
    isZarfEnabled,
    isTansibEnabled,
    setFolderState,
    zarfStatePath,
    tansibStatePath
};