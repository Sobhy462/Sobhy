const chalk = require('chalk');

const logger = {
    success(message) {
        console.log(chalk.hex('#00FF00')('✅ ' + message));
    },
    
    error(message, error = '') {
        console.error(chalk.hex('#FF0000')('❌ ' + message + (error ? ': ' + error : '')));
    },
    
    info(message) {
        console.info(chalk.hex('#8A2BE2')('✨ ' + message));
    },
    
    warn(message) {
        console.warn(chalk.hex('#FFD700')('⚠️ ' + message));
    }
};

module.exports = logger;