const chalk = require('chalk');
const os = require('os');
const { jidDecode } = require('@whiskeysockets/baileys');

const getRAM = () => {
    const total = os.totalmem();
    const used = total - os.freemem();
    return `${(used / 1024 ** 3).toFixed(2)}GB / ${(total / 1024 ** 3).toFixed(2)}GB`;
};

function cleanName(name) {
    if (!name) return 'ﻑﻭﺮﻌﻣ ﺮﻴﻏ';
    return name.replace(/[^\p{L}\p{N}\p{Emoji}\s@._-]/gu, '').trim() || 'ﻑﻭﺮﻌﻣ ﺮﻴﻏ';
}

function realLen(s) {
    if (!s) return 0;
    let len = 0;
    for (const c of s) {
        if (/[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\uFB50-\uFDFF\uFE70-\uFEFF]/.test(c)) len += 2;
        else if (/\p{Emoji}/u.test(c)) len += 2;
        else len += 1;
    }
    return len;
}

function pad(s, w) {
    const rl = realLen(s);
    return rl < w ? ' '.repeat(w - rl) : '';
}

// ==================== استخراج الرقم الحقيقي ====================
function extractRealId(msg) {
    let jid = msg.key?.participant || msg.key?.remoteJid || msg.sender || '';
    
    if (!jid) return 'ﻑﻭﺮﻌﻣ ﺮﻴﻏ';
    
    if (jid.includes('@s.whatsapp.net')) {
        let number = jid.split('@')[0];
        if (number.startsWith('0')) number = number.substring(1);
        return number;
    }
    
    if (jid.includes('@lid')) {
        try {
            const decoded = jidDecode(jid);
            if (decoded?.user) {
                let number = decoded.user;
                if (number.startsWith('0')) number = number.substring(1);
                return number;
            }
        } catch (e) {}
        
        let lidNumber = jid.split('@')[0].replace(/^lid:/i, '');
        const extractedNumber = lidNumber.match(/\d{7,15}/);
        if (extractedNumber) {
            let number = extractedNumber[0];
            if (number.startsWith('0')) number = number.substring(1);
            return number;
        }
        if (/^\d+$/.test(lidNumber) && lidNumber.length >= 7) {
            let number = lidNumber;
            if (number.startsWith('0')) number = number.substring(1);
            return number;
        }
    }
    
    if (jid.includes('@user')) {
        let number = jid.split('@')[0];
        if (number.startsWith('0')) number = number.substring(1);
        return number;
    }
    
    if (msg.message?.extendedTextMessage?.contextInfo?.participant) {
        const participant = msg.message.extendedTextMessage.contextInfo.participant;
        if (participant.includes('@s.whatsapp.net')) {
            let number = participant.split('@')[0];
            if (number.startsWith('0')) number = number.substring(1);
            return number;
        }
        if (participant.includes('@lid')) {
            const lidNumber = participant.split('@')[0].replace(/^lid:/i, '');
            const extractedNumber = lidNumber.match(/\d{7,15}/);
            if (extractedNumber) {
                let number = extractedNumber[0];
                if (number.startsWith('0')) number = number.substring(1);
                return number;
            }
        }
    }
    
    if (msg.message?.extendedTextMessage?.contextInfo?.quotedMessage) {
        const quotedMsg = msg.message.extendedTextMessage.contextInfo.quotedMessage;
        if (quotedMsg?.key?.participant) {
            const participant = quotedMsg.key.participant;
            if (participant.includes('@s.whatsapp.net')) {
                let number = participant.split('@')[0];
                if (number.startsWith('0')) number = number.substring(1);
                return number;
            }
            if (participant.includes('@lid')) {
                const lidNumber = participant.split('@')[0].replace(/^lid:/i, '');
                const extractedNumber = lidNumber.match(/\d{7,15}/);
                if (extractedNumber) {
                    let number = extractedNumber[0];
                    if (number.startsWith('0')) number = number.substring(1);
                    return number;
                }
            }
        }
    }
    
    if (msg.pushName) {
        const nameMatch = msg.pushName.match(/\d{7,15}/);
        if (nameMatch) {
            let number = nameMatch[0];
            if (number.startsWith('0')) number = number.substring(1);
            return number;
        }
    }
    
    const raw = jid.split('@')[0] || jid;
    if (/^\d+$/.test(raw) && raw.length >= 7) {
        let number = raw;
        if (number.startsWith('0')) number = number.substring(1);
        return number;
    }
    
    const numbers = raw.match(/\d{7,15}/);
    if (numbers) {
        let number = numbers[0];
        if (number.startsWith('0')) number = number.substring(1);
        return number;
    }
    
    return raw;
}

function extractRawId(msg) {
    const jid = msg.key?.participant || msg.key?.remoteJid || msg.sender || '';
    if (!jid) return 'ﻑﻭﺮﻌﻣ ﺮﻴﻏ';
    return jid.split('@')[0];
}

// ==================== أنيميشن سريع وجميل ====================
let animationInterval = null;
let animationActive = false;

function startSearchAnimation(commandName) {
    if (animationActive) return;
    animationActive = true;
    
    const waveFrames = [
        '▰▰▰▰▰▰▰▰▰▰', '▰▰▰▰▰▰▰▰▰▱', '▰▰▰▰▰▰▰▰▱▱',
        '▰▰▰▰▰▰▰▱▱▱', '▰▰▰▰▰▰▱▱▱▱', '▰▰▰▰▰▱▱▱▱▱',
        '▰▰▰▰▱▱▱▱▱▱', '▰▰▰▱▱▱▱▱▱▱', '▰▰▱▱▱▱▱▱▱▱',
        '▰▱▱▱▱▱▱▱▱▱', '▱▱▱▱▱▱▱▱▱▱'
    ];
    
    const purple = chalk.hex('#8A2BE2');
    const gold = chalk.hex('#FFD700');
    
    console.log('');
    console.log(purple('╔══════════════════════════════════╗'));
    console.log(gold(`      📡 EXECUTING: ${chalk.hex('#FF69B4').bold(commandName)}`));
    console.log(purple('╚══════════════════════════════════╝'));
    console.log('');

    let i = 0;
    animationInterval = setInterval(() => {
        const frame = waveFrames[i];
        let coloredFrame = '';
        for (let j = 0; j < frame.length; j++) {
            const colors = ['#FFD700', '#8A2BE2', '#FF69B4', '#00CED1'];
            const colorIndex = (j + i) % colors.length;
            coloredFrame += chalk.hex(colors[colorIndex])(frame[j]);
        }
        process.stdout.write(`\r  ${coloredFrame} ${chalk.hex('#FFFFFF').bold('PROCESSING')} ${chalk.hex('#FFD700')('✦')}${chalk.hex('#8A2BE2')('✦')}${chalk.hex('#FF69B4')('✦')}`);
        i = (i + 1) % waveFrames.length;
    }, 50);
}

function stopSearchAnimation() {
    if (animationInterval) {
        clearInterval(animationInterval);
        animationInterval = null;
        process.stdout.write('\r' + ' '.repeat(55) + '\r');
    }
    animationActive = false;
}

// ==================== دالة عرض المعلومات ====================
const formatMessage = (msg, sock, options = {}) => {
    const commandName = options.command || (options.handled === false ? 'Message' : 'Command');
    
    // بدء الأنيميشن فوراً
    startSearchAnimation(commandName);
    
    // تنفيذ باقي الكود بعد الأنيميشن
    setTimeout(() => {
        try {
            const pu = chalk.hex('#8A2BE2');
            const go = chalk.hex('#FFD700');
            const pi = chalk.hex('#FF69B4');
            const cy = chalk.hex('#00CED1');
            const wh = chalk.hex('#FFFFFF');
            const gr = chalk.hex('#00FF00');
            const re = chalk.hex('#FF0000');
            const or = chalk.hex('#FF8C00');
            const hp = chalk.hex('#FF1493');
            const ye = chalk.hex('#FFFF00');
            const bl = chalk.hex('#00BFFF');

            const W = 46;
            const date = new Date().toLocaleString('en-US', { month: 'long', day: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true });
            const chatId = msg.key?.remoteJid || '';
            const isGroup = chatId.endsWith('@g.us');
            const isFromMe = msg.key?.fromMe || false;
            
            const realId = extractRealId(msg);
            const rawId = extractRawId(msg);
            
            const senderName = cleanName(msg.pushName || 'ﻑﻭﺮﻌﻣ ﺮﻴﻏ').substring(0, 18);
            
            // ====== تحديد اسم المرسل ======
            let senderDisplay = '';
            
            if (isFromMe) {
                const botJid = sock.user?.jid || sock.user?.id || '';
                let botNumber = 'Bot';
                if (botJid.includes('@s.whatsapp.net')) {
                    botNumber = botJid.split('@')[0];
                } else {
                    botNumber = botJid.replace('@s.whatsapp.net', '').split(':')[0] || 'Bot';
                }
                if (botNumber.startsWith('0')) botNumber = botNumber.substring(1);
                senderDisplay = `+${botNumber}`;
            } else {
                let foundNumber = null;
                
                if (realId && /^\d{7,15}$/.test(realId) && realId !== 'ﻑﻭﺮﻌﻣ ﺮﻴﻏ') {
                    foundNumber = realId;
                }
                
                if (!foundNumber && msg.pushName) {
                    const nameMatch = msg.pushName.match(/\d{7,15}/);
                    if (nameMatch) {
                        foundNumber = nameMatch[0];
                    }
                }
                
                if (!foundNumber && !isGroup) {
                    const chatIdParts = chatId.split('@');
                    if (chatIdParts.length > 0 && /^\d+$/.test(chatIdParts[0]) && chatIdParts[0].length >= 7) {
                        foundNumber = chatIdParts[0];
                    }
                }
                
                if (!foundNumber && msg.key?.participant) {
                    const participant = msg.key.participant;
                    if (participant.includes('@s.whatsapp.net')) {
                        foundNumber = participant.split('@')[0];
                    } else if (participant.includes('@lid')) {
                        const lidNumber = participant.split('@')[0].replace(/^lid:/i, '');
                        const extractedNumber = lidNumber.match(/\d{7,15}/);
                        if (extractedNumber) {
                            foundNumber = extractedNumber[0];
                        }
                    }
                }
                
                if (!foundNumber && !isGroup && msg.key?.remoteJid) {
                    const remoteJid = msg.key.remoteJid;
                    if (remoteJid.includes('@s.whatsapp.net')) {
                        foundNumber = remoteJid.split('@')[0];
                    }
                }
                
                if (!foundNumber && msg.message?.extendedTextMessage?.contextInfo?.participant) {
                    const participant = msg.message.extendedTextMessage.contextInfo.participant;
                    if (participant.includes('@s.whatsapp.net')) {
                        foundNumber = participant.split('@')[0];
                    } else if (participant.includes('@lid')) {
                        const lidNumber = participant.split('@')[0].replace(/^lid:/i, '');
                        const extractedNumber = lidNumber.match(/\d{7,15}/);
                        if (extractedNumber) {
                            foundNumber = extractedNumber[0];
                        }
                    }
                }
                
                if (!foundNumber && rawId && /^\d+$/.test(rawId) && rawId.length >= 7) {
                    foundNumber = rawId;
                }
                
                if (foundNumber && /^\d{7,15}$/.test(foundNumber)) {
                    if (foundNumber.startsWith('0')) foundNumber = foundNumber.substring(1);
                    senderDisplay = `+${foundNumber}`;
                } else {
                    senderDisplay = `LID: ${rawId}`;
                }
            }
            
            let chatDisplay = isGroup ? 'ﺔﻋﻮﻤﺠﻣ' : 'ﺹﺎﺧ';
            let memberCountDisplay = '';
            let groupIdDisplay = '';
            let chatTypeDisplay = isGroup ? 'ﺔﻋﻮﻤﺠﻣ' : 'ﺹﺎﺧ';
            
            if (isGroup) {
                const meta = global.groupMetadata?.[chatId];
                const groupName = (meta?.subject || 'ﻑﻭﺮﻌﻣ ﺮﻴﻏ').substring(0, 24);
                chatDisplay = groupName;
                const memberCount = meta?.participants?.length || '?';
                memberCountDisplay = `👥 ${memberCount} ﺍًﻮﻀﻋ`;
                groupIdDisplay = chatId.split('@')[0];
            } else {
                chatDisplay = senderName;
                memberCountDisplay = `👤 ﺔﺻﺎﺧ ﺔﺛﺩﺎﺤﻣ`;
                groupIdDisplay = chatId.split('@')[0];
            }

            const botJid = sock.user?.jid || sock.user?.id || '';
            let botNumber = 'Bot';
            if (botJid.includes('@s.whatsapp.net')) {
                botNumber = botJid.split('@')[0];
            } else {
                botNumber = botJid.replace('@s.whatsapp.net', '').split(':')[0] || 'Bot';
            }
            if (botNumber.startsWith('0')) botNumber = botNumber.substring(1);

            let content = '';
            const m = msg.message || {};
            
            if (m.conversation) {
                content = m.conversation;
            } else if (m.extendedTextMessage?.text) {
                content = m.extendedTextMessage.text;
            } else if (m.imageMessage) {
                content = m.imageMessage.caption || '📷 [ﺓﺭﻮﺻ]';
            } else if (m.videoMessage) {
                content = m.videoMessage.caption || '🎥 [ﻮﻳﺪﻴﻓ]';
            } else if (m.stickerMessage) {
                content = '🎴 [ﻖﺼﻠﻣ]';
            } else if (m.audioMessage) {
                content = '🎵 [ﺕﻮﺻ]';
            } else if (m.documentMessage) {
                content = `📄 [ﺪﻨﺘﺴﻣ: ${m.documentMessage.fileName || 'ﻒﻠﻣ'}]`;
            } else if (m.contactMessage) {
                content = `👤 [فيﻝﺎﺼﺗﺍ ﺔﻬﺟ: ${m.contactMessage.displayName || ''}]`;
            } else if (m.locationMessage) {
                content = '📍 [ﻊﻗﻮﻣ]';
            } else if (m.reactionMessage) {
                const reactionEmoji = m.reactionMessage.text || '👍';
                content = ` [ ${reactionEmoji}:.ﻞﻋﺎﻔﺗ]`;
            } else {
                content = '❓ [ﺔﻓﻭﺮﻌﻣ ﺮﻴﻏ ﺔﻟﺎﺳﺭ]';
            }

            if (content.length > 500) content = content.substring(0, 500) + '...';

            const mode = options.mode || 'off';
            const botStatus = options.botStatus || 'ﺔﻠﻌﻔﻣ';
            const zarfStatus = options.zarf || 'ﺔﻠﻄﻌﻣ';
            
            let statusText = '';
            let statusColor;
            if (options.handled === true) {
                if (options.success === true) {
                    statusText = 'ﺡﺎﺠﻨﺑ ﺬﻴﻔﻨﺗ ﻢﺗ ✅';
                    statusColor = gr;
                } else {
                    const reason = options.reason || 'ﺔﻓﻭﺮﻌﻣ ﺮﻴﻏ';
                    statusText = `❌ ﻞﺸﻓ (${reason})`;
                    statusColor = re;
                }
            } else {
                const reason = options.reason === 'not_command' ? 'ﺮﻣﺃ ﺲﻴﻟ' : (options.reason || 'ﻞﻫﺎﺠﺗ ﻢﺗ');
                statusText = `⏩ ﻞﻫﺎﺠﺗ ﻢﺗ (${reason})`;
                statusColor = ye;
            }

            const duration = options.duration ? `${options.duration}ms` : 'N/A';
            const cmdName = options.command || '';
            
    // إيقاف الأنيميشن وعرض النتيجة
            stopSearchAnimation();
            
            console.log('');
            console.log(pu('╔' + '═'.repeat(W) + '╗'));
            console.log(pu('║') + go('          👑 MAKIMA BOT INFO 👑               ') + pu('║'));
            console.log(pu('╠' + '═'.repeat(W) + '╣'));
            console.log(pu('║ ') + cy('📱 Bot    : ') + go('𝐌𝐀𝐊𝐈𝐌𝐀') + wh(' (+' + botNumber + ')') + pad('📱 Bot    : 𝐌𝐀𝐊𝐈𝐌𝐀 (+' + botNumber + ')', W) + pu(' '));
            console.log(pu('║ ') + cy('💾 RAM    : ') + go(getRAM()) + pad('💾 RAM    : ' + getRAM(), W) + pu(' '));
            console.log(pu('║ ') + wh('📅 Date   : ' + (date.length > 34 ? date.substring(0, 31) + '...' : date)) + pad('📅 Date   : ' + (date.length > 34 ? date.substring(0, 31) + '...' : date), W) + pu(''));
            
            let senderLine = '';
            if (isFromMe) {
                senderLine = `🤖 Bot    : ${senderDisplay} ~ ﻪﺴﻔﻧ ﺕﻮﺒﻟﺍ`;
                console.log(pu('║ ') + bl(senderLine) + pad(senderLine, W) + pu(' '));
            } else {
                senderLine = `👤 Sender : ${senderDisplay} ~ ${senderName}`;
                console.log(pu('║ ') + pi(senderLine) + pad(senderLine, W) + pu(' '));
            }
            
            console.log(pu('║ ') + cy('👥 Chat   : ') + go(chatDisplay) + pad('👥 Chat   : ' + chatDisplay, W) + pu(' '));
            console.log(pu('║ ') + cy('🆔 Chat ID: ') + go(groupIdDisplay) + pad('🆔 Chat ID: ' + groupIdDisplay, W) + pu(' '));
            console.log(pu('║ ') + cy('📌 Type   : ') + go(chatTypeDisplay) + pad('📌 Type   : ' + chatTypeDisplay, W) + pu(' '));
            console.log(pu('║ ') + cy('👥 Count  : ') + go(memberCountDisplay) + pad('👥 Count  : ' + memberCountDisplay, W) + pu(' '));
            console.log(pu('╠' + '═'.repeat(W) + '╣'));
            
            if (cmdName) {
                const cmdLen = realLen(cmdName);
                const boxW = Math.min(Math.max(cmdLen + 4, 10), W - 4);
                const left = Math.floor((W - boxW - 2) / 2);
                const sp = ' '.repeat(Math.max(0, left));
                const border = '╔' + '═'.repeat(boxW) + '╗';
                const line = '║ ' + cmdName + ' '.repeat(boxW - cmdLen) + ' ║';
                const border2 = '╚' + '═'.repeat(boxW) + '╗';
                console.log(pu('║ ') + sp + hp(border) + pad(sp + border, W) + pu(' '));
                console.log(pu('║ ') + sp + hp(line) + pad(sp + line, W) + pu(' '));
                console.log(pu('║ ') + sp + hp(border2) + pad(sp + border2, W) + pu(' '));
                console.log(pu('╠' + '═'.repeat(W) + '╣'));
            }
            
            console.log(pu('║ ') + go('🎭 Mode   : [' + mode + '] | ✅ ' + botStatus) + pad('🎭 Mode   : [' + mode + '] | ✅ ' + botStatus, W) + pu(' '));
            console.log(pu('║ ') + cy('🌀 Zarf   : ' + zarfStatus) + pad('🌀 Zarf   : ' + zarfStatus, W) + pu(' '));
            console.log(pu('╠' + '═'.repeat(W) + '╣'));
            console.log(pu('║ ') + statusColor('📊 Status : ' + statusText) + pad('📊 Status : ' + statusText, W) + pu(' '));
            if (options.handled === true && options.success === true && options.duration) {
                console.log(pu('║ ') + cy('⏱️ Time   : ' + duration) + pad('⏱️ Time   : ' + duration, W) + pu(' '));
            }
            console.log(pu('╠' + '═'.repeat(W) + '╣'));
            console.log(pu('║ ') + or('💬 Msg    : ') + wh(content) + pad('💬 Msg    : ' + content, W) + pu(' '));
            console.log(pu('╚' + '═'.repeat(W) + '╝'));
            console.log('');
        } catch (e) {}
    }, 100);
};

const formatError = (type, msg) => {
    stopSearchAnimation();
    const pu = chalk.hex('#8A2BE2'), re = chalk.hex('#FF0000'), ye = chalk.hex('#FFFF00');
    const W = 46;
    console.log('');
    console.log(pu('╔' + '═'.repeat(W) + '╗'));
    console.log(pu('║') + re('           💀 ERROR DETECTED 💀            ') + pu('║'));
    console.log(pu('╠' + '═'.repeat(W) + '╣'));
    const txt = ('⚠️ ' + type + ': ' + msg).substring(0, 42);
    console.log(pu('║ ') + ye(txt) + ' '.repeat(Math.max(0, W - 2 - realLen(txt))) + pu(' ║'));
    console.log(pu('╚' + '═'.repeat(W) + '╝'));
    console.log('');
};

const formatBotStatus = (status, details = '') => {
    const pu = chalk.hex('#8A2BE2');
    const icons = { connected:'✅ CONNECTED', disconnected:'💀 DISCONNECTED', reconnecting:'🔄 RECONNECTING', ready:'🎯 READY' };
    const cols = { connected: chalk.hex('#00FF00'), disconnected: chalk.hex('#FF0000'), reconnecting: chalk.hex('#FFFF00'), ready: chalk.hex('#FFD700') };
    const icon = icons[status] || '📌 ' + status;
    const color = cols[status] || chalk.hex('#FFD700');
    const txt = icon + (details ? ' - ' + details : '');
    const W = 46;
    console.log('');
    console.log(pu('╔' + '═'.repeat(W) + '╗'));
    console.log(pu('║ ') + color(txt) + ' '.repeat(Math.max(0, W - 2 - realLen(txt))) + pu(' ║'));
    console.log(pu('╚' + '═'.repeat(W) + '╝'));
    console.log('');
};

module.exports = { formatMessage, formatError, formatBotStatus };