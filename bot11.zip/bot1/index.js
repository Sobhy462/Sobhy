const { fork } = require('child_process');
const { join } = require('path');
const fs = require('fs-extra');
const logger = require('./utils/console');
const { formatError } = require('./utils/consoleFormat');
const chalk = require('chalk');

const maxRetries = 3;
const retryDelay = 5000;

let isRunning = false;
let retryCount = 0;

// ============ أدوات مساعدة ============
const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

const purple = chalk.hex('#8A2BE2');
const gold = chalk.hex('#FFD700');
const cyan = chalk.hex('#00CED1');
const pink = chalk.hex('#FF69B4');
const white = chalk.hex('#FFFFFF');
const green = chalk.hex('#00FF00');

// ============ عرض شاشة البداية الأسطورية ============
async function displayStartupBanner() {
    console.clear();
    console.log('');
    console.log(purple('╔══════════════════════════════════╗'));
    console.log(purple('║') + gold('      🚀 MAKIMA BOT STARTING      ') + purple('║'));
    console.log(purple('╠══════════════════════════════════╣'));
    console.log(purple('║ ') + cyan('📱 Bot    : ') + gold('𝐌𝐀𝐊𝐈𝐌𝐀') + pink(' v2.5.0') + ' '.repeat(15) + purple(' '));
    console.log(purple('║ ') + cyan('👑 Dev    : ') + gold('Monte') + ' '.repeat(27) + purple(' '));
    console.log(purple('║ ') + cyan('📦 Node   : ') + gold(process.version) + ' '.repeat(24) + purple(' '));
    console.log(purple('║ ') + cyan('💻 OS     : ') + gold(process.platform) + ' '.repeat(26) + purple(' '));
    console.log(purple('╠══════════════════════════════════╣'));
    console.log(purple('║ ') + white('ﺔﻟﺎﺤﻟﺍ : ') + gold('Initializing...') + ' '.repeat(15) + purple(' '));
    console.log(purple('╚══════════════════════════════════╝'));
    console.log('');
    
    const bar = '█'.repeat(0) + '░'.repeat(20);
    process.stdout.write(gold(`  [${bar}] 0%`));
    
    for (let i = 1; i <= 20; i++) {
        await sleep(150);
        const filled = '█'.repeat(i) + '░'.repeat(20 - i);
        const percent = i * 5;
        process.stdout.write('\r' + gold(`  [${filled}] ${percent}%`));
    }
    
    console.log('\n');
    await sleep(300);
}

function handleConnection(retry = 0) {
    const currentPath = process.cwd();
    const connectionFolder = join(currentPath, 'ملف_الاتصال');

    if (!fs.existsSync(connectionFolder)) {
        logger.warn('ﻝﺎﺼﺗﻻﺍ ﻒﻠﻣ ﺩﻮﺟﻮﻣ ﺮﻴﻏ ،ﻝﺎﺣ ﻱﺃ ﻰﻠﻋ ﺔﻌﺑﺎﺘﻤﻟﺍ ﻢﺘﻴﺳ...');
    }

    if (isRunning) return;
    isRunning = true;
    
    console.log(purple('╔══════════════════════════════════╗'));
    console.log(purple('║ ') + green('ﺕﻮﺒﻟﺍ ﻞﻴﻐﺸﺗ ﻢﺗ !ﺩﺎﻌﺘﺳﻻﺍ') + purple(' '));
    console.log(purple('╚══════════════════════════════════╝'));
    console.log('');

    const child = fork(join(__dirname, 'main.js'), [], {
        stdio: ['inherit', 'inherit', 'inherit', 'ipc'],
        env: {
            ...process.env,
            CONNECTION_FOLDER: connectionFolder
        }
    });

    child.on('message', (data) => {
        if (data === 'ready') {
            retryCount = 0;
            logger.success('!ﺡﺎﺠﻨﺑ ﺕﻮﺒﻟﺍ ﻞﻴﻐﺸﺗ ﻢﺗ');
        } else if (data === 'reset') {
            logger.warn('...ﻪﻨﻣ ﺐﻠﻄﺑ ﺕﻮﺒﻟﺍ ﺔﻋﺎﺟﺭﺇ');
            child.kill();
            setTimeout(() => handleConnection(0), 2000);
        } else if (data === 'uptime') {
            child.send(process.uptime());
        }
    });

    child.on('exit', async (code) => {
        isRunning = false;

        if (code === 0) {
            logger.info('ﺔﻴﻋﺎﺒﻃ ﺔﻘﻳﺮﻄﺑ ﺕﻮﺒﻟﺍ ﻕﻼﻏﺇ ﻢﺗ');
            return;
        }

        if (code === 429) {
            logger.warn('...ﺕﺎﺒﻠﻄﻟﺍ ﻝﺪﻌﻣ ﺯﻭﺎﺠﺗ ﻢﺗ');
            await delay(10000);
            return handleConnection(retry);
        }

        if (retry < maxRetries) {
            retry++;
            console.log('');
            console.log(purple('╔══════════════════════════════════╗'));
            console.log(purple('║ ') + gold(`Retry ${retry}/${maxRetries}`) + purple('║'));
            console.log(purple('╚══════════════════════════════════╝'));
            await delay(retryDelay);
            handleConnection(retry);
        } else {
            formatError('Startup Error', 'ﻞﻴﻐﺸﺘﻟﺍ ﺕﺎﻟﻭﺎﺤﻣ ﺩﺪﺣ ﺯﻭﺎﺠﺗ ﻢﺗ');
            process.exit(1);
        }
    });

    child.on('error', (err) => {
        isRunning = false;
        formatError('Child Process Error', err.message);
        if (retry < maxRetries) {
            retry++;
            setTimeout(() => handleConnection(retry), retryDelay);
        }
    });

    setTimeout(() => {
        if (!child.connected) {
            formatError('Connection Timeout', 'ﻥﻮﺛ ﺮﺸﻋ ﺔﺜﻠﺛ ﻝﻼﺧ ﺕﻮﺒﻟﺎﺑ ﻝﺎﺼﺗﻻﺍ ﻞﺸﻓ');
            child.kill();
            handleConnection(retry + 1);
        }
    }, 10000);
}

function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

// ==================== معالجة الأخطاء ====================
process.on('SIGINT', () => {
    console.log('');
    console.log(purple('╔══════════════════════════════════╗'));
    console.log(purple('║ ') + gold('Bot stopped manually') + purple('║'));
    console.log(purple('╚══════════════════════════════════╝'));
    process.exit();
});

process.on('uncaughtException', (err) => {
    if (err.code === 'ECONNRESET' || err.code === 'rate-overlimit') {
        logger.warn('ﺃﻄﺧ ﺎﺟﺗﻧﺭﺃ ﻢﺗ');
        return;
    }
    formatError('Uncaught Exception', err.message);
});

process.on('unhandledRejection', (reason) => {
    if (reason?.code === 429) {
        logger.warn('...ﺮﻈﺘﻧﺍ ﻢﺘﻳ ﺕﺎﺒﻠﻄﻟﺍ ﻝﺪﻌﻣ ﺯﻭﺎﺠﺗ');
        return;
    }
    formatError('Unhandled Rejection', reason?.message || reason);
});

// ==================== بدء التشغيل ====================
(async () => {
    await displayStartupBanner();
    logger.info('...ﻞﻴﻐﺸﺘﻟﺍ ﺀﺪﺑ');
    handleConnection();
})();