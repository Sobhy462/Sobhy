const fs = require('fs');
const path = require('path');

const elitePath = path.join(process.cwd(), 'haykala', 'elite.json');
const devPath = path.join(process.cwd(), 'haykala', 'developer.json');

let eliteNumbers = [];
let lastDevData = {};

// تحميل النخبة
const loadEliteNumbers = () => {
  if (fs.existsSync(elitePath)) {
    eliteNumbers = JSON.parse(fs.readFileSync(elitePath, 'utf-8'));
  } else {
    eliteNumbers = [];
  }
};

// حفظ النخبة
const saveEliteNumbers = () => {
  fs.writeFileSync(elitePath, JSON.stringify(eliteNumbers, null, 2));
};

// استخراج الرقم فقط من jid أو LED
const extractPureNumber = (jid) => jid.toString().replace(/[@:].*/g, '');

// التحقق إذا الرقم نخبة
const isElite = (number) => {
  const pureNumber = extractPureNumber(number);
  return eliteNumbers.includes(pureNumber);
};

// إضافة رقم للنخبة
const addEliteNumber = (number) => {
  const pureNumber = extractPureNumber(number);
  if (!eliteNumbers.includes(pureNumber)) {
    eliteNumbers.push(pureNumber);
    saveEliteNumbers();
  }
};

// إزالة رقم من النخبة
const removeEliteNumber = (number) => {
  const pureNumber = extractPureNumber(number);
  eliteNumbers = eliteNumbers.filter(n => n !== pureNumber);
  saveEliteNumbers();
};

// تحميل الأرقام عند التشغيل
loadEliteNumbers();

// ================== المزامنة مع developer.json ==================
const syncWithDevelopers = () => {
  if (!fs.existsSync(devPath)) return;

  let devData;
  try {
    devData = JSON.parse(fs.readFileSync(devPath, 'utf-8'));
  } catch {
    return;
  }

  // دمج جميع المطورين في مصفوفة واحدة
  const allDevLEDs = [
    ...(devData.founder || []),
    ...(devData.ownerbot || []),
    ...(devData.developers || [])
  ];

  // تحويل LED إلى أرقام pureNumber
  const devNumbers = allDevLEDs.map(extractPureNumber);

  // إضافة المطورين الجدد فقط إلى النخبة
  devNumbers.forEach(n => {
    if (!eliteNumbers.includes(n)) addEliteNumber(n);
  });

  // **تم إزالة الجزء الذي يحذف الأرقام غير الموجودة في developer.json**

  lastDevData = devData;
};

// مراقبة التغييرات في developer.json
fs.watchFile(devPath, { interval: 1000 }, (curr, prev) => {
  if (curr.mtimeMs !== prev.mtimeMs) {
    syncWithDevelopers();
  }
});

// التزامن الأول عند التشغيل
syncWithDevelopers();

module.exports = {
  eliteNumbers,
  isElite,
  addEliteNumber,
  removeEliteNumber,
  extractPureNumber
};