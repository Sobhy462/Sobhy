// حالة.js - عرض حالة البوت (السرعة، المدة، الذاكرة)

const { jidDecode } = require('@whiskeysockets/baileys');
const os = require('os');

// ========== دالة الإرسال الموحدة ==========
async function sendMessage(sock, chatId, lines, quoted = null, mentions = []) {
    if (!Array.isArray(lines)) {
        lines = [lines];
    }

    let msg = `📊 حـالـة الـبـوت 📊\n`;
    msg += `━━━━━━━━━━━━━━━━━━━━\n`;
    for (const line of lines) {
        if (line && line.trim()) {
            msg += `${line}\n`;
        }
    }
    msg += `━━━━━━━━━━━━━━━━━━━━\n`;
    msg += `𝘽𝙔┇𝑴𝑨𝑲𝑰𝑴𝑨`;

    await sock.sendMessage(chatId, { text: msg, mentions }, { quoted: quoted });
}

// ========== دالة تنسيق الوقت ==========
function formatUptime(seconds) {
    const days = Math.floor(seconds / 86400);
    const hours = Math.floor((seconds % 86400) / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = Math.floor(seconds % 60);

    if (days > 0) {
        return `${days} يوم ${hours} ساعة ${minutes} دقيقة ${secs} ثانية`;
    } else if (hours > 0) {
        return `${hours} ساعة ${minutes} دقيقة ${secs} ثانية`;
    } else if (minutes > 0) {
        return `${minutes} دقيقة ${secs} ثانية`;
    } else {
        return `${secs} ثانية`;
    }
}

// ========== دالة تنسيق الذاكرة ==========
function formatMemory(bytes) {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1048576) return (bytes / 1024).toFixed(2) + ' KB';
    if (bytes < 1073741824) return (bytes / 1048576).toFixed(2) + ' MB';
    return (bytes / 1073741824).toFixed(2) + ' GB';
}

module.exports = {
    command: ['حالة', 'بنج'],
    category: 'نظام',
    description: '📊 عرض حالة البوت (السرعة، المدة، الذاكرة)',

    async execute(sock, msg) {
        try {
            const chatId = msg.key.remoteJid;
            const sender = msg.key.participant || msg.key.remoteJid;

            // ===== حساب السرعة =====
            const start = Date.now();
            await sock.sendPresenceUpdate('composing', chatId);
            const ping = Date.now() - start;

            // ===== مدة التشغيل =====
            const uptimeSeconds = process.uptime();
            const uptimeFormatted = formatUptime(uptimeSeconds);

            // ===== استخدام الذاكرة =====
            const memoryUsage = process.memoryUsage();
            const heapUsed = formatMemory(memoryUsage.heapUsed);
            const heapTotal = formatMemory(memoryUsage.heapTotal);
            const rss = formatMemory(memoryUsage.rss);

            // ===== نظام التشغيل =====
            const platform = os.platform();
            const arch = os.arch();
            const cpus = os.cpus().length;
            const loadAvg = os.loadavg().map(l => l.toFixed(2)).join(', ');

            // ===== بناء الرسالة =====
            const lines = [
                `🟢 *الحالة:* نشط`,
                '',
                `⚡ *السرعة:* ${ping}ms`,
                `⏱️ *مدة التشغيل:* ${uptimeFormatted}`,
                '',
                `💾 *استخدام الذاكرة:*`,
                `   • المستخدمة: ${heapUsed}`,
                `   • الإجمالية: ${heapTotal}`,
                `   • RSS: ${rss}`,
                '',
                `🖥️ *النظام:*`,
                `   • المنصة: ${platform}`,
                `   • المعالج: ${arch}`,
                `   • الأنوية: ${cpus}`,
                `   • الحمل: ${loadAvg}`,
                '',
                `👤 *تم الطلب من:* @${sender.split('@')[0]}`
            ];

            await sendMessage(sock, chatId, lines, msg, [sender]);

        } catch (error) {
            console.error('❌ خطأ في أمر حالة:', error);
            await sendMessage(sock, msg.key.remoteJid, [
                '❌ *حدث خطأ*',
                '',
                `📝 ${error.message || 'خطأ غير معروف'}`,
                '',
                '📌 حاول مرة أخرى لاحقاً'
            ], msg);
        }
    }
};