// ========== ملصق.js - إنشاء ملصق من الصور والفيديوهات (مع النشر في جروب الملصقات بالنص الافتراضي) ==========
const { downloadContentFromMessage } = require('@whiskeysockets/baileys');
const fs = require('fs');
const path = require('path');
const { execFile } = require('child_process');
const webp = require('node-webpmux');
const crypto = require('crypto');
const axios = require('axios');

// استيراد دوال نظام التبادل
let loadData, getGroupName;
try {
    const exchangeModule = require('./تبادل.js');
    loadData = exchangeModule.loadData;
    getGroupName = exchangeModule.getGroupName;
} catch (e) {
    console.error('❌ فشل استيراد دوال التبادل:', e.message);
    loadData = () => ({});
    getGroupName = async () => 'جروب غير معروف';
}

const TEMP_DIR = path.join(__dirname, 'temp');

// ========== إعداد ==========
const DEFAULT_TEXT = '『⚕️ 𝑂⃝⃕ ╏ 𝐅𝐑𝐈𝐄𝐍𝐃𝐒 ⚘️ 𝑺𝑻𝑰𝑪𝑲𝑬𝑹𝑺 』';

const decorate = (text) =>
  `🌟─────────❰🐧 ${text} 🐧❱─────────🌟`;

// ========== التأكد من وجود المجلدات ==========
if (!fs.existsSync(TEMP_DIR)) {
    fs.mkdirSync(TEMP_DIR, { recursive: true });
}

// ========== دوال EXIF ==========
function generateStickerID() {
    return crypto.randomBytes(8).toString('hex');
}

function buildExifBuffer(packname, author, id, emojis = ['⚕️']) {
    const jsonBuffer = Buffer.from(
        JSON.stringify({
            'sticker-pack-id': id,
            'sticker-pack-name': packname || DEFAULT_TEXT,
            'sticker-pack-publisher': author || '',
            emojis
        }),
        'utf8'
    );

    const exifAttr = Buffer.from([
        0x49, 0x49, 0x2A, 0x00,
        0x08, 0x00, 0x00, 0x00,
        0x01, 0x00,
        0x41, 0x57,
        0x07, 0x00,
        0x00, 0x00,
        0x00, 0x00,
        0x16, 0x00,
        0x00, 0x00
    ]);

    const exif = Buffer.concat([exifAttr, jsonBuffer]);
    exif.writeUIntLE(jsonBuffer.length, 14, 4);

    return exif;
}

async function addExif(buffer, text) {
    try {
        const img = new webp.Image();
        await img.load(buffer);

        img.exif = buildExifBuffer(
            text || DEFAULT_TEXT,
            '',
            generateStickerID()
        );

        return await img.save(null);
    } catch (error) {
        console.error('Error adding EXIF:', error);
        return buffer;
    }
}

// ========== دوال التحويل ==========
async function streamToBuffer(stream) {
    const chunks = [];
    for await (const chunk of stream) chunks.push(chunk);
    return Buffer.concat(chunks);
}

// ========== جلب صورة البروفايل ==========
async function getProfilePicture(sock, jid) {
    try {
        const ppUrl = await sock.profilePictureUrl(jid, 'image');
        const response = await axios.get(ppUrl, {
            responseType: 'arraybuffer',
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
        });
        return Buffer.from(response.data);
    } catch (err) {
        console.error('خطأ في جلب البروفايل:', err.message);
        return null;
    }
}

// ========== الأمر الرئيسي ==========
module.exports = {
    category: 'وسائط',
    command: ['ملصق', 's', 'm', 'ستيكر'],
description: ' (تحويل الصوره او الفيديو او البروفايل لملصق)',

    async execute(sock, m) {
        let inputPath = '';
        let outputPath = '';

        try {
            const chatId = m.key.remoteJid;
            const sender = m.key.participant || m.key.remoteJid;
            const senderName = m.pushName || sender.split('@')[0];

            // استخراج النص المخصص والمنشن
            const fullText = m.message?.conversation || m.message?.extendedTextMessage?.text || '';
            const mentionedJids = m.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
            const match = fullText.match(/^\.ملصق\s+(.+)/);
            let textAfterCommand = match ? match[1].trim() : '';
            
            let targetJid = null;
            if (mentionedJids.length > 0) {
                targetJid = mentionedJids[0];
            }

            let customText = DEFAULT_TEXT;
            if (textAfterCommand) {
                let textWithoutMentions = textAfterCommand;
                if (mentionedJids.length > 0) {
                    for (const jid of mentionedJids) {
                        let name = jid.split('@')[0];
                        const mentionPattern = new RegExp(`@${name}`, 'gi');
                        textWithoutMentions = textWithoutMentions.replace(mentionPattern, '').trim();
                    }
                }
                if (textWithoutMentions && textWithoutMentions.length > 0) {
                    customText = textWithoutMentions;
                }
            }

            // ===== استخراج الوسائط (صورة أو فيديو) =====
            let image = m.message?.imageMessage ||
                        m.message?.viewOnceMessageV2?.message?.imageMessage ||
                        m.message?.viewOnceMessage?.message?.imageMessage;

            let video = m.message?.videoMessage ||
                        m.message?.viewOnceMessageV2?.message?.videoMessage ||
                        m.message?.viewOnceMessage?.message?.videoMessage;

            if (!image && !video) {
                const quoted = m.message?.extendedTextMessage?.contextInfo?.quotedMessage ||
                               m.message?.imageMessage?.contextInfo?.quotedMessage ||
                               m.message?.videoMessage?.contextInfo?.quotedMessage;
                if (quoted) {
                    image = quoted?.imageMessage ||
                            quoted?.viewOnceMessageV2?.message?.imageMessage ||
                            quoted?.viewOnceMessage?.message?.imageMessage;
                    video = quoted?.videoMessage ||
                            quoted?.viewOnceMessageV2?.message?.videoMessage ||
                            quoted?.viewOnceMessage?.message?.videoMessage;
                }
            }

            if (targetJid) {
                imageBuffer = await getProfilePicture(sock, targetJid);
                if (!imageBuffer) {
                    return sock.sendMessage(chatId, { 
                        text: decorate('هذا الشخص ليس لديه صورة بروفايل') 
                    }, { quoted: m });
                }
                mediaType = 'image';
            }
            else if (image || video) {
                mediaType = image ? 'image' : 'video';
                const media = image || video;
                imageBuffer = await streamToBuffer(
                    await downloadContentFromMessage(media, mediaType)
                );
                if (!imageBuffer || imageBuffer.length < 100) {
                    return sock.sendMessage(chatId, { 
                        text: decorate('فشل التحميل') 
                    }, { quoted: m });
                }
                const maxSize = 120 * 1024 * 1024;
                if (imageBuffer.length > maxSize) {
                    return sock.sendMessage(chatId, { 
                        text: decorate(`الملف كبير جداً (${(imageBuffer.length / 1024 / 1024).toFixed(1)} ميجابايت)\nالحد الأقصى: 120 ميجابايت`) 
                    }, { quoted: m });
                }
            }
            else {
                return sock.sendMessage(chatId, { 
                    text: decorate('أرسل صورة أو فيديو مع الأمر، أو قم بمنشن شخص، أو رد على وسائط') 
                }, { quoted: m });
            }

            // ========== تحويل الصورة ==========
            const now = Date.now();
            
            inputPath = path.join(TEMP_DIR, `in-${now}.${mediaType === 'image' ? 'jpg' : 'mp4'}`);
            outputPath = path.join(TEMP_DIR, `out-${now}.webp`);

            fs.writeFileSync(inputPath, imageBuffer);

            let args;

            if (mediaType === 'image') {
                args = [
                    '-y',
                    '-i', inputPath,
                    '-vf', 'scale=512:512:force_original_aspect_ratio=decrease,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=0x00000000',
                    '-vcodec', 'libwebp',
                    '-lossless', '0',
                    '-q:v', '80',
                    '-compression_level', '6',
                    '-preset', 'default',
                    '-loop', '0',
                    outputPath
                ];
            } else {
                const durationParam = '-t';
                const maxDuration = 6;

                args = [
                    '-y',
                    '-i', inputPath,
                    '-vf', 'fps=10,scale=512:512:force_original_aspect_ratio=decrease,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=0x00000000',
                    '-vcodec', 'libwebp',
                    '-lossless', '0',
                    '-q:v', '80',
                    '-compression_level', '6',
                    '-preset', 'default',
                    '-loop', '0',
                    '-an',
                    '-vsync', '0',
                    durationParam, String(maxDuration),
                    outputPath
                ];
            }

            await new Promise((resolve, reject) => {
                execFile('ffmpeg', args, (err) => {
                    if (err) reject(err);
                    else resolve();
                });
            });

            if (!fs.existsSync(outputPath)) {
                throw new Error('فشل إنشاء الملف');
            }

            // ===== حفظ النسخة الأصلية بدون EXIF =====
            const originalWebpBuffer = fs.readFileSync(outputPath);

            // ===== إضافة EXIF المخصص للملصق في الجروب الحالي =====
            const sticker = await addExif(originalWebpBuffer, customText);

            // ===== إرسال الملصق في الجروب الحالي =====
            await sock.sendMessage(chatId, {
                sticker: sticker
            }, { quoted: m });

            // ===== نشر الملصق في جروب "ملصقات" (إن وجد) بالنص الافتراضي =====
            try {
                const exchangeData = loadData();
                const stickerGroups = exchangeData['ملصقات'] || [];
                
                if (stickerGroups.length > 0) {
                    // نضيف EXIF بالنص الافتراضي للنسخة الأصلية
                    const defaultSticker = await addExif(originalWebpBuffer, DEFAULT_TEXT);

                    for (const groupJid of stickerGroups) {
                        if (groupJid === chatId) continue;
                        try {
                            await sock.sendMessage(groupJid, {
                                sticker: defaultSticker
                            });
                            console.log(`✅ نشر الملصق (بالنص الافتراضي) في ${groupJid}`);
                            await new Promise(resolve => setTimeout(resolve, 500));
                        } catch (e) {
                            console.error(`❌ فشل النشر في ${groupJid}:`, e.message);
                        }
                    }
                }
            } catch (e) {
                console.error('❌ خطأ في نشر الملصق:', e.message);
            }

        } catch (error) {
            console.error('❌ خطأ:', error);

            return sock.sendMessage(m.key.remoteJid, { 
                text: decorate(`حدث خطأ: ${error.message || 'خطأ غير معروف'}`) 
            }, { quoted: m });
        } finally {
            // تنظيف الملفات المؤقتة
            try {
                if (inputPath && fs.existsSync(inputPath)) fs.unlinkSync(inputPath);
                if (outputPath && fs.existsSync(outputPath)) fs.unlinkSync(outputPath);
            } catch (cleanupError) {
                console.error('Cleanup error:', cleanupError);
            }
        }
    }
};