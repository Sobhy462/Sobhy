// متجر.js - المتجر الأسطوري (عرض جميع المنتجات في صفحة واحدة) - نسخة محدثة مع دعم نظام التخزين المنفصل وتحديث أوصاف الدروع
const fs = require('fs');
const path = require('path');

const pointsPath = path.join(__dirname, '../data/points.json');

// ===== مسارات التخزين المنفصل =====
const dataDir = path.join(__dirname, '../data/kingdom');
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

const MAIN_PATH = path.join(dataDir, 'main.json');
const SOLDIERS_PATH = path.join(dataDir, 'soldiers.json');
const WEAPONS_PATH = path.join(dataDir, 'weapons.json');
const ACCESSORIES_PATH = path.join(dataDir, 'accessories.json');
const POTIONS_PATH = path.join(dataDir, 'potions.json');
const SPELLS_PATH = path.join(dataDir, 'spells.json');
const SOULBOOK_PATH = path.join(dataDir, 'soulbook.json');
const COMPANION_PATH = path.join(dataDir, 'companion.json');

// ===== التأكد من وجود جميع الملفات =====
const allPaths = [MAIN_PATH, SOLDIERS_PATH, WEAPONS_PATH, ACCESSORIES_PATH, POTIONS_PATH, SPELLS_PATH, SOULBOOK_PATH, COMPANION_PATH];
for (const p of allPaths) {
    if (!fs.existsSync(p)) fs.writeFileSync(p, JSON.stringify({}, null, 2));
}
if (!fs.existsSync(pointsPath)) fs.writeFileSync(pointsPath, JSON.stringify({}, null, 2));

function loadJSON(file) { try { return JSON.parse(fs.readFileSync(file)); } catch { return {}; } }
function saveJSON(file, data) { 
    try {
        if (fs.existsSync(file)) fs.writeFileSync(file + '.bak', fs.readFileSync(file));
        fs.writeFileSync(file, JSON.stringify(data, null, 2));
        return true;
    } catch (e) {
        console.error('❌ فشل حفظ:', file, e.message);
        return false;
    }
}

// ========== دوال التخزين المنفصل ==========
function loadUserData(jid) {
    const main = loadJSON(MAIN_PATH)[jid] || {};
    const soldiers = loadJSON(SOLDIERS_PATH)[jid] || {};
    const weapons = loadJSON(WEAPONS_PATH)[jid] || {};
    const accessories = loadJSON(ACCESSORIES_PATH)[jid] || {};
    const potions = loadJSON(POTIONS_PATH)[jid] || {};
    const spells = loadJSON(SPELLS_PATH)[jid] || {};
    const soulBook = loadJSON(SOULBOOK_PATH)[jid] || {};
    const companion = loadJSON(COMPANION_PATH)[jid] || null;

    return {
        level: main.level || 1,
        prosperity: main.prosperity || 0,
        lands: main.lands || 0,
        gold: main.gold || 0,
        name: main.name || `مملكة @${jid.split('@')[0]}`,
        owner: main.owner || jid,
        nameChangesUsed: main.nameChangesUsed || 0,
        resources: loadJSON(path.join(dataDir, 'resources.json'))[jid] || { wood: 0, stone: 0, iron: 0 },
        buildings: loadJSON(path.join(dataDir, 'buildings.json'))[jid] || {},
        soldiers: soldiers,
        weapons: weapons,
        accessories: accessories,
        potions: potions,
        spellsUsed: spells,
        soulBook: soulBook,
        companion: companion,
        lastActive: Date.now()
    };
}

function saveUserData(jid, data) {
    const main = loadJSON(MAIN_PATH);
    main[jid] = {
        level: data.level || 1,
        prosperity: data.prosperity || 0,
        lands: data.lands || 0,
        gold: data.gold || 0,
        name: data.name || `مملكة @${jid.split('@')[0]}`,
        owner: data.owner || jid,
        nameChangesUsed: data.nameChangesUsed || 0
    };
    saveJSON(MAIN_PATH, main);

    const soldiers = loadJSON(SOLDIERS_PATH);
    soldiers[jid] = data.soldiers || {};
    saveJSON(SOLDIERS_PATH, soldiers);

    const weapons = loadJSON(WEAPONS_PATH);
    weapons[jid] = data.weapons || {};
    saveJSON(WEAPONS_PATH, weapons);

    const accessories = loadJSON(ACCESSORIES_PATH);
    accessories[jid] = data.accessories || {};
    saveJSON(ACCESSORIES_PATH, accessories);

    const potions = loadJSON(POTIONS_PATH);
    potions[jid] = data.potions || {};
    saveJSON(POTIONS_PATH, potions);

    const spells = loadJSON(SPELLS_PATH);
    spells[jid] = data.spellsUsed || {};
    saveJSON(SPELLS_PATH, spells);

    const soulBook = loadJSON(SOULBOOK_PATH);
    soulBook[jid] = data.soulBook || { pages: 0, spirits: [] };
    saveJSON(SOULBOOK_PATH, soulBook);

    const companion = loadJSON(COMPANION_PATH);
    companion[jid] = data.companion || null;
    saveJSON(COMPANION_PATH, companion);

    // تحديث الموارد والمباني
    const resources = loadJSON(path.join(dataDir, 'resources.json'));
    resources[jid] = data.resources || { wood: 0, stone: 0, iron: 0 };
    saveJSON(path.join(dataDir, 'resources.json'), resources);

    const buildings = loadJSON(path.join(dataDir, 'buildings.json'));
    buildings[jid] = data.buildings || {};
    saveJSON(path.join(dataDir, 'buildings.json'), buildings);
}

function userExists(jid) {
    const main = loadJSON(MAIN_PATH);
    return !!main[jid];
}

// ========== قائمة المنتجات الكاملة (تم تحديث اسم درع الآلهة إلى درع ملك) ==========
const fullProductsList = [
    // ===== أسلحة =====
    { id: 1, name: 'سيف حديدي', type: 'weapon', key: 'ironSword', cost: 150, desc: 'هجوم +10 دائم' },
    { id: 2, name: 'درع ذهبي', type: 'weapon', key: 'goldenShield', cost: 250, desc: 'دفاع +15، يمتص 150 ضرر' },
    { id: 3, name: 'قوس أسطوري', type: 'weapon', key: 'legendaryBow', cost: 300, desc: 'هجوم +20 دائم' },
    { id: 4, name: 'سيف البرق', type: 'weapon', key: 'lightningSword', cost: 400, desc: 'هجوم +40 دائم' },
    { id: 5, name: 'مطرقة العمالقة', type: 'weapon', key: 'giantHammer', cost: 550, desc: 'هجوم +60 دائم' },
    { id: 6, name: 'قوس الموت', type: 'weapon', key: 'deathBow', cost: 700, desc: 'هجوم +80 دائم (نادر)' },
    { id: 7, name: 'فأس الدمار', type: 'weapon', key: 'destructionAxe', cost: 900, desc: 'هجوم +100 دائم (أسطوري)' },
    { id: 8, name: 'سيف الأبطال', type: 'weapon', key: 'heroSword', cost: 500, desc: 'هجوم +50، دفاع +10' },
    { id: 9, name: 'قوس الزمن', type: 'weapon', key: 'timeBow', cost: 850, desc: 'هجوم +70، فرصة لإضعاف العدو' },
    { id: 10, name: 'نصل الأبدية', type: 'weapon', key: 'eternalBlade', cost: 1500, desc: 'هجوم +120، نادر أسطوري' },
    { id: 11, name: 'درع النار', type: 'weapon', key: 'fireShield', cost: 450, desc: 'دفاع +40، يمتص 400 ضرر' },
    { id: 12, name: 'درع ملك', type: 'weapon', key: 'godShield', cost: 800, desc: 'دفاع +80، يمتص 900 ضرر (أسطوري)' },  // ✅ تم التعديل هنا
    // ===== جنود =====
    { id: 13, name: 'جندي عادي', type: 'soldier', key: 'normal', cost: 30, desc: 'هجوم +2 دائم' },
    { id: 14, name: 'فارس', type: 'soldier', key: 'knight', cost: 80, desc: 'هجوم +5، دفاع +2 دائم' },
    { id: 15, name: 'رامٍ', type: 'soldier', key: 'archer', cost: 50, desc: 'هجوم +4 دائم' },
    { id: 16, name: 'حارس النخبة', type: 'soldier', key: 'eliteGuard', cost: 150, desc: 'هجوم +8، دفاع +4 دائم' },
    { id: 17, name: 'منشق التنين', type: 'soldier', key: 'dragonSpearman', cost: 300, desc: 'هجوم +15، دفاع +8 دائم' },
    { id: 18, name: 'قائد أسطوري', type: 'soldier', key: 'legendaryCommander', cost: 600, desc: 'هجوم +30، دفاع +15 دائم' },
    // ===== تعاويذ =====
    { id: 19, name: 'لهيب التنين', type: 'spell', key: 'dragonFlame', cost: 120, desc: 'دمج 50 مرة يومياً' },
    { id: 20, name: 'شفاء الملك', type: 'spell', key: 'kingsHeal', cost: 100, desc: '+50 صحة مرة يومياً' },
    { id: 21, name: 'عاصفة البرق', type: 'spell', key: 'lightningStorm', cost: 150, desc: 'مضاعفة الضربة الأولى مرة يومياً' },
    { id: 22, name: 'الثور الهائج', type: 'spell', key: 'ragingBull', cost: 180, desc: '+10% هجوم مرة يومياً' },
    { id: 23, name: 'تجمد', type: 'spell', key: 'freeze', cost: 160, desc: 'تشل العدو لجولة واحدة' },
    { id: 24, name: 'إعصار', type: 'spell', key: 'cyclone', cost: 200, desc: 'يقلل دفاع العدو 20%' },
    { id: 25, name: 'لعنة الموت', type: 'spell', key: 'curse', cost: 400, desc: 'فرصة 50% لقتل العدو فوراً (مرة واحدة)' },
    // ===== رفقاء =====
    { id: 26, name: 'تنين أسطوري', type: 'companion', key: 'dragon', cost: 600, desc: 'هجوم ودفاع +15%' },
    { id: 27, name: 'ذئب الظلام', type: 'companion', key: 'darkWolf', cost: 350, desc: 'هجوم +10%' },
    { id: 28, name: 'نسر الجليد', type: 'companion', key: 'iceEagle', cost: 450, desc: 'دفاع +12%' },
    { id: 29, name: 'تنين العالم الآخر', type: 'companion', key: 'otherworldDragon', cost: 1200, desc: 'هجوم ودفاع +25% (نادر)' },
    // ===== صفحات روح =====
    { id: 30, name: 'صفحة روح نادرة', type: 'soulPage', key: 'soulPage', cost: 100, desc: 'تضيف صفحة لكتاب الأرواح' },
    { id: 31, name: '3 صفحات روح', type: 'soulPage', key: 'soulPage3', cost: 250, desc: 'تضيف 3 صفحات' },
    { id: 32, name: '5 صفحات روح', type: 'soulPage', key: 'soulPage5', cost: 400, desc: 'تضيف 5 صفحات' },
    { id: 33, name: 'صفحة روح الظلام', type: 'soulPage', key: 'soulPageDark', cost: 600, desc: 'تضيف 5 صفحات وتستدعي روح الظلام' },
    // ===== إكسسوارات =====
    { id: 34, name: 'خاتم القوة', type: 'accessory', key: 'powerRing', cost: 200, desc: 'هجوم +10 دائم' },
    { id: 35, name: 'خاتم الحماية', type: 'accessory', key: 'protectionRing', cost: 200, desc: 'دفاع +10 دائم' },
    { id: 36, name: 'تاج الملوك', type: 'accessory', key: 'kingsCrown', cost: 900, desc: 'هجوم +30، دفاع +30، صحة +100' },
    { id: 37, name: 'قناع الظل', type: 'accessory', key: 'shadowMask', cost: 400, desc: 'دفاع +15' },
    { id: 38, name: 'قناع البطل', type: 'accessory', key: 'heroMask', cost: 700, desc: 'هجوم +20، دفاع +20، صحة +50' },
    // ===== جرعات =====
    { id: 39, name: 'جرعة شفاء صغيرة', type: 'potion', key: 'smallHeal', cost: 50, desc: 'تستعيد 50 صحة' },
    { id: 40, name: 'جرعة شفاء كبيرة', type: 'potion', key: 'largeHeal', cost: 150, desc: 'تستعيد 150 صحة' },
    { id: 41, name: 'جرعة الطاقة', type: 'potion', key: 'energyPotion', cost: 200, desc: 'تضاعف هجومك في المعركة التالية' },
    { id: 42, name: 'جرعة شفاء مصنعة', type: 'potion', key: 'craftedHeal', cost: 300, desc: 'تستعيد 300 صحة (نادرة)' }
];

// ========== دالة تصحيح بيانات المستخدم ==========
function sanitizeUser(user) {
    if (!user) return null;
    if (user.level === undefined || user.level === null) user.level = 1;
    if (user.prosperity === undefined || user.prosperity === null) user.prosperity = 0;
    if (user.lands === undefined || user.lands === null) user.lands = 0;
    if (user.gold === undefined || user.gold === null) user.gold = 0;
    if (user.monstersDefeated === undefined || user.monstersDefeated === null) user.monstersDefeated = 0;
    if (user.pvpWins === undefined || user.pvpWins === null) user.pvpWins = 0;
    if (user.pvpLosses === undefined || user.pvpLosses === null) user.pvpLosses = 0;
    if (user.name === undefined || user.name === null) user.name = `مملكة @${user.owner?.split('@')[0] || 'غير معروف'}`;
    if (user.nameChangesUsed === undefined || user.nameChangesUsed === null) user.nameChangesUsed = 0;
    if (!user.resources) user.resources = { wood: 0, stone: 0, iron: 0 };
    if (user.resources.wood === undefined || user.resources.wood === null) user.resources.wood = 0;
    if (user.resources.stone === undefined || user.resources.stone === null) user.resources.stone = 0;
    if (user.resources.iron === undefined || user.resources.iron === null) user.resources.iron = 0;
    if (!user.buildings) user.buildings = { barracks: { level: 0 }, quarry: { level: 0 }, lumberMill: { level: 0 }, ironMine: { level: 0 } };
    if (user.buildings.barracks === undefined) user.buildings.barracks = { level: 0 };
    if (user.buildings.quarry === undefined) user.buildings.quarry = { level: 0 };
    if (user.buildings.lumberMill === undefined) user.buildings.lumberMill = { level: 0 };
    if (user.buildings.ironMine === undefined) user.buildings.ironMine = { level: 0 };
    if (user.buildings.barracks.level === undefined || user.buildings.barracks.level === null) user.buildings.barracks.level = 0;
    if (user.buildings.quarry.level === undefined || user.buildings.quarry.level === null) user.buildings.quarry.level = 0;
    if (user.buildings.lumberMill.level === undefined || user.buildings.lumberMill.level === null) user.buildings.lumberMill.level = 0;
    if (user.buildings.ironMine.level === undefined || user.buildings.ironMine.level === null) user.buildings.ironMine.level = 0;
    if (!user.soldiers) user.soldiers = {};
    const soldierTypes = ['normal', 'knight', 'archer', 'eliteGuard', 'dragonSpearman', 'legendaryCommander'];
    for (const t of soldierTypes) if (user.soldiers[t] === undefined || user.soldiers[t] === null) user.soldiers[t] = 0;
    if (!user.weapons) user.weapons = {};
    const weaponTypes = ['ironSword', 'goldenShield', 'legendaryBow', 'lightningSword', 'giantHammer', 'deathBow', 'destructionAxe', 'heroSword', 'timeBow', 'eternalBlade', 'fireShield', 'godShield'];
    for (const t of weaponTypes) if (user.weapons[t] === undefined || user.weapons[t] === null) user.weapons[t] = 0;
    if (!user.accessories) user.accessories = {};
    const accessoryTypes = ['powerRing', 'protectionRing', 'kingsCrown', 'shadowMask', 'heroMask'];
    for (const t of accessoryTypes) if (user.accessories[t] === undefined || user.accessories[t] === null) user.accessories[t] = 0;
    if (!user.potions) user.potions = {};
    const potionTypes = ['smallHeal', 'largeHeal', 'energyPotion', 'craftedHeal'];
    for (const t of potionTypes) if (user.potions[t] === undefined || user.potions[t] === null) user.potions[t] = 0;
    if (!user.soulBook) user.soulBook = { pages: 0, spirits: [] };
    if (user.soulBook.pages === undefined || user.soulBook.pages === null) user.soulBook.pages = 0;
    if (!user.soulBook.spirits) user.soulBook.spirits = [];
    if (!user.companion) user.companion = null;
    if (!user.owner) user.owner = user.owner || null;
    if (!user.spellsUsed) user.spellsUsed = {};
    user.lastActive = Date.now();
    return user;
}

// ========== دالة الإرسال ==========
async function sendShopMessage(sock, chatId, lines, quoted = null, mentions = []) {
    let msg = `🏪 المتجر الأسطوري\n`;
    msg += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
    for (const line of lines) {
        msg += `${line}\n`;
    }
    msg += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
    msg += `💡 .شراء [رقم أو اسم المنتج] [العدد]\n`;
    msg += `📝 .شراء درع ذهبي 2\n`;
    msg += `𝘽𝙔┇𝑴𝑨𝑲𝑰𝑴𝑨`;
    await sock.sendMessage(chatId, { text: msg, mentions }, { quoted: quoted });
}

// ========== الأمر الرئيسي ==========
module.exports = {
    command: 'متجر',
    description: '🏪 المتجر الأسطوري – جميع المنتجات في صفحة واحدة',
    category: 'مملكة',
    async execute(sock, msg) {
        try {
            const chatId = msg.key.remoteJid;
            const sender = msg.key.participant || msg.participant || msg.key.remoteJid;

            // ===== التحقق من وجود مملكة =====
            if (!userExists(sender)) {
                await sendShopMessage(sock, chatId, [
                    `❌ @${sender.split('@')[0]}، ليس لديك مملكة.`,
                    `📌 استخدم .لاعب جديد لتأسيس مملكتك.`
                ], msg, [sender]);
                return;
            }

            // ===== تحميل بيانات المستخدم من النظام المنفصل =====
            let user = loadUserData(sender);
            user = sanitizeUser(user);
            saveUserData(sender, user);

            // تحميل النقاط
            const points = loadJSON(pointsPath);
            const userPoints = points[sender] || 0;

            // بناء قائمة المنتجات
            const lines = [
                `👑 @${sender.split('@')[0]}`,
                `💰 رصيدك: ${userPoints} نقطة`,
                `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`
            ];

            // تقسيم المنتجات إلى مجموعات للعرض
            const categories = {
                weapon: '⚔️ الأسلحة',
                soldier: '👥 الجنود',
                spell: '🔮 التعاويذ',
                companion: '🐦 الرفقاء',
                soulPage: '📖 صفحات الروح',
                accessory: '💍 الإكسسوارات',
                potion: '🧪 الجرعات'
            };

            for (const [type, categoryName] of Object.entries(categories)) {
                const items = fullProductsList.filter(p => p.type === type);
                if (items.length === 0) continue;
                
                lines.push(``);
                lines.push(`★ ${categoryName} ★`);
                
                for (const item of items) {
                    const emoji = {
                        weapon: '🗡️',
                        soldier: '👤',
                        spell: '✨',
                        companion: '🐉',
                        soulPage: '📄',
                        accessory: '💎',
                        potion: '🧪'
                    }[item.type] || '📦';
                    
                    lines.push(`  ${item.id}. ${emoji} ${item.name}`);
                    lines.push(`     💰 ${item.cost} نقطة | ${item.desc}`);
                }
            }

            // إضافة شرح نظام الدروع الجديد
            lines.push(``);
            lines.push(`━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
            lines.push(`🛡️ *نظام الدروع الجديد:*`);
            lines.push(`• الدروع تمتص ضرراً بقيمة ثابتة (درع ذهبي: 150، درع نار: 400، درع ملك: 900).`);  // ✅ تم التعديل هنا
            lines.push(`• إذا كان الضرر أكبر من قدرة الدروع → تُستهلك جميع الدروع ويصل الضرر المتبقي.`);
            lines.push(`• إذا كان الضرر أقل من أو يساوي قدرة الدروع → تُستهلك 10% من الدروع ولا يصل ضرر.`);
            lines.push(`📌 كلما زاد عدد الدروع، زادت الحماية.`);
            lines.push(`💡 استخدم .مملكتي لمعرفة عدد الدروع لديك.`);

            await sendShopMessage(sock, chatId, lines, msg, [sender]);

        } catch (error) {
            console.error('✗ خطأ في أمر متجر:', error);
            await sendShopMessage(sock, msg.key.remoteJid, [
                `❌ حدث خطأ أثناء عرض المتجر.`,
                `📌 حاول مرة أخرى لاحقاً.`
            ], msg);
        }
    }
};