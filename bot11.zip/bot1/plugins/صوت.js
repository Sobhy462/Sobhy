// صوت.js - تحميل صوت من يوتيوب (نسخة محسنة)
const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');
const os = require('os');

const pointsPath = path.join(__dirname, '../data/points.json');
const commandPrice = 200;

// ========== التأكد من وجود المجلدات والملفات ==========
if (!fs.existsSync(path.join(__dirname, '../data'))) {
    fs.mkdirSync(path.join(__dirname, '../data'), { recursive: true });
}
if (!fs.existsSync(pointsPath)) {
    fs.writeFileSync(pointsPath, JSON.stringify({}, null, 2));
}

// ========== دوال النقاط ==========
function loadPoints() {
    try {
        return JSON.parse(fs.readFileSync(pointsPath));
    } catch {
        return {};
    }
}

function savePoints(data) {
    fs.writeFileSync(pointsPath, JSON.stringify(data, null, 2));
}

function getPoints(user) {
    const points = loadPoints();
    return points[user] || 0;
}

function deductPoints(user, amount) {
    const points = loadPoints();
    const current = points[user] || 0;

    if (current < amount) {
        return { success: false, message: `رصيدك ${current} نقطة، تحتاج ${amount} نقطة` };
    }

    points[user] = current - amount;
    savePoints(points);
    return { success: true };
}

function getRandomTempFile() {
    return path.join(os.tmpdir(), `bot_audio_${Date.now()}_${Math.random().toString(36).slice(2, 8)}.mp3`);
}

// ========== دالة الإرسال ==========
async function sendMessage(sock, chatId, lines, quoted = null, mentions = []) {
    if (!Array.isArray(lines)) {
        lines = [lines];
    }

    let msg = `🎵 تـحـمـيـل صـوت 🎵\n`;
    msg += `━━━━━━━━━━━━━━━━━━━━\n`;
    for (const line of lines) {
        msg += `${line}\n`;
    }
    msg += `━━━━━━━━━━━━━━━━━━━━\n`;
    msg += `𝘽𝙔┇𝑴𝑨𝑲𝑰𝑴𝑨`;
    await sock.sendMessage(chatId, { text: msg, mentions }, { quoted: quoted });
}

module.exports = {
    command: 'صوت',
    category: 'وسائط',
    description: '🎧 تحميل أغنية من يوتيوب وإرسالها كصوت مقابل 200 نقطة',
    usage: '.صوت [اسم الأغنية]',

    async execute(sock, msg) {
        try {
            const chatId = msg.key.remoteJid;
            const sender = msg.key.participant || msg.key.remoteJid;
            const fullText = msg.message?.conversation || msg.message?.extendedTextMessage?.text || '';
            const query = fullText.replace(/^\.صوت\s*/i, '').trim();

            // عرض المساعدة
            if (!query) {
                const userPoints = getPoints(sender);
                const lines = [
                    '🎧 *تحميل الصوت من يوتيوب*',
                    '',
                    `💰 السعر: ${commandPrice} نقطة`,
                    `🪙 رصيدك: ${userPoints} نقطة`,
                    '',
                    '📖 الاستخدام:',
                    '.صوت اسم الأغنية',
                    '📝 مثال: .صوت Despacito',
                    '',
                    '💡 ملاحظة:',
                    '• يتم خصم النقاط بعد نجاح التحميل',
                    '• يحتاج اتصال إنترنت'
                ];
                await sendMessage(sock, chatId, lines, msg, [sender]);
                return;
            }

            // التحقق من الرصيد
            const userPoints = getPoints(sender);
            if (userPoints < commandPrice) {
                const lines = [
                    '❌ *رصيد غير كافٍ*',
                    '',
                    `💰 السعر: ${commandPrice} نقطة`,
                    `🪙 رصيدك الحالي: ${userPoints} نقطة`,
                    `💔 تحتاج: ${commandPrice - userPoints} نقطة إضافية`,
                    '',
                    '💡 اربح نقاطاً من الألعاب والفعاليات'
                ];
                await sendMessage(sock, chatId, lines, msg, [sender]);
                return;
            }

            // رسالة انتظار
            await sendMessage(sock, chatId, [
                `🔍 جاري البحث عن: "${query}"`,
                '⏳ جاري التحميل...',
                `💳 سيتم خصم ${commandPrice} نقطة بعد الإرسال.`
            ], msg);

            // ملف مؤقت
            const tempFile = getRandomTempFile();
            if (fs.existsSync(tempFile)) fs.unlinkSync(tempFile);

            // تشغيل yt-dlp
            const ytdlp = spawn('yt-dlp', [
                '-x', '--audio-format', 'mp3',
                '--output', tempFile,
                '--no-playlist',
                `ytsearch1:${query}`
            ]);

            let stderrData = '';

            ytdlp.stderr.on('data', data => {
                stderrData += data.toString();
                console.log(`[yt-dlp] ${data}`);
            });

            const exitCode = await new Promise((resolve) => {
                ytdlp.on('close', resolve);
            });

            if (exitCode !== 0 || !fs.existsSync(tempFile) || fs.statSync(tempFile).size < 1024) {
                throw new Error('فشل تحميل الصوت');
            }

            // قراءة الملف
            const audioBuffer = fs.readFileSync(tempFile);

            // خصم النقاط بعد نجاح التحميل
            const deductionResult = deductPoints(sender, commandPrice);
            if (!deductionResult.success) {
                throw new Error(deductionResult.message);
            }

            // إرسال الصوت
            await sock.sendMessage(chatId, {
                audio: audioBuffer,
                mimetype: 'audio/mpeg',
                ptt: true
            }, { quoted: msg });

            const remainingPoints = getPoints(sender);
            const lines = [
                `✅ تم إرسال "${query}" بنجاح!`,
                `💰 تم خصم ${commandPrice} نقطة`,
                `🪙 رصيدك المتبقي: ${remainingPoints} نقطة`,
                '',
                '🎵 استمتع بالصوت!'
            ];

            await sendMessage(sock, chatId, lines, msg, [sender]);

            // حذف الملف المؤقت
            if (fs.existsSync(tempFile)) fs.unlinkSync(tempFile);

        } catch (error) {
            console.error('❌ خطأ في تحميل الصوت:', error);

            await sendMessage(sock, chatId, [
                '❌ *فشل التحميل*',
                '',
                `📛 السبب: ${error.message || 'خطأ غير معروف'}`,
                '',
                '💡 تأكد من اسم الأغنية وحاول مرة أخرى',
                '🔗 تأكد من اتصال الإنترنت'
            ], msg);
        }
    }
};