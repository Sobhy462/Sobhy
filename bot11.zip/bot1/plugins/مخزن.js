// مخزن.js - عرض جميع مقتنياتك من الأسلحة، الجنود، التعاويذ، والإكسسوارات (نسخة محدثة مع دعم الدروع والتصحيح التلقائي) - متوافقة مع نظام التخزين المنفصل
const fs = require('fs');
const path = require('path');

// ===== مسارات التخزين المنفصل =====
const dataDir = path.join(__dirname, '../data/kingdom');
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

const MAIN_PATH = path.join(dataDir, 'main.json');
const SOLDIERS_PATH = path.join(dataDir, 'soldiers.json');
const WEAPONS_PATH = path.join(dataDir, 'weapons.json');
const ACCESSORIES_PATH = path.join(dataDir, 'accessories.json');
const POTIONS_PATH = path.join(dataDir, 'potions.json');
const SPELLS_PATH = path.join(dataDir, 'spells.json');
const SOULBOOK_PATH = path.join(dataDir, 'soulbook.json');
const COMPANION_PATH = path.join(dataDir, 'companion.json');

// ===== التأكد من وجود جميع الملفات =====
const allPaths = [MAIN_PATH, SOLDIERS_PATH, WEAPONS_PATH, ACCESSORIES_PATH, POTIONS_PATH, SPELLS_PATH, SOULBOOK_PATH, COMPANION_PATH];
for (const p of allPaths) {
    if (!fs.existsSync(p)) fs.writeFileSync(p, JSON.stringify({}, null, 2));
}

function loadJSON(file) { try { return JSON.parse(fs.readFileSync(file)); } catch { return {}; } }
function saveJSON(file, data) { 
    try {
        if (fs.existsSync(file)) fs.writeFileSync(file + '.bak', fs.readFileSync(file));
        fs.writeFileSync(file, JSON.stringify(data, null, 2));
        return true;
    } catch (e) {
        console.error('❌ فشل حفظ:', file, e.message);
        return false;
    }
}

// ========== دوال التخزين المنفصل ==========
function loadUserData(jid) {
    const main = loadJSON(MAIN_PATH)[jid] || {};
    const soldiers = loadJSON(SOLDIERS_PATH)[jid] || {};
    const weapons = loadJSON(WEAPONS_PATH)[jid] || {};
    const accessories = loadJSON(ACCESSORIES_PATH)[jid] || {};
    const potions = loadJSON(POTIONS_PATH)[jid] || {};
    const spells = loadJSON(SPELLS_PATH)[jid] || {};
    const soulBook = loadJSON(SOULBOOK_PATH)[jid] || {};
    const companion = loadJSON(COMPANION_PATH)[jid] || null;

    return {
        level: main.level || 1,
        name: main.name || `مملكة @${jid.split('@')[0]}`,
        owner: main.owner || jid,
        soldiers: soldiers,
        weapons: weapons,
        accessories: accessories,
        potions: potions,
        spellsUsed: spells,
        soulBook: soulBook,
        companion: companion,
        lastActive: Date.now()
    };
}

function saveUserData(jid, data) {
    const main = loadJSON(MAIN_PATH);
    main[jid] = {
        level: data.level || 1,
        name: data.name || `مملكة @${jid.split('@')[0]}`,
        owner: data.owner || jid
    };
    saveJSON(MAIN_PATH, main);

    const soldiers = loadJSON(SOLDIERS_PATH);
    soldiers[jid] = data.soldiers || {};
    saveJSON(SOLDIERS_PATH, soldiers);

    const weapons = loadJSON(WEAPONS_PATH);
    weapons[jid] = data.weapons || {};
    saveJSON(WEAPONS_PATH, weapons);

    const accessories = loadJSON(ACCESSORIES_PATH);
    accessories[jid] = data.accessories || {};
    saveJSON(ACCESSORIES_PATH, accessories);

    const potions = loadJSON(POTIONS_PATH);
    potions[jid] = data.potions || {};
    saveJSON(POTIONS_PATH, potions);

    const spells = loadJSON(SPELLS_PATH);
    spells[jid] = data.spellsUsed || {};
    saveJSON(SPELLS_PATH, spells);

    const soulBook = loadJSON(SOULBOOK_PATH);
    soulBook[jid] = data.soulBook || { pages: 0, spirits: [] };
    saveJSON(SOULBOOK_PATH, soulBook);

    const companion = loadJSON(COMPANION_PATH);
    companion[jid] = data.companion || null;
    saveJSON(COMPANION_PATH, companion);
}

function userExists(jid) {
    const main = loadJSON(MAIN_PATH);
    return !!main[jid];
}

// ========== دالة تصحيح بيانات المستخدم ==========
function sanitizeUser(user) {
    if (!user) return null;
    if (user.level === undefined || user.level === null) user.level = 1;
    if (user.name === undefined || user.name === null) user.name = `مملكة @${user.owner?.split('@')[0] || 'غير معروف'}`;
    if (!user.owner) user.owner = user.owner || null;
    if (!user.soldiers) user.soldiers = {};
    const soldierTypes = ['normal', 'knight', 'archer', 'eliteGuard', 'dragonSpearman', 'legendaryCommander'];
    for (const t of soldierTypes) if (user.soldiers[t] === undefined || user.soldiers[t] === null) user.soldiers[t] = 0;
    if (!user.weapons) user.weapons = {};
    const weaponTypes = ['ironSword', 'goldenShield', 'legendaryBow', 'lightningSword', 'giantHammer', 'deathBow', 'destructionAxe', 'heroSword', 'timeBow', 'eternalBlade', 'fireShield', 'godShield'];
    for (const t of weaponTypes) if (user.weapons[t] === undefined || user.weapons[t] === null) user.weapons[t] = 0;
    if (!user.accessories) user.accessories = {};
    const accessoryTypes = ['powerRing', 'protectionRing', 'kingsCrown', 'shadowMask', 'heroMask'];
    for (const t of accessoryTypes) if (user.accessories[t] === undefined || user.accessories[t] === null) user.accessories[t] = 0;
    if (!user.potions) user.potions = {};
    const potionTypes = ['smallHeal', 'largeHeal', 'energyPotion', 'craftedHeal'];
    for (const t of potionTypes) if (user.potions[t] === undefined || user.potions[t] === null) user.potions[t] = 0;
    if (!user.soulBook) user.soulBook = { pages: 0, spirits: [] };
    if (user.soulBook.pages === undefined || user.soulBook.pages === null) user.soulBook.pages = 0;
    if (!user.soulBook.spirits) user.soulBook.spirits = [];
    if (user.companion === undefined || user.companion === null) user.companion = null;
    if (!user.spellsUsed) user.spellsUsed = {};
    user.lastActive = Date.now();
    return user;
}

// ========== أنواع الدروع (للتحديد) ==========
const SHIELD_KEYS = ['goldenShield', 'fireShield', 'godShield'];
const SHIELD_NAMES = {
    goldenShield: '🛡️ درع ذهبي (يمتص 15%)',
    fireShield: '🔥 درع النار (يمتص 25%)',
    godShield: '✨ درع الآلهة (يمتص 40%)'
};

// ========== دالة الإرسال ==========
async function sendMessage(sock, chatId, lines, quoted = null, mentions = []) {
    if (!Array.isArray(lines)) {
        lines = [lines];
    }
    
    let msg = `🎒 مـخـزنـك 🎒\n`;
    msg += `━━━━━━━━━━━━━━━━━━━━\n`;
    for (const line of lines) {
        msg += `${line}\n`;
    }
    msg += `━━━━━━━━━━━━━━━━━━━━\n`;
    msg += `𝘽𝙔┇𝑴𝑨𝑲𝑰𝑴𝑨`;
    await sock.sendMessage(chatId, { text: msg, mentions }, { quoted: quoted });
}

// ========== الأمر الرئيسي ==========
module.exports = {
    command: 'مخزن',
    description: '🎒 عرض جميع مقتنياتك من الأسلحة، الجنود، التعاويذ، الإكسسوارات والرفيق',
    category: 'مملكة',
    async execute(sock, msg) {
        try {
            const chatId = msg.key.remoteJid;
            const sender = msg.key.participant || msg.participant || msg.key.remoteJid;

            // ===== تحميل البيانات من النظام المنفصل =====
            if (!userExists(sender)) {
                await sendMessage(sock, chatId, [
                    `❌ @${sender.split('@')[0]}، ليس لديك مملكة.`,
                    `📌 استخدم .لاعب جديد لتأسيس مملكتك.`
                ], msg, [sender]);
                return;
            }

            let user = loadUserData(sender);
            user = sanitizeUser(user);
            saveUserData(sender, user);

            // ===== استخراج البيانات =====
            const weapons = user.weapons || {};
            const soldiers = user.soldiers || {};
            const spells = user.spellsUsed || {};
            const accessories = user.accessories || {};
            const companion = user.companion || null;
            const soulBook = user.soulBook || { pages: 0, spirits: [] };
            const potions = user.potions || {};

            // ===== الأسلحة (مع تمييز الدروع) =====
            const weaponEntries = [
                { name: '🗡️ سيف حديدي', key: 'ironSword' },
                { name: '🏹 قوس أسطوري', key: 'legendaryBow' },
                { name: '⚔️ سيف البرق', key: 'lightningSword' },
                { name: '🔨 مطرقة العمالقة', key: 'giantHammer' },
                { name: '🏹 قوس الموت', key: 'deathBow' },
                { name: '🪓 فأس الدمار', key: 'destructionAxe' },
                { name: '🗡️ سيف الأبطال', key: 'heroSword' },
                { name: '🏹 قوس الزمن', key: 'timeBow' },
                { name: '⚔️ نصل الأبدية', key: 'eternalBlade' }
            ];

            const shieldEntries = [
                { name: SHIELD_NAMES.goldenShield, key: 'goldenShield' },
                { name: SHIELD_NAMES.fireShield, key: 'fireShield' },
                { name: SHIELD_NAMES.godShield, key: 'godShield' }
            ];

            const weaponLines = weaponEntries
                .filter(({ key }) => (weapons[key] || 0) > 0)
                .map(({ name, key }) => `${name}: ${weapons[key]}`);

            const shieldLines = shieldEntries
                .filter(({ key }) => (weapons[key] || 0) > 0)
                .map(({ name, key }) => `${name}: ${weapons[key]}`);

            // ===== الجنود =====
            const soldierEntries = [
                { name: '👨‍🌾 جندي عادي', key: 'normal' },
                { name: '🏇 فارس', key: 'knight' },
                { name: '🏹 رامٍ', key: 'archer' },
                { name: '🛡️ حارس النخبة', key: 'eliteGuard' },
                { name: '🐉 منشق التنين', key: 'dragonSpearman' },
                { name: '⚔️ قائد أسطوري', key: 'legendaryCommander' }
            ];

            const soldierLines = soldierEntries
                .filter(({ key }) => (soldiers[key] || 0) > 0)
                .map(({ name, key }) => `${name}: ${soldiers[key]}`);

            // ===== التعاويذ =====
            const spellEntries = [
                { name: '🔥 لهيب التنين', key: 'dragonFlame' },
                { name: '💖 شفاء الملك', key: 'kingsHeal' },
                { name: '⚡ عاصفة البرق', key: 'lightningStorm' },
                { name: '🐂 الثور الهائج', key: 'ragingBull' },
                { name: '❄️ تجمد', key: 'freeze' },
                { name: '🌪️ إعصار', key: 'cyclone' },
                { name: '☠️ لعنة الموت', key: 'curse' }
            ];

            const spellLines = spellEntries
                .filter(({ key }) => (spells[key] || 0) > 0)
                .map(({ name, key }) => `${name}: ${spells[key]}/1`);

            // ===== الإكسسوارات =====
            const accessoryEntries = [
                { name: '💍 خاتم القوة', key: 'powerRing' },
                { name: '💍 خاتم الحماية', key: 'protectionRing' },
                { name: '👑 تاج الملوك', key: 'kingsCrown' },
                { name: '🎭 قناع الظل', key: 'shadowMask' },
                { name: '🎭 قناع البطل', key: 'heroMask' }
            ];

            const accessoryLines = accessoryEntries
                .filter(({ key }) => (accessories[key] || 0) > 0)
                .map(({ name, key }) => `${name}: ${accessories[key]}`);

            // ===== الجرعات =====
            const potionEntries = [
                { name: '🧪 جرعة شفاء صغيرة', key: 'smallHeal' },
                { name: '🧪 جرعة شفاء كبيرة', key: 'largeHeal' },
                { name: '🧪 جرعة الطاقة', key: 'energyPotion' },
                { name: '🧪 جرعة شفاء مصنعة', key: 'craftedHeal' }
            ];

            const potionLines = potionEntries
                .filter(({ key }) => (potions[key] || 0) > 0)
                .map(({ name, key }) => `${name}: ${potions[key]}`);

            // ===== الرفيق =====
            const companionLine = companion ? `${companion.name} (قوته: ${companion.power || 0}%)` : 'لا يوجد';

            // ===== كتاب الأرواح =====
            const soulLine = `${soulBook.pages || 0} صفحة | الأرواح: ${(soulBook.spirits || []).length}`;

            // ===== بناء الرسالة =====
            const lines = [
                `👑 @${sender.split('@')[0]}`,
                ``,
                `⚔️ *أسلحتك:*`,
                weaponLines.length > 0 ? weaponLines.join(' | ') : '   لا توجد أسلحة',
                ``,
                `🛡️ *دروعك (للحماية في المعارك):*`,
                shieldLines.length > 0 ? shieldLines.join(' | ') : '   لا توجد دروع',
                ``,
                `👥 *جنودك:*`,
                soldierLines.length > 0 ? soldierLines.join(' | ') : '   لا يوجد جنود',
                ``,
                `🔮 *تعاويذك (مرة يومياً):*`,
                spellLines.length > 0 ? spellLines.join(' | ') : '   لا توجد تعاويذ',
                ``,
                `💍 *إكسسواراتك:*`,
                accessoryLines.length > 0 ? accessoryLines.join(' | ') : '   لا توجد إكسسوارات',
                ``,
                `🧪 *جرعاتك:*`,
                potionLines.length > 0 ? potionLines.join(' | ') : '   لا توجد جرعات',
                ``,
                `🐦 *الرفيق:* ${companionLine}`,
                `📖 *كتاب الأرواح:* ${soulLine}`,
                ``,
                `📌 *ملاحظة:* الدروع تستخدم تلقائياً عند الهجوم أو الغزو وتستهلك تدريجياً.`
            ];

            await sendMessage(sock, chatId, lines, msg, [sender]);

        } catch (error) {
            console.error('✗ خطأ في أمر مخزن:', error);
            await sendMessage(sock, msg.key.remoteJid, [
                `❌ حدث خطأ أثناء عرض المخزن.`,
                `📌 حاول مرة أخرى لاحقاً.`
            ], msg);
        }
    }
};