// قص.js - قص مقطع صوتي أو فيديو حسب الثواني (نسخة محسنة بدون خطوط)
const { downloadContentFromMessage } = require('@whiskeysockets/baileys');
const { exec } = require('child_process');
const fs = require('fs');
const path = require('path');

// ========== دالة الإرسال ==========
async function sendMessage(sock, chatId, lines, quoted = null, mentions = []) {
    if (!Array.isArray(lines)) {
        lines = [lines];
    }
    
    let msg = `✂️ قـص الـمـقـطـع ✂️\n`;
    msg += `━━━━━━━━━━━━━━━━━━━━\n`;
    for (const line of lines) {
        msg += `${line}\n`;
    }
    msg += `━━━━━━━━━━━━━━━━━━━━\n`;
    msg += `𝘽𝙔┇𝑴𝑨𝑲𝑰𝑴𝑨`;
    await sock.sendMessage(chatId, { text: msg, mentions }, { quoted: quoted });
}

module.exports = {
    command: 'قص',
    description: '✂️ يقص مقطع صوتي أو فيديو حسب الثواني المحددة',
    usage: '.قص 10 (رد على فيديو أو صوت)',
    category: 'عام',

    async execute(sock, m) {
        try {
            const body = m.message?.extendedTextMessage?.text || m.message?.conversation || '';
            const duration = parseInt(body.replace(/^\.\s*قص/i, '').trim());

            if (isNaN(duration) || duration < 1) {
                await sendMessage(sock, m.key.remoteJid, [
                    '⏱️ حدد مدة صحيحة بالثواني.',
                    '📝 مثال: .قص 15'
                ], m);
                return;
            }

            const contextInfo = m.message?.extendedTextMessage?.contextInfo;
            const quoted = contextInfo?.quotedMessage;
            const video = quoted?.videoMessage;
            const audio = quoted?.audioMessage;

            if (!quoted || (!video && !audio)) {
                await sendMessage(sock, m.key.remoteJid, [
                    '🎬 رد على فيديو أو صوت لاستخدام الأمر.',
                    '📝 مثال: رد على فيديو واكتب .قص 10'
                ], m);
                return;
            }

            const type = video ? 'video' : 'audio';
            const content = video || audio;
            const stream = await downloadContentFromMessage(content, type);
            let buffer = Buffer.from([]);

            for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk]);

            // مجلد مؤقت
            const tempDir = path.join(__dirname, '../temp');
            if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true });

            const ext = type === 'video' ? 'mp4' : 'mp3';
            const inputPath = path.join(tempDir, `clip-input-${Date.now()}.${ext}`);
            const outputPath = path.join(tempDir, `clip-output-${Date.now()}.${ext}`);

            fs.writeFileSync(inputPath, buffer);

            // تفاعل جارٍ القص
            await sock.sendMessage(m.key.remoteJid, {
                react: { text: '⏳', key: m.key }
            });

            const ffmpegCmd = type === 'video'
                ? `ffmpeg -y -i "${inputPath}" -t ${duration} -c copy "${outputPath}"`
                : `ffmpeg -y -i "${inputPath}" -t ${duration} -f mp3 -vn -ar 44100 -ac 2 -b:a 192k "${outputPath}"`;

            exec(ffmpegCmd, async (err) => {
                if (err || !fs.existsSync(outputPath)) {
                    console.error('❌ خطأ في القص:', err);
                    
                    // تنظيف الملفات المؤقتة
                    try { if (fs.existsSync(inputPath)) fs.unlinkSync(inputPath); } catch(e) {}
                    try { if (fs.existsSync(outputPath)) fs.unlinkSync(outputPath); } catch(e) {}
                    
                    await sendMessage(sock, m.key.remoteJid, [
                        '❌ فشل قص الملف، تأكد أن المدة لا تتجاوز مدة المقطع.'
                    ], m);
                    return;
                }

                const result = fs.readFileSync(outputPath);
                const message = type === 'video'
                    ? { video: result }
                    : { audio: result, mimetype: 'audio/mpeg', ptt: true };

                await sock.sendMessage(m.key.remoteJid, message, { quoted: m });

                // تنظيف الملفات المؤقتة
                try { if (fs.existsSync(inputPath)) fs.unlinkSync(inputPath); } catch(e) {}
                try { if (fs.existsSync(outputPath)) fs.unlinkSync(outputPath); } catch(e) {}

                // تفاعل نجاح
                await sock.sendMessage(m.key.remoteJid, {
                    react: { text: '✅', key: m.key }
                });
            });

        } catch (err) {
            console.error('📛 خطأ أثناء القص:', err);
            await sendMessage(sock, m.key.remoteJid, [
                '⚠️ حدث خطأ أثناء المعالجة، حاول مجدداً.'
            ], m);
        }
    }
};