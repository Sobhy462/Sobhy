// جمع.js - فعالية جمع كلمة بمستويات (نسخة محسنة بدون خطوط)
const fs = require('fs');
const path = require('path');

const pointsPath = path.join(__dirname, '../data/points.json');

if (!fs.existsSync(path.join(__dirname, '../data'))) fs.mkdirSync(path.join(__dirname, '../data'), { recursive: true });
if (!fs.existsSync(pointsPath)) fs.writeFileSync(pointsPath, JSON.stringify({}, null, 2));

function loadJSON(file) { try { return JSON.parse(fs.readFileSync(file)); } catch { return {}; } }
function saveJSON(file, data) { fs.writeFileSync(file, JSON.stringify(data, null, 2)); }

function getLevel(points) {
    if (points >= 10000) return '🦁 LEGEND';
    if (points >= 1000) return '💎 PRO';
    if (points >= 500) return '🔥 ADVANCED';
    if (points >= 200) return '🌱 JUNIOR';
    return '🐣 BEGINNER';
}

// ========== بنك الأسئلة ==========
const jam3Words = {
    سهل: [
        { q: "سر", a: "اسرار" },
        { q: "كتاب", a: "كتب" },
        { q: "قلم", a: "اقلام" },
        { q: "بيت", a: "بيوت" },
        { q: "ولد", a: "اولاد" },
        { q: "مدينة", a: "مدن" },
        { q: "بحر", a: "بحار" },
        { q: "عين", a: "عيون" },
        { q: "باب", a: "ابواب" },
        { q: "شارع", a: "شوارع" },
        { q: "مسجد", a: "مساجد" },
        { q: "قصة", a: "قصص" },
        { q: "يوم", a: "ايام" },
        { q: "شهر", a: "شهور" },
        { q: "ساعة", a: "ساعات" },
        { q: "كرسي", a: "كراسي" },
        { q: "صديق", a: "اصدقاء" },
        { q: "جبل", a: "جبال" },
        { q: "نهر", a: "انهار" },
        { q: "زهرة", a: "ازهار" }
    ],
    متوسط: [
        { q: "رجل", a: "رجال" },
        { q: "امرأة", a: "نساء" },
        { q: "طفل", a: "اطفال" },
        { q: "شيخ", a: "شيوخ" },
        { q: "ملك", a: "ملوك" },
        { q: "طريق", a: "طرق" },
        { q: "شخص", a: "اشخاص" },
        { q: "نافذة", a: "نوافذ" },
        { q: "طالب", a: "طلاب" },
        { q: "جندي", a: "جنود" },
        { q: "قائد", a: "قادة" },
        { q: "وزير", a: "وزراء" },
        { q: "مشكلة", a: "مشاكل" },
        { q: "فكرة", a: "افكار" },
        { q: "هدف", a: "اهداف" },
        { q: "لغة", a: "لغات" },
        { q: "قانون", a: "قوانين" },
        { q: "رسالة", a: "رسائل" },
        { q: "ورقة", a: "اوراق" },
        { q: "حديقة", a: "حدائق" }
    ],
    صعب: [
        { q: "رئيس", a: "رؤساء" },
        { q: "امر", a: "اوامر" },
        { q: "سؤال", a: "اسئلة" },
        { q: "جواب", a: "اجوبة" },
        { q: "شيء", a: "اشياء" },
        { q: "صوت", a: "اصوات" },
        { q: "سلاح", a: "اسلحة" },
        { q: "رجل اعمال", a: "رجال اعمال" },
        { q: "حساب", a: "حسابات" },
        { q: "ملف", a: "ملفات" },
        { q: "برنامج", a: "برامج" },
        { q: "موقف", a: "مواقف" },
        { q: "قرار", a: "قرارات" },
        { q: "انسان", a: "بشر" },
        { q: "مرض", a: "امراض" },
        { q: "طبيب", a: "اطباء" },
        { q: "مهندس", a: "مهندسون" },
        { q: "محامي", a: "محامون" },
        { q: "قاضي", a: "قضاة" },
        { q: "معلم", a: "معلمون" }
    ]
};

const rewardMap = { سهل: 50, متوسط: 100, صعب: 200 };
const penaltyMap = { سهل: 30, متوسط: 60, صعب: 100 };

// ========== دالة الإرسال ==========
async function sendMessage(sock, chatId, lines, quoted = null, mentions = []) {
    if (!Array.isArray(lines)) {
        lines = [lines];
    }

    let msg = `🧠 فـعـالـيـة جـمـع الـكـلـمـة 🧠\n`;
    msg += `━━━━━━━━━━━━━━━━━━━━\n`;
    for (const line of lines) {
        msg += `${line}\n`;
    }
    msg += `━━━━━━━━━━━━━━━━━━━━\n`;
    msg += `𝘽𝙔┇𝑴𝑨𝑲𝑰𝑴𝑨`;
    await sock.sendMessage(chatId, { text: msg, mentions }, { quoted: quoted });
}

// ========== الأمر الرئيسي ==========
module.exports = {
    command: ['جمع', 'تجميع'],
    description: '🧠 فعالية جمع كلمة بمستويات (سهل/متوسط/صعب)',
    usage: '.جمع [سهل|متوسط|صعب]',
    category: 'فعاليات',
    example: '.جمع سهل',

    async execute(sock, msg) {
        try {
            const chatId = msg.key.remoteJid;
            const sender = msg.key.participant || msg.participant || msg.key.remoteJid;
            const points = loadJSON(pointsPath);

            const body = msg.message?.conversation || msg.message?.extendedTextMessage?.text || '';
            const parts = body.trim().split(/\s+/);
            const inputLevel = (parts[1] || 'سهل').trim();

            const validLevels = ['سهل', 'متوسط', 'صعب'];
            if (!validLevels.includes(inputLevel)) {
                const lines = [
                    '❌ *المستوى غير صحيح!*',
                    '',
                    '📖 *المستويات المتاحة:*',
                    '🟢 سهل - 50 نقطة',
                    '🟡 متوسط - 100 نقطة',
                    '🔴 صعب - 200 نقطة',
                    '',
                    '💡 مثال: .جمع سهل'
                ];
                await sendMessage(sock, chatId, lines, msg, [sender]);
                return;
            }

            const chosen = jam3Words[inputLevel][Math.floor(Math.random() * jam3Words[inputLevel].length)];
            const correctAnswer = chosen.a.trim().toLowerCase();
            const reward = rewardMap[inputLevel];
            const penalty = penaltyMap[inputLevel];

            // إرسال السؤال
            const lines = [
                `📚 المستوى: *${inputLevel}*`,
                '',
                `❓ ما هو جمع كلمة:`,
                `「 ${chosen.q} 」`,
                '',
                `⏳ الوقت: 20 ثانية`,
                `💰 الجائزة: ${reward} نقطة`,
                `💔 الخسارة: -${penalty} نقطة`,
                '',
                `📝 اكتب الإجابة`
            ];

            await sendMessage(sock, chatId, lines, msg, [sender]);

            let finished = false;

            const handler = async ({ messages }) => {
                if (finished) return;
                for (const m of messages) {
                    if (m.key.remoteJid !== chatId) continue;
                    const winner = m.key.participant || m.participant || m.key.remoteJid;
                    const txt = m.message?.conversation || m.message?.extendedTextMessage?.text || '';
                    if (!txt) continue;

                    if (txt.trim().toLowerCase() === correctAnswer) {
                        finished = true;
                        clearTimeout(timeout);
                        sock.ev.off('messages.upsert', handler);

                        points[winner] = (points[winner] || 0) + reward;
                        saveJSON(pointsPath, points);

                        const resultLines = [
                            `🎉 *إجابة صحيحة!*`,
                            '',
                            `📖 ${chosen.q} ⇢ ${chosen.a}`,
                            '',
                            `🏆 الفائز: @${winner.split('@')[0]}`,
                            `💰 +${reward} نقطة`,
                            `📊 نقاطك: ${points[winner]}`,
                            `🏅 رتبتك: ${getLevel(points[winner])}`,
                            '',
                            `🥳 تهانينا!`
                        ];
                        await sendMessage(sock, chatId, resultLines, m, [winner]);
                        return;
                    }
                }
            };

            sock.ev.on('messages.upsert', handler);

            const timeout = setTimeout(async () => {
                if (finished) return;
                finished = true;
                sock.ev.off('messages.upsert', handler);

                // خصم من جميع المشاركين
                const metadata = await sock.groupMetadata(chatId);
                let deductedCount = 0;

                for (const participant of metadata.participants) {
                    const jid = participant.id;
                    if (jid !== sock.user.id) {
                        points[jid] = Math.max(0, (points[jid] || 0) - penalty);
                        deductedCount++;
                    }
                }

                saveJSON(pointsPath, points);

                const penaltyLines = [
                    `⏰ *انتهى الوقت!*`,
                    '',
                    `📖 الإجابة الصحيحة: ${chosen.q} ⇢ ${chosen.a}`,
                    '',
                    `💔 تم خصم ${penalty} نقطة`,
                    '',
                    `📌 حاول مرة أخرى مع .جمع`
                ];
                await sendMessage(sock, chatId, penaltyLines, msg);
            }, 20000);

        } catch (error) {
            console.error('✗ خطأ في أمر جمع:', error);
            await sendMessage(sock, msg.key.remoteJid, [
                '❌ حدث خطأ أثناء تنفيذ الأمر.',
                '📌 حاول مرة أخرى لاحقاً.'
            ], msg);
        }
    }
};