// مغارة.js - استكشاف مغارة مظلمة (مخاطرة عالية، مكافآت كبيرة) - مع تايمر موثوق
const fs = require('fs');
const path = require('path');

const dataDir = path.join(__dirname, '../data/kingdom');
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

const MAIN_PATH = path.join(dataDir, 'main.json');
const TIMERS_PATH = path.join(dataDir, 'timers.json');

const allPaths = [MAIN_PATH, TIMERS_PATH];
for (const p of allPaths) {
    if (!fs.existsSync(p)) fs.writeFileSync(p, JSON.stringify({}, null, 2));
}

function loadJSON(file) { try { return JSON.parse(fs.readFileSync(file)); } catch { return {}; } }
function saveJSON(file, data) {
    try {
        fs.writeFileSync(file, JSON.stringify(data, null, 2));
        JSON.parse(fs.readFileSync(file));
        return true;
    } catch (e) {
        console.error('❌ فشل حفظ:', file, e.message);
        return false;
    }
}

function loadUserData(jid) {
    const main = loadJSON(MAIN_PATH)[jid] || {};
    const timers = loadJSON(TIMERS_PATH)[jid] || {};
    return {
        level: main.level || 1,
        gold: main.gold || 0,
        lastMine: timers.lastMine || 0,
        mineCount: timers.mineCount || 0,
        lastSea: timers.lastSea || 0,
        seaCount: timers.seaCount || 0,
        lastForest: timers.lastForest || 0,
        forestCount: timers.forestCount || 0,
        lastDungeon: timers.lastDungeon || 0,
        dungeonCount: timers.dungeonCount || 0
    };
}

function saveUserData(jid, data) {
    const main = loadJSON(MAIN_PATH);
    main[jid] = { level: data.level || 1, gold: data.gold || 0 };
    saveJSON(MAIN_PATH, main);

    const timers = loadJSON(TIMERS_PATH);
    if (!timers[jid]) timers[jid] = {};
    timers[jid] = {
        ...timers[jid],
        lastMine: data.lastMine || 0,
        mineCount: data.mineCount || 0,
        lastSea: data.lastSea || 0,
        seaCount: data.seaCount || 0,
        lastForest: data.lastForest || 0,
        forestCount: data.forestCount || 0,
        lastDungeon: data.lastDungeon || 0,
        dungeonCount: data.dungeonCount || 0
    };
    saveJSON(TIMERS_PATH, timers);
}

function userExists(jid) { return !!loadJSON(MAIN_PATH)[jid]; }

async function sendMessage(sock, chatId, lines, quoted = null, mentions = []) {
    if (!Array.isArray(lines)) lines = [lines];
    let msg = `🕯️ اسـتـكـشـاف مـغـارة 🕯️\n━━━━━━━━━━━━━━━━━━━━\n`;
    for (const line of lines) msg += `${line}\n`;
    msg += `━━━━━━━━━━━━━━━━━━━━\n𝘽𝙔┇𝑴𝑨𝑲𝑰𝑴𝑨`;
    await sock.sendMessage(chatId, { text: msg, mentions }, { quoted: quoted });
}

module.exports = {
    command: 'مغارة',
    description: '🕯️ استكشاف مغارة مظلمة (مخاطرة عالية، مكافآت كبيرة)',
    category: 'مملكة',
    usage: '.مغارة',
    async execute(sock, msg) {
        try {
            const chatId = msg.key.remoteJid;
            const sender = msg.key.participant || msg.key.remoteJid;

            if (!userExists(sender)) {
                await sendMessage(sock, chatId, ['❌ ليس لديك مملكة!'], msg, [sender]);
                return;
            }

            const user = loadUserData(sender);
            const now = Date.now();
            if (user.lastDungeon && (now - user.lastDungeon) < 24 * 60 * 60 * 1000) {
                const remaining = 24 * 60 * 60 * 1000 - (now - user.lastDungeon);
                const hours = Math.floor(remaining / (60 * 60 * 1000));
                await sendMessage(sock, chatId, [
                    `⏳ انتظر ${hours} ساعة قبل استكشاف المغارة مرة أخرى.`
                ], msg, [sender]);
                return;
            }

            const successRate = Math.min(0.8, 0.2 + (user.level * 0.01));
            const success = Math.random() < successRate;

            let details = '';
            const pointsPath = path.join(__dirname, '../data/points.json');
            const pts = loadJSON(pointsPath);

            if (success) {
                const goldBonus = Math.floor(Math.random() * 500) + (user.level * 2);
                const pointsBonus = Math.floor(Math.random() * 200) + (user.level * 3);
                const weapon = Math.random() < 0.3 ? 'eternalBlade' : null;

                user.gold = (user.gold || 0) + goldBonus;
                pts[sender] = (pts[sender] || 0) + pointsBonus;
                details = `🪙 ذهب +${goldBonus}\n💰 نقاط +${pointsBonus}`;
                if (weapon) {
                    const weaponsPath = path.join(__dirname, '../data/kingdom/weapons.json');
                    const weapons = loadJSON(weaponsPath);
                    weapons[sender] = weapons[sender] || {};
                    weapons[sender][weapon] = (weapons[sender][weapon] || 0) + 1;
                    saveJSON(weaponsPath, weapons);
                    details += `\n🗡️ حصلت على نصل الأبدية!`;
                }
            } else {
                const loss = Math.floor(Math.random() * 100) + 20;
                user.gold = Math.max(0, (user.gold || 0) - loss);
                details = `💔 فشلت في استكشاف المغارة! خسرت ${loss} ذهب.`;
            }

            user.lastDungeon = now;
            user.dungeonCount = (user.dungeonCount || 0) + 1;
            saveUserData(sender, user);
            saveJSON(pointsPath, pts);

            await sendMessage(sock, chatId, [
                success ? '✅ نجحت في استكشاف المغارة!' : '❌ فشلت في استكشاف المغارة!',
                details,
                `📊 عدد المحاولات: ${user.dungeonCount}`
            ], msg, [sender]);

        } catch (error) {
            console.error('✗ خطأ في مغارة:', error);
            await sendMessage(sock, msg.key.remoteJid, ['❌ حدث خطأ.'], msg);
        }
    }
};