// مملكتي.js - عرض مملكتك مع قائمة الأوامر السريعة (نسخة محدثة مع دعم الفرق والدروع ونظام التطور الجديد) - متوافقة مع نظام التخزين المنفصل
const fs = require('fs');
const path = require('path');

const pointsPath = path.join(__dirname, '../data/points.json');
const teamsPath = path.join(__dirname, '../data/teams.json');
const treatiesPath = path.join(__dirname, '../data/treaties.json');

// ===== مسارات التخزين المنفصل =====
const dataDir = path.join(__dirname, '../data/kingdom');
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

const MAIN_PATH = path.join(dataDir, 'main.json');
const RESOURCES_PATH = path.join(dataDir, 'resources.json');
const BUILDINGS_PATH = path.join(dataDir, 'buildings.json');
const SOLDIERS_PATH = path.join(dataDir, 'soldiers.json');
const WEAPONS_PATH = path.join(dataDir, 'weapons.json');
const ACCESSORIES_PATH = path.join(dataDir, 'accessories.json');
const POTIONS_PATH = path.join(dataDir, 'potions.json');
const SPELLS_PATH = path.join(dataDir, 'spells.json');
const STATS_PATH = path.join(dataDir, 'stats.json');
const ACTIVE_PATH = path.join(dataDir, 'active.json');
const SOULBOOK_PATH = path.join(dataDir, 'soulbook.json');
const COMPANION_PATH = path.join(dataDir, 'companion.json');

// ===== التأكد من وجود جميع الملفات =====
const allPaths = [MAIN_PATH, RESOURCES_PATH, BUILDINGS_PATH, SOLDIERS_PATH, WEAPONS_PATH, ACCESSORIES_PATH, POTIONS_PATH, SPELLS_PATH, STATS_PATH, ACTIVE_PATH, SOULBOOK_PATH, COMPANION_PATH];
for (const p of allPaths) {
    if (!fs.existsSync(p)) fs.writeFileSync(p, JSON.stringify({}, null, 2));
}

function loadJSON(file) { try { return JSON.parse(fs.readFileSync(file)); } catch { return {}; } }
function saveJSON(file, data) { 
    try {
        if (fs.existsSync(file)) fs.writeFileSync(file + '.bak', fs.readFileSync(file));
        fs.writeFileSync(file, JSON.stringify(data, null, 2));
        return true;
    } catch (e) {
        console.error('❌ فشل حفظ:', file, e.message);
        return false;
    }
}

// ========== دوال التخزين المنفصل ==========
function loadUserData(jid) {
    const main = loadJSON(MAIN_PATH)[jid] || {};
    const resources = loadJSON(RESOURCES_PATH)[jid] || {};
    const buildings = loadJSON(BUILDINGS_PATH)[jid] || {};
    const soldiers = loadJSON(SOLDIERS_PATH)[jid] || {};
    const weapons = loadJSON(WEAPONS_PATH)[jid] || {};
    const accessories = loadJSON(ACCESSORIES_PATH)[jid] || {};
    const potions = loadJSON(POTIONS_PATH)[jid] || {};
    const spells = loadJSON(SPELLS_PATH)[jid] || {};
    const stats = loadJSON(STATS_PATH)[jid] || {};
    const active = loadJSON(ACTIVE_PATH)[jid] || {};
    const soulBook = loadJSON(SOULBOOK_PATH)[jid] || {};
    const companion = loadJSON(COMPANION_PATH)[jid] || null;

    return {
        level: main.level || 1,
        prosperity: main.prosperity || 0,
        lands: main.lands || 0,
        gold: main.gold || 0,
        name: main.name || `مملكة @${jid.split('@')[0]}`,
        owner: main.owner || jid,
        nameChangesUsed: main.nameChangesUsed || 0,
        resources: resources,
        buildings: buildings,
        soldiers: soldiers,
        weapons: weapons,
        accessories: accessories,
        potions: potions,
        spellsUsed: spells,
        soulBook: soulBook,
        companion: companion,
        pvpWins: stats.pvpWins || 0,
        pvpLosses: stats.pvpLosses || 0,
        monstersDefeated: stats.monstersDefeated || 0,
        lastActive: active.lastActive || 0,
        lastDaily: active.lastDaily || 0,
        lastAttack: active.lastAttack || 0,
        attacksToday: active.attacksToday || 0,
        lastAttackReset: active.lastAttackReset || 0,
        attackRestStage: active.attackRestStage || 0,
        attackRestStartTime: active.attackRestStartTime || 0,
        attackCountSinceRest: active.attackCountSinceRest || 0,
        lastMonsterFight: active.lastMonsterFight || 0,
        monsterFightCount: active.monsterFightCount || 0,
        restStage: active.restStage || 0,
        restStartTime: active.restStartTime || 0,
        lastSpellReset: active.lastSpellReset || 0,
        totalSpellsUsedWeekly: active.totalSpellsUsedWeekly || 0,
        upgradeCountToday: active.upgradeCountToday || 0,
        lastUpgradeReset: active.lastUpgradeReset || 0,
        upgradeRestStage: active.upgradeRestStage || 0,
        upgradeRestStartTime: active.upgradeRestStartTime || 0,
        upgradeCountSinceRest: active.upgradeCountSinceRest || 0,
        spellEffects: active.spellEffects || {}
    };
}

function saveUserData(jid, data) {
    const main = loadJSON(MAIN_PATH);
    main[jid] = {
        level: data.level || 1,
        prosperity: data.prosperity || 0,
        lands: data.lands || 0,
        gold: data.gold || 0,
        name: data.name || `مملكة @${jid.split('@')[0]}`,
        owner: data.owner || jid,
        nameChangesUsed: data.nameChangesUsed || 0
    };
    saveJSON(MAIN_PATH, main);

    const resources = loadJSON(RESOURCES_PATH);
    resources[jid] = data.resources || { wood: 0, stone: 0, iron: 0 };
    saveJSON(RESOURCES_PATH, resources);

    const buildings = loadJSON(BUILDINGS_PATH);
    buildings[jid] = data.buildings || {};
    saveJSON(BUILDINGS_PATH, buildings);

    const soldiers = loadJSON(SOLDIERS_PATH);
    soldiers[jid] = data.soldiers || {};
    saveJSON(SOLDIERS_PATH, soldiers);

    const weapons = loadJSON(WEAPONS_PATH);
    weapons[jid] = data.weapons || {};
    saveJSON(WEAPONS_PATH, weapons);

    const accessories = loadJSON(ACCESSORIES_PATH);
    accessories[jid] = data.accessories || {};
    saveJSON(ACCESSORIES_PATH, accessories);

    const potions = loadJSON(POTIONS_PATH);
    potions[jid] = data.potions || {};
    saveJSON(POTIONS_PATH, potions);

    const spells = loadJSON(SPELLS_PATH);
    spells[jid] = data.spellsUsed || {};
    saveJSON(SPELLS_PATH, spells);

    const stats = loadJSON(STATS_PATH);
    stats[jid] = {
        pvpWins: data.pvpWins || 0,
        pvpLosses: data.pvpLosses || 0,
        monstersDefeated: data.monstersDefeated || 0
    };
    saveJSON(STATS_PATH, stats);

    const active = loadJSON(ACTIVE_PATH);
    active[jid] = {
        lastActive: data.lastActive || Date.now(),
        lastDaily: data.lastDaily || 0,
        lastAttack: data.lastAttack || 0,
        attacksToday: data.attacksToday || 0,
        lastAttackReset: data.lastAttackReset || 0,
        attackRestStage: data.attackRestStage || 0,
        attackRestStartTime: data.attackRestStartTime || 0,
        attackCountSinceRest: data.attackCountSinceRest || 0,
        lastMonsterFight: data.lastMonsterFight || 0,
        monsterFightCount: data.monsterFightCount || 0,
        restStage: data.restStage || 0,
        restStartTime: data.restStartTime || 0,
        lastSpellReset: data.lastSpellReset || 0,
        totalSpellsUsedWeekly: data.totalSpellsUsedWeekly || 0,
        upgradeCountToday: data.upgradeCountToday || 0,
        lastUpgradeReset: data.lastUpgradeReset || 0,
        upgradeRestStage: data.upgradeRestStage || 0,
        upgradeRestStartTime: data.upgradeRestStartTime || 0,
        upgradeCountSinceRest: data.upgradeCountSinceRest || 0,
        spellEffects: data.spellEffects || {}
    };
    saveJSON(ACTIVE_PATH, active);

    const soulBook = loadJSON(SOULBOOK_PATH);
    soulBook[jid] = data.soulBook || { pages: 0, spirits: [] };
    saveJSON(SOULBOOK_PATH, soulBook);

    const companion = loadJSON(COMPANION_PATH);
    companion[jid] = data.companion || null;
    saveJSON(COMPANION_PATH, companion);
}

function userExists(jid) {
    const main = loadJSON(MAIN_PATH);
    return !!main[jid];
}

// ========== دوال الفرق ==========
function loadTeams() { return loadJSON(teamsPath); }
function saveTeams(data) { saveJSON(teamsPath, data); }
function isPlayerInTeam(jid, teams) {
    for (const [teamName, teamData] of Object.entries(teams)) {
        if (teamData.leader === jid || (teamData.members && teamData.members.includes(jid))) {
            return teamName;
        }
    }
    return null;
}
function getTeam(teamName, teams) { return teams[teamName] || null; }

// ========== دوال المعاهدات ==========
function loadTreaties() { return loadJSON(treatiesPath); }
function getTreatiesForPlayer(jid, treaties) {
    const result = [];
    for (const [key, treaty] of Object.entries(treaties)) {
        if (treaty.party1 === jid || treaty.party2 === jid) {
            if (treaty.status === 'accepted') {
                const other = treaty.party1 === jid ? treaty.party2 : treaty.party1;
                const otherUser = loadUserData(other);
                const otherName = otherUser?.name || `@${other.split('@')[0]}`;
                result.push({ id: key, with: other, name: otherName, since: treaty.acceptedAt });
            }
        }
    }
    return result;
}

// ========== دوال الإحصائيات ==========
function calculateStats(level, soldiers, weapons, accessories) {
    soldiers = soldiers || {};
    weapons = weapons || {};
    accessories = accessories || {};

    let baseHealth = 100 + (level - 1) * 20;
    let baseAttack = 10 + (level - 1) * 5;
    let baseDefense = 5 + (level - 1) * 3;

    let totalAttack = baseAttack
        + (soldiers.normal || 0) * 2
        + (soldiers.knight || 0) * 5
        + (soldiers.archer || 0) * 4
        + (soldiers.eliteGuard || 0) * 8
        + (soldiers.dragonSpearman || 0) * 15
        + (soldiers.legendaryCommander || 0) * 30
        + (weapons.ironSword || 0) * 10
        + (weapons.legendaryBow || 0) * 20
        + (weapons.lightningSword || 0) * 40
        + (weapons.giantHammer || 0) * 60
        + (weapons.deathBow || 0) * 80
        + (weapons.destructionAxe || 0) * 100
        + (weapons.heroSword || 0) * 50
        + (weapons.timeBow || 0) * 70
        + (weapons.eternalBlade || 0) * 120
        + (accessories.powerRing || 0) * 10
        + (accessories.kingsCrown || 0) * 30
        + (accessories.heroMask || 0) * 20;

    let totalDefense = baseDefense
        + (soldiers.knight || 0) * 2
        + (soldiers.eliteGuard || 0) * 4
        + (soldiers.dragonSpearman || 0) * 8
        + (soldiers.legendaryCommander || 0) * 15
        + (weapons.goldenShield || 0) * 15
        + (weapons.fireShield || 0) * 40
        + (weapons.godShield || 0) * 80
        + (accessories.protectionRing || 0) * 10
        + (accessories.kingsCrown || 0) * 30
        + (accessories.shadowMask || 0) * 15
        + (accessories.heroMask || 0) * 20;

    return { health: baseHealth, attack: totalAttack, defense: totalDefense };
}

function getUpgradeCost(level) { return 500 + (level * 50); }

// ========== دوال نظام التطور (الحد اليومي والاستراحة) ==========
const MAX_UPGRADE_USAGE_PER_DAY = 500;
const REST_TIME_MS = 10 * 60 * 1000; // 10 دقائق

function getRemainingUpgradesToday(user) {
    const today = new Date().toDateString();
    const lastResetDate = user.lastUpgradeReset ? new Date(user.lastUpgradeReset).toDateString() : null;
    if (lastResetDate !== today) {
        return MAX_UPGRADE_USAGE_PER_DAY;
    }
    const used = user.upgradeCountToday || 0;
    return Math.max(0, MAX_UPGRADE_USAGE_PER_DAY - used);
}

function getUpgradeRestStatus(user) {
    const now = Date.now();
    const stage = user.upgradeRestStage || 0;
    const startTime = user.upgradeRestStartTime || 0;
    if (stage === 1) {
        const elapsed = now - startTime;
        if (elapsed >= REST_TIME_MS) {
            return { inRest: false, remaining: 0 };
        } else {
            return { inRest: true, remaining: REST_TIME_MS - elapsed };
        }
    }
    return { inRest: false, remaining: 0 };
}

// ========== دوال الدروع ==========
const SHIELD_TYPES = {
    goldenShield: { name: '🛡️ درع ذهبي', absorbPercent: 0.15 },
    fireShield: { name: '🔥 درع النار', absorbPercent: 0.25 },
    godShield: { name: '✨ درع الآلهة', absorbPercent: 0.40 }
};

function getShieldCounts(user) {
    const weapons = user.weapons || {};
    const counts = {};
    for (const [key, info] of Object.entries(SHIELD_TYPES)) {
        counts[key] = weapons[key] || 0;
    }
    return counts;
}

// ========== تنسيق الوقت ==========
function formatTime(ms) {
    const seconds = Math.floor(ms / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);
    if (days > 0) return `${days} يوم ${hours % 24} ساعة ${minutes % 60} دقيقة ${seconds % 60} ثانية`;
    if (hours > 0) return `${hours} ساعة ${minutes % 60} دقيقة ${seconds % 60} ثانية`;
    if (minutes > 0) return `${minutes} دقيقة ${seconds % 60} ثانية`;
    return `${seconds} ثانية`;
}

// ========== دالة تصحيح بيانات المستخدم ==========
function sanitizeUser(user) {
    if (!user) return null;
    if (user.level === undefined || user.level === null) user.level = 1;
    if (user.prosperity === undefined || user.prosperity === null) user.prosperity = 0;
    if (user.lands === undefined || user.lands === null) user.lands = 0;
    if (user.gold === undefined || user.gold === null) user.gold = 0;
    if (user.monstersDefeated === undefined || user.monstersDefeated === null) user.monstersDefeated = 0;
    if (user.pvpWins === undefined || user.pvpWins === null) user.pvpWins = 0;
    if (user.pvpLosses === undefined || user.pvpLosses === null) user.pvpLosses = 0;
    if (user.name === undefined || user.name === null) user.name = null;
    if (user.nameChangesUsed === undefined || user.nameChangesUsed === null) user.nameChangesUsed = 0;

    if (user.upgradeCountToday === undefined || user.upgradeCountToday === null) user.upgradeCountToday = 0;
    if (user.lastUpgradeReset === undefined || user.lastUpgradeReset === null) user.lastUpgradeReset = 0;
    if (user.upgradeRestStage === undefined || user.upgradeRestStage === null) user.upgradeRestStage = 0;
    if (user.upgradeRestStartTime === undefined || user.upgradeRestStartTime === null) user.upgradeRestStartTime = 0;
    if (user.upgradeCountSinceRest === undefined || user.upgradeCountSinceRest === null) user.upgradeCountSinceRest = 0;

    if (!user.resources) user.resources = { wood: 0, stone: 0, iron: 0 };
    if (user.resources.wood === undefined || user.resources.wood === null) user.resources.wood = 0;
    if (user.resources.stone === undefined || user.resources.stone === null) user.resources.stone = 0;
    if (user.resources.iron === undefined || user.resources.iron === null) user.resources.iron = 0;

    if (!user.buildings) user.buildings = { barracks: { level: 0 }, quarry: { level: 0 }, lumberMill: { level: 0 }, ironMine: { level: 0 } };
    if (user.buildings.barracks === undefined) user.buildings.barracks = { level: 0 };
    if (user.buildings.quarry === undefined) user.buildings.quarry = { level: 0 };
    if (user.buildings.lumberMill === undefined) user.buildings.lumberMill = { level: 0 };
    if (user.buildings.ironMine === undefined) user.buildings.ironMine = { level: 0 };
    if (user.buildings.barracks.level === undefined || user.buildings.barracks.level === null) user.buildings.barracks.level = 0;
    if (user.buildings.quarry.level === undefined || user.buildings.quarry.level === null) user.buildings.quarry.level = 0;
    if (user.buildings.lumberMill.level === undefined || user.buildings.lumberMill.level === null) user.buildings.lumberMill.level = 0;
    if (user.buildings.ironMine.level === undefined || user.buildings.ironMine.level === null) user.buildings.ironMine.level = 0;

    if (!user.soldiers) user.soldiers = {};
    const soldierTypes = ['normal', 'knight', 'archer', 'eliteGuard', 'dragonSpearman', 'legendaryCommander'];
    for (const t of soldierTypes) if (user.soldiers[t] === undefined || user.soldiers[t] === null) user.soldiers[t] = 0;

    if (!user.weapons) user.weapons = {};
    const weaponTypes = ['ironSword', 'goldenShield', 'legendaryBow', 'lightningSword', 'giantHammer', 'deathBow', 'destructionAxe', 'heroSword', 'timeBow', 'eternalBlade', 'fireShield', 'godShield'];
    for (const t of weaponTypes) if (user.weapons[t] === undefined || user.weapons[t] === null) user.weapons[t] = 0;

    if (!user.accessories) user.accessories = {};
    const accessoryTypes = ['powerRing', 'protectionRing', 'kingsCrown', 'shadowMask', 'heroMask'];
    for (const t of accessoryTypes) if (user.accessories[t] === undefined || user.accessories[t] === null) user.accessories[t] = 0;

    if (!user.potions) user.potions = {};
    const potionTypes = ['smallHeal', 'largeHeal', 'energyPotion', 'craftedHeal'];
    for (const t of potionTypes) if (user.potions[t] === undefined || user.potions[t] === null) user.potions[t] = 0;

    if (!user.soulBook) user.soulBook = { pages: 0, spirits: [] };
    if (user.soulBook.pages === undefined || user.soulBook.pages === null) user.soulBook.pages = 0;
    if (!user.soulBook.spirits) user.soulBook.spirits = [];

    if (!user.companion) user.companion = null;

    user.lastActive = Date.now();
    return user;
}

// ========== دالة الإرسال ==========
async function sendMessage(sock, chatId, lines, quoted = null, mentions = []) {
    if (!Array.isArray(lines)) {
        lines = [lines];
    }
    
    let msg = `🏰 مـمـلـكـتـي الـعـمـلاقـة 🏰\n`;
    msg += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
    for (const line of lines) {
        msg += `${line}\n`;
    }
    msg += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
    msg += `𝘽𝙔┇𝑴𝑨𝑲𝑰𝑴𝑨`;
    await sock.sendMessage(chatId, { text: msg, mentions }, { quoted: quoted });
}

module.exports = {
    command: 'مملكتي',
    description: '🏰 عرض مملكتك العملاقة مع قائمة الأوامر السريعة',
    category: 'مملكة',
    async execute(sock, msg) {
        try {
            const chatId = msg.key.remoteJid;
            const sender = msg.key.participant || msg.participant || msg.key.remoteJid;
            
            const points = loadJSON(pointsPath);
            const teams = loadTeams();
            const treaties = loadTreaties();
            
            // ===== تحميل بيانات المستخدم من النظام المنفصل =====
            if (!userExists(sender)) {
                await sendMessage(sock, chatId, [
                    `❌ @${sender.split('@')[0]}، ليس لديك مملكة.`,
                    '📌 استخدم .لاعب جديد لتأسيس مملكتك.'
                ], msg, [sender]);
                return;
            }
            
            let user = loadUserData(sender);
            user = sanitizeUser(user);
            saveUserData(sender, user);
            
            // ===== معلومات الفريق =====
            const teamName = isPlayerInTeam(sender, teams);
            let teamInfo = 'لا يوجد';
            let teamLeader = '';
            let teamMembersCount = 0;
            if (teamName) {
                const team = getTeam(teamName, teams);
                if (team) {
                    teamInfo = teamName;
                    teamLeader = team.leader;
                    teamMembersCount = (team.members || []).length + 1;
                }
            }
            
            // ===== معلومات المعاهدات =====
            const playerTreaties = getTreatiesForPlayer(sender, treaties);
            let treatiesInfo = 'لا يوجد';
            if (playerTreaties.length > 0) {
                treatiesInfo = playerTreaties.map(t => {
                    return `${t.name} (منذ ${new Date(t.since).toLocaleDateString()})`;
                }).join(' | ');
            }
            
        // ===== معلومات التطور =====
            const remainingUpgrades = getRemainingUpgradesToday(user);
            const restStatus = getUpgradeRestStatus(user);
            let upgradeStatus = `📊 متبقي اليوم: ${remainingUpgrades}`;
            if (restStatus.inRest) {
                upgradeStatus += `\n⏳ استراحة: ${formatTime(restStatus.remaining)}`;
            }
            
            // ===== معلومات الدروع =====
            const shieldCounts = getShieldCounts(user);
            const shieldLines = [];
            for (const [key, count] of Object.entries(shieldCounts)) {
                if (count > 0) {
                    const info = SHIELD_TYPES[key];
                    shieldLines.push(`${info.name}: ${count} (يمتص ${Math.round(info.absorbPercent*100)}%)`);
                }
            }
            const shieldDisplay = shieldLines.length > 0 ? shieldLines.join(' | ') : 'لا يوجد';
            
            // ===== الإحصائيات الأساسية =====
            const stats = calculateStats(user.level, user.soldiers, user.weapons, user.accessories);
            let playerPoints = points[sender] || 0;
            const pointsDisplay = playerPoints > 999999 ? playerPoints.toLocaleString() : playerPoints.toString();
            const nextCost = getUpgradeCost(user.level);
            const companionName = user.companion ? user.companion.name : 'لا يوجد';
            const soulPages = user.soulBook?.pages || 0;
            const kingdomName = user.name || `مملكة @${sender.split('@')[0]}`;
            
            const lines = [
                `👑 *${kingdomName}*`,
                ``,
                `✍️ المالك: @${sender.split('@')[0]}`,
                `✨ المستوى: ${user.level}`,
                `📈 الازدهار: ${user.prosperity} 💎`,
                `🗺️ الأراضي: ${user.lands} أرض`,
                `❤️ الصحة: ${stats.health}`,
                `⚔️ الهجوم: ${stats.attack}`,
                `🛡️ الدفاع: ${stats.defense}`,
                `💰 نقاطك: ${pointsDisplay}`,
                `🐉 وحوش هزمتها: ${user.monstersDefeated}`,
                `🐦 الرفيق: ${companionName}`,
                `📖 صفحات روحك: ${soulPages}`,
                `🏆 انتصارات PvP: ${user.pvpWins}  |  هزائم: ${user.pvpLosses}`,
                ``,
                `🏴 *الفريق*: ${teamInfo}`,
                `👥 عدد الأعضاء: ${teamMembersCount}`,
                ``,
                `🤝 *المعاهدات*: ${treatiesInfo}`,
                ``,
                `🛡️ *الدروع*: ${shieldDisplay}`,
                ``,
                `📊 *الموارد*: 🪵 ${user.resources.wood} | 🪨 ${user.resources.stone} | ⛏️ ${user.resources.iron}`,
                `🏗️ *المباني*: ثكنات (${user.buildings.barracks.level}) | منشرة (${user.buildings.lumberMill.level}) | مقلع (${user.buildings.quarry.level}) | منجم (${user.buildings.ironMine.level})`,
                ``,
                `📈 تكلفة التطوير: ${nextCost} نقطة`,
                `🔄 التطور: ${upgradeStatus}`,
                ``,
                `📜 *أوامرك السريعة*`,
                `   • .تطور  • .دخل  • .وحش  • .غزو  • .مهمة  • .بنك`,
                `   • .متجر  • .مخزن  • .رفيق  • .كتاب  • .صياغة  • .تصنيفي`,
                `   • .ترتيب  • .تحويل  • .سرقة  • .معاهدة`
            ];

            await sendMessage(sock, chatId, lines, msg, [sender]);

        } catch (error) {
            console.error('✗ خطأ في أمر مملكتي:', error);
            await sendMessage(sock, msg.key.remoteJid, [
                '❌ حدث خطأ أثناء عرض مملكتك.',
                '📌 حاول مرة أخرى لاحقاً.'
            ], msg);
        }
    }
};