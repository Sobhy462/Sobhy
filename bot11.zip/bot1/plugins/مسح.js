// مسح.js - حذف مملكة مستخدم بالكامل مع إزالته من الفرق والمعاهدات (للمطورين فقط)
// ✅ يدعم الرد على رسالة المستخدم أو منشنه، مع تأكيد قوي
// ✅ لا يمسح النسخ الاحتياطية (يحتفظ بـ .bak)
const fs = require('fs');
const path = require('path');
const hay = require('../haykala/developer');

// ===== مسارات التخزين المنفصل (نظام الممالك) =====
const dataDir = path.join(__dirname, '../data/kingdom');
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

const MAIN_PATH = path.join(dataDir, 'main.json');
const RESOURCES_PATH = path.join(dataDir, 'resources.json');
const BUILDINGS_PATH = path.join(dataDir, 'buildings.json');
const SOLDIERS_PATH = path.join(dataDir, 'soldiers.json');
const WEAPONS_PATH = path.join(dataDir, 'weapons.json');
const ACCESSORIES_PATH = path.join(dataDir, 'accessories.json');
const POTIONS_PATH = path.join(dataDir, 'potions.json');
const SPELLS_PATH = path.join(dataDir, 'spells.json');
const STATS_PATH = path.join(dataDir, 'stats.json');
const ACTIVE_PATH = path.join(dataDir, 'active.json');
const SOULBOOK_PATH = path.join(dataDir, 'soulbook.json');
const COMPANION_PATH = path.join(dataDir, 'companion.json');
const EXPLORED_CAVES_PATH = path.join(dataDir, 'explored_caves.json');

// ===== مسارات الملفات العامة =====
const pointsPath = path.join(__dirname, '../data/points.json');
const bankPath = path.join(__dirname, '../data/bank.json');
const loansPath = path.join(__dirname, '../data/loans.json');
const teamsPath = path.join(__dirname, '../data/teams.json');
const treatiesPath = path.join(__dirname, '../data/treaties.json');
const questPath = path.join(__dirname, '../data/quests.json');
const stealActivePath = path.join(__dirname, '../data/stealActive.json');
const stealLogsPath = path.join(__dirname, '../data/stealLogs.json');
const hiddenPath = path.join(__dirname, '../data/hidden-points.json');

// ===== التأكد من وجود جميع الملفات =====
const allPaths = [
    MAIN_PATH, RESOURCES_PATH, BUILDINGS_PATH, SOLDIERS_PATH, WEAPONS_PATH,
    ACCESSORIES_PATH, POTIONS_PATH, SPELLS_PATH, STATS_PATH, ACTIVE_PATH,
    SOULBOOK_PATH, COMPANION_PATH, EXPLORED_CAVES_PATH,
    pointsPath, bankPath, loansPath, teamsPath, treatiesPath, questPath,
    stealActivePath, stealLogsPath, hiddenPath
];
for (const p of allPaths) {
    const dir = path.dirname(p);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    if (!fs.existsSync(p)) {
        fs.writeFileSync(p, p.endsWith('.json') ? JSON.stringify({}, null, 2) : '{}');
    }
}

function loadJSON(file) {
    try { return JSON.parse(fs.readFileSync(file)); } catch { return {}; }
}

function saveJSON(file, data) {
    try {
        if (fs.existsSync(file)) {
            if (!fs.existsSync(file + '.bak')) {
                fs.writeFileSync(file + '.bak', fs.readFileSync(file));
            }
        }
        fs.writeFileSync(file, JSON.stringify(data, null, 2));
        return true;
    } catch (e) {
        console.error('❌ فشل حفظ الملف:', file, e.message);
        return false;
    }
}

// ========== دوال مساعدة ==========
function getCleanJid(jid) {
    if (!jid) return '';
    if (jid.includes('@')) return jid.split('@')[0].replace(/[^0-9]/g, '');
    return jid.replace(/[^0-9]/g, '');
}

function extractTarget(msg) {
    // 1. المنشن المباشر
    const contextInfo = msg.message?.extendedTextMessage?.contextInfo || {};
    if (contextInfo.mentionedJid && contextInfo.mentionedJid.length > 0) {
        return contextInfo.mentionedJid[0];
    }
    // 2. الرد على رسالة
    if (contextInfo.participant) {
        return contextInfo.participant;
    }
    // 3. محاولة استخراج رقم من النص (مثال: @123456)
    const text = msg.message?.conversation || msg.message?.extendedTextMessage?.text || '';
    const match = text.match(/@(\d+)/);
    if (match) {
        return `${match[1]}@s.whatsapp.net`;
    }
    return null;
}

function userExists(jid) {
    const main = loadJSON(MAIN_PATH);
    return !!main[jid];
}

// ========== دالة حذف بيانات المستخدم بالكامل ==========
function deleteUserData(jid) {
    let deleted = { kingdom: false, points: 0, bank: 0, loans: 0, team: null, treaty: false };

    // 1. حذف من ملفات التخزين المنفصل
    const kingdomFiles = [
        MAIN_PATH, RESOURCES_PATH, BUILDINGS_PATH, SOLDIERS_PATH, WEAPONS_PATH,
        ACCESSORIES_PATH, POTIONS_PATH, SPELLS_PATH, STATS_PATH, ACTIVE_PATH,
        SOULBOOK_PATH, COMPANION_PATH, EXPLORED_CAVES_PATH
    ];
    for (const file of kingdomFiles) {
        const data = loadJSON(file);
        if (data[jid] !== undefined) {
            delete data[jid];
            saveJSON(file, data);
            if (file === MAIN_PATH) deleted.kingdom = true;
        }
    }

    // 2. حذف النقاط
    const points = loadJSON(pointsPath);
    if (points[jid] !== undefined) {
        deleted.points = points[jid];
        delete points[jid];
        saveJSON(pointsPath, points);
    }

    // 3. حذف البنك
    const bank = loadJSON(bankPath);
    if (bank[jid]) {
        deleted.bank = bank[jid].deposit || 0;
        delete bank[jid];
        saveJSON(bankPath, bank);
    }

    // 4. حذف القروض
    const loans = loadJSON(loansPath);
    if (loans[jid]) {
        deleted.loans = loans[jid].remaining || 0;
        delete loans[jid];
        saveJSON(loansPath, loans);
    }

    // 5. حذف من الفرق
    const teams = loadJSON(teamsPath);
    for (const [teamName, teamData] of Object.entries(teams)) {
        if (teamData.leader === jid) {
            delete teams[teamName];
            deleted.team = { name: teamName, action: 'deleted' };
            saveJSON(teamsPath, teams);
            break;
        } else if (teamData.members && teamData.members.includes(jid)) {
            teamData.members = teamData.members.filter(m => m !== jid);
            deleted.team = { name: teamName, action: 'removed' };
            saveJSON(teamsPath, teams);
            break;
        }
    }

    // 6. حذف من المعاهدات
    const treaties = loadJSON(treatiesPath);
    let treatyDeleted = false;
    for (const [key, treaty] of Object.entries(treaties)) {
        if (treaty.party1 === jid || treaty.party2 === jid) {
            delete treaties[key];
            treatyDeleted = true;
        }
    }
    if (treatyDeleted) {
        deleted.treaty = true;
        saveJSON(treatiesPath, treaties);
    }

    // 7. حذف من المهام
    const quests = loadJSON(questPath);
    if (quests[jid]) {
        delete quests[jid];
        saveJSON(questPath, quests);
    }

    // 8. حذف من السرقات النشطة
    const stealActive = loadJSON(stealActivePath);
    if (stealActive[jid]) {
        delete stealActive[jid];
        saveJSON(stealActivePath, stealActive);
    }

    // 9. حذف من سجلات السرقات (باستخدام الرقم)
    const cleanJid = getCleanJid(jid);
    const logs = loadJSON(stealLogsPath);
    let logsChanged = false;
    for (const [key, log] of Object.entries(logs)) {
        if (log.sender === cleanJid || log.target === cleanJid) {
            delete logs[key];
            logsChanged = true;
        }
    }
    if (logsChanged) {
        saveJSON(stealLogsPath, logs);
    }

    // 10. حذف من قائمة المخفيين (إذا كان موجوداً)
    const hidden = loadJSON(hiddenPath);
    const index = hidden.indexOf(jid);
    if (index !== -1) {
        hidden.splice(index, 1);
        saveJSON(hiddenPath, hidden);
    }

    return deleted;
}

// ========== دالة الإرسال ==========
async function sendMessage(sock, chatId, lines, quoted = null, mentions = []) {
    if (!Array.isArray(lines)) lines = [lines];
    let msg = `🗑️ مـسـح مـمـلـكـة 🗑️\n`;
    msg += `━━━━━━━━━━━━━━━━━━━━\n`;
    for (const line of lines) {
        msg += `${line}\n`;
    }
    msg += `━━━━━━━━━━━━━━━━━━━━\n`;
    msg += `𝘽𝙔┇𝑴𝑨𝑲𝑰𝑴𝑨`;
    await sock.sendMessage(chatId, { text: msg, mentions }, { quoted: quoted });
}

// ========== الأمر الرئيسي ==========
module.exports = {
    command: ['مسح', 'امسح'],
    description: '🗑️ حذف مملكة مستخدم بالكامل + إزالته من الفريق والمعاهدات (للمطورين فقط)',
    category: 'مملكة',
    usage: '.مسح (بالرد على رسالة الشخص) أو .مسح @منشن',
    example: '.مسح @منشن  أو  (رد على رسالة الشخص) .مسح',

    async execute(sock, msg) {
        try {
            const chatId = msg.key.remoteJid;
            const sender = msg.key.participant || msg.participant || msg.key.remoteJid;

            // ===== التحقق من صلاحية المطور =====
            const senderLid = hay.toLid(sender);
            if (!(hay.isFounder(senderLid) || hay.isOwnerbot(senderLid) || hay.isDeveloper(senderLid))) {
                return await sendMessage(sock, chatId, ['🚫 هذا الأمر مخصص للمطورين فقط.'], msg, [sender]);
            }

            // ===== استخراج الهدف (منشن أو رد) =====
            const target = extractTarget(msg);
            if (!target) {
                return await sendMessage(sock, chatId, [
                    '❌ يجب منشن الشخص أو الرد على رسالته.',
                    '📝 مثال: .مسح @منشن',
                    '📝 أو: (رد على رسالة الشخص) .مسح'
                ], msg, [sender]);
            }

            if (target === sender) {
                return await sendMessage(sock, chatId, ['❌ لا يمكنك مسح مملكتك بنفسك.'], msg, [sender]);
            }

            // ===== التحقق من وجود مملكة =====
            if (!userExists(target)) {
                return await sendMessage(sock, chatId, [`❌ @${getCleanJid(target)} ليس لديه مملكة.`], msg, [sender, target]);
            }

            // ===== تأكيد أقوى: يطلب كتابة اسم المستخدم المستهدف =====
            const targetNum = getCleanJid(target);
            await sendMessage(sock, chatId, [
                `⚠️ *تحذير!* أنت على وشك حذف مملكة @${targetNum} نهائياً.`,
                `📌 سيتم حذف: النقاط، البنك، القروض، وجميع بيانات المملكة.`,
                `📌 إذا كان قائد فريق، سيتم حذف الفريق بالكامل.`,
                `📌 إذا كان عضواً، سيتم إخراجه من الفريق.`,
                `📌 سيتم إلغاء جميع معاهداته.`,
                '',
                `🔐 لتأكيد الحذف، اكتب: \`تأكيد حذف ${targetNum}\``,
                `📌 خلال 30 ثانية.`
            ], msg, [sender, target]);

            // ===== معالج التأكيد =====
            const confirmHandler = async ({ messages }) => {
                for (const m of messages) {
                    const from = m.key.participant || m.participant || m.key.remoteJid;
                    if (from !== sender) continue;
                    const txt = m.message?.conversation || m.message?.extendedTextMessage?.text || '';
                    if (txt.trim() === `تأكيد حذف`) {
                        const deleted = deleteUserData(target);
                        const lines = [
                            `✅ تم حذف مملكة @${targetNum} بنجاح.`,
                            '',
                            '📊 *البيانات المحذوفة:*'
                        ];
                        if (deleted.kingdom) lines.push('   🏰 المملكة: تم الحذف');
                        if (deleted.points !== undefined) lines.push(`   💰 النقاط: ${deleted.points}`);
                        if (deleted.bank !== undefined) lines.push(`   🏦 البنك: ${deleted.bank}`);
                        if (deleted.loans !== undefined) lines.push(`   📉 القروض: ${deleted.loans}`);
                        if (deleted.team) {
                            if (deleted.team.action === 'deleted') {
                                lines.push(`   🏴 الفريق "${deleted.team.name}": تم حذفه بالكامل (لأن المستخدم كان قائداً)`);
                            } else {
                                lines.push(`   🏴 الفريق "${deleted.team.name}": تم إخراج المستخدم منه`);
                            }
                        } else {
                            lines.push('   🏴 الفريق: المستخدم ليس في أي فريق');
                        }
                        if (deleted.treaty) {
                            lines.push('   🤝 المعاهدات: تم إلغاء جميع معاهداته');
                        }
                        lines.push('', '📌 يمكن للمستخدم إنشاء مملكة وفريق جديد متى شاء.');
                        await sendMessage(sock, chatId, lines, m, [sender, target]);
                        sock.ev.off('messages.upsert', confirmHandler);
                        return;
                    } else {
                        await sendMessage(sock, chatId, ['❌ تم إلغاء عملية المسح.'], m, [sender]);
                        sock.ev.off('messages.upsert', confirmHandler);
                        return;
                    }
                }
            };

            sock.ev.on('messages.upsert', confirmHandler);
            setTimeout(() => {
                sock.ev.off('messages.upsert', confirmHandler);
            }, 30000);

        } catch (error) {
            console.error('✗ خطأ في أمر مسح:', error);
            await sendMessage(sock, msg.key.remoteJid, [
                '❌ حدث خطأ أثناء تنفيذ الأمر.',
                '📌 حاول مرة أخرى لاحقاً.'
            ], msg);
        }
    }
};