// ايقاف.js - إيقاف البوت في المحادثة (للمطورين فقط)

const fs = require('fs');
const path = require('path');
const { isElite } = require('../haykala/elite.js');

const disabledChatsPath = path.join(__dirname, '..', 'db', 'disabledChats.json');

// ========== دالة الإرسال الموحدة ==========
async function sendMessage(sock, chatId, lines, quoted = null, mentions = []) {
    if (!Array.isArray(lines)) lines = [lines];
    let msg = `⛔ إيـقـاف الـبـوت ⛔\n`;
    msg += `━━━━━━━━━━━━━━━━━━━━\n`;
    for (const line of lines) {
        if (line && line.trim()) msg += `${line}\n`;
    }
    msg += `━━━━━━━━━━━━━━━━━━━━\n`;
    msg += `𝘽𝙔┇𝑴𝑨𝑲𝑰𝑴𝑨`;
    await sock.sendMessage(chatId, { text: msg, mentions }, { quoted });
}

// ========== ضمان وجود الملف ==========
function ensureFile() {
    const dir = path.dirname(disabledChatsPath);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    if (!fs.existsSync(disabledChatsPath)) {
        fs.writeFileSync(disabledChatsPath, JSON.stringify({}, null, 2));
    }
}

// ========== تحميل المحادثات الموقوفة ==========
function loadDisabledChats() {
    ensureFile();
    try {
        return JSON.parse(fs.readFileSync(disabledChatsPath, 'utf8'));
    } catch {
        return {};
    }
}

// ========== حفظ المحادثات الموقوفة ==========
function saveDisabledChats(data) {
    ensureFile();
    fs.writeFileSync(disabledChatsPath, JSON.stringify(data, null, 2));
}

module.exports = {
    command: ['ايقاف'],
    description: '⛔ إيقاف البوت في المحادثة (للمطورين فقط)',
    category: 'خاصة',
    usage: '.ايقاف  ──  إيقاف البوت في المجموعة/الخاص',

    async execute(sock, msg) {
        try {
            const chatId = msg.key.remoteJid;
            const sender = msg.key.participant || msg.key.remoteJid;

            // ===== التحقق من صلاحيات المطور =====
            if (!isElite(sender)) {
                return sendMessage(sock, chatId, [
                    'ذل من لا صلاحيات له 😂🫵'
                ], msg);
            }

            // ===== تحميل البيانات =====
            const disabledChats = loadDisabledChats();

            // ===== التحقق من الحالة =====
            if (disabledChats[chatId]) {
                return sendMessage(sock, chatId, [
                    '⚠️ *البوت موقوف بالفعل*',
                    '',
                    '📌 البوت متوقف في هذه المحادثة.',
                    '📌 استخدم `.تشغيل` لتفعيله مرة أخرى.'
                ], msg);
            }

            // ===== إيقاف البوت =====
            disabledChats[chatId] = true;
            saveDisabledChats(disabledChats);

            await sendMessage(sock, chatId, [
                '✅ *تم الإيقاف بنجاح*',
                '',
                '🔴 البوت متوقف الآن في هذه المحادثة.',
                '📌 استخدم `.تشغيل` لتفعيله مرة أخرى.'
            ], msg);

        } catch (error) {
            console.error('❌ خطأ في أمر ايقاف:', error);
            await sendMessage(sock, msg.key.remoteJid, [
                '❌ *حدث خطأ*',
                '',
                `📝 ${error.message || 'خطأ غير معروف'}`,
                '',
                '📌 حاول مرة أخرى لاحقاً'
            ], msg);
        }
    }
};