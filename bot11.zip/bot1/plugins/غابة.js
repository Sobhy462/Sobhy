// غابة.js - استكشاف الغابة للحصول على موارد نادرة ورفقاء (مع تايمر موثوق)
const fs = require('fs');
const path = require('path');

const dataDir = path.join(__dirname, '../data/kingdom');
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

const MAIN_PATH = path.join(dataDir, 'main.json');
const RESOURCES_PATH = path.join(dataDir, 'resources.json');
const TIMERS_PATH = path.join(dataDir, 'timers.json');

const allPaths = [MAIN_PATH, RESOURCES_PATH, TIMERS_PATH];
for (const p of allPaths) {
    if (!fs.existsSync(p)) fs.writeFileSync(p, JSON.stringify({}, null, 2));
}

function loadJSON(file) { try { return JSON.parse(fs.readFileSync(file)); } catch { return {}; } }
function saveJSON(file, data) {
    try {
        fs.writeFileSync(file, JSON.stringify(data, null, 2));
        JSON.parse(fs.readFileSync(file));
        return true;
    } catch (e) {
        console.error('❌ فشل حفظ:', file, e.message);
        return false;
    }
}

function loadUserData(jid) {
    const main = loadJSON(MAIN_PATH)[jid] || {};
    const resources = loadJSON(RESOURCES_PATH)[jid] || {};
    const timers = loadJSON(TIMERS_PATH)[jid] || {};
    return {
        level: main.level || 1,
        resources: resources,
        lastMine: timers.lastMine || 0,
        mineCount: timers.mineCount || 0,
        lastSea: timers.lastSea || 0,
        seaCount: timers.seaCount || 0,
        lastForest: timers.lastForest || 0,
        forestCount: timers.forestCount || 0,
        lastDungeon: timers.lastDungeon || 0,
        dungeonCount: timers.dungeonCount || 0
    };
}

function saveUserData(jid, data) {
    const main = loadJSON(MAIN_PATH);
    main[jid] = { level: data.level || 1 };
    saveJSON(MAIN_PATH, main);

    const resources = loadJSON(RESOURCES_PATH);
    resources[jid] = data.resources || {};
    saveJSON(RESOURCES_PATH, resources);

    const timers = loadJSON(TIMERS_PATH);
    if (!timers[jid]) timers[jid] = {};
    timers[jid] = {
        ...timers[jid],
        lastMine: data.lastMine || 0,
        mineCount: data.mineCount || 0,
        lastSea: data.lastSea || 0,
        seaCount: data.seaCount || 0,
        lastForest: data.lastForest || 0,
        forestCount: data.forestCount || 0,
        lastDungeon: data.lastDungeon || 0,
        dungeonCount: data.dungeonCount || 0
    };
    saveJSON(TIMERS_PATH, timers);
}

function userExists(jid) { return !!loadJSON(MAIN_PATH)[jid]; }

async function sendMessage(sock, chatId, lines, quoted = null, mentions = []) {
    if (!Array.isArray(lines)) lines = [lines];
    let msg = `🌳 اسـتـكـشـاف الـغـابـة 🌳\n━━━━━━━━━━━━━━━━━━━━\n`;
    for (const line of lines) msg += `${line}\n`;
    msg += `━━━━━━━━━━━━━━━━━━━━\n𝘽𝙔┇𝑴𝑨𝑲𝑰𝑴𝑨`;
    await sock.sendMessage(chatId, { text: msg, mentions }, { quoted: quoted });
}

module.exports = {
    command: 'غابة',
    description: '🌳 استكشاف الغابة للحصول على خشب نادر ورفقاء',
    category: 'مملكة',
    usage: '.غابة',
    async execute(sock, msg) {
        try {
            const chatId = msg.key.remoteJid;
            const sender = msg.key.participant || msg.key.remoteJid;

            if (!userExists(sender)) {
                await sendMessage(sock, chatId, ['❌ ليس لديك مملكة!'], msg, [sender]);
                return;
            }

            const user = loadUserData(sender);
            const now = Date.now();
            if (user.lastForest && (now - user.lastForest) < 4 * 60 * 60 * 1000) {
                const remaining = 4 * 60 * 60 * 1000 - (now - user.lastForest);
                const hours = Math.floor(remaining / (60 * 60 * 1000));
                const mins = Math.floor((remaining % (60 * 60 * 1000)) / (60 * 1000));
                await sendMessage(sock, chatId, [
                    `⏳ انتظر ${hours} ساعة ${mins} دقيقة قبل استكشاف الغابة مرة أخرى.`
                ], msg, [sender]);
                return;
            }

            const level = user.level;
            const woodBonus = Math.floor(level * 0.6) + 20;
            const rareWood = Math.random() < 0.2 ? Math.floor(level * 0.1) + 2 : 0;
            const companion = Math.random() < 0.1 ? 'ذئب الغابة' : null;

            user.resources.wood = (user.resources.wood || 0) + woodBonus;
            let extra = '';
            if (rareWood > 0) {
                user.resources.rareWood = (user.resources.rareWood || 0) + rareWood;
                extra = `🪵 خشب نادر +${rareWood}\n`;
            }
            if (companion) {
                const companionPath = path.join(__dirname, '../data/kingdom/companion.json');
                const comp = loadJSON(companionPath);
                comp[sender] = companion;
                saveJSON(companionPath, comp);
                extra += `🐺 حصلت على رفيق: ${companion}!`;
            }

            user.lastForest = now;
            user.forestCount = (user.forestCount || 0) + 1;
            saveUserData(sender, user);

            await sendMessage(sock, chatId, [
                `🌳 استكشفت الغابة!`,
                `🪵 خشب عادي +${woodBonus}`,
                extra || '',
                `📊 عدد المرات: ${user.forestCount}`
            ], msg, [sender]);

        } catch (error) {
            console.error('✗ خطأ في غابة:', error);
            await sendMessage(sock, msg.key.remoteJid, ['❌ حدث خطأ.'], msg);
        }
    }
};