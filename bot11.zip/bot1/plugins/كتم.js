// كتم.js - كتم أو إلغاء كتم الأعضاء في المجموعة (صلاحيات متدرجة)

const fs = require('fs');
const path = require('path');
const { isElite } = require('../haykala/elite.js');
const { isDeveloper, isOwnerbot, isFounder } = require('../haykala/developer.js');
const { jidDecode } = require('@whiskeysockets/baileys');

const dataDir = path.join(__dirname, '..', 'data');
const muteFilePath = path.join(dataDir, 'muted.json');

if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });
if (!fs.existsSync(muteFilePath)) fs.writeFileSync(muteFilePath, JSON.stringify([]));

// ========== دالة الإرسال الموحدة ==========
async function sendMessage(sock, chatId, lines, quoted = null, mentions = []) {
    if (!Array.isArray(lines)) lines = [lines];

    let msg = `🔇 الـكـتـم إدارة المجموعة 🔇\n`;
    msg += `━━━━━━━━━━━━━━━━━━━━\n`;
    for (const line of lines) {
        if (line && line.trim()) msg += `${line}\n`;
    }
    msg += `━━━━━━━━━━━━━━━━━━━━\n`;
    msg += `𝘽𝙔┇𝑴𝑨𝑲𝑰𝑴𝑨`;

    await sock.sendMessage(chatId, { text: msg, mentions }, { quoted: quoted });
}
// =========================================

// ========== دوال مساعدة ==========
function getRealNumber(jid) {
    if (!jid) return 'غير معروف';
    
    // محاولة فك الـ JID
    try {
        const decoded = jidDecode(jid);
        if (decoded?.user) {
            // استخراج الرقم من المستخدم
            const user = decoded.user;
            // إزالة أي بادئة مثل 0 أو 91
            const num = user.replace(/[^0-9]/g, '');
            // إذا كان الرقم يبدأ بـ 0 نزيله
            return num.replace(/^0+/, '');
        }
    } catch {}
    
    // محاولة استخراج الرقم مباشرة من الـ JID
    let num = jid.split('@')[0];
    // إزالة كل العلامات غير الرقمية
    num = num.replace(/[^0-9]/g, '');
    // إزالة الأصفار البادئة
    return num.replace(/^0+/, '');
}

function getDisplayName(jid) {
    if (!jid) return '@غير معروف';
    const num = getRealNumber(jid);
    // إذا كان الرقم أقل من 10 أرقام، قد يكون lid
    if (num.length < 10) {
        // محاولة الحصول على الرقم من بيانات المجموعة
        return `@${num}`;
    }
    return `@${num}`;
}

function normalizeJid(jid) {
    if (!jid) return null;
    try {
        const decoded = jidDecode(jid);
        if (decoded?.user) {
            return `${decoded.user}@s.whatsapp.net`;
        }
    } catch {}
    // إذا فشل الفك، نحاول استخراج الرقم مباشرة
    const num = jid.split('@')[0]?.replace(/[^0-9]/g, '');
    if (num) {
        return `${num}@s.whatsapp.net`;
    }
    return jid;
}

async function getUserRole(sock, chatId, jid) {
    if (!jid) return 'عضو';
    
    // التحقق من الرتب الخاصة أولاً
    if (isFounder(jid)) return 'الاونر بوت';
    if (isOwnerbot(jid)) return 'الأونر';
    if (isDeveloper(jid)) return 'المطور';
    if (isElite(jid)) return 'النخبة';

    try {
        const metadata = await sock.groupMetadata(chatId);
        const adminJids = metadata.participants
            .filter(p => p.admin === 'admin' || p.admin === 'superadmin')
            .map(p => p.id);

        const normalized = normalizeJid(jid);
        const shortNumber = getRealNumber(jid);
        
        const isAdmin = adminJids.some(adminJid => {
            const adminNormalized = normalizeJid(adminJid);
            const adminShort = getRealNumber(adminJid);
            return adminJid === jid || 
                   adminNormalized === normalized || 
                   adminNormalized === jid ||
                   adminJid === normalized ||
                   adminShort === shortNumber;
        });

        if (isAdmin) return 'مشرف';
    } catch (err) {
        console.error('خطأ في جلب بيانات المجموعة:', err);
    }
    return 'عضو';
}

function canMute(muterRole, targetRole) {
    const rankOrder = {
        'عضو': 0, 
        'مشرف': 1, 
        'النخبة': 2,
        'المطور': 3, 
        'الأونر': 4, 
        'الاونر بوت': 5
    };
    return rankOrder[muterRole] > rankOrder[targetRole];
}
// =========================================

const loadMuted = () => {
    try { return JSON.parse(fs.readFileSync(muteFilePath)); }
    catch { return []; }
};

const saveMuted = (data) => {
    try { fs.writeFileSync(muteFilePath, JSON.stringify(data, null, 2)); }
    catch (err) { console.error("خطأ في حفظ ملف الكتم:", err); }
};

let unwatch = null;

module.exports = {
    command: 'كتم',
    description: '🔇 كتم أو إلغاء كتم عضو (صلاحيات متدرجة)',
    category: 'ادارة',
    async execute(sock, m) {
        try {
            const chatId = m.key.remoteJid;
            const sender = m.key.participant || m.participant;
            const normalizedSender = normalizeJid(sender);

            const senderRole = await getUserRole(sock, chatId, normalizedSender);
            
            if (senderRole === 'عضو') {
                return await sendMessage(sock, chatId, [
                    'ذل من لا صلاحيات له 😂🫵'
                ], m);
            }

            const body = m.message?.extendedTextMessage?.text || m.message?.conversation || '';
            const args = body.trim().split(/\s+/).slice(1);
            const action = args[0]?.toLowerCase();

            // استخراج الهدف
            const context = m.message?.extendedTextMessage?.contextInfo;
            let target = null;
            
            if (context?.mentionedJid?.length) {
                target = context.mentionedJid[0];
            } else if (context?.participant) {
                target = context.participant;
            } else if (context?.quotedMessage?.participant) {
                target = context.quotedMessage.participant;
            } else if (m.mentionedJid?.length) {
                target = m.mentionedJid[0];
            } else if (m.key?.participant) {
                target = m.key.participant;
            }

            let mutedUsers = loadMuted();

            // ===== حالة الكتم =====
            if (action === 'حالة') {
                if (mutedUsers.length === 0) {
                    return await sendMessage(sock, chatId, [
                        'ℹ️ *لا يوجد أي عضو مكتوم حالياً*',
                        '',
                        '📌 القائمة فارغة'
                    ], m);
                }
                const list = mutedUsers.map(jid => `- ${getDisplayName(jid)}`).join('\n');
                return await sendMessage(sock, chatId, [
                    '🔇 *قائمة المكتومين*',
                    '',
                    list
                ], m, mutedUsers);
            }

            // ===== تحرير الكتم =====
            if (action === 'تحرير') {
                if (senderRole !== 'الاونر بوت' && senderRole !== 'الأونر') {
                    return await sendMessage(sock, chatId, [
                        '🚫 *غير مصرح*',
                        '',
                        '🔒 فقط الأونر يمكنهم تحرير جميع المكتومين.',
                        '📌 يمكنك إلغاء كتم الأفراد باستخدام `.كتم الغاء`'
                    ], m);
                }
                fs.writeFileSync(muteFilePath, JSON.stringify([]));
                if (unwatch) { unwatch(); unwatch = null; }
                return await sendMessage(sock, chatId, [
                    '✅ *تم تحرير جميع المكتومين*',
                    '',
                    '📌 تم مسح قائمة الكتم بالكامل'
                ], m);
            }

            // ===== فك الكتم =====
            if (action === 'الغاء') {
                if (!target) {
                    return await sendMessage(sock, chatId, [
                        '❌ *لم أتمكن من تحديد الشخص*',
                        '',
                        '📌 يرجى الرد على رسالة العضو أو منشنته'
                    ], m);
                }
                const normalizedTarget = normalizeJid(target);
                if (!normalizedTarget) {
                    return await sendMessage(sock, chatId, [
                        '❌ *رقم غير صالح*',
                        '',
                        '📌 تأكد من الرقم المستهدف'
                    ], m);
                }
                
                if (!mutedUsers.includes(normalizedTarget)) {
                    return await sendMessage(sock, chatId, [
                        'ℹ️ *العضو غير مكتوم أصلاً*',
                        '',
                        '📌 لا يوجد كتم لهذا العضو'
                    ], m);
                }
                const targetRole = await getUserRole(sock, chatId, normalizedTarget);
                if (!canMute(senderRole, targetRole) && senderRole !== 'الاونر بوت') {
                    return await sendMessage(sock, chatId, [
                        '🚫 *غير مصرح*',
                        '',
                        '🔒 لا يمكنك إلغاء كتم عضو من نفس رتبتك أو أعلى.',
                        `📌 رتبتك: ${senderRole} | رتبة المستهدف: ${targetRole}`
                    ], m);
                }
                mutedUsers = mutedUsers.filter(jid => jid !== normalizedTarget);
                saveMuted(mutedUsers);
                if (mutedUsers.length === 0 && unwatch) { unwatch(); unwatch = null; }
                return await sendMessage(sock, chatId, [
                    '✅ *تم إلغاء كتم العضو*',
                    '📌 يمكنه الآن التحدث في المجموعة'
                ], m, [normalizedTarget]);
            }

            // ===== كتم عضو جديد =====
            if (!target) {
                return await sendMessage(sock, chatId, [
                    '❌ *استخدم الأمر بالشكل الصحيح*',
                    '',
                    '📌 `.كتم @منشن` أو بالرد على رسالة العضو',
                    '📌 `.كتم الغاء @منشن` لإلغاء الكتم',
                    '📌 `.كتم حالة` لعرض المكتومين',
                    '📌 `.كتم تحرير` لمسح القائمة (الأونر فقط)'
                ], m);
            }

            const normalizedTarget = normalizeJid(target);
            if (!normalizedTarget) {
                return await sendMessage(sock, chatId, [
                    '❌ *رقم غير صالح*',
                    '',
                    '📌 تأكد من الرقم المستهدف'
                ], m);
            }
            
            if (normalizedTarget === normalizedSender) {
                return await sendMessage(sock, chatId, [
                    '❌ *لا يمكنك كتم نفسك*',
                    '',
                    '📌 اختر عضواً آخر'
                ], m);
            }

            const targetRole = await getUserRole(sock, chatId, normalizedTarget);
            if (!canMute(senderRole, targetRole)) {
                return await sendMessage(sock, chatId, [
                    '🚫 *غير مصرح*',
                    '',
                    '🔒 لا يمكنك كتم عضو من نفس رتبتك أو أعلى.',
                    `📌 رتبتك: ${senderRole} | رتبة المستهدف: ${targetRole}`
                ], m);
            }

            if (mutedUsers.includes(normalizedTarget)) {
                return await sendMessage(sock, chatId, [
                    'ℹ️ *العضو مكتوم بالفعل*',
                    '📌 لا يمكن تكرار الكتم'
                ], m, [normalizedTarget]);
            }

            mutedUsers.push(normalizedTarget);
            saveMuted(mutedUsers);

            await sendMessage(sock, chatId, [
                '🔇 *تم كتم العضو بنجاح*',
                '📌 خلاص مش هينبح تاني 🤧'
            ], m, [normalizedTarget, normalizedSender]);

            if (!unwatch) { unwatch = watchMutedMessages(sock); }

        } catch (err) {
            console.error("حدث خطأ في تنفيذ الأمر:", err);
            const chatId = m.key?.remoteJid || 'unknown';
            await sendMessage(sock, chatId, [
                '❌ *حدث خطأ غير متوقع*',
                '',
                `📝 ${err.message || 'خطأ غير معروف'}`,
                '📌 حاول مرة أخرى لاحقاً'
            ], m);
        }
    }
};

// ===== مراقبة رسائل المكتومين وحذفها =====
function watchMutedMessages(sock) {
    const listener = async ({ messages }) => {
        const mutedSet = new Set(loadMuted());
        for (const msg of messages) {
            const chatId = msg.key.remoteJid;
            const sender = msg.key.participant || msg.key.remoteJid;
            const normalizedSender = normalizeJid(sender);
            if (mutedSet.has(normalizedSender)) {
                try {
                    await sock.sendMessage(chatId, {
                        delete: {
                            remoteJid: chatId,
                            fromMe: false,
                            id: msg.key.id,
                            participant: sender
                        }
                    }).catch(err => console.error("فشل حذف رسالة المكتوم:", err.message));
                } catch (err) {
                    console.error("فشل حذف رسالة المكتوم:", err.message);
                }
            }
        }
    };
    sock.ev.on('messages.upsert', listener);
    return () => sock.ev.off('messages.upsert', listener);
}