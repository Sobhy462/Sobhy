// منشن.js - منشن جميع الأعضاء مع نص (للمشرفين والنخبة)

const { isElite, extractPureNumber } = require('../haykala/elite');
const { isFounder, isOwnerbot, isDeveloper } = require('../haykala/developer');

// ========== دالة التحقق من الصلاحية ==========
async function hasPermission(sock, senderLid, senderNumber, chatId) {
    try {
        // ✅ المطور، الأونر، النخبة
        if (isFounder(senderLid) || 
            isOwnerbot(senderLid) || 
            isDeveloper(senderLid) ||
            isElite(senderNumber)) {
            return true;
        }

        // ✅ المشرفين في الجروب
        if (chatId && chatId.endsWith('@g.us')) {
            const groupMetadata = await sock.groupMetadata(chatId);
            const participant = groupMetadata.participants.find(p => p.id === senderLid);
            if (participant && (participant.admin === 'admin' || participant.admin === 'superadmin')) {
                return true;
            }
        }

        return false;
    } catch {
        return false;
    }
}

// ========== دالة التحقق من وجود نقطة في النص ==========
function containsDot(text) {
    if (!text) return false;
    // التحقق من وجود نقطة (.) في النص
    return text.includes('.');
}

// ========== دالة الإرسال مع الرد ==========
async function sendReply(sock, chatId, lines, quoted = null, mentions = []) {
    if (!Array.isArray(lines)) {
        lines = [lines];
    }

    let msg = `📢 مـنـشـن الـكـل 📢\n`;
    msg += `━━━━━━━━━━━━━━━━━━━━\n`;
    for (const line of lines) {
        if (line && line.trim()) {
            msg += `${line}\n`;
        }
    }
    msg += `━━━━━━━━━━━━━━━━━━━━\n`;
    msg += `𝘽𝙔┇𝑴𝑨𝑲𝑰𝑴𝑨`;
    
    await sock.sendMessage(chatId, { 
        text: msg, 
        mentions 
    }, { 
        quoted: quoted 
    });
}

module.exports = {
    command: ['منشن', 'م', 'مخفي'],
    description: '📢 منشن جميع أعضاء المجموعة مع نص (للمشرفين والنخبة)',
    category: 'ادارة',
    usage: '.منشن [النص] | .م [النص] | .مخفي [النص]',

    async execute(sock, msg) {
        try {
            const groupJid = msg.key.remoteJid;
            const sender = msg.key.participant || msg.participant || msg.key.remoteJid;
            const senderNumber = extractPureNumber(sender);

            // ===== التحقق من أن الأمر في مجموعة =====
            if (!groupJid || !groupJid.endsWith('@g.us')) {
                await sendReply(sock, groupJid, [
                    '❌ *هذا الأمر يعمل في الجروبات فقط*',
                    '',
                    '📌 يرجى استخدام الأمر في مجموعة'
                ], msg);
                return;
            }

            // ===== التحقق من الصلاحية (مشرف أو نخبة أو مطور/أونر) =====
            const hay = require('../haykala/developer');
            const lid = hay.toLid(sender);
            
            const canMention = await hasPermission(sock, lid, senderNumber, groupJid);

            if (!canMention) {
                await sendReply(sock, groupJid, [
                    '🚫 *غير مصرح*',
                    '',
                    '🔒 هذا الأمر للمطور، الأونر، النخبة، ومشرفي الجروب فقط.'
                ], msg);
                return;
            }

            // ===== جلب بيانات المجموعة =====
            const metadata = await sock.groupMetadata(groupJid);
            
            // ===== قائمة جميع الأعضاء للمنشن =====
            const mentions = metadata.participants.map(p => p.id);

            // ===== استخراج النص الكامل =====
            const fullText = msg.message?.conversation || 
                            msg.message?.extendedTextMessage?.text || '';

            // ===== الحالة 1: الرد على رسالة =====
            const quotedMsg = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
            const quotedMsgKey = msg.message?.extendedTextMessage?.contextInfo?.stanzaId;
            const quotedParticipant = msg.message?.extendedTextMessage?.contextInfo?.participant;

            // إذا كان هناك رد على رسالة
            if (quotedMsg && quotedMsgKey) {
                // 🛡️ التحقق من أن الرسالة المقتبسة لا تحتوي على نقطة (.)
                const quotedText = quotedMsg?.conversation || 
                                   quotedMsg?.extendedTextMessage?.text || 
                                   quotedMsg?.imageMessage?.caption || 
                                   quotedMsg?.videoMessage?.caption || 
                                   '';

                // منع أي رسالة تحتوي على نقطة (.) حتى لو كانت في النص
                if (containsDot(quotedText)) {
                    await sendReply(sock, groupJid, [
                        '🛡️ *تم منع إعادة التوجيه*',
                        '',
                        '⚠️ لا يمكن إعادة توجيه رسائل تحتوي على نقطة (.)',
                        '📌 هذا لمنع استغلال النظام وإعادة توجيه الأوامر.'
                    ], msg);
                    return;
                }

                // إعادة توجيه الرسالة المقتبسة مع منشن الكل
                const forwardMsg = {
                    key: {
                        remoteJid: groupJid,
                        fromMe: false,
                        id: quotedMsgKey,
                        participant: quotedParticipant,
                    },
                    message: quotedMsg
                };

                await sock.sendMessage(groupJid, {
                    forward: forwardMsg,
                    mentions: mentions
                });
                return;
            }

            // ===== الحالة 2: استخراج النص من الأمر =====
            let cleanText = '';
            
            // إزالة الأمر من النص
            const parts = fullText.trim().split(/\s+/);
            if (parts.length > 1) {
                cleanText = parts.slice(1).join(' ').trim();
            }

            // ===== الحالة 3: النص الافتراضي =====
            if (!cleanText) {
                cleanText = 'صلّ على النبي محمد ﷺ 💜';
            }

            // 🛡️ منع النص إذا كان يحتوي على نقطة (.)
            if (containsDot(cleanText)) {
                await sendReply(sock, groupJid, [
                    '🛡️ *تم منع المنشن*',
                    '',
                    '⚠️ لا يمكن استخدام نقطة (.) في نص المنشن.',
                    '📌 النقطة محظورة لمنع استغلال النظام وإعادة توجيه الأوامر.'
                ], msg);
                return;
            }

            // ===== إزالة أي منشن من النص =====
            const finalText = cleanText.replace(/@\S+/g, '').trim() || cleanText;

            // ===== إرسال الرسالة مع منشن الكل =====
            await sock.sendMessage(groupJid, {
                text: finalText,
                mentions: mentions
            });

        } catch (err) {
            console.error('❌ خطأ في أمر منشن:', err);
            
            const chatId = msg.key?.remoteJid || 'unknown';
            await sendReply(sock, chatId, [
                '❌ *حدث خطأ*',
                '',
                `📝 ${err.message || err.toString()}`,
                '',
                '📌 حاول مرة أخرى لاحقاً'
            ], msg);
        }
    }
};