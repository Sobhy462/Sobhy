// تسجيل.js - أمر تسجيل البطاقة الشخصية (نسخة مبسطة بدون صلاحيات)
// يدعم التسجيل بالرد على صورة أو بدون صورة
// عند كتابة .تسجيل بدون وسائط → يعرض رسالة المساعدة فقط

const fs = require('fs');
const path = require('path');
const { downloadMediaMessage } = require('@whiskeysockets/baileys');

// ========== المسارات ==========
const dataDir = path.join(__dirname, '..', 'data');
const profilesFile = path.join(dataDir, 'profiles.json');
const pointsFile = path.join(dataDir, 'points.json');
const imagesFolder = path.join(dataDir, 'profiles_images');

// ========== التأكد من وجود المجلدات والملفات ==========
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });
if (!fs.existsSync(profilesFile)) fs.writeFileSync(profilesFile, '{}');
if (!fs.existsSync(pointsFile)) fs.writeFileSync(pointsFile, '{}');
if (!fs.existsSync(imagesFolder)) fs.mkdirSync(imagesFolder, { recursive: true });

// ========== دوال التحميل والحفظ ==========
function loadProfiles() {
    try { return JSON.parse(fs.readFileSync(profilesFile)); } catch { return {}; }
}

function saveProfiles(data) {
    fs.writeFileSync(profilesFile, JSON.stringify(data, null, 2));
}

function loadPoints() {
    try { return JSON.parse(fs.readFileSync(pointsFile)); } catch { return {}; }
}

function savePoints(data) {
    fs.writeFileSync(pointsFile, JSON.stringify(data, null, 2));
}

// ========== دوال البطاقة ==========
function getProfile(jid) {
    const profiles = loadProfiles();
    return profiles[jid] || null;
}

function setProfile(jid, nickname, age, gender, imagePath) {
    const profiles = loadProfiles();
    profiles[jid] = { nickname, age, gender, image: imagePath || null };
    saveProfiles(profiles);
}

function isTitleTaken(title, excludeUser = null) {
    const profiles = loadProfiles();
    for (const [user, data] of Object.entries(profiles)) {
        if (user === excludeUser) continue;
        if (data.nickname && data.nickname.toLowerCase() === title.toLowerCase()) {
            return true;
        }
    }
    return false;
}

function getPoints(jid) {
    const points = loadPoints();
    return points[jid] || 0;
}

function addPoints(jid, amount) {
    const points = loadPoints();
    points[jid] = (points[jid] || 0) + amount;
    savePoints(points);
    return points[jid];
}

// ========== دالة الإرسال الموحدة ==========
async function sendMessage(sock, chatId, lines, quoted = null, mentions = []) {
    if (!Array.isArray(lines)) {
        lines = [lines];
    }

    let msg = `📝 *نـظـام الـتـسـجـيـل* 📝\n`;
    msg += `━━━━━━━━━━━━━━━━━━━━\n`;
    for (const line of lines) {
        if (line && line.trim()) {
            msg += `${line}\n`;
        }
    }
    msg += `━━━━━━━━━━━━━━━━━━━━\n`;
    msg += `𝘽𝙔┇𝑴𝑨𝑲𝑰𝑴𝑨`;

    await sock.sendMessage(chatId, { text: msg, mentions }, { quoted: quoted });
}

// ========== الأمر الرئيسي ==========
module.exports = {
    command: ['تسجيل'],
    category: 'عام',
    description: '📝 تسجيل أو تحديث بطاقتك الشخصية (اللقب، العمر، الجنس، الصورة)',
    usage: '.تسجيل اللقب العمر الجنس\n.تسجيل اللقب العمر الجنس (مع الرد على صورة)',

    async execute(sock, msg) {
        try {
            const chatId = msg.key.remoteJid;
            const sender = msg.key.participant || msg.key.remoteJid;

            // استخراج النص والوسائط
            const body = msg.message?.conversation || msg.message?.extendedTextMessage?.text || '';
            const args = body.split(/\s+/).slice(1); // الأجزاء بعد الأمر

            // ===== إذا لم توجد وسائط كافية → عرض المساعدة فقط =====
            if (args.length < 3) {
                await sendMessage(sock, chatId, [
                    '⚠️ *الاستخدام الصحيح:*',
                    '',
                    '📝 `.تسجيل اللقب العمر الجنس`',
                    '📸 `.تسجيل اللقب العمر الجنس` (مع الرد على صورة)',
                    '',
                    '📌 أمثلة:',
                    '• `.تسجيل المحارب 25 ذكر`',
                    '• (رد على صورة) `.تسجيل الملكة 22 أنثى`',
                    '',
                    '💡 إذا كنت مسجلاً بالفعل، استخدم هذا الأمر لتحديث بياناتك (بدون نقاط إضافية).'
                ], msg);
                return;
            }

            // ===== التحقق من وجود صورة مرفقة (رد على صورة) =====
            const quotedMsg = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
            let imagePath = null;

            if (quotedMsg?.imageMessage) {
                try {
                    const imageBuffer = await downloadMediaMessage(
                        { key: msg.key, message: quotedMsg },
                        'buffer',
                        {},
                        { reuploadRequest: sock }
                    );
                    const filename = `profile_${Date.now()}_${Math.random().toString(36).substring(7)}.jpg`;
                    imagePath = path.join(imagesFolder, filename);
                    fs.writeFileSync(imagePath, imageBuffer);
                } catch (e) {
                    console.error('❌ فشل تحميل الصورة المرفقة:', e);
                }
            }

            // ===== استخراج العمر والجنس واللقب =====
            const age = parseInt(args[args.length - 2]);
            const gender = args[args.length - 1];
            const title = args.slice(0, args.length - 2).join(' ');

            // التحقق من صحة العمر
            if (isNaN(age) || age < 1 || age > 120) {
                await sendMessage(sock, chatId, [
                    '❌ *العمر غير صالح*',
                    '',
                    '📌 يجب أن يكون العمر رقماً بين 1 و 120.'
                ], msg);
                return;
            }

            // التحقق من صحة الجنس
            const validGenders = ['ذكر', 'أنثى', 'رجل', 'امرأة', 'male', 'female'];
            if (!validGenders.includes(gender.toLowerCase())) {
                await sendMessage(sock, chatId, [
                    '❌ *الجنس غير صالح*',
                    '',
                    '📌 يجب أن يكون: ذكر، أنثى، رجل، امرأة'
                ], msg);
                return;
            }

            // تنسيق الجنس
            const genderMap = { 'رجل': 'ذكر', 'male': 'ذكر', 'امرأة': 'أنثى', 'female': 'أنثى' };
            const finalGender = genderMap[gender.toLowerCase()] || gender;

            // ===== التحقق من اللقب =====
            if (isTitleTaken(title, sender)) {
                await sendMessage(sock, chatId, [
                    '❌ *اللقب مأخوذ بالفعل*',
                    '',
                    `📌 اللقب "${title}" مستخدم من قبل شخص آخر.`,
                    '💡 اختر لقباً آخر.'
                ], msg);
                return;
            }

            // ===== جلب صورة الحساب إذا لم توجد صورة مرفقة =====
            if (!imagePath) {
                try {
                    const ppUrl = await sock.profilePictureUrl(sender, 'image');
                    if (ppUrl) {
                        const response = await fetch(ppUrl);
                        const buffer = await response.arrayBuffer();
                        const filename = `profile_${Date.now()}_${Math.random().toString(36).substring(7)}.jpg`;
                        imagePath = path.join(imagesFolder, filename);
                        fs.writeFileSync(imagePath, Buffer.from(buffer));
                    }
                } catch (e) {
                    // لا توجد صورة حساب، نكمل بدون صورة
                }
            }

            // ===== التحقق من وجود بطاقة قديمة =====
            const oldProfile = getProfile(sender);
            const isNewUser = !oldProfile;

            // حذف الصورة القديمة إن وجدت
            if (oldProfile && oldProfile.image && fs.existsSync(oldProfile.image)) {
                try { fs.unlinkSync(oldProfile.image); } catch (e) {}
            }

            // ===== حفظ البيانات الجديدة =====
            setProfile(sender, title, age, finalGender, imagePath);

            // ===== منح النقاط فقط للمستخدم الجديد (منع الاستغلال) =====
            let pointsMessage = '';
            const currentPoints = getPoints(sender);
            if (isNewUser) {
                const newPoints = addPoints(sender, 100);
                pointsMessage = `💰 +100 نقطة مكافأة تسجيل (الرصيد: ${newPoints})`;
            } else {
                pointsMessage = `🔄 تم تحديث البيانات (بدون نقاط إضافية، الرصيد: ${currentPoints})`;
            }

            // ===== بناء رسالة النجاح =====
            const lines = [
                isNewUser ? '✅ *تم تسجيل بطاقتك بنجاح!*' : '✅ *تم تحديث بطاقتك بنجاح!*',
                '',
                `🏷️ اللقب: ${title}`,
                `📅 العمر: ${age} سنة`,
                `⚥ الجنس: ${finalGender}`,
                pointsMessage,
                '',
                imagePath ? '📸 تم حفظ الصورة ✅' : '📸 لم يتم إرفاق صورة'
            ];

            const mentions = [sender];
            await sendMessage(sock, chatId, lines, msg, mentions);

        } catch (error) {
            console.error('❌ خطأ في أمر تسجيل:', error);
            await sendMessage(sock, msg.key.remoteJid, [
                '❌ *حدث خطأ*',
                '',
                `📝 ${error.message || 'خطأ غير معروف'}`,
                '',
                '📌 حاول مرة أخرى لاحقاً'
            ], msg);
        }
    }
};