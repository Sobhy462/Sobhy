// حالة.js - نظام نشر الحالات في المجموعة (مثل البوست) مع دعم الميديا والوصف + مسح الحالات المنشورة
// الصلاحيات: النخبة (elite) ومشرفي المجموعة

const { prepareWAMessageMedia, generateWAMessageFromContent, proto, downloadMediaMessage } = require('@whiskeysockets/baileys');
const { isElite } = require('../haykala/elite.js');
const fs = require('fs');
const path = require('path');

// ========== ملف لتخزين مفاتيح الحالات المنشورة ==========
const statusFile = path.join(__dirname, '../data/statusMessages.json');
if (!fs.existsSync(path.dirname(statusFile))) fs.mkdirSync(path.dirname(statusFile), { recursive: true });
if (!fs.existsSync(statusFile)) fs.writeFileSync(statusFile, JSON.stringify({}));

function loadStatusMessages() {
    try { return JSON.parse(fs.readFileSync(statusFile)); } catch { return {}; }
}

function saveStatusMessages(data) {
    fs.writeFileSync(statusFile, JSON.stringify(data, null, 2));
}

// ========== دالة الإرسال الموحدة (لرسائل النص والإشعارات) ==========
async function sendMessage(sock, chatId, lines, quoted = null, mentions = []) {
    if (!Array.isArray(lines)) lines = [lines];
    let msg = `📢 نـشـر الـحـالـة 📢\n`;
    msg += `━━━━━━━━━━━━━━━━━━━━\n`;
    for (const line of lines) {
        if (line && line.trim()) msg += `${line}\n`;
    }
    msg += `━━━━━━━━━━━━━━━━━━━━\n`;
    msg += `𝘽𝙔┇𝑴𝑨𝑲𝑰𝑴𝑨`;
    const sent = await sock.sendMessage(chatId, { text: msg, mentions }, { quoted });
    return sent;
}

// ========== دالة حفظ مفتاح الحالة المنشورة ==========
function saveStatusKey(chatId, messageKey) {
    if (!messageKey || !messageKey.id || !messageKey.remoteJid) {
        console.error('❌ مفتاح الرسالة غير صحيح:', messageKey);
        return;
    }
    const data = loadStatusMessages();
    if (!data[chatId]) data[chatId] = [];
    // تجنب التكرار
    const exists = data[chatId].some(k => k.id === messageKey.id);
    if (!exists) {
        data[chatId].push(messageKey);
        if (data[chatId].length > 50) data[chatId].shift(); // حد أقصى 50
        saveStatusMessages(data);
        console.log(`✅ تم حفظ مفتاح الحالة: ${messageKey.id}`);
    }
}

// ========== دالة حذف آخر حالة منشورة ==========
async function deleteLastStatus(sock, chatId, count = 1) {
    const data = loadStatusMessages();
    const keys = data[chatId] || [];
    if (keys.length === 0) return { deleted: 0, message: '❌ لا توجد حالات سابقة للحذف.' };

    const toDelete = keys.splice(-count);
    saveStatusMessages(data);

    let deletedCount = 0;
    for (const key of toDelete) {
        try {
            if (key && key.id && key.remoteJid) {
                await sock.sendMessage(chatId, { delete: key });
                deletedCount++;
            }
        } catch (e) {
            console.error('❌ فشل حذف الحالة:', e);
        }
    }
    return { deleted: deletedCount, message: `✅ تم حذف ${deletedCount} حالة منشورة.` };
}

// ========== دالة حذف جميع الحالات المنشورة ==========
async function deleteAllStatus(sock, chatId) {
    const data = loadStatusMessages();
    const keys = data[chatId] || [];
    if (keys.length === 0) return { deleted: 0, message: '❌ لا توجد حالات سابقة للحذف.' };

    let deletedCount = 0;
    for (const key of keys) {
        try {
            if (key && key.id && key.remoteJid) {
                await sock.sendMessage(chatId, { delete: key });
                deletedCount++;
            }
        } catch (e) {
            console.error('❌ فشل حذف الحالة:', e);
        }
    }
    data[chatId] = [];
    saveStatusMessages(data);
    return { deleted: deletedCount, message: `✅ تم حذف جميع الحالات (${deletedCount}).` };
}

// ========== دالة التحقق من صلاحيات المستخدم ==========
async function isUserAuthorized(sock, chatId, userId) {
    if (isElite(userId)) return true;
    try {
        const groupMetadata = await sock.groupMetadata(chatId);
        const participant = groupMetadata.participants.find(p => p.id === userId);
        return participant && (participant.admin === 'admin' || participant.admin === 'superadmin');
    } catch {
        return false;
    }
}

// ========== دالة مساعدة لتنسيق رسالة المساعدة ==========
function getHelpMessage() {
    return `📢 *نظام الحالة في المجموعة*
━━━━━━━━━━━━━━━━━━━━
📌 *الاستخدام:*
• .حاله (رد على ميديا) → نشر الميديا كحالة
• .حاله وصف (رد على ميديا) → نشر الميديا مع وصف
• .حاله مسح → حذف آخر حالة منشورة
• .حاله مسح 3 → حذف آخر 3 حالات منشورة
• .حاله مسح كل → حذف جميع الحالات المنشورة

👥 *الصلاحيات:*
• النخبة ومشرفي المجموعة

━━━━━━━━━━━━━━━━━━━━
〔 𝑴𝑨𝑲𝑰𝑴𝑨 𝑩𝑶𝑻 〕`;
}

// ========== الأمر الرئيسي ==========
module.exports = {
    command: ['حاله'],
    category: 'عام',
    description: '📢 نشر حالة (صورة/فيديو/ملصق) في المجموعة مع أو بدون وصف + مسح الحالات المنشورة',
    usage: '.حالة (رد على ميديا)\n.حالة وصف (رد على ميديا مع نص)\n.حالة مسح [عدد]\n.حالة مسح كل',

    async execute(sock, msg, args) {
        try {
            const chatId = msg.key.remoteJid;
            const sender = msg.key.participant || msg.key.remoteJid;
            const fullText = msg.message?.conversation || msg.message?.extendedTextMessage?.text || '';
            const parts = fullText.trim().split(/\s+/);
            const subCommand = parts.length > 1 ? parts[1].toLowerCase() : '';

            if (!chatId.endsWith('@g.us')) {
                return await sock.sendMessage(chatId, {
                    text: '❗ هذا الأمر يعمل داخل المجموعات فقط.'
                }, { quoted: msg });
            }

            // ===== التحقق من الصلاحيات =====
            const authorized = await isUserAuthorized(sock, chatId, sender);
            if (!authorized) {
                return await sock.sendMessage(chatId, {
                    text: 'ذل من لا صلاحيات له 😂🫵'
                }, { quoted: msg });
            }

            // ==========================================================
            // 1. أمر المسح
            // ==========================================================
            if (subCommand === 'مسح') {
                const countArg = parts.length > 2 ? parts[2] : '1';

                if (countArg === 'كل') {
                    const result = await deleteAllStatus(sock, chatId);
                    return await sock.sendMessage(chatId, { text: result.message }, { quoted: msg });
                }

                const count = parseInt(countArg);
                if (isNaN(count) || count < 1) {
                    return await sock.sendMessage(chatId, {
                        text: '❌ يرجى تحديد عدد صحيح أكبر من 0.\nمثال: `.حاله مسح 3`'
                    }, { quoted: msg });
                }

                const result = await deleteLastStatus(sock, chatId, count);
                return await sock.sendMessage(chatId, { text: result.message }, { quoted: msg });
            }

            // ==========================================================
            // 2. نشر حالة (بوست) - باستخدام prepareWAMessageMedia + relayMessage
            // ==========================================================
            let isDescription = false;
            let descriptionText = '';

            if (subCommand === 'وصف') {
                isDescription = true;
                descriptionText = parts.slice(2).join(' ').trim();
            }

            const quotedMsg = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
            if (!quotedMsg) {
                return await sock.sendMessage(chatId, {
                    text: `❌ يجب الرد على صورة، فيديو، أو ملصق.\n\n${getHelpMessage()}`
                }, { quoted: msg });
            }

            // ===== تحديد نوع الميديا =====
            let mediaType = null;
            let mediaCaption = '';

            if (quotedMsg.imageMessage) {
                mediaType = 'image';
                mediaCaption = quotedMsg.imageMessage?.caption || '';
            } else if (quotedMsg.videoMessage) {
                mediaType = 'video';
                mediaCaption = quotedMsg.videoMessage?.caption || '';
            } else if (quotedMsg.stickerMessage) {
                mediaType = 'sticker';
            } else {
                return await sock.sendMessage(chatId, {
                    text: '❌ يجب الرد على *صورة* أو *فيديو* أو *ملصق*.'
                }, { quoted: msg });
            }

            // ===== تحميل الميديا =====
            let mediaBuffer;
            try {
                const stanzaId = msg.message?.extendedTextMessage?.contextInfo?.stanzaId || msg.key.id;
                const participant = msg.message?.extendedTextMessage?.contextInfo?.participant || sender;

                mediaBuffer = await downloadMediaMessage(
                    {
                        key: {
                            remoteJid: chatId,
                            fromMe: false,
                            id: stanzaId,
                            participant: participant
                        },
                        message: quotedMsg
                    },
                    'buffer',
                    {},
                    {
                        logger: console,
                        reuploadRequest: sock.updateMediaMessage
                    }
                );
            } catch (err) {
                console.error('❌ خطأ في تحميل الميديا:', err);
                return await sock.sendMessage(chatId, {
                    text: '❌ فشل تحميل الميديا، حاول مرة أخرى.'
                }, { quoted: msg });
            }

            if (!mediaBuffer) {
                return await sock.sendMessage(chatId, {
                    text: '❌ فشل تحميل الميديا، حاول مرة أخرى.'
                }, { quoted: msg });
            }

            // ===== تجهيز الكابشن =====
            let finalCaption = '';
            if (isDescription && descriptionText) {
                finalCaption = `📝 *وصف الحالة:*\n${descriptionText}`;
            } else if (mediaCaption) {
                finalCaption = mediaCaption;
            }

            // ===== إرسال الميديا كحالة (بوست) باستخدام prepareWAMessageMedia و relayMessage =====
            try {
                if (mediaType === 'sticker') {
                    // الملصق يُرسل مباشرة مع إمكانية إرسال نص منفصل للوصف
                    const sentSticker = await sock.sendMessage(chatId, { sticker: mediaBuffer });
                    if (finalCaption) {
                        await sock.sendMessage(chatId, { text: finalCaption });
                    }
                    if (sentSticker && sentSticker.key) {
                        saveStatusKey(chatId, sentSticker.key);
                    }
                    await sock.sendMessage(chatId, { react: { text: '✅', key: msg.key } });
                    return;
                }

                // للصورة والفيديو: نستخدم prepareWAMessageMedia و relayMessage
                const mediaOptions = { [mediaType]: mediaBuffer };
                const prepared = await prepareWAMessageMedia(mediaOptions, { upload: sock.waUploadToServer });
                const messageKey = mediaType === 'image' ? 'imageMessage' : 'videoMessage';

                const contentMsg = {
                    [messageKey]: {
                        ...prepared[messageKey],
                        caption: finalCaption || '',
                        contextInfo: {
                            isGroupStatus: true,
                            pairedMediaType: 'NOT_PAIRED_MEDIA',
                            statusAudienceMetadata: {
                                audienceType: 1,
                                listEmoji: '📢',
                                listName: 'حالة المجموعة'
                            }
                        }
                    }
                };

                const webMsg = proto.Message.fromObject(contentMsg);
                const waMsg = generateWAMessageFromContent(chatId, webMsg, { userJid: sock.user.id, quoted: msg });
                await sock.relayMessage(chatId, waMsg.message, { messageId: waMsg.key.id });

                // ✅ حفظ مفتاح الرسالة المرسلة (للحذف لاحقاً)
                if (waMsg && waMsg.key) {
                    saveStatusKey(chatId, waMsg.key);
                }

                await sock.sendMessage(chatId, { react: { text: '✅', key: msg.key } });

                // إشعار النجاح
                await sendMessage(sock, chatId, [
                    '✅ *تم نشر الحالة بنجاح*',
                    '',
                    `📌 *النوع:* ${mediaType === 'sticker' ? 'ملصق' : mediaType === 'image' ? 'صورة' : 'فيديو'}`,
                    finalCaption ? `📝 *الوصف:*\n${finalCaption}` : '',
                    '',
                    `👤 *بواسطة:* @${sender.split('@')[0]}`,
                    '',
                    `📌 *للحذف:* .حاله مسح`
                ], msg, [sender]);

            } catch (err) {
                console.error('❌ خطأ في نشر الحالة:', err);
                await sock.sendMessage(chatId, { react: { text: '❌', key: msg.key } });
                await sock.sendMessage(chatId, {
                    text: `❌ حدث خطأ أثناء النشر: ${err.message || 'خطأ غير معروف'}`
                }, { quoted: msg });
            }

        } catch (err) {
            console.error('❌ خطأ عام:', err);
            await sock.sendMessage(msg.key.remoteJid, {
                text: `❌ حدث خطأ: ${err.message || 'خطأ غير معروف'}`
            }, { quoted: msg });
        }
    }
};