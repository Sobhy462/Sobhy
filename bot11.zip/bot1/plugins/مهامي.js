// مهام.js - نظام إدارة المهام المتكامل (نسخة محسنة)
const fs = require('fs');
const path = require('path');

const tasksPath = path.join(__dirname, '../data/tasks.json');

if (!fs.existsSync(path.dirname(tasksPath))) fs.mkdirSync(path.dirname(tasksPath), { recursive: true });
if (!fs.existsSync(tasksPath)) fs.writeFileSync(tasksPath, JSON.stringify({}, null, 2));

function loadTasks() {
    try { return JSON.parse(fs.readFileSync(tasksPath)); } catch { return {}; }
}

function saveTasks(data) {
    fs.writeFileSync(tasksPath, JSON.stringify(data, null, 2));
}

// ========== دالة الإرسال ==========
async function sendMessage(sock, chatId, lines, quoted = null, mentions = []) {
    if (!Array.isArray(lines)) {
        lines = [lines];
    }
    
    let msg = `📋 إدارة المهام 📋\n`;
    msg += `━━━━━━━━━━━━━━━━━━━━\n`;
    for (const line of lines) {
        msg += `${line}\n`;
    }
    msg += `━━━━━━━━━━━━━━━━━━━━\n`;
    msg += `𝘽𝙔┇𝑴𝑨𝑲𝑰𝑴𝑨`;
    await sock.sendMessage(chatId, { text: msg, mentions }, { quoted: quoted });
}

module.exports = {
    command: 'مهام',
    description: '📋 إدارة مهامك (عرض، إضافة، حذف)',
    category: 'عام',
    usage: '.مهام [عرض|اضف|حذف|مساعدة]',

    async execute(sock, msg) {
        try {
            const chatId = msg.key.remoteJid;
            const userId = msg.key.participant || msg.key.remoteJid;

            const fullText = msg.message?.conversation || msg.message?.extendedTextMessage?.text || '';
            const args = fullText.trim().split(/\s+/);
            const action = args[1]?.toLowerCase() || 'عرض';

            const data = loadTasks();
            if (!data[chatId]) data[chatId] = {};
            if (!data[chatId][userId]) data[chatId][userId] = [];

            const userTasks = data[chatId][userId];

            // ===== عرض المساعدة =====
            if (action === 'مساعدة' || action === 'help') {
                const lines = [
                    '📚 *أوامر المهام*',
                    ``,
                    '📌 .مهام - عرض مهامك مع الشرح',
                    '📌 .مهام اضف [المهمة] - إضافة مهمة جديدة',
                    '📌 .مهام حذف [الرقم] - حذف مهمة',
                    '📌 .مهام مساعدة - هذه القائمة',
                    ``,
                    '📝 أمثلة:',
                    '.مهام اضف شراء خبز',
                    '.مهام حذف 2'
                ];
                await sendMessage(sock, chatId, lines, msg);
                return;
            }

            // ===== عرض المهام =====
            if (action === 'عرض' || action === 'show') {
                if (userTasks.length === 0) {
                    await sendMessage(sock, chatId, [
                        '📭 لا توجد مهام لك.',
                        '📌 استخدم .مهام اضف [المهمة] لإضافة مهمة.'
                    ], msg);
                    return;
                }

                const lines = [
                    `📚 *مهامك* (${userTasks.length})`,
                    ``
                ];

                userTasks.forEach((task, index) => {
                    lines.push(`${index + 1}. ${task.text}`);
                });

                lines.push(``);
                lines.push(`📌 .مهام حذف [الرقم] - لحذف مهمة`);
                lines.push(`📌 .مهام اضف [المهمة] - لإضافة مهمة`);

                await sendMessage(sock, chatId, lines, msg);
                return;
            }

            // ===== إضافة مهمة =====
            if (action === 'اضف' || action === 'add') {
                const taskText = args.slice(2).join(' ').trim();

                if (!taskText) {
                    await sendMessage(sock, chatId, [
                        '❗ اكتب المهمة بعد الأمر.',
                        '📝 مثال: .مهام اضف شراء خبز'
                    ], msg);
                    return;
                }

                userTasks.push({
                    text: taskText,
                    date: Date.now()
                });

                saveTasks(data);

                await sendMessage(sock, chatId, [
                    `✅ تمت إضافة المهمة:`,
                    `📋 ${taskText}`,
                    `📊 عدد مهامك: ${userTasks.length}`
                ], msg);
                return;
            }

            // ===== حذف مهمة =====
            if (action === 'حذف' || action === 'delete' || action === 'del') {
                const index = parseInt(args[2]);

                if (isNaN(index) || index < 1) {
                    await sendMessage(sock, chatId, [
                        '❗ اكتب رقم المهمة لحذفها.',
                        '📝 مثال: .مهام حذف 2'
                    ], msg);
                    return;
                }

                if (index < 1 || index > userTasks.length) {
                    await sendMessage(sock, chatId, [
                        '❌ رقم المهمة غير موجود.',
                        `📊 عدد مهامك: ${userTasks.length}`
                    ], msg);
                    return;
                }

                const removed = userTasks.splice(index - 1, 1);
                saveTasks(data);

                await sendMessage(sock, chatId, [
                    `🗑️ تم حذف المهمة رقم ${index}:`,
                    `📋 ${removed[0].text}`,
                    `📊 عدد مهامك المتبقي: ${userTasks.length}`
                ], msg);
                return;
            }

            // ===== عرض المهام مع الشرح (الأمر الأساسي بدون كلمة) =====
            if (userTasks.length === 0) {
                await sendMessage(sock, chatId, [
                    '📭 لا توجد مهام لك.',
                    ``,
                    '📚 *الأوامر المتاحة:*',
                    '📌 .مهام اضف [المهمة] - إضافة مهمة',
                    '📌 .مهام حذف [الرقم] - حذف مهمة',
                    '📌 .مهام مساعدة - عرض المساعدة'
                ], msg);
                return;
            }

            // عرض المهام مع الشرح
            const lines = [
                `📚 *مهامك* (${userTasks.length})`,
                ``
            ];

            userTasks.forEach((task, index) => {
                lines.push(`${index + 1}. ${task.text}`);
            });

            lines.push(``);
            lines.push(`━━━━━━━━━━━━━━━━━━━━`);
            lines.push(`📌 *لإضافة مهمة:* .مهام اضف [المهمة]`);
            lines.push(`📌 *لحذف مهمة:* .مهام حذف [الرقم]`);
            lines.push(`📝 مثال: .مهام اضف شراء خبز`);
            lines.push(`📝 مثال: .مهام حذف 2`);

            await sendMessage(sock, chatId, lines, msg);

        } catch (error) {
            console.error('✗ خطأ في أمر مهام:', error);
            await sendMessage(sock, msg.key.remoteJid, [
                '❌ حدث خطأ أثناء تنفيذ الأمر.',
                '📌 حاول مرة أخرى لاحقاً.'
            ], msg);
        }
    }
};