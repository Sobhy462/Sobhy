// دعوة.js - دعوة لاعب للانضمام إلى فريقك (مع دعم .تحالف كاسم بديل) - نسخة متوافقة مع نظام التخزين المنفصل
const fs = require('fs');
const path = require('path');

const teamsPath = path.join(__dirname, '../data/teams.json');

// ===== مسارات التخزين المنفصل =====
const dataDir = path.join(__dirname, '../data/kingdom');
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

const MAIN_PATH = path.join(dataDir, 'main.json');

// ===== التأكد من وجود جميع الملفات =====
if (!fs.existsSync(MAIN_PATH)) fs.writeFileSync(MAIN_PATH, JSON.stringify({}, null, 2));
if (!fs.existsSync(teamsPath)) fs.writeFileSync(teamsPath, JSON.stringify({}, null, 2));

function loadJSON(file) {
    try { return JSON.parse(fs.readFileSync(file)); } catch { return {}; }
}
function saveJSON(file, data) {
    try {
        if (fs.existsSync(file)) fs.writeFileSync(file + '.bak', fs.readFileSync(file));
        fs.writeFileSync(file, JSON.stringify(data, null, 2));
        return true;
    } catch (e) {
        console.error('❌ فشل حفظ الملف:', file, e.message);
        return false;
    }
}

// ========== دوال التخزين المنفصل ==========
function loadUserData(jid) {
    const main = loadJSON(MAIN_PATH)[jid] || {};
    return {
        level: main.level || 1,
        prosperity: main.prosperity || 0,
        lands: main.lands || 0,
        gold: main.gold || 0,
        name: main.name || `مملكة @${jid.split('@')[0]}`,
        owner: main.owner || jid,
        nameChangesUsed: main.nameChangesUsed || 0,
        lastActive: Date.now()
    };
}

function saveUserData(jid, data) {
    const main = loadJSON(MAIN_PATH);
    main[jid] = {
        level: data.level || 1,
        prosperity: data.prosperity || 0,
        lands: data.lands || 0,
        gold: data.gold || 0,
        name: data.name || `مملكة @${jid.split('@')[0]}`,
        owner: data.owner || jid,
        nameChangesUsed: data.nameChangesUsed || 0
    };
    saveJSON(MAIN_PATH, main);
}

function userExists(jid) {
    const main = loadJSON(MAIN_PATH);
    return !!main[jid];
}

// ========== دوال الفرق ==========
function loadTeams() { return loadJSON(teamsPath); }
function saveTeams(data) { saveJSON(teamsPath, data); }

function getTeamNameByMember(jid, teams) {
    for (const [teamName, teamData] of Object.entries(teams)) {
        if (teamData.leader === jid || (teamData.members && teamData.members.includes(jid))) {
            return teamName;
        }
    }
    return null;
}

function getTeam(teamName, teams) {
    return teams[teamName] || null;
}

function isPlayerInTeam(jid, teams) {
    return getTeamNameByMember(jid, teams) !== null;
}

// ========== دالة تصحيح بيانات المستخدم ==========
function sanitizeUser(user) {
    if (!user) return null;
    if (user.level === undefined || user.level === null) user.level = 1;
    if (user.prosperity === undefined || user.prosperity === null) user.prosperity = 0;
    if (user.lands === undefined || user.lands === null) user.lands = 0;
    if (user.gold === undefined || user.gold === null) user.gold = 0;
    if (user.monstersDefeated === undefined || user.monstersDefeated === null) user.monstersDefeated = 0;
    if (user.pvpWins === undefined || user.pvpWins === null) user.pvpWins = 0;
    if (user.pvpLosses === undefined || user.pvpLosses === null) user.pvpLosses = 0;
    if (user.name === undefined || user.name === null) user.name = `مملكة @${user.owner?.split('@')[0] || 'غير معروف'}`;
    if (user.nameChangesUsed === undefined || user.nameChangesUsed === null) user.nameChangesUsed = 0;
    if (!user.resources) user.resources = { wood: 0, stone: 0, iron: 0 };
    if (user.resources.wood === undefined || user.resources.wood === null) user.resources.wood = 0;
    if (user.resources.stone === undefined || user.resources.stone === null) user.resources.stone = 0;
    if (user.resources.iron === undefined || user.resources.iron === null) user.resources.iron = 0;
    if (!user.buildings) user.buildings = { barracks: { level: 0 }, quarry: { level: 0 }, lumberMill: { level: 0 }, ironMine: { level: 0 } };
    if (user.buildings.barracks === undefined) user.buildings.barracks = { level: 0 };
    if (user.buildings.quarry === undefined) user.buildings.quarry = { level: 0 };
    if (user.buildings.lumberMill === undefined) user.buildings.lumberMill = { level: 0 };
    if (user.buildings.ironMine === undefined) user.buildings.ironMine = { level: 0 };
    if (user.buildings.barracks.level === undefined || user.buildings.barracks.level === null) user.buildings.barracks.level = 0;
    if (user.buildings.quarry.level === undefined || user.buildings.quarry.level === null) user.buildings.quarry.level = 0;
    if (user.buildings.lumberMill.level === undefined || user.buildings.lumberMill.level === null) user.buildings.lumberMill.level = 0;
    if (user.buildings.ironMine.level === undefined || user.buildings.ironMine.level === null) user.buildings.ironMine.level = 0;
    if (!user.soldiers) user.soldiers = {};
    const soldierTypes = ['normal', 'knight', 'archer', 'eliteGuard', 'dragonSpearman', 'legendaryCommander'];
    for (const t of soldierTypes) if (user.soldiers[t] === undefined || user.soldiers[t] === null) user.soldiers[t] = 0;
    if (!user.weapons) user.weapons = {};
    const weaponTypes = ['ironSword', 'goldenShield', 'legendaryBow', 'lightningSword', 'giantHammer', 'deathBow', 'destructionAxe', 'heroSword', 'timeBow', 'eternalBlade', 'fireShield', 'godShield'];
    for (const t of weaponTypes) if (user.weapons[t] === undefined || user.weapons[t] === null) user.weapons[t] = 0;
    if (!user.accessories) user.accessories = {};
    const accessoryTypes = ['powerRing', 'protectionRing', 'kingsCrown', 'shadowMask', 'heroMask'];
    for (const t of accessoryTypes) if (user.accessories[t] === undefined || user.accessories[t] === null) user.accessories[t] = 0;
    if (!user.potions) user.potions = {};
    const potionTypes = ['smallHeal', 'largeHeal', 'energyPotion', 'craftedHeal'];
    for (const t of potionTypes) if (user.potions[t] === undefined || user.potions[t] === null) user.potions[t] = 0;
    if (!user.soulBook) user.soulBook = { pages: 0, spirits: [] };
    if (user.soulBook.pages === undefined || user.soulBook.pages === null) user.soulBook.pages = 0;
    if (!user.soulBook.spirits) user.soulBook.spirits = [];
    if (!user.companion) user.companion = null;
    if (!user.owner) user.owner = user.owner || null;
    if (!user.spellsUsed) user.spellsUsed = {};
    user.lastActive = Date.now();
    return user;
}

// ========== دالة الإرسال ==========
async function sendMessage(sock, chatId, lines, quoted = null, mentions = []) {
    if (!Array.isArray(lines)) lines = [lines];
    let msg = `🤝 دعـوة لـلـفـريـق 🤝\n`;
    msg += `━━━━━━━━━━━━━━━━━━━━\n`;
    for (const line of lines) {
        msg += `${line}\n`;
    }
    msg += `━━━━━━━━━━━━━━━━━━━━\n`;
    msg += `𝘽𝙔┇𝑴𝑨𝑲𝑰𝑴𝑨`;
    await sock.sendMessage(chatId, { text: msg, mentions }, { quoted: quoted });
}

// ========== دوال استخراج المنشن ==========
function extractMentions(msg) {
    const contextInfo = msg.message?.extendedTextMessage?.contextInfo || {};
    if (contextInfo.mentionedJid && contextInfo.mentionedJid.length > 0) {
        return contextInfo.mentionedJid;
    }
    const text = msg.message?.conversation || msg.message?.extendedTextMessage?.text || '';
    const mentionMatch = text.match(/@(\d+)/);
    if (mentionMatch) {
        return [`${mentionMatch[1]}@s.whatsapp.net`];
    }
    if (contextInfo.participant) {
        return [contextInfo.participant];
    }
    return [];
}

// تخزين الدعوات النشطة
const activeInvites = new Map();

// ========== الأمر الرئيسي ==========
module.exports = {
    command: ['دعوة', 'تحالف'],
    description: '🤝 دعوة لاعب للانضمام إلى فريقك (القائد فقط)',
    category: 'مملكة',
    usage: '.دعوة @منشن',
    example: '.دعوة @منشن',

    async execute(sock, msg) {
        try {
            const chatId = msg.key.remoteJid;
            const sender = msg.key.participant || msg.participant || msg.key.remoteJid;

            // استخراج الهدف
            const mentioned = extractMentions(msg);
            const quotedSender = msg.message?.extendedTextMessage?.contextInfo?.participant || null;
            let target = null;

            if (mentioned.length > 0) {
                target = mentioned[0];
            } else if (quotedSender) {
                target = quotedSender;
            } else {
                await sendMessage(sock, chatId, [
                    `❌ @${sender.split('@')[0]}`,
                    `📌 يجب منشن الشخص الذي تريد دعوته أو الرد على رسالته.`,
                    `📝 مثال: .دعوة @منشن`
                ], msg, [sender]);
                return;
            }

            if (target === sender) {
                await sendMessage(sock, chatId, [
                    `❌ لا يمكنك دعوة نفسك!`
                ], msg, [sender]);
                return;
            }

            // تحميل البيانات
            const teams = loadTeams();

            // ===== التحقق من وجود مملكة للمرسل =====
            if (!userExists(sender)) {
                await sendMessage(sock, chatId, [
                    `❌ @${sender.split('@')[0]}، ليس لديك مملكة.`,
                    `📌 استخدم .لاعب جديد لتأسيس مملكتك.`
                ], msg, [sender]);
                return;
            }

            let senderUser = loadUserData(sender);
            senderUser = sanitizeUser(senderUser);
            saveUserData(sender, senderUser);

            // ===== التحقق من وجود مملكة للهدف =====
            if (!userExists(target)) {
                await sendMessage(sock, chatId, [
                    `❌ @${target.split('@')[0]}، ليس لديه مملكة.`,
                    `📌 لا يمكن دعوة شخص ليس لديه مملكة.`
                ], msg, [sender, target]);
                return;
            }

            let targetUser = loadUserData(target);
            targetUser = sanitizeUser(targetUser);
            saveUserData(target, targetUser);

            // ===== التحقق من أن المرسل في فريق =====
            const senderTeamName = getTeamNameByMember(sender, teams);
            if (!senderTeamName) {
                await sendMessage(sock, chatId, [
                    `❌ @${sender.split('@')[0]}، أنت لست في أي فريق.`,
                    `📌 استخدم .فريق جديد لإنشاء فريق أولاً.`
                ], msg, [sender]);
                return;
            }

            const teamData = getTeam(senderTeamName, teams);
            if (!teamData) {
                await sendMessage(sock, chatId, [
                    `❌ حدث خطأ: الفريق غير موجود.`
                ], msg, [sender]);
                return;
            }

            // ===== التحقق من أن المرسل هو القائد =====
            if (teamData.leader !== sender) {
                await sendMessage(sock, chatId, [
                    `❌ @${sender.split('@')[0]}، فقط قائد الفريق يمكنه دعوة أعضاء جدد.`
                ], msg, [sender]);
                return;
            }

            // ===== التحقق من أن الهدف ليس في فريق بالفعل =====
            if (isPlayerInTeam(target, teams)) {
                await sendMessage(sock, chatId, [
                    `⚠️ @${target.split('@')[0]}، هو بالفعل عضو في فريق آخر.`,
                    `📌 لا يمكنك دعوته.`
                ], msg, [sender, target]);
                return;
            }

            // ===== التحقق من وجود دعوة نشطة =====
            for (const [key, invite] of activeInvites) {
                if (invite.teamName === senderTeamName && invite.target === target && invite.status === 'pending') {
                    await sendMessage(sock, chatId, [
                        `⏳ هناك دعوة معلقة لـ @${target.split('@')[0]} بالفعل.`,
                        `📌 انتظر الرد.`
                    ], msg, [sender, target]);
                    return;
                }
            }

            // ===== إنشاء دعوة جديدة =====
            const inviteId = Date.now().toString();
            const inviteData = {
                id: inviteId,
                teamName: senderTeamName,
                leader: sender,
                target: target,
                status: 'pending',
                timestamp: Date.now()
            };

            activeInvites.set(inviteId, inviteData);

            // ===== إرسال الدعوة للهدف =====
            await sendMessage(sock, chatId, [
                `📨 @${sender.split('@')[0]} يدعوك للانضمام إلى فريق *${senderTeamName}*.`,
                ``,
                `👑 القائد: @${sender.split('@')[0]}`,
                `👥 عدد الأعضاء: ${teamData.members.length + 1}`,
                ``,
                `⚠️ *للمدعو @${target.split('@')[0]}*:`,
                `📌 اكتب \`موافق\` لقبول الدعوة.`,
                `📌 اكتب \`رفض\` لرفض الدعوة.`,
                ``,
                `⏳ الدعوة تنتهي بعد 5 دقائق.`
            ], msg, [sender, target]);

            // ===== مراقبة رد المدعو =====
            const handler = async ({ messages }) => {
                for (const m of messages) {
                    const from = m.key.participant || m.participant || m.key.remoteJid;
                    if (from === sock.user.id) continue;
                    if (m.key.remoteJid !== chatId) continue;

                    const txt = m.message?.conversation || m.message?.extendedTextMessage?.text || '';
                    if (!txt.trim()) continue;
                    const content = txt.trim().toLowerCase();

                    const invite = activeInvites.get(inviteId);
                    if (!invite || invite.status !== 'pending') continue;

                    // التأكد أن المرسل هو المدعو
                    if (from !== invite.target) {
                        if (from === invite.leader) {
                            await sendMessage(sock, chatId, [
                                `⏳ @${from.split('@')[0]}، انتظر رد @${invite.target.split('@')[0]}.`
                            ], m, [from, invite.target]);
                        }
                        continue;
                    }

                    // قبول الدعوة
                    if (content === 'موافق') {
                        const currentTeams = loadJSON(teamsPath);
                        const team = getTeam(invite.teamName, currentTeams);
                        if (team) {
                            if (!team.members.includes(invite.target)) {
                                team.members.push(invite.target);
                                saveTeams(currentTeams);
                            }
                        }

                        // تحديث lastActive للعضو
                        let memberUser = loadUserData(invite.target);
                        memberUser = sanitizeUser(memberUser);
                        saveUserData(invite.target, memberUser);

                        activeInvites.delete(inviteId);

                        await sendMessage(sock, chatId, [
                            `✅ @${invite.target.split('@')[0]} وافق على الدعوة!`,
                            ``,
                            `🎉 انضم @${invite.target.split('@')[0]} إلى فريق *${invite.teamName}*.`,
                            `👥 عدد الأعضاء الآن: ${team ? team.members.length + 1 : 'غير معروف'}`,
                            ``,
                            `📌 استخدم .فريقي لعرض معلومات فريقك.`
                        ], m, [invite.leader, invite.target]);
                        sock.ev.off('messages.upsert', handler);
                        return;
                    }

                    // رفض الدعوة
                    if (content === 'رفض') {
                        activeInvites.delete(inviteId);

                        await sendMessage(sock, chatId, [
                            `❌ @${invite.target.split('@')[0]} رفض الدعوة.`,
                            ``,
                            `📌 يمكن للقائد @${invite.leader.split('@')[0]} إرسال دعوة جديدة لاحقاً.`
                        ], m, [invite.leader, invite.target]);
                        sock.ev.off('messages.upsert', handler);
                        return;
                    }
                }
            };

            sock.ev.on('messages.upsert', handler);

            // انتهاء المهلة
            setTimeout(() => {
                const invite = activeInvites.get(inviteId);
                if (invite && invite.status === 'pending') {
                    activeInvites.delete(inviteId);
                    sock.ev.off('messages.upsert', handler);
                    sendMessage(sock, chatId, [
                        `⏰ انتهت صلاحية الدعوة (5 دقائق).`,
                        `📌 أرسل دعوة جديدة إذا أردت.`
                    ], null, [invite.leader, invite.target]);
                }
            }, 5 * 60 * 1000);

        } catch (error) {
            console.error('✗ خطأ في أمر دعوة:', error);
            await sendMessage(sock, msg.key.remoteJid, [
                '❌ حدث خطأ أثناء تنفيذ الأمر.',
                '📌 حاول مرة أخرى لاحقاً.'
            ], msg);
        }
    }
};