const fs = require('fs');
const path = require('path');

module.exports = {
   command: ['لافيو', 'بوسة'],
    description: '💋 إرسال بوسة ساخنة لشخص تم منشنه أو الرد عليه.',
    usage: '.بوسة [منشن أو رد على رسالة]',
    category: 'تحرش',

    async execute(sock, msg) {
        try {
            await sock.sendMessage(msg.key.remoteJid, { react: { text: '🫦', key: msg.key } });

            const kissLines = [
                "💋 بوسة على خدك الأيمن، والأيسر هدية مجانية 🫦",
                "💋 بوسة هواء، بس روحها وصلت قلبك 💖",
                "💋 بوسة مممم... طعمها سكر ونسيم 🍬",
                "💋 بوسة طويلة جداً، لدرجة إنك تنسى تتنفس 😘💨",
                "💋 بوسة على جبينك، عشان تبقى في بالي دايم 💭",
                "💋 بوسة سريعة، بس تأثيرها أبدي 💥",
                "💋 بوسة ناعمة كالحرير، تحسها على جلدك 🫦",
                "💋 بوسة دافئة، تدفيك من برد الدنيا 🌞",
                "💋 بوسة فيها حنية أم، وحلاوة حب 💞",
                "💋 بوسة تكفي تغير مزاجك 180 درجة 😏",
                "💋 بوسة على شفتيك، لو تسمح لي 🫦💋",
                "💋 بوسة ممزوجة بعطر الياسمين 🌸",
                "💋 بوسة فيها شوية جرأة، وشوية خجل 😳",
                "💋 بوسة تحكي قصة حب من أول نظرة 👀",
                "💋 بوسة تخليني أحس إنك ملكي 👑",
                "💋 بوسة تروح وتيجي، بس تبقالي أنا 😉",
                "💋 بوسة تسكر بدون خمر 🍷",
                "💋 بوسة تحلم فيها من الليل للنهار 🌙",
                "💋 بوسة فيها كل مشاعر الكون 🌌",
                "💋 بوسة على خدك، وثانية على رقبتك 🦋",
                "💋 بوسة تغني في أذنك كلمات حب 🎵",
                "💋 بوسة تحسها في عروقك 👀",
                "💋 بوسة ترسم ابتسامة على وشك 😁",
                "💋 بوسة تنفض عنك كل تعب اليوم 🧘",
                "💋 بوسة فيها حرارة الصيف، ونسيم الشتاء ☀️❄️",
                "💋 بوسة تعيد ترتيب خلاياك 🧬",
                "💋 بوسة تخليك تنسى كل الهموم 🌊",
                "💋 بوسة تكافئ صبرك على الانتظار ⏳",
                "💋 بوسة تمنحك جرعة أمل 💫",
                "💋 بوسة تقول لك 'أنا هنا' بدون كلام 🤫",
                "💋 بوسة تسافر عبر الزمن لقلبك 🕰️",
                "💋 بوسة تخليك تحس إنك نجم 🌟",
                "💋 بوسة فيها لمسة جنون 🥴",
                "💋 بوسة تشبه طعم الفراولة 🍓",
                "💋 بوسة تقدم لك اعتذار عن أي غياب 💌",
                "💋 بوسة تقول 'بحبك' بصمت ❤️",
                "💋 بوسة تذكّرك بأيام الحب الأولى 🌷",
                "💋 بوسة تغسل روحك من أي حزن 🧼",
                "💋 بوسة تعطيك طاقة جديدة لليوم ⚡",
                "💋 بوسة أخيرة، بس مش آخر مرة 😘💋"
            ];

            let targetJid = null;
            let quotedMessageId = null;

            if (msg.message.extendedTextMessage?.contextInfo?.quotedMessage) {
                targetJid = msg.message.extendedTextMessage.contextInfo.participant;
                quotedMessageId = msg.message.extendedTextMessage.contextInfo.stanzaId;
            } else if (msg.message.extendedTextMessage?.contextInfo?.mentionedJid?.length > 0) {
                targetJid = msg.message.extendedTextMessage.contextInfo.mentionedJid[0];
            } else {
                await sock.sendMessage(
                    msg.key.remoteJid,
                    { text: `❌ لازم تمنشن أو ترد على رسالة عشان أقدر أرسل البوسة🫦🤤` },
                    { quoted: msg }
                );
                return;
            }

            if (!targetJid) {
                await sock.sendMessage(
                    msg.key.remoteJid,
                    { text: `❌ ما قدرت أحدد الشخص، جرب تمنشنه أو ترد عليه.` },
                    { quoted: msg }
                );
                return;
            }

            // ✅ تم التصحيح هنا: استخدم kissLines بدلاً من flirtLines
            const randomKiss = kissLines[Math.floor(Math.random() * kissLines.length)];

            if (quotedMessageId) {
                await sock.sendMessage(
                    msg.key.remoteJid,
                    { text: `${randomKiss}` },
                    { quoted: {
                        key: {
                            remoteJid: msg.key.remoteJid,
                            id: quotedMessageId,
                            participant: targetJid
                        },
                        message: { conversation: "Original Message" }
                    }}
                );
            } else {
                await sock.sendMessage(
                    msg.key.remoteJid,
                    { 
                        text: `@${targetJid.split('@')[0]} ${randomKiss}`,
                        mentions: [targetJid]
                    },
                    { quoted: msg }
                );
            }

        } catch (error) {
            console.error('❌ خطأ في أمر "بوسة":', error);
            await sock.sendMessage(msg.key.remoteJid, {
                text: `❌ صار خطأ: ${error.message || error.toString()}`
            }, { quoted: msg });
        }
    }
};