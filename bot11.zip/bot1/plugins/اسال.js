// اسال.js - فعالية الأسئلة العلمية التنافسية (نسخة محسنة)

const fs = require('fs');
const path = require('path');

const pointsPath = path.join(__dirname, '../data/points.json');
const ranksPath = path.join(__dirname, '../data/ranks.json');

// ========== التأكد من وجود الملفات ==========
if (!fs.existsSync(pointsPath)) fs.writeFileSync(pointsPath, JSON.stringify({}, null, 2));
if (!fs.existsSync(ranksPath)) fs.writeFileSync(ranksPath, JSON.stringify({}, null, 2));

// ========== دوال مساعدة ==========
function loadJSON(file) {
    try { return JSON.parse(fs.readFileSync(file)); } 
    catch { return {}; }
}

function saveJSON(file, data) {
    fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

function getLevel(points) {
    if (points >= 1000000000) return '👑 DEVELOPER';
    if (points >= 100000000) return '🌀 KING OF POINTS';
    if (points >= 10000000) return '💀 BIG BOSS';
    if (points >= 1000000) return '🔥🔥 WTF';
    if (points >= 100000) return '🔪🩸 KILLER';
    if (points >= 10000) return '🦁 LEGEND';
    if (points >= 1000) return '💎 PRO';
    if (points >= 500) return '🔥 advanced';
    if (points >= 200) return '🌱 junior';
    return '🙂 beginner';
}

function formatNumber(num) {
    if (num === undefined || num === null || isNaN(num)) return '0';
    num = Math.floor(num);
    if (num >= 1e15) return '∞';
    if (num >= 1e12) return (num / 1e12).toFixed(2) + ' تريليون';
    if (num >= 1e9) return (num / 1e9).toFixed(2) + ' مليار';
    if (num >= 1e6) return (num / 1e6).toFixed(2) + ' مليون';
    if (num >= 1e3) return (num / 1e3).toFixed(2) + ' ألف';
    return num.toString();
}

// ========== دالة تطبيع النص ==========
function normalize(str) {
    return str.trim()
        .replace(/[أإآ]/g, 'ا')
        .replace(/[ى]/g, 'ي')
        .replace(/\s+/g, ' ')
        .toLowerCase();
}

function isMatching(input, answers) {
    const normInput = normalize(input);
    return answers.some(a => normalize(a) === normInput);
}

// ========== دالة الإرسال بتنسيق موحد ==========
async function sendMessage(sock, chatId, lines, quoted = null, mentions = []) {
    if (!Array.isArray(lines)) {
        lines = [lines];
    }

    let msg = `🎓 أسـئـلـة عـلـمـيـة 🎓\n`;
    msg += `━━━━━━━━━━━━━━━━━━━━\n`;
    for (const line of lines) {
        if (line && line.trim()) {
            msg += `${line}\n`;
        }
    }
    msg += `━━━━━━━━━━━━━━━━━━━━\n`;
    msg += `𝘽𝙔┇𝑴𝑨𝑲𝑰𝑴𝑨`;
    
    await sock.sendMessage(chatId, { 
        text: msg, 
        mentions 
    }, { 
        quoted: quoted 
    });
}

// ========== قائمة الأسئلة العلمية - النسخة الموسعة ==========
const questions = [
    // ===== المجموعة الأولى: الفضاء والكواكب =====
    { question: 'ما هو الكوكب الأحمر؟', answers: ['المريخ', 'مرّيخ', 'كوكب المريخ'] },
    { question: 'ما هو أقرب كوكب إلى الشمس؟', answers: ['عطارد', 'الزئبق'] },
    { question: 'ما هو أبعد كوكب في المجموعة الشمسية؟', answers: ['نبتون', 'نيبتون'] },
    { question: 'كم عدد الكواكب في النظام الشمسي؟', answers: ['8', 'ثمانية', '8 كواكب'] },
    { question: 'ما هو أكبر كوكب في المجموعة الشمسية؟', answers: ['المشتري', 'مشتري', 'جوبيتر'] },
    { question: 'ما هو أصغر كوكب في المجموعة الشمسية؟', answers: ['عطارد', 'الزئبق'] },
    { question: 'ما هو الكوكب الذي يدور حوله حلقات؟', answers: ['زحل', 'ساتورن'] },
    { question: 'ما هو الكوكب الأزرق؟', answers: ['الأرض', 'ارض', 'الكوكب الأرضي'] },
    { question: 'ما هي المجموعة التي تحتوي على الشمس والكواكب؟', answers: ['المجموعة الشمسية', 'النظام الشمسي'] },
    { question: 'ما هو القمر التابع لكوكب الأرض؟', answers: ['القمر', 'الأقمار'] },
    { question: 'ما هي أول مركبة فضائية هبطت على القمر؟', answers: ['أبولو 11', 'ابولو'] },
    { question: 'ما هو اسم أول رائد فضاء مشى على القمر؟', answers: ['نيل أرمسترونغ', 'ارمسترونغ', 'نيل'] },
    { question: 'ما هو عدد الأقمار الطبيعية لكوكب المريخ؟', answers: ['2', 'اثنان', 'قمران'] },

    // ===== المجموعة الثانية: الكيمياء والعناصر =====
    { question: 'ما هو العنصر الكيميائي الذي رمزه O؟', answers: ['أكسجين', 'الأكسجين', 'اكسجين', 'اوكسجين'] },
    { question: 'ما هو العنصر الكيميائي الذي رمزه H؟', answers: ['هيدروجين', 'الهيدروجين'] },
    { question: 'ما هو العنصر الكيميائي الذي رمزه C؟', answers: ['كربون', 'الكربون'] },
    { question: 'ما هو العنصر الكيميائي الذي رمزه N؟', answers: ['نيتروجين', 'النيتروجين', 'آزوت'] },
    { question: 'ما هو العنصر الكيميائي الذي رمزه Fe؟', answers: ['حديد', 'الحديد'] },
    { question: 'ما هو العنصر الكيميائي الذي رمزه Au؟', answers: ['ذهب', 'الذهب'] },
    { question: 'ما هو العنصر الكيميائي الذي رمزه Ag؟', answers: ['فضة', 'الفضة'] },
    { question: 'ما هو العنصر الكيميائي الذي رمزه Cu؟', answers: ['نحاس', 'النحاس'] },
    { question: 'ما هو العنصر الكيميائي الذي رمزه He؟', answers: ['هيليوم', 'الهيليوم'] },
    { question: 'ما هو العنصر الكيميائي الذي رمزه Na؟', answers: ['صوديوم', 'الصوديوم'] },
    { question: 'ما هو العنصر الكيميائي الذي رمزه Cl؟', answers: ['كلور', 'الكلور'] },
    { question: 'ما هو العنصر الكيميائي الذي رمزه K؟', answers: ['بوتاسيوم', 'البوتاسيوم'] },
    { question: 'ما هو العنصر الكيميائي الذي رمزه Ca؟', answers: ['كالسيوم', 'الكالسيوم'] },
    { question: 'ما هو العنصر الكيميائي الذي رمزه Mg؟', answers: ['مغنيسيوم', 'المغنيسيوم'] },
    { question: 'ما هو العنصر الكيميائي الذي رمزه Zn؟', answers: ['زنك', 'الزنك'] },

    // ===== المجموعة الثالثة: علماء واختراعات =====
    { question: 'من أول من وضع علم الجبر؟', answers: ['الخوارزمي', 'خوارزمي', 'محمد بن موسى الخوارزمي'] },
    { question: 'من هو مكتشف قانون الجاذبية؟', answers: ['نيوتن', 'اسحاق نيوتن', 'إسحاق نيوتن'] },
    { question: 'من هو مؤسس شركة مايكروسوفت؟', answers: ['بيل غيتس', 'غيتس', 'بيل', 'بل غيتس'] },
    { question: 'من هو مؤسس شركة آبل؟', answers: ['ستيف جوبز', 'جوبز', 'ستيف'] },
    { question: 'من هو مخترع المصباح الكهربائي؟', answers: ['توماس إديسون', 'إديسون', 'اديسون'] },
    { question: 'من هو مخترع الهاتف؟', answers: ['غراهام بيل', 'بيل', 'ألكسندر غراهام بيل'] },
    { question: 'من هو مخترع الطائرة؟', answers: ['الأخوان رايت', 'رايت', 'ويلبر رايت'] },
    { question: 'من هو مكتشف البنسلين؟', answers: ['فليمنغ', 'ألكسندر فليمنغ'] },
    { question: 'من هو مكتشف الدورة الدموية؟', answers: ['ابن النفيس', 'النفيس'] },
    { question: 'من هو مؤسس علم المنطق؟', answers: ['أرسطو', 'ارسطو', 'ارسطوطاليس'] },
    { question: 'من هو مؤسس علم النفس الحديث؟', answers: ['سيغموند فرويد', 'فرويد'] },
    { question: 'من هو صاحب نظرية النسبية؟', answers: ['أينشتاين', 'البرت أينشتاين', 'انشتاين'] },
    { question: 'من هو مخترع الطباعة؟', answers: ['غوتنبرغ', 'جوتنبرج'] },
    { question: 'من هو مكتشف الدورة الدموية الصغرى؟', answers: ['ابن سينا', 'بو علي سينا'] },

    // ===== المجموعة الرابعة: جغرافيا ودول =====
    { question: 'ما هي عاصمة اليابان؟', answers: ['طوكيو', 'توكيو', 'طوكيوه'] },
    { question: 'ما هي عاصمة مصر؟', answers: ['القاهرة', 'قاهرة', 'القاهره'] },
    { question: 'ما هي عاصمة السعودية؟', answers: ['الرياض', 'رياض'] },
    { question: 'ما هي عاصمة الإمارات؟', answers: ['أبو ظبي', 'ابوظبي', 'أبوظبي'] },
    { question: 'ما هي عاصمة قطر؟', answers: ['الدوحة', 'دوحة'] },
    { question: 'ما هي عاصمة الكويت؟', answers: ['مدينة الكويت', 'كويت'] },
    { question: 'ما هي عاصمة الأردن؟', answers: ['عمان', 'عمّان'] },
    { question: 'ما هي عاصمة المغرب؟', answers: ['الرباط', 'رباط'] },
    { question: 'ما هي عاصمة الجزائر؟', answers: ['الجزائر', 'جزائر'] },
    { question: 'ما هي عاصمة تونس؟', answers: ['تونس'] },
    { question: 'ما هي عاصمة فلسطين؟', answers: ['القدس', 'قدس', 'القدس الشريف'] },
    { question: 'ما هي عاصمة لبنان؟', answers: ['بيروت'] },
    { question: 'ما هي عاصمة سوريا؟', answers: ['دمشق'] },
    { question: 'ما هي عاصمة العراق؟', answers: ['بغداد'] },
    { question: 'ما هي عاصمة اليمن؟', answers: ['صنعاء'] },
    { question: 'ما هي عاصمة السودان؟', answers: ['الخرطوم', 'خرطوم'] },
    { question: 'ما هي عاصمة ليبيا؟', answers: ['طرابلس'] },
    { question: 'في أي قارة تقع مصر؟', answers: ['أفريقيا', 'افريقيا', 'إفريقيا'] },
    { question: 'في أي قارة تقع السعودية؟', answers: ['آسيا', 'اسيا'] },
    { question: 'في أي قارة تقع أستراليا؟', answers: ['أوقيانوسيا', 'اوقيانوسيا', 'استراليا'] },
    { question: 'ما هي أكبر دولة في العالم من حيث المساحة؟', answers: ['روسيا', 'روسي'] },
    { question: 'ما هي أصغر دولة في العالم من حيث المساحة؟', answers: ['الفاتيكان', 'فاتيكان', 'فايتيكان'] },
    { question: 'ما هي أكبر دولة في العالم من حيث عدد السكان؟', answers: ['الهند', 'الهند'] },
    { question: 'ما هو أكبر محيط في العالم؟', answers: ['المحيط الهادئ', 'الهادئ', 'باسيفيك', 'محيط هادئ'] },
    { question: 'ما هو أعمق محيط في العالم؟', answers: ['المحيط الهادئ', 'الهادئ'] },
    { question: 'ما هو أعلى جبل في العالم؟', answers: ['إيفرست', 'جبل ايفرست', 'افريست'] },

    // ===== المجموعة الخامسة: حيوانات وطبيعة =====
    { question: 'ما هو الحيوان الذي يُعرف بـ "ملك الغابة"؟', answers: ['الأسد', 'اسد', 'ملك الغابة'] },
    { question: 'ما هو أسرع حيوان بري؟', answers: ['الفهد', 'فهد', 'شيتا', 'شيتاه'] },
    { question: 'ما هو أضخم حيوان في العالم؟', answers: ['الحوت الأزرق', 'حوت أزرق', 'الحوت'] },
    { question: 'ما هو أطول حيوان في العالم؟', answers: ['الزرافة', 'زرافة'] },
    { question: 'ما هو الحيوان الذي يستطيع تغيير لونه؟', answers: ['الحرباء', 'حرباء'] },
    { question: 'ما هو أسرع طائر في العالم؟', answers: ['الصقر', 'الشاهين', 'صقر'] },
    { question: 'ما هو أذكى حيوان في العالم؟', answers: ['الدلفين', 'دولفين'] },
    { question: 'ما هو أكبر طائر في العالم؟', answers: ['النعامة', 'نعامة'] },
    { question: 'ما هو الحيوان الذي ينام وعيناه مفتوحتان؟', answers: ['الدلفين', 'الحوت'] },
    { question: 'ما هو الحيوان الذي لا يشرب الماء؟', answers: ['الكوالا', 'كوالا', 'الكنغر'] },
    { question: 'ما هو الحيوان الذي يمتلك أطول رقبة؟', answers: ['الزرافة', 'زرافة'] },
    { question: 'ما هو أطول نهر في العالم؟', answers: ['النيل', 'نيل'] },
    { question: 'ما هو أعلى شلال في العالم؟', answers: ['شلال أنجل', 'انجل'] },
    { question: 'ما هو أكبر صحراء في العالم؟', answers: ['الصحراء الكبرى', 'الصحراء'] },
    { question: 'ما هو أبرد مكان في العالم؟', answers: ['أنتاركتيكا', 'القارة القطبية'] },

    // ===== المجموعة السادسة: رياضيات =====
    { question: 'ما هو عدد أضلاع المربع؟', answers: ['4', 'أربعة', 'اربع'] },
    { question: 'ما هو عدد أضلاع المثلث؟', answers: ['3', 'ثلاثة', 'ثلاث'] },
    { question: 'ما هو عدد أضلاع المستطيل؟', answers: ['4', 'أربعة'] },
    { question: 'ما هو عدد أضلاع الدائرة؟', answers: ['0', 'صفر', 'لا يوجد'] },
    { question: 'ما هو ناتج 5 + 5؟', answers: ['10', 'عشرة', '١٠'] },
    { question: 'ما هو ناتج 6 × 6؟', answers: ['36', 'ستة وثلاثون'] },
    { question: 'ما هو ناتج 10 ÷ 2؟', answers: ['5', 'خمسة', '٥'] },
    { question: 'ما هو ناتج 9 - 3؟', answers: ['6', 'ستة', '٦'] },
    { question: 'ما هو الجذر التربيعي لـ 16؟', answers: ['4', 'أربعة'] },
    { question: 'ما هو الجذر التربيعي لـ 81؟', answers: ['9', 'تسعة'] },
    { question: 'ما هو العدد الأولي الذي يأتي بعد 7؟', answers: ['11', 'احد عشر'] },
    { question: 'ما هو العدد الزوجي الذي يأتي بعد 2؟', answers: ['4', 'أربعة'] },
    { question: 'كم عدد أيام الأسبوع؟', answers: ['7', 'سبعة'] },
    { question: 'كم عدد أشهر السنة؟', answers: ['12', 'اثنا عشر'] },

    // ===== المجموعة السابعة: لغة وبرمجة =====
    { question: 'ما هي لغة البرمجة التي تبدأ بـ "ج" وتشتهر لتطوير الويب؟', answers: ['جافاسكريبت', 'جافا سكريبت', 'JavaScript', 'جاڤا سكريبت'] },
    { question: 'ما هي لغة البرمجة التي تستخدم لتطوير تطبيقات أندرويد؟', answers: ['جافا', 'Java', 'كوتلن', 'Kotlin'] },
    { question: 'ما هي لغة البرمجة التي تستخدم لتطوير تطبيقات iOS؟', answers: ['سويفت', 'Swift', 'أوبجيكتيف سي'] },
    { question: 'ما هي لغة البرمجة الأكثر استخداماً في الذكاء الاصطناعي؟', answers: ['بايثون', 'Python', 'باي ثون'] },
    { question: 'ما هي لغة البرمجة التي تستخدم لتطوير الألعاب؟', answers: ['سي شارب', 'C#', 'سي++', 'C++'] },
    { question: 'ما هي لغة البرمجة التي تستخدم لتصميم مواقع الويب؟', answers: ['HTML', 'اتش تي ام ال', 'إتش تي إم إل'] },
    { question: 'ما هي لغة البرمجة التي تستخدم لتنسيق صفحات الويب؟', answers: ['CSS', 'سي اس اس', 'سي إس إس'] },
    { question: 'ما هو نظام التشغيل الأكثر استخداماً في العالم؟', answers: ['ويندوز', 'Windows'] },
    { question: 'ما هو نظام التشغيل المفتوح المصدر؟', answers: ['لينكس', 'Linux', 'أوبونتو'] },
    { question: 'ما هو نظام التشغيل الخاص بشركة آبل؟', answers: ['ماك', 'MacOS', 'ماك أو إس'] },
    { question: 'ما هو نظام التشغيل الخاص بالهواتف الذكية من جوجل؟', answers: ['أندرويد', 'Android'] },

    // ===== المجموعة الثامنة: أدب وثقافة =====
    { question: 'من هو مؤلف رواية "البؤساء"؟', answers: ['فيكتور هوغو', 'هوغو', 'Victor Hugo'] },
    { question: 'من هو مؤلف رواية "مئة عام من العزلة"؟', answers: ['غابرييل غارسيا ماركيز', 'ماركيز'] },
    { question: 'من هو مؤلف كتاب "ألف ليلة وليلة"؟', answers: ['غير معروف', 'مجهول'] },
    { question: 'من هو شاعر المعلقات السبع؟', answers: ['امرؤ القيس', 'طرفة'] },
    { question: 'ما هو اسم مسرحيات ويليام شكسبير الشهيرة؟', answers: ['هاملت', 'روميو وجولييت', 'ماكبث'] },
    { question: 'من هو أبو الشعر الحديث؟', answers: ['أحمد شوقي', 'شوقي'] },
    { question: 'من هو مؤلف كتاب "الرحيق المختوم"؟', answers: ['صفي الرحمن المباركفوري', 'المباركفوري'] },
    { question: 'من هو مؤلف كتاب "البيان والتبيين"؟', answers: ['الجاحظ', 'جاحظ'] },
    { question: 'ما هو أشهر كتب ابن خلدون؟', answers: ['المقدمة', 'تاريخ ابن خلدون'] },
    { question: 'ما هو اسم الكتاب المقدس عند المسلمين؟', answers: ['القرآن', 'القرآن الكريم'] },

    // ===== المجموعة التاسعة: صحة وطب =====
    { question: 'كم عدد عظام جسم الإنسان؟', answers: ['206', 'مئتان وست'] },
    { question: 'كم عدد عضلات جسم الإنسان؟', answers: ['600', 'ستمائة'] },
    { question: 'كم عدد أسنان الإنسان البالغ؟', answers: ['32', 'اثنان وثلاثون'] },
    { question: 'ما هو حجم قلب الإنسان؟', answers: ['حجم قبضة اليد', 'مثل قبضة'] },
    { question: 'كم عدد نبضات القلب في الدقيقة؟', answers: ['72', '70', '80'] },
    { question: 'ما هي نسبة الماء في جسم الإنسان؟', answers: ['60%', 'ستون بالمئة'] },
    { question: 'ما هو الجهاز المسؤول عن التنفس؟', answers: ['الجهاز التنفسي', 'الرئتين'] },
    { question: 'ما هو الجهاز المسؤول عن الهضم؟', answers: ['الجهاز الهضمي', 'المعدة'] },
    { question: 'ما هو أكبر عضو في جسم الإنسان؟', answers: ['الجلد', 'الكبد'] },
    { question: 'ما هو أصغر عظم في جسم الإنسان؟', answers: ['العظيمات الثلاث', 'ركاب'] },
    { question: 'ما هو الفيتامين الذي ينتجه الجلد عند التعرض للشمس؟', answers: ['فيتامين د', 'د'] },
    { question: 'ما هو المعدن الأساسي في العظام؟', answers: ['الكالسيوم', 'كالسيوم'] },
    { question: 'ما هو السكر الموجود في الدم؟', answers: ['الجلوكوز', 'سكر'] },

    // ===== المجموعة العاشرة: عامة ومتنوعة =====
    { question: 'ما هو الجهاز الذي يستخدم لقياس درجة الحرارة؟', answers: ['الترمومتر', 'ترمومتر', 'ثيرمومتر', 'ميزان حرارة'] },
    { question: 'ما هي وحدة قياس شدة التيار الكهربائي؟', answers: ['الأمبير', 'امبير', 'أمبير', 'Ampere'] },
    { question: 'ما هي وحدة قياس الجهد الكهربائي؟', answers: ['الفولت', 'فولت', 'Volt'] },
    { question: 'ما هي وحدة قياس المقاومة الكهربائية؟', answers: ['الأوم', 'اوم', 'Ohm'] },
    { question: 'ما هو اللون الناتج عن خلط الأحمر والأزرق؟', answers: ['الأرجواني', 'ارجواني', 'بنفسجي', 'موف'] },
    { question: 'ما هو اللون الناتج عن خلط الأحمر والأصفر؟', answers: ['البرتقالي', 'برتقالي'] },
    { question: 'ما هو اللون الناتج عن خلط الأزرق والأصفر؟', answers: ['الأخضر', 'اخضر'] },
    { question: 'ما هي الألوان الأساسية؟', answers: ['الأحمر', 'الأزرق', 'الأصفر'] },
    { question: 'ما هي اللغة الأكثر تحدثاً في العالم؟', answers: ['الإنجليزية', 'الانجليزية', 'الإنجليزية'] },
    { question: 'ما هي ثاني أكثر لغة تحدثاً في العالم؟', answers: ['الصينية', 'المندرين'] },
    { question: 'ما هي اللغة الرسمية في مصر؟', answers: ['العربية'] },
    { question: 'ما هي العملة الرسمية في مصر؟', answers: ['الجنيه المصري', 'جنيه مصري'] },
    { question: 'ما هي عملة السعودية؟', answers: ['الريال السعودي', 'ريال'] },
    { question: 'ما هي عملة الإمارات؟', answers: ['الدرهم الإماراتي', 'درهم'] }
];

// ======================================================================
// ==================== تصدير الأسئلة ====================
// ======================================================================

if (typeof module !== 'undefined' && module.exports) {
    module.exports = { questions };
}

// ========== إعدادات اللعبة ==========
const rewardPoints = 100;
const penaltyPoints = 50;
const questionTime = 30000;
const maxScore = 10;

// ========== منع تكرار الألعاب ==========
const activeGames = new Map();

// ========== الأمر الرئيسي ==========
module.exports = {
    command: ['اسال'],
    description: '🎓 أسئلة علمية تنافسية (الكل يشارك)',
    category: 'فعاليات',
    usage: '.اسال',

    async execute(sock, msg) {
        try {
            const chatId = msg.key.remoteJid;
            const sender = msg.key.participant || msg.participant || msg.key.remoteJid;
            const senderNum = sender.split('@')[0];

            // ===== التحقق من وجود لعبة نشطة =====
            if (activeGames.has(chatId)) {
                await sendMessage(sock, chatId, [
                    '⚠️ *يوجد سؤال نشط*',
                    '',
                    '📌 يمكنك الانضمام بكتابة `انضم`',
                    '📌 أو الانسحاب بـ `انسحب`'
                ], msg);
                return;
            }

            // ===== اختيار سؤال عشوائي =====
            const selected = questions[Math.floor(Math.random() * questions.length)];
            const questionText = selected.question;
            const correctAnswer = selected.answers[0];

            // ===== إعداد اللعبة =====
            const game = {
                status: 'registering',
                players: [sender],
                scores: { [sender]: 0 },
                currentQuestion: selected,
                roundActive: false,
                roundFinished: false,
                roundTimeout: null,
                registrationTimeout: null,
                wrongAnswers: []
            };
            activeGames.set(chatId, game);

            // ===== رسالة التسجيل =====
            await sendMessage(sock, chatId, [
                `🎓 *فعالية الأسئلة العلمية* 🎓`,
                '',
                `👤 *المنشئ:* @${senderNum}`,
                '',
                '📝 *قواعد اللعبة:*',
                '   • اكتب `انضم` للمشاركة (30 ثانية)',
                '   • كل إجابة صحيحة = +1 نقطة',
                '   • أول من يجمع 10 نقاط يفوز بـ 700 نقطة',
                '   • الإجابة الخاطئة = -5 نقاط',
                '   • المهلة 60 ثانية → خصم 10 نقاط',
                '',
                '⏳ *فترة التسجيل:* 30 ثانية'
            ], msg, [sender]);

            // ===== مستمع التسجيل =====
            const joinHandler = async ({ messages }) => {
                const currentGame = activeGames.get(chatId);
                if (!currentGame || currentGame.status !== 'registering') return;

                for (const m of messages) {
                    const senderMsg = m.key.participant || m.participant || m.key.remoteJid;
                    if (senderMsg === sock.user.id) continue;
                    if (m.key.remoteJid !== chatId) continue;

                    const txt = m.message?.conversation || m.message?.extendedTextMessage?.text || '';
                    if (!txt.trim()) continue;
                    const content = txt.trim().toLowerCase();

                    if (content === 'انضم') {
                        if (currentGame.players.includes(senderMsg)) {
                            await sendMessage(sock, chatId, [
                                `⚠️ @${senderMsg.split('@')[0]} أنت مشترك بالفعل.`
                            ], m, [senderMsg]);
                            continue;
                        }
                        currentGame.players.push(senderMsg);
                        currentGame.scores[senderMsg] = 0;
                        await sendMessage(sock, chatId, [
                            `✅ @${senderMsg.split('@')[0]} انضم! (${currentGame.players.length})`
                        ], m, [senderMsg]);
                    }
                }
            };

            sock.ev.on('messages.upsert', joinHandler);

            // ===== إنهاء التسجيل بعد 30 ثانية =====
            game.registrationTimeout = setTimeout(async () => {
                sock.ev.off('messages.upsert', joinHandler);
                const currentGame = activeGames.get(chatId);
                if (!currentGame || currentGame.status !== 'registering') return;

                if (currentGame.players.length < 2) {
                    await sendMessage(sock, chatId, [
                        '❌ *لم ينضم عدد كافٍ من اللاعبين*',
                        '',
                        '📌 يلزم لاعبين على الأقل لبدء اللعبة'
                    ], msg);
                    activeGames.delete(chatId);
                    return;
                }

                currentGame.status = 'playing';
                await startNewRound(sock, chatId);
            }, 30000);

            // ===== دالة بدء جولة جديدة =====
            async function startNewRound(sock, chatId) {
                const currentGame = activeGames.get(chatId);
                if (!currentGame || currentGame.status !== 'playing') return;

                const q = questions[Math.floor(Math.random() * questions.length)];
                currentGame.currentQuestion = q;
                currentGame.roundActive = true;
                currentGame.roundFinished = false;
                currentGame.wrongAnswers = [];

                // ===== عرض السؤال =====
                const playerList = currentGame.players.map(p => `@${p.split('@')[0]}`).join('، ');
                await sendMessage(sock, chatId, [
                    `🎓 *السؤال العلمي:*`,
                    '',
                    `❓ ${q.question}`,
                    '',
                    `👥 *المشاركون:* ${currentGame.players.length}`,
                    `⏳ *الوقت:* 60 ثانية`,
                    `✅ *الإجابة الصحيحة:* +1 نقطة`,
                    `❌ *الإجابة الخاطئة:* -5 نقاط`,
                    '',
                    `📊 *النقاط:*`,
                    ...currentGame.players.map(p => {
                        const score = currentGame.scores[p] || 0;
                        return `   👤 @${p.split('@')[0]} → ${score} نقطة`;
                    }),
                    '',
                    '✍️ أرسل إجابتك!'
                ], msg, currentGame.players);

                // ===== مستمع الإجابات =====
                const answerHandler = async ({ messages }) => {
                    const current = activeGames.get(chatId);
                    if (!current || current.status !== 'playing' || !current.roundActive) return;

                    for (const m of messages) {
                        const responder = m.key.participant || m.participant || m.key.remoteJid;
                        if (responder === sock.user.id) continue;
                        if (m.key.remoteJid !== chatId) continue;

                        const txt = m.message?.conversation || m.message?.extendedTextMessage?.text || '';
                        if (!txt.trim()) continue;

                        // ===== انسحاب =====
                        if (txt.trim().toLowerCase() === 'انسحب') {
                            const idx = current.players.indexOf(responder);
                            if (idx !== -1) {
                                current.players.splice(idx, 1);
                                delete current.scores[responder];
                                await sendMessage(sock, chatId, [
                                    `🚪 @${responder.split('@')[0]} انسحب. (المتبقي: ${current.players.length})`
                                ], m, [responder]);
                                if (current.players.length < 2) {
                                    await sendMessage(sock, chatId, [
                                        '❌ *أصبح عدد اللاعبين أقل من 2*',
                                        '',
                                        '📌 تم إلغاء الفعالية'
                                    ]);
                                    clearTimeout(current.roundTimeout);
                                    sock.ev.off('messages.upsert', answerHandler);
                                    activeGames.delete(chatId);
                                    return;
                                }
                                continue;
                            }
                            continue;
                        }

                        // ===== التحقق من المشارك =====
                        if (!current.players.includes(responder)) continue;

                        // ===== التحقق من الإجابة =====
                        if (isMatching(txt, current.currentQuestion.answers)) {
                            // إجابة صحيحة
                            current.scores[responder] = (current.scores[responder] || 0) + 1;
                            const newScore = current.scores[responder];

                            await sendMessage(sock, chatId, [
                                `✅ @${responder.split('@')[0]} إجابة صحيحة! +1 نقطة`,
                                `📊 رصيدك: ${newScore}/${maxScore}`
                            ], m, [responder]);

                            // ===== التحقق من الفوز =====
                            if (newScore >= maxScore) {
                                const points = loadJSON(pointsPath);
                                const ranks = loadJSON(ranksPath);
                                const finalReward = 700;

                                points[responder] = (points[responder] || 0) + finalReward;
                                ranks[responder] = (ranks[responder] || 0) + 1;
                                saveJSON(pointsPath, points);
                                saveJSON(ranksPath, ranks);

                                await sendMessage(sock, chatId, [
                                    '🏆 *فوز!* 🏆',
                                    '',
                                    `👑 *الفائز:* @${responder.split('@')[0]}`,
                                    `🎉 *الجائزة:* +${finalReward} نقطة`,
                                    `💰 *رصيدك:* ${formatNumber(points[responder] || 0)} نقطة`,
                                    `🏅 *رتبتك:* ${getLevel(points[responder] || 0)}`
                                ], null, [responder]);

                                clearTimeout(current.roundTimeout);
                                sock.ev.off('messages.upsert', answerHandler);
                                activeGames.delete(chatId);
                                return;
                            }

                            // بدء جولة جديدة
                            clearTimeout(current.roundTimeout);
                            current.roundActive = false;
                            current.roundFinished = true;
                            await startNewRound(sock, chatId);
                            return;
                        } else {
                            // إجابة خاطئة
                            if (current.wrongAnswers.includes(responder)) continue;
                            current.wrongAnswers.push(responder);

                            const points = loadJSON(pointsPath);
                            const penalty = 5;
                            points[responder] = (points[responder] || 0) - penalty;
                            saveJSON(pointsPath, points);

                            await sendMessage(sock, chatId, [
                                `❌ @${responder.split('@')[0]} إجابة خاطئة! -${penalty} نقطة`,
                                `📊 رصيدك: ${formatNumber(points[responder] || 0)} نقطة`
                            ], m, [responder]);
                        }
                    }
                };

                sock.ev.on('messages.upsert', answerHandler);
                current.listener = answerHandler;

                // ===== مهلة 60 ثانية =====
                current.roundTimeout = setTimeout(async () => {
                    const finalGame = activeGames.get(chatId);
                    if (finalGame && finalGame.status === 'playing' && finalGame.roundActive) {
                        sock.ev.off('messages.upsert', answerHandler);
                        const points = loadJSON(pointsPath);
                        let penaltyMsg = ['⏰ *انتهى الوقت!*', '', '📌 تم خصم 10 نقاط من جميع المشاركين:', ''];
                        for (const player of finalGame.players) {
                            points[player] = (points[player] || 0) - 10;
                            penaltyMsg.push(`   👤 @${player.split('@')[0]} → ${formatNumber(points[player] || 0)} نقطة`);
                        }
                        saveJSON(pointsPath, points);
                        await sendMessage(sock, chatId, penaltyMsg, null, finalGame.players);
                        activeGames.delete(chatId);
                    }
                }, 60000);
            }

        } catch (error) {
            console.error('❌ خطأ في أمر اسال:', error);
            activeGames.delete(msg.key.remoteJid);
            await sendMessage(sock, msg.key.remoteJid, [
                '❌ *حدث خطأ*',
                '',
                `📝 ${error.message || 'خطأ غير معروف'}`,
                '',
                '📌 حاول مرة أخرى لاحقاً'
            ], msg);
        }
    }
};