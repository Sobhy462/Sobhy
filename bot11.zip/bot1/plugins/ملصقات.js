// حزمة.js - إنشاء حزمة ملصقات من Pinterest (ثابتة فقط، متحركة فقط، أو مختلط، تقسيم 60 لكل حزمة)
// مع النشر التلقائي في جروب الملصقات مع منشن صاحب الطلب واسم الحزمة

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');
const crypto = require('crypto');
const https = require('https');
const axios = require('axios');
const JSZip = require('jszip');
const webp = require('node-webpmux');

// ========== استيراد دوال نظام التبادل ==========
let loadData;
try {
    const exchangeModule = require('./تبادل.js');
    loadData = exchangeModule.loadData;
} catch (e) {
    console.error('❌ فشل استيراد دوال التبادل:', e.message);
    loadData = () => ({});
}

// ========== إعدادات ==========
const TEMP_DIR = path.join(__dirname, 'temp');
if (!fs.existsSync(TEMP_DIR)) fs.mkdirSync(TEMP_DIR, { recursive: true });

const PACK_NAME = '『⚕️ 𝑂⃝⃕ ╏ 𝐅𝐑𝐈𝐄𝐍𝐃𝐒 ⚘️ 𝑺𝑻𝑰𝑪𝑲𝑬𝑹𝑺 』';
const PUBLISHER = '𝑴𝑨𝑲𝑰𝑴𝑨';
const EMOJIS = ['⚕️'];
const PRICE = 500;

// ========== إعدادات التقسيم ==========
const MAX_STICKERS_PER_PACK = 60;
const MAX_PACK_SIZE_BYTES = 7 * 1024 * 1024;

const pointsPath = path.join(__dirname, '../data/points.json');

// ========== دوال النقاط ==========
function loadPoints() {
    if (!fs.existsSync(pointsPath)) fs.writeFileSync(pointsPath, JSON.stringify({}, null, 2));
    return JSON.parse(fs.readFileSync(pointsPath));
}

function savePoints(data) {
    fs.writeFileSync(pointsPath, JSON.stringify(data, null, 2));
}

function formatPoints(num) {
    if (num === undefined || num === null || isNaN(num)) return '0';
    num = Math.floor(num);
    if (num >= 1e15) return '∞';
    if (num >= 1e12) return (num / 1e12).toFixed(2) + ' تريليون';
    if (num >= 1e9) return (num / 1e9).toFixed(2) + ' مليار';
    if (num >= 1e6) return (num / 1e6).toFixed(2) + ' مليون';
    if (num >= 1e3) return (num / 1e3).toFixed(2) + ' ألف';
    return num.toString();
}

// ========== دالة الإرسال الموحدة ==========
async function sendMessage(sock, chatId, lines, quoted = null, mentions = []) {
    if (!Array.isArray(lines)) {
        lines = [lines];
    }

    let msg = `📦 حـزمة مـلـصـقـات 📦\n`;
    msg += `━━━━━━━━━━━━━━━━━━━━\n`;
    for (const line of lines) {
        if (line && line.trim()) {
            msg += `${line}\n`;
        }
    }
    msg += `━━━━━━━━━━━━━━━━━━━━\n`;
    msg += `𝘽𝙔┇𝑴𝑨𝑲𝑰𝑴𝑨`;

    await sock.sendMessage(chatId, { text: msg, mentions }, { quoted: quoted });
}

// ========== إضافة EXIF للملصق الفردي ==========
async function addExif(webpBuffer, packId, packName) {
    try {
        const img = new webp.Image();
        await img.load(webpBuffer);
        const json = {
            'sticker-pack-id': packId,
            'sticker-pack-name': packName,
            'sticker-pack-publisher': PUBLISHER,
            'emojis': EMOJIS,
        };
        const exifAttr = Buffer.from([
            0x49, 0x49, 0x2A, 0x00, 0x08, 0x00, 0x00, 0x00,
            0x01, 0x00, 0x41, 0x57, 0x07, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x16, 0x00, 0x00, 0x00,
        ]);
        const jsonBuffer = Buffer.from(JSON.stringify(json), 'utf8');
        const exif = Buffer.concat([exifAttr, jsonBuffer]);
        exif.writeUIntLE(jsonBuffer.length, 14, 4);
        img.exif = exif;
        return await img.save(null);
    } catch (e) {
        console.warn('⚠️ فشل إضافة EXIF، نرسل الملصق بدون EXIF:', e.message);
        return webpBuffer;
    }
}

// ========== دوال تحويل الصور (مع إضافة EXIF) ==========

async function makeWebpStatic(buffer, packId, packName) {
    const ts = Date.now();
    const inputPath = path.join(TEMP_DIR, `static_${ts}.jpg`);
    const outputPath = path.join(TEMP_DIR, `static_${ts}.webp`);
    try {
        fs.writeFileSync(inputPath, buffer);
        let webpBuffer = null;
        try {
            execSync(`ffmpeg -y -i "${inputPath}" -vf "scale=512:512:force_original_aspect_ratio=decrease,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=0x00000000" -c:v libwebp -compression_level 6 -q:v 80 "${outputPath}"`, { stdio: 'pipe', timeout: 30000 });
            if (fs.existsSync(outputPath)) webpBuffer = fs.readFileSync(outputPath);
        } catch (e) {}
        if (!webpBuffer) {
            try {
                const outMagick = path.join(TEMP_DIR, `static_${ts}_magick.webp`);
                execSync(`convert "${inputPath}" -strip -resize 512x512 -background none -gravity center -extent 512x512 "${outMagick}"`, { stdio: 'pipe' });
                if (fs.existsSync(outMagick)) {
                    webpBuffer = fs.readFileSync(outMagick);
                    fs.unlinkSync(outMagick);
                }
            } catch (e) {}
        }
        if (!webpBuffer) throw new Error('فشل تحويل الصورة إلى WebP');
        return await addExif(webpBuffer, packId, packName);
    } finally {
        try { if (fs.existsSync(inputPath)) fs.unlinkSync(inputPath); } catch {}
        try { if (fs.existsSync(outputPath)) fs.unlinkSync(outputPath); } catch {}
    }
}

async function makeWebpAnimated(buffer, packId, packName) {
    const ts = Date.now();
    const inputPath = path.join(TEMP_DIR, `anim_${ts}.gif`);
    const outputPath = path.join(TEMP_DIR, `anim_${ts}.webp`);
    try {
        fs.writeFileSync(inputPath, buffer);
        execSync(`ffmpeg -y -i "${inputPath}" -vf "scale=512:512:force_original_aspect_ratio=decrease,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=0x00000000,fps=15" -loop 0 -q:v 80 -preset default -an "${outputPath}"`, { stdio: 'pipe', timeout: 30000 });
        if (!fs.existsSync(outputPath)) throw new Error('فشل تحويل GIF إلى WebP متحرك');
        const webpBuffer = fs.readFileSync(outputPath);
        return await addExif(webpBuffer, packId, packName);
    } finally {
        try { if (fs.existsSync(inputPath)) fs.unlinkSync(inputPath); } catch {}
        try { if (fs.existsSync(outputPath)) fs.unlinkSync(outputPath); } catch {}
    }
}

async function makeTrayWebp(buffer) {
    const ts = Date.now();
    const inputPath = path.join(TEMP_DIR, `tray_${ts}.jpg`);
    const outputPath = path.join(TEMP_DIR, `tray_${ts}.webp`);
    try {
        fs.writeFileSync(inputPath, buffer);
        try {
            execSync(`ffmpeg -y -i "${inputPath}" -vf "crop=iw:ih" -c:v libwebp -compression_level 6 "${outputPath}"`, { stdio: 'pipe', timeout: 30000 });
            if (fs.existsSync(outputPath)) return fs.readFileSync(outputPath);
        } catch (e) {}
        try {
            const outMagick = path.join(TEMP_DIR, `tray_${ts}_magick.webp`);
            execSync(`convert "${inputPath}" -strip "${outMagick}"`, { stdio: 'pipe' });
            if (fs.existsSync(outMagick)) {
                const result = fs.readFileSync(outMagick);
                fs.unlinkSync(outMagick);
                return result;
            }
        } catch (e) {}
        return makeBlankTrayWebp();
    } finally {
        try { if (fs.existsSync(inputPath)) fs.unlinkSync(inputPath); } catch {}
        try { if (fs.existsSync(outputPath)) fs.unlinkSync(outputPath); } catch {}
    }
}

async function makeBlankTrayWebp() {
    const ts = Date.now();
    const outputPath = path.join(TEMP_DIR, `blank_${ts}.webp`);
    try {
        execSync(`ffmpeg -y -f lavfi -i "color=black:size=252x252:duration=1" -vf "format=rgba,colorchannelmixer=aa=0" -frames:v 1 "${outputPath}"`, { stdio: 'pipe' });
        return fs.readFileSync(outputPath);
    } finally {
        try { if (fs.existsSync(outputPath)) fs.unlinkSync(outputPath); } catch {}
    }
}

async function makeThumbnailJpeg(buffer) {
    const ts = Date.now();
    const inputPath = path.join(TEMP_DIR, `thumb_${ts}.jpg`);
    const outputPath = path.join(TEMP_DIR, `thumb_${ts}.jpeg`);
    try {
        fs.writeFileSync(inputPath, buffer);
        try {
            execSync(`ffmpeg -y -i "${inputPath}" -q:v 2 "${outputPath}"`, { stdio: 'pipe', timeout: 30000 });
            if (fs.existsSync(outputPath)) return fs.readFileSync(outputPath);
        } catch (e) {}
        try {
            const outMagick = path.join(TEMP_DIR, `thumb_${ts}_magick.jpg`);
            execSync(`convert "${inputPath}" -strip "${outMagick}"`, { stdio: 'pipe' });
            if (fs.existsSync(outMagick)) {
                const result = fs.readFileSync(outMagick);
                fs.unlinkSync(outMagick);
                return result;
            }
        } catch (e) {}
        return buffer;
    } finally {
        try { if (fs.existsSync(inputPath)) fs.unlinkSync(inputPath); } catch {}
        try { if (fs.existsSync(outputPath)) fs.unlinkSync(outputPath); } catch {}
    }
}

// ========== دوال التشفير والرفع ==========

function sha256(buffer) {
    return crypto.createHash('sha256').update(buffer).digest();
}

function toB64Url(buffer) {
    return Buffer.from(buffer).toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '');
}

function getHkdf(ikm, salt, info, length) {
    try {
        if (typeof crypto.hkdfSync === 'function') {
            const result = crypto.hkdfSync('sha256', ikm, salt, info, length);
            return Buffer.isBuffer(result) ? result : Buffer.from(result);
        }
    } catch {}
    const mac = crypto.createHmac('sha256', salt);
    const prk = mac.update(ikm).digest();
    const N = Math.ceil(length / 32);
    let okm = Buffer.alloc(0);
    let t = Buffer.alloc(0);
    for (let i = 1; i <= N; i++) {
        const hmac = crypto.createHmac('sha256', prk);
        hmac.update(t);
        hmac.update(info);
        hmac.update(Buffer.from([i]));
        t = hmac.digest();
        okm = Buffer.concat([okm, t.slice(0, Math.min(t.length, length - okm.length))]);
        if (okm.length >= length) break;
    }
    return okm;
}

async function uploadToServer(sock, buffer, { hkdf, mediaPath, mediaKey = crypto.randomBytes(32) }) {
    const expanded = getHkdf(mediaKey, Buffer.alloc(32), Buffer.from(hkdf), 112);
    const iv = expanded.subarray(0, 16);
    const cipherKey = expanded.subarray(16, 48);
    const macKey = expanded.subarray(48, 80);

    const cipher = crypto.createCipheriv('aes-256-cbc', cipherKey, iv);
    const encrypted = Buffer.concat([cipher.update(buffer), cipher.final()]);
    const mac = crypto.createHmac('sha256', macKey).update(iv).update(encrypted).digest().subarray(0, 10);
    const encBuffer = Buffer.concat([encrypted, mac]);
    const fileSha256 = sha256(buffer);
    const fileEncSha256 = sha256(encBuffer);

    const iq = await sock.query({
        tag: 'iq',
        attrs: { id: Date.now().toString(), to: 's.whatsapp.net', type: 'set', xmlns: 'w:m' },
        content: [{ tag: 'media_conn', attrs: {} }]
    });

    const mediaConn = iq.content?.find(v => v.tag === 'media_conn');
    if (!mediaConn) throw new Error('media_conn غير موجود');
    const auth = mediaConn.attrs?.auth;
    if (!auth) throw new Error('auth غير موجود');

    const hosts = (mediaConn.content || []).filter(v => v.tag === 'host').map(v => v.attrs?.hostname).filter(Boolean);
    if (!hosts.length) throw new Error('لا يوجد host للرفع');

    const token = encodeURIComponent(fileEncSha256.toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, ''));

    let lastError;
    for (const host of hosts) {
        try {
            const json = await new Promise((resolve, reject) => {
                const url = new URL(`https://${host}${mediaPath}/${token}?auth=${encodeURIComponent(auth)}&token=${token}`);
                const req = https.request({
                    hostname: url.hostname,
                    port: 443,
                    path: url.pathname + url.search,
                    method: 'POST',
                    headers: {
                        Origin: 'https://web.whatsapp.com',
                        Referer: 'https://web.whatsapp.com/',
                        'Content-Type': 'application/octet-stream',
                        'Content-Length': encBuffer.length
                    }
                }, (res) => {
                    let body = '';
                    res.on('data', c => body += c);
                    res.on('end', () => {
                        if (res.statusCode < 200 || res.statusCode >= 300) {
                            return reject(new Error(`فشل الرفع ${res.statusCode}`));
                        }
                        try { resolve(JSON.parse(body)); } catch { reject(new Error('رد غير JSON')); }
                    });
                });
                req.on('error', reject);
                req.write(encBuffer);
                req.end();
            });
            const directPath = json.direct_path ?? json.directPath ?? json.url ?? json.path;
            if (!directPath) throw new Error('directPath غير موجود');
            return { mediaKey, fileLength: buffer.length, fileSha256, fileEncSha256, directPath, ...json };
        } catch (e) { lastError = e; }
    }
    throw lastError ?? new Error('جميع محاولات الرفع فشلت');
}

// ========== البحث في Pinterest (صور ثابتة) ==========

async function getCookies() {
    try {
        const response = await axios.get('https://www.pinterest.com', {
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
            },
            maxRedirects: 0
        });
        const cookies = response.headers['set-cookie'];
        if (cookies) {
            return cookies.map(c => c.split(';')[0]).join('; ');
        }
        return null;
    } catch { return null; }
}

async function searchPinterest(query, targetCount, maxAttempts = 5) {
    for (let attempt = 0; attempt < maxAttempts; attempt++) {
        try {
            const cookies = await getCookies();
            if (!cookies) continue;

            const params = {
                source_url: `/search/pins/?q=${encodeURIComponent(query)}`,
                data: JSON.stringify({
                    options: {
                        isPrefetch: false,
                        query: query,
                        scope: "pins",
                        bookmarks: [""],
                        page_size: Math.min(targetCount + 50, 200),
                        field_set_key: "react_story_pin_detail",
                        include_unified_content: true,
                        personalization_info: false
                    },
                    context: {}
                }),
                _: Date.now()
            };

            const url = `https://www.pinterest.com/resource/BaseSearchResource/get/?${new URLSearchParams(params).toString()}`;
            const response = await axios.get(url, {
                headers: {
                    'accept': 'application/json, text/javascript, */*; q=0.01',
                    'accept-language': 'ar,en;q=0.9',
                    'referer': 'https://www.pinterest.com/',
                    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                    'x-app-version': 'a9522f',
                    'x-pinterest-appstate': 'active',
                    'x-pinterest-pws-handler': 'www/[username]/[slug].js',
                    'x-requested-with': 'XMLHttpRequest',
                    cookie: cookies
                }
            });

            if (response.status !== 200) continue;
            const data = response.data;

            let results = data.resource_response?.data?.results?.filter(v => v.images?.orig) || [];
            results = results.filter(item => {
                const hasGoodImage = item.images?.orig?.url && !item.images.orig.url.includes('default');
                const isAd = item.type === 'ad' || item.is_ad || item.ad;
                return hasGoodImage && !isAd;
            });

            if (results.length === 0) continue;

            const pins = results.slice(0, targetCount).map(v => {
                let imageUrl = v.images.orig.url;
                if (v.images["736x"]?.url) imageUrl = v.images["736x"].url;
                if (v.images["orig"]?.url) imageUrl = v.images["orig"].url;
                imageUrl = imageUrl.replace("/736x/", "/originals/");
                imageUrl = imageUrl.replace("/564x/", "/originals/");
                return {
                    id: v.id,
                    image: imageUrl,
                    title: v.title || v.description || 'No title'
                };
            });

            return {
                status: true,
                total: pins.length,
                pins
            };
        } catch (e) {
            console.warn(`محاولة ${attempt + 1} فشلت:`, e.message);
            if (attempt < maxAttempts - 1) {
                await new Promise(resolve => setTimeout(resolve, 2000 + Math.random() * 3000));
            }
        }
    }
    return { status: false, message: "لم يتم العثور على نتائج." };
}

// ========== البحث عن صور متحركة (Tenor + GIPHY) ==========

async function searchAnimated(query, count = 10) {
    const results = [];
    const UA = 'Mozilla/5.0 (Linux; Android 12; Pixel 6) AppleWebKit/537.36';

    // Tenor
    try {
        const res = await axios.get(`https://tenor.com/search/${encodeURIComponent(query)}-gifs`, {
            headers: { 'User-Agent': UA, 'Accept': 'text/html' }
        });
        if (res.status === 200) {
            const html = res.data;
            const matches = html.match(/https:\/\/media\.tenor\.com\/[^\s"'\\><]+\.gif/gi) || [];
            results.push(...matches);
        }
    } catch {}

    // GIPHY
    try {
        const res = await axios.get(`https://giphy.com/search/${encodeURIComponent(query)}`, {
            headers: { 'User-Agent': UA, 'Accept': 'text/html' }
        });
        if (res.status === 200) {
            const html = res.data;
            const matches = html.match(/https:\/\/media\d?\.giphy\.com\/media\/[^\s"'\\><]+\/giphy\.gif/gi) || [];
            results.push(...matches);
        }
    } catch {}

    return [...new Set(results)].slice(0, count);
}

// ========== إرسال حزمة الملصقات (60 لكل حزمة) ==========

async function sendStickerPack(sock, chatId, pack, query, quoted) {
    function splitPackIntoGroups(stickers) {
        const groups = [];
        let currentGroup = [];
        let currentSize = 0;
        for (const sticker of stickers) {
            const stickerSize = sticker.buffer.length;
            if (currentGroup.length >= MAX_STICKERS_PER_PACK || (currentSize + stickerSize) > MAX_PACK_SIZE_BYTES) {
                if (currentGroup.length > 0) groups.push([...currentGroup]);
                currentGroup = [];
                currentSize = 0;
            }
            currentGroup.push(sticker);
            currentSize += stickerSize;
        }
        if (currentGroup.length > 0) groups.push(currentGroup);
        return groups;
    }

    const stickerGroups = splitPackIntoGroups(pack);
    if (stickerGroups.length === 0) throw new Error('لا توجد ملصقات صالحة للإرسال');

    let sent = 0;
    for (let i = 0; i < stickerGroups.length; i++) {
        const group = stickerGroups[i];
        const packNumber = i + 1;
        const totalGroups = stickerGroups.length;

        const zip = new JSZip();
        const stickersMetadata = [];

        for (const item of group) {
            const fileName = `${toB64Url(sha256(item.buffer))}.webp`;
            zip.file(fileName, item.buffer);
            stickersMetadata.push({
                fileName,
                isAnimated: item.isAnimated || false,
                emojis: EMOJIS,
                accessibilityLabel: '',
                isLottie: false,
                mimetype: 'image/webp'
            });
        }

        const trayIconFileName = 'tray_icon.webp';
        const traySource = group.find(v => !v.isAnimated)?.buffer || group[0]?.buffer;
        const trayBuffer = traySource ? await makeTrayWebp(traySource) : await makeBlankTrayWebp();
        zip.file(trayIconFileName, trayBuffer);

        const archive = await zip.generateAsync({ type: 'nodebuffer', compression: 'STORE' });

        const packUpload = await uploadToServer(sock, archive, {
            hkdf: 'WhatsApp Sticker Pack Keys',
            mediaPath: '/mms/sticker-pack'
        });
        const thumbnailBuffer = await makeThumbnailJpeg(trayBuffer);
        const thumbUpload = await uploadToServer(sock, thumbnailBuffer, {
            hkdf: 'WhatsApp Sticker Pack Thumbnail Keys',
            mediaPath: '/mms/thumbnail-sticker-pack',
            mediaKey: packUpload.mediaKey
        });

        let packName = PACK_NAME;
        if (totalGroups > 1) {
            packName += ` (${packNumber}/${totalGroups})`;
        }

        await sock.relayMessage(chatId, {
            stickerPackMessage: {
                stickerPackId: `Pack_${crypto.randomBytes(8).toString('hex')}`,
                name: packName,
                publisher: PUBLISHER,
                packDescription: `⚕️ ${query}`,
                stickers: stickersMetadata,
                fileLength: packUpload.fileLength,
                fileSha256: packUpload.fileSha256,
                fileEncSha256: packUpload.fileEncSha256,
                mediaKey: packUpload.mediaKey,
                directPath: packUpload.directPath,
                mediaKeyTimestamp: Math.floor(Date.now() / 1000),
                stickerPackSize: packUpload.fileLength,
                stickerPackOrigin: 2,
                trayIconFileName,
                thumbnailDirectPath: thumbUpload.directPath,
                thumbnailSha256: thumbUpload.fileSha256,
                thumbnailEncSha256: thumbUpload.fileEncSha256,
                thumbnailHeight: 252,
                thumbnailWidth: 252,
                imageDataHash: thumbUpload.fileSha256.toString('base64')
            },
            messageContextInfo: {
                messageSecret: crypto.randomBytes(32),
                forwardingScore: 0,
                isForwarded: true,
                contextInfo: {
                    isForwarded: true,
                    forwardingScore: 0,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: '120363426966062635@newsletter',
                        newsletterName: '『⚕️ 𝑂⃝⃕ ╏ 𝐅𝐑𝐈𝐄𝐍𝐃𝐒 ⚘️ 𝑺𝑻𝑰𝑪𝑲𝑬𝑹𝑺 』𝑴𝑨𝑲𝑰𝑴𝑨',
                        serverMessageId: 1
                    }
                }
            }
        }, { quoted });

        sent++;
    }

    return sent;
}

// ========== الأمر الرئيسي ==========

module.exports = {
    command: ['حزمة', 'ملصقات'],
    description: '📦 إنشاء حزمة ملصقات من Pinterest (ثابتة / متحركة / مختلط) مع اسم الحزمة على الملصق',
    category: 'وسائط',
    usage: '.حزمة [كلمة البحث] [العدد] [متحرك|ثابت]',

    async execute(sock, msg) {
        try {
            const chatId = msg.key.remoteJid;
            const sender = msg.key.participant || msg.key.remoteJid;
            const senderName = msg.pushName || sender.split('@')[0];

            const fullText = msg.message?.conversation || msg.message?.extendedTextMessage?.text || '';
            const parts = fullText.trim().split(/\s+/);
            const args = parts.slice(1);

            if (!args || args.length === 0) {
                await sendMessage(sock, chatId, [
                    '📦 *حزمة ملصقات Pinterest*',
                    '',
                    '📌 الاستخدام:',
                    '`.حزمة [كلمة البحث] [العدد] [متحرك|ثابت]`',
                    '',
                    '📝 *أمثلة:*',
                    '   `.حزمة سبايدر مان 30` ← مختلط',
                    '   `.حزمة قطط 80` ← مختلط',
                    '   `.حزمة أنمي 200` ← مختلط',
                    '   `.حزمة قطط متحرك 20` ← متحرك فقط',
                    '   `.حزمة أنمي متحركة 50` ← متحرك فقط',
                    '   `.حزمة قطط ثابت 30` ← ثابت فقط',
                    '   `.حزمة أنمي ثابته 40` ← ثابت فقط',
                    '',
                    `💰 *السعر:* ${PRICE} نقطة لكل حزمة`,
                    `⚠️ *كل حزمة تحتوي على 60 ملصق كحد أقصى*`,
                    '📦 *يتم إرسالها كحزمة واحدة أو أكثر*',
                    '🖼️ *اختر النوع: ثابت، متحرك، أو مختلط (بدون كلمة)*'
                ], msg);
                return;
            }

            let query = args.join(' ');
            let totalStickers = 60; // افتراضي
            let mode = 'mixed'; // mixed, animated, static

            // تحليل النص لاكتشاف الكلمات المفتاحية
            const words = query.split(' ');
            let lastWord = words[words.length - 1].toLowerCase();

            // التحقق من الكلمة الأخيرة (بدون حساسية لحالة الأحرف)
            if (lastWord === 'متحرك' || lastWord === 'متحركة') {
                mode = 'animated';
                query = words.slice(0, -1).join(' ');
            } else if (lastWord === 'ثابت' || lastWord === 'ثابته' || lastWord === 'ثابتة') {
                mode = 'static';
                query = words.slice(0, -1).join(' ');
            } else {
                // قد يكون الرقم في النهاية
                const possibleNumber = words[words.length - 1];
                if (!isNaN(possibleNumber) && parseInt(possibleNumber) > 0) {
                    totalStickers = Math.min(parseInt(possibleNumber), 200);
                    query = words.slice(0, -1).join(' ');
                }
            }

            // ===== نظام النقاط =====
            const points = loadPoints();
            const userPoints = points[sender] || 0;
            if (userPoints < PRICE) {
                await sendMessage(sock, chatId, [
                    '❌ *رصيد غير كافٍ*',
                    '',
                    `💰 سعر الحزمة: *${PRICE} نقطة*`,
                    `💰 رصيدك الحالي: *${formatPoints(userPoints)} نقطة*`,
                    `💰 المتبقي: *${formatPoints(PRICE - userPoints)} نقطة*`,
                    '',
                    '📌 يمكنك كسب النقاط عبر:',
                    '   • الفوز في المعارك ⚔️',
                    '   • هزيمة الوحوش 🐉',
                    '   • المشاركة في الفعاليات 🎯'
                ], msg);
                return;
            }

            points[sender] -= PRICE;
            savePoints(points);

            // تحديد نوع البحث لعرضه في الرسالة
            const modeText = {
                'mixed': 'ثابتة + متحركة 🖼️🎬',
                'animated': 'متحركة فقط 🎬',
                'static': 'ثابتة فقط 🖼️'
            };

            await sendMessage(sock, chatId, [
                `🔍 *جاري البحث عن:* ${query}`,
                `📊 *العدد المطلوب:* ${totalStickers} ملصق`,
                `🎯 *النوع:* ${modeText[mode]}`,
                `💰 *تم خصم:* ${PRICE} نقطة`,
                `📉 *الرصيد المتبقي:* ${formatPoints(points[sender])} نقطة`
            ], msg);

            const pack = [];
            const UA = 'Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36';
            const packId = crypto.randomBytes(16).toString('hex');

            if (mode === 'animated') {
                // ===== جلب صور متحركة فقط =====
                const animatedUrls = await searchAnimated(query, totalStickers + 5);
                for (let i = 0; i < animatedUrls.length && pack.length < totalStickers; i++) {
                    try {
                        const res = await axios.get(animatedUrls[i], {
                            responseType: 'arraybuffer',
                            headers: { 'User-Agent': UA },
                            timeout: 20000
                        });
                        if (res.status !== 200) continue;
                        const buffer = Buffer.from(res.data);
                        const webpBuffer = await makeWebpAnimated(buffer, packId, PACK_NAME);
                        pack.push({ buffer: webpBuffer, isAnimated: true });
                    } catch (e) {
                        console.warn('فشل تحميل صورة متحركة:', e.message);
                    }
                }
            } else if (mode === 'static') {
                // ===== جلب صور ثابتة فقط =====
                const staticResult = await searchPinterest(query, totalStickers + 5);
                if (staticResult.status) {
                    for (let i = 0; i < staticResult.pins.length && pack.length < totalStickers; i++) {
                        try {
                            const res = await axios.get(staticResult.pins[i].image, {
                                responseType: 'arraybuffer',
                                headers: { 'User-Agent': UA },
                                timeout: 15000
                            });
                            if (res.status !== 200) continue;
                            const buffer = Buffer.from(res.data);
                            const webpBuffer = await makeWebpStatic(buffer, packId, PACK_NAME);
                            pack.push({ buffer: webpBuffer, isAnimated: false });
                        } catch (e) {
                            console.warn('فشل تحميل صورة ثابتة:', e.message);
                        }
                    }
                }
            } else {
                // ===== مختلط: ثابتة + متحركة =====
                const staticResult = await searchPinterest(query, Math.ceil(totalStickers * 0.6) + 5);
                let staticPins = staticResult.status ? staticResult.pins : [];

                const animatedNeeded = Math.max(0, totalStickers - staticPins.length);
                const animatedUrls = await searchAnimated(query, animatedNeeded + 5);

                // صور ثابتة
                for (let i = 0; i < staticPins.length && pack.length < totalStickers; i++) {
                    try {
                        const res = await axios.get(staticPins[i].image, {
                            responseType: 'arraybuffer',
                            headers: { 'User-Agent': UA },
                            timeout: 15000
                        });
                        if (res.status !== 200) continue;
                        const buffer = Buffer.from(res.data);
                        const webpBuffer = await makeWebpStatic(buffer, packId, PACK_NAME);
                        pack.push({ buffer: webpBuffer, isAnimated: false });
                    } catch (e) {
                        console.warn('فشل تحميل صورة ثابتة:', e.message);
                    }
                }

                // صور متحركة
                for (let i = 0; i < animatedUrls.length && pack.length < totalStickers; i++) {
                    try {
                        const res = await axios.get(animatedUrls[i], {
                            responseType: 'arraybuffer',
                            headers: { 'User-Agent': UA },
                            timeout: 20000
                        });
                        if (res.status !== 200) continue;
                        const buffer = Buffer.from(res.data);
                        const webpBuffer = await makeWebpAnimated(buffer, packId, PACK_NAME);
                        pack.push({ buffer: webpBuffer, isAnimated: true });
                    } catch (e) {
                        console.warn('فشل تحميل صورة متحركة:', e.message);
                    }
                }
            }

            if (pack.length === 0) {
                points[sender] += PRICE;
                savePoints(points);
                await sendMessage(sock, chatId, [
                    '❌ *لا توجد صور قابلة للتحويل*',
                    '',
                    `📌 لم نجد نتائج لـ "${query}"`,
                    '💰 تم إرجاع النقاط تلقائياً',
                    '',
                    '💡 جرب كلمات بحث مختلفة'
                ], msg);
                return;
            }

            // ===== إرسال الحزم في الجروب الحالي =====
            const sentPacks = await sendStickerPack(sock, chatId, pack, query, msg);

            // ===== حساب عدد الملصقات في كل نوع =====
            const totalStatic = pack.filter(s => !s.isAnimated).length;
            const totalAnimated = pack.filter(s => s.isAnimated).length;

            let resultLines = [
                '✅ *تم إرسال الحزمة بنجاح!*',
                '',
                `📦 *عدد الملصقات:* ${pack.length}`,
                `📦 *عدد الحزم المرسلة:* ${sentPacks} (كل حزمة تحتوي على 60 ملصق كحد أقصى)`,
                `💰 *السعر:* ${PRICE} نقطة`,
                `📉 *الرصيد المتبقي:* ${formatPoints(points[sender])} نقطة`,
                '',
                `🏷️ *اسم الحزمة:* ${PACK_NAME}`,
                '💡 *نصيحة:* اضغط على أي ملصق ثم "إضافة الحزمة" لحفظها كلها'
            ];

            // إضافة إحصاءات الأنواع حسب الوضع
            if (mode === 'animated') {
                resultLines.splice(3, 0, `🎬 *متحرك:* ${totalAnimated}`);
            } else if (mode === 'static') {
                resultLines.splice(3, 0, `🖼️ *ثابت:* ${totalStatic}`);
            } else {
                resultLines.splice(3, 0, `🖼️ *ثابت:* ${totalStatic}`, `🎬 *متحرك:* ${totalAnimated}`);
            }

            await sendMessage(sock, chatId, resultLines, msg);

            // ============================================================
            // 📤 نشر الحزمة في جروب "ملصقات" (إن وجد) مع منشن صاحب الطلب
            // ============================================================
            try {
                const exchangeData = loadData();
                const stickerGroups = exchangeData['ملصقات'] || [];

                if (stickerGroups.length > 0) {
                    for (const groupJid of stickerGroups) {
                        if (groupJid === chatId) continue; // تجنب الإرسال في نفس الجروب

                        try {
                            // 1. إرسال رسالة إشعار تحتوي على منشن صاحب الطلب واسم الحزمة
                            const notifyMsg = `📦 *صاحب طلب الحزمة  ${senderName}*\n📌 *اسم الحزمة:* ${query}`;
                            await sock.sendMessage(groupJid, {
                                text: notifyMsg,
                                mentions: [sender] // منشن صاحب الطلب
                            });

                            // 2. إرسال الحزمة نفسها
                            await sendStickerPack(sock, groupJid, pack, query, null);
                            
                            console.log(`✅ نشر الحزمة في ${groupJid}`);
                            await new Promise(resolve => setTimeout(resolve, 500));
                        } catch (e) {
                            console.error(`❌ فشل النشر في ${groupJid}:`, e.message);
                        }
                    }
                }
            } catch (e) {
                console.error('❌ خطأ في نشر الحزمة:', e.message);
            }

        } catch (error) {
            console.error('❌ خطأ في أمر حزمة:', error);
            await sendMessage(sock, msg.key.remoteJid, [
                '❌ *حدث خطأ*',
                '',
                `📝 ${error.message || 'خطأ غير معروف'}`,
                '',
                '📌 حاول مرة أخرى لاحقاً'
            ], msg);
        }
    }
};