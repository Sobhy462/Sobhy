// شراء.js - شراء منتج من المتجر (مع إمكانية تحديد العدد بالرقم أو الاسم) - نسخة متوافقة مع نظام التخزين المنفصل
const fs = require('fs');
const path = require('path');

const pointsPath = path.join(__dirname, '../data/points.json');
const shopPath = path.join(__dirname, '../data/shop.json');

// ===== مسارات التخزين المنفصل =====
const dataDir = path.join(__dirname, '../data/kingdom');
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

const MAIN_PATH = path.join(dataDir, 'main.json');
const SOLDIERS_PATH = path.join(dataDir, 'soldiers.json');
const WEAPONS_PATH = path.join(dataDir, 'weapons.json');
const ACCESSORIES_PATH = path.join(dataDir, 'accessories.json');
const POTIONS_PATH = path.join(dataDir, 'potions.json');
const SPELLS_PATH = path.join(dataDir, 'spells.json');
const SOULBOOK_PATH = path.join(dataDir, 'soulbook.json');
const COMPANION_PATH = path.join(dataDir, 'companion.json');
const ACTIVE_PATH = path.join(dataDir, 'active.json');

// ===== التأكد من وجود جميع الملفات =====
const allPaths = [MAIN_PATH, SOLDIERS_PATH, WEAPONS_PATH, ACCESSORIES_PATH, POTIONS_PATH, SPELLS_PATH, SOULBOOK_PATH, COMPANION_PATH, ACTIVE_PATH];
for (const p of allPaths) {
    if (!fs.existsSync(p)) fs.writeFileSync(p, JSON.stringify({}, null, 2));
}
if (!fs.existsSync(pointsPath)) fs.writeFileSync(pointsPath, JSON.stringify({}, null, 2));
if (!fs.existsSync(shopPath)) fs.writeFileSync(shopPath, JSON.stringify({ products: [] }, null, 2));

function loadJSON(file) {
    try { return JSON.parse(fs.readFileSync(file)); } catch { return {}; }
}
function saveJSON(file, data) {
    try {
        if (fs.existsSync(file)) fs.writeFileSync(file + '.bak', fs.readFileSync(file));
        fs.writeFileSync(file, JSON.stringify(data, null, 2));
        return true;
    } catch (e) {
        console.error('❌ فشل حفظ الملف:', file, e.message);
        return false;
    }
}

// ========== دوال التخزين المنفصل ==========
function loadUserData(jid) {
    const main = loadJSON(MAIN_PATH)[jid] || {};
    const soldiers = loadJSON(SOLDIERS_PATH)[jid] || {};
    const weapons = loadJSON(WEAPONS_PATH)[jid] || {};
    const accessories = loadJSON(ACCESSORIES_PATH)[jid] || {};
    const potions = loadJSON(POTIONS_PATH)[jid] || {};
    const spells = loadJSON(SPELLS_PATH)[jid] || {};
    const soulBook = loadJSON(SOULBOOK_PATH)[jid] || {};
    const companion = loadJSON(COMPANION_PATH)[jid] || null;
    const active = loadJSON(ACTIVE_PATH)[jid] || {};

    return {
        level: main.level || 1,
        prosperity: main.prosperity || 0,
        lands: main.lands || 0,
        gold: main.gold || 0,
        name: main.name || `مملكة @${jid.split('@')[0]}`,
        owner: main.owner || jid,
        nameChangesUsed: main.nameChangesUsed || 0,
        soldiers: soldiers,
        weapons: weapons,
        accessories: accessories,
        potions: potions,
        spellsUsed: spells,
        soulBook: soulBook,
        companion: companion,
        lastActive: active.lastActive || Date.now()
    };
}

function saveUserData(jid, data) {
    const main = loadJSON(MAIN_PATH);
    main[jid] = {
        level: data.level || 1,
        prosperity: data.prosperity || 0,
        lands: data.lands || 0,
        gold: data.gold || 0,
        name: data.name || `مملكة @${jid.split('@')[0]}`,
        owner: data.owner || jid,
        nameChangesUsed: data.nameChangesUsed || 0
    };
    saveJSON(MAIN_PATH, main);

    const soldiers = loadJSON(SOLDIERS_PATH);
    soldiers[jid] = data.soldiers || {};
    saveJSON(SOLDIERS_PATH, soldiers);

    const weapons = loadJSON(WEAPONS_PATH);
    weapons[jid] = data.weapons || {};
    saveJSON(WEAPONS_PATH, weapons);

    const accessories = loadJSON(ACCESSORIES_PATH);
    accessories[jid] = data.accessories || {};
    saveJSON(ACCESSORIES_PATH, accessories);

    const potions = loadJSON(POTIONS_PATH);
    potions[jid] = data.potions || {};
    saveJSON(POTIONS_PATH, potions);

    const spells = loadJSON(SPELLS_PATH);
    spells[jid] = data.spellsUsed || {};
    saveJSON(SPELLS_PATH, spells);

    const soulBook = loadJSON(SOULBOOK_PATH);
    soulBook[jid] = data.soulBook || { pages: 0, spirits: [] };
    saveJSON(SOULBOOK_PATH, soulBook);

    const companion = loadJSON(COMPANION_PATH);
    companion[jid] = data.companion || null;
    saveJSON(COMPANION_PATH, companion);

    const active = loadJSON(ACTIVE_PATH);
    active[jid] = {
        lastActive: data.lastActive || Date.now()
    };
    saveJSON(ACTIVE_PATH, active);
}

function userExists(jid) {
    const main = loadJSON(MAIN_PATH);
    return !!main[jid];
}

// ========== قائمة المنتجات الكاملة (للبحث) ==========
const fullProductsList = [
    // ===== أسلحة =====
    { id: 1, name: 'سيف حديدي', type: 'weapon', key: 'ironSword', cost: 150, desc: 'هجوم +10 دائم' },
    { id: 2, name: 'درع ذهبي', type: 'weapon', key: 'goldenShield', cost: 250, desc: 'دفاع +15 دائم' },
    { id: 3, name: 'قوس أسطوري', type: 'weapon', key: 'legendaryBow', cost: 300, desc: 'هجوم +20 دائم' },
    { id: 4, name: 'سيف البرق', type: 'weapon', key: 'lightningSword', cost: 400, desc: 'هجوم +40 دائم' },
    { id: 5, name: 'مطرقة العمالقة', type: 'weapon', key: 'giantHammer', cost: 550, desc: 'هجوم +60 دائم' },
    { id: 6, name: 'قوس الموت', type: 'weapon', key: 'deathBow', cost: 700, desc: 'هجوم +80 دائم (نادر)' },
    { id: 7, name: 'فأس الدمار', type: 'weapon', key: 'destructionAxe', cost: 900, desc: 'هجوم +100 دائم (أسطوري)' },
    { id: 8, name: 'سيف الأبطال', type: 'weapon', key: 'heroSword', cost: 500, desc: 'هجوم +50، دفاع +10' },
    { id: 9, name: 'قوس الزمن', type: 'weapon', key: 'timeBow', cost: 850, desc: 'هجوم +70، فرصة لإضعاف العدو' },
    { id: 10, name: 'نصل الأبدية', type: 'weapon', key: 'eternalBlade', cost: 1500, desc: 'هجوم +120، نادر أسطوري' },
    { id: 11, name: 'درع النار', type: 'weapon', key: 'fireShield', cost: 450, desc: 'دفاع +40 دائم' },
    { id: 12, name: 'درع الملك', type: 'weapon', key: 'godShield', cost: 800, desc: 'دفاع +80 دائم (أسطوري)' },
    // ===== جنود =====
    { id: 13, name: 'جندي عادي', type: 'soldier', key: 'normal', cost: 30, desc: 'هجوم +2 دائم' },
    { id: 14, name: 'فارس', type: 'soldier', key: 'knight', cost: 80, desc: 'هجوم +5، دفاع +2 دائم' },
    { id: 15, name: 'رامٍ', type: 'soldier', key: 'archer', cost: 50, desc: 'هجوم +4 دائم' },
    { id: 16, name: 'حارس النخبة', type: 'soldier', key: 'eliteGuard', cost: 150, desc: 'هجوم +8، دفاع +4 دائم' },
    { id: 17, name: 'منشق التنين', type: 'soldier', key: 'dragonSpearman', cost: 300, desc: 'هجوم +15، دفاع +8 دائم' },
    { id: 18, name: 'قائد أسطوري', type: 'soldier', key: 'legendaryCommander', cost: 600, desc: 'هجوم +30، دفاع +15 دائم' },
    // ===== تعاويذ =====
    { id: 19, name: 'لهيب التنين', type: 'spell', key: 'dragonFlame', cost: 120, desc: 'دمج 50 مرة يومياً' },
    { id: 20, name: 'شفاء الملك', type: 'spell', key: 'kingsHeal', cost: 100, desc: '+50 صحة مرة يومياً' },
    { id: 21, name: 'عاصفة البرق', type: 'spell', key: 'lightningStorm', cost: 150, desc: 'مضاعفة الضربة الأولى مرة يومياً' },
    { id: 22, name: 'الثور الهائج', type: 'spell', key: 'ragingBull', cost: 180, desc: '+10% هجوم مرة يومياً' },
    { id: 23, name: 'تجمد', type: 'spell', key: 'freeze', cost: 160, desc: 'تشل العدو لجولة واحدة' },
    { id: 24, name: 'إعصار', type: 'spell', key: 'cyclone', cost: 200, desc: 'يقلل دفاع العدو 20%' },
    { id: 25, name: 'لعنة الموت', type: 'spell', key: 'curse', cost: 400, desc: 'فرصة 50% لقتل العدو فوراً (مرة واحدة)' },
    // ===== رفقاء =====
    { id: 26, name: 'تنين أسطوري', type: 'companion', key: 'dragon', cost: 600, desc: 'هجوم ودفاع +15%' },
    { id: 27, name: 'ذئب الظلام', type: 'companion', key: 'darkWolf', cost: 350, desc: 'هجوم +10%' },
    { id: 28, name: 'نسر الجليد', type: 'companion', key: 'iceEagle', cost: 450, desc: 'دفاع +12%' },
    { id: 29, name: 'تنين العالم الآخر', type: 'companion', key: 'otherworldDragon', cost: 1200, desc: 'هجوم ودفاع +25% (نادر)' },
    // ===== صفحات روح =====
    { id: 30, name: 'صفحة روح نادرة', type: 'soulPage', key: 'soulPage', cost: 100, desc: 'تضيف صفحة لكتاب الأرواح' },
    { id: 31, name: '3 صفحات روح', type: 'soulPage', key: 'soulPage3', cost: 250, desc: 'تضيف 3 صفحات' },
    { id: 32, name: '5 صفحات روح', type: 'soulPage', key: 'soulPage5', cost: 400, desc: 'تضيف 5 صفحات' },
    { id: 33, name: 'صفحة روح الظلام', type: 'soulPage', key: 'soulPageDark', cost: 600, desc: 'تضيف 5 صفحات وتستدعي روح الظلام' },
    // ===== إكسسوارات =====
    { id: 34, name: 'خاتم القوة', type: 'accessory', key: 'powerRing', cost: 200, desc: 'هجوم +10 دائم' },
    { id: 35, name: 'خاتم الحماية', type: 'accessory', key: 'protectionRing', cost: 200, desc: 'دفاع +10 دائم' },
    { id: 36, name: 'تاج الملوك', type: 'accessory', key: 'kingsCrown', cost: 900, desc: 'هجوم +30، دفاع +30، صحة +100' },
    { id: 37, name: 'قناع الظل', type: 'accessory', key: 'shadowMask', cost: 400, desc: 'دفاع +15' },
    { id: 38, name: 'قناع البطل', type: 'accessory', key: 'heroMask', cost: 700, desc: 'هجوم +20، دفاع +20، صحة +50' },
    // ===== جرعات =====
    { id: 39, name: 'جرعة شفاء صغيرة', type: 'potion', key: 'smallHeal', cost: 50, desc: 'تستعيد 50 صحة' },
    { id: 40, name: 'جرعة شفاء كبيرة', type: 'potion', key: 'largeHeal', cost: 150, desc: 'تستعيد 150 صحة' },
    { id: 41, name: 'جرعة الطاقة', type: 'potion', key: 'energyPotion', cost: 200, desc: 'تضاعف هجومك في المعركة التالية' },
    { id: 42, name: 'جرعة شفاء مصنعة', type: 'potion', key: 'craftedHeal', cost: 300, desc: 'تستعيد 300 صحة (نادرة)' }
];

// ========== دالة الإرسال الفاخرة ==========
async function sendFancy(sock, chatId, lines, quoted = null, mentions = []) {
    let msg = `💰 شـراء 💰\n`;
    msg += `━━━━━━━━━━━━━━━━━━━━\n`;
    for (const line of lines) {
        msg += `${line}\n`;
    }
    msg += `━━━━━━━━━━━━━━━━━━━━\n`;
    msg += `𝘽𝙔┇𝑴𝑨𝑲𝑰𝑴𝑨`;
    await sock.sendMessage(chatId, { text: msg, mentions }, { quoted: quoted });
}

// ========== دالة البحث عن المنتج ==========
function findProduct(identifier) {
    const id = parseInt(identifier);
    if (!isNaN(id) && id > 0) {
        const product = fullProductsList.find(p => p.id === id);
        if (product) return product;
    }
    
    const searchLower = identifier.toLowerCase().trim();
    let product = fullProductsList.find(p => p.name.toLowerCase() === searchLower);
    if (product) return product;
    
    product = fullProductsList.find(p => p.name.toLowerCase().includes(searchLower));
    if (product) return product;
    
    const keywords = searchLower.split(' ');
    let bestMatch = null;
    let bestScore = 0;
    for (const p of fullProductsList) {
        const nameLower = p.name.toLowerCase();
        let score = 0;
        for (const kw of keywords) {
            if (nameLower.includes(kw)) score++;
        }
        if (score > bestScore) {
            bestScore = score;
            bestMatch = p;
        }
    }
    return bestMatch;
}

// ========== الأمر الرئيسي ==========
module.exports = {
    command: 'شراء',
    description: '💰 شراء منتج من المتجر الأسطوري (بالرقم أو الاسم)',
    category: 'مملكة',
    async execute(sock, msg) {
        try {
            const chatId = msg.key.remoteJid;
            const sender = msg.key.participant || msg.participant || msg.key.remoteJid;

            const fullText = msg.message?.conversation || msg.message?.extendedTextMessage?.text || '';
            const args = fullText.trim().split(/\s+/);

            if (args.length < 2) {
                await sendFancy(sock, chatId, [
                    `⚠️ @${sender.split('@')[0]}`,
                    `📌 استخدم: .شراء [رقم المنتج أو اسمه] [العدد]`,
                    `📝 مثال: .شراء 1 3`,
                    `📝 مثال: .شراء درع ذهبي 2`
                ], msg, [sender]);
                return;
            }

            let quantity = 1;
            let productIdentifier = '';
            
            const lastArg = args[args.length - 1];
            const lastIsNumber = !isNaN(parseInt(lastArg)) && parseInt(lastArg) > 0;
            
            if (lastIsNumber) {
                quantity = parseInt(lastArg);
                productIdentifier = args.slice(1, -1).join(' ');
                if (!productIdentifier) productIdentifier = args[1];
            } else {
                productIdentifier = args.slice(1).join(' ');
            }

            const product = findProduct(productIdentifier);
            
            if (!product) {
                const availableProducts = fullProductsList
                    .slice(0, 10)
                    .map(p => `  ${p.id}. ${p.name} (${p.cost} نقطة)`)
                    .join('\n');
                
                await sendFancy(sock, chatId, [
                    `❌ لا يوجد منتج بالاسم "${productIdentifier}".`,
                    `📌 المنتجات المتاحة:`,
                    availableProducts,
                    `📌 استخدم .متجر لعرض القائمة الكاملة.`
                ], msg, [sender]);
                return;
            }

            if (quantity > 100) {
                await sendFancy(sock, chatId, [
                    `❌ لا يمكن شراء أكثر من 100 قطعة مرة واحدة.`
                ], msg, [sender]);
                return;
            }

            const totalCost = product.cost * quantity;

            // ===== التحقق من وجود مملكة =====
            if (!userExists(sender)) {
                await sendFancy(sock, chatId, [
                    `❌ @${sender.split('@')[0]}، ليس لديك مملكة.`,
                    `📌 استخدم .لاعب جديد لتأسيس مملكتك.`
                ], msg, [sender]);
                return;
            }

            // ===== تحميل بيانات المستخدم =====
            const points = loadJSON(pointsPath);
            let userPoints = points[sender] || 0;
            let user = loadUserData(sender);

            if (userPoints < totalCost) {
                await sendFancy(sock, chatId, [
                    `❌ رصيدك لا يكفي!`,
                    `💰 السعر: ${product.cost} نقطة × ${quantity} = ${totalCost}`,
                    `💰 رصيدك: ${userPoints} نقطة`
                ], msg, [sender]);
                return;
            }

            // ===== تطبيق الشراء =====
            let purchaseDetail = '';

            if (product.type === 'weapon') {
                user.weapons[product.key] = (user.weapons[product.key] || 0) + quantity;
                purchaseDetail = `⚔️ تمت إضافة ${quantity} × ${product.name} إلى مخزن أسلحتك.`;
            } else if (product.type === 'soldier') {
                user.soldiers[product.key] = (user.soldiers[product.key] || 0) + quantity;
                purchaseDetail = `👥 تمت إضافة ${quantity} × ${product.name} إلى جيشك.`;
            } else if (product.type === 'spell') {
                user.spellsUsed[product.key] = (user.spellsUsed[product.key] || 0) + 1;
                purchaseDetail = `🔮 تم تفعيل ${product.name} (مرة واحدة يومياً).`;
            } else if (product.type === 'companion') {
                const powerMap = { dragon: 15, darkWolf: 10, iceEagle: 12, otherworldDragon: 25 };
                const power = powerMap[product.key] || 10;
                user.companion = { name: product.name, power: power };
                purchaseDetail = `🐦 أصبح ${product.name} رفيقك الجديد (قوته ${power}%).`;
            } else if (product.type === 'soulPage') {
                let pages = 0;
                let spirit = null;
                if (product.key === 'soulPage') pages = 1 * quantity;
                else if (product.key === 'soulPage3') pages = 3 * quantity;
                else if (product.key === 'soulPage5') pages = 5 * quantity;
                else if (product.key === 'soulPageDark') {
                    pages = 5 * quantity;
                    spirit = 'روح الظلام';
                }
                user.soulBook.pages = (user.soulBook.pages || 0) + pages;
                if (spirit) {
                    if (!user.soulBook.spirits) user.soulBook.spirits = [];
                    for (let i = 0; i < quantity; i++) {
                        user.soulBook.spirits.push(spirit);
                    }
                    purchaseDetail = `📖 تمت إضافة ${pages} صفحات روح${quantity > 1 ? ' و ' + quantity + ' أرواح' : ''}.`;
                } else {
                    purchaseDetail = `📖 تمت إضافة ${pages} صفحات روح.`;
                }
            } else if (product.type === 'accessory') {
                user.accessories[product.key] = (user.accessories[product.key] || 0) + quantity;
                purchaseDetail = `💍 تمت إضافة ${quantity} × ${product.name} إلى إكسسواراتك.`;
            } else if (product.type === 'potion') {
                user.potions[product.key] = (user.potions[product.key] || 0) + quantity;
                purchaseDetail = `🧪 تمت إضافة ${quantity} × ${product.name} إلى جرعاتك.`;
            }

            // ===== حفظ التغييرات =====
            points[sender] = userPoints - totalCost;
            user.lastActive = Date.now();
            saveJSON(pointsPath, points);
            saveUserData(sender, user);

            const lines = [
                `🎉 @${sender.split('@')[0]}`,
                `✅ تم شراء *${quantity} × ${product.name}* بنجاح!`,
                ``,
                `📋 ${purchaseDetail}`,
                `💰 تم خصم ${totalCost} نقطة`,
                `💰 رصيدك المتبقي: ${points[sender]} نقطة`,
                ``,
                `📌 استخدم .مخزن لعرض مقتنياتك`
            ];

            await sendFancy(sock, chatId, lines, msg, [sender]);

        } catch (error) {
            console.error('✗ خطأ في أمر شراء:', error);
            await sendFancy(sock, msg.key.remoteJid, [
                `❌ حدث خطأ أثناء عملية الشراء.`,
                `📌 حاول مرة أخرى لاحقاً.`
            ], msg);
        }
    }
};