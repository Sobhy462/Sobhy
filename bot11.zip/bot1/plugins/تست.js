const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

module.exports = {
  command: 'تست',
  description: '⚡ عرض حالة البوت ومعلومات النظام',
  category: 'نظام',

  async execute(sock, msg) {
    try {
      const jid = msg.key.remoteJid;
      const sender = msg.key.participant || jid;
      const number = sender.split('@')[0];
      const pushName = msg.pushName || "Unknown";

      const hay = require('../haykala/developer');
      const { isElite } = require('../haykala/elite.js');
      const lid = hay.toLid(sender);

      const botName = 'MAKIMA BOT v2';
      const version = '5.0';
      const uptime = process.uptime();
      const uptimeStr = formatUptime(uptime);
      const groupsCount = '12';
      const usersCount = '245';

      // 🔋 شريط الطاقة القديم (▰▱)
      const powerStages = [
        "▰▱▱▱▱▱▱▱▱▱ 10%",
        "▰▰▱▱▱▱▱▱▱▱ 20%",
        "▰▰▰▰▱▱▱▱▱▱ 40%",
        "▰▰▰▰▰▰▱▱▱▱ 60%",
        "▰▰▰▰▰▰▰▰▱▱ 80%",
        "▰▰▰▰▰▰▰▰▰▱ 90%",
        "▰▰▰▰▰▰▰▰▰▰ 100%"
      ];

      // 🔹 زيادة العرض قليلاً لمنح مساحة
      const LINE_WIDTH = 30;

      function formatUptime(seconds) {
        const d = Math.floor(seconds / 86400);
        const h = Math.floor((seconds % 86400) / 3600);
        const m = Math.floor((seconds % 3600) / 60);
        const s = Math.floor(seconds % 60);
        return `${d}d ${h}h ${m}m ${s}s`;
      }

      // تحديد الرتبة
      let rank = 'عضو';
      let rankIcon = '👤';
      let rankColor = '🔵';
      let specialMessage = 'نحن هنا لخدمتك دائماً!';

      if (hay.isFounder(lid)) {
        rank = 'المالك';
        rankIcon = '👑';
        rankColor = '💎';
        specialMessage = 'أنت المنشئ!';
      } else if (hay.isOwnerbot(lid)) {
        rank = 'مالك البوت';
        rankIcon = '⚜️';
        rankColor = '🔱';
        specialMessage = 'أنت السيد!';
      } else if (hay.isDeveloper(lid)) {
        rank = 'مطور';
        rankIcon = '💻';
        rankColor = '⚡';
        specialMessage = 'أنت المبدع!';
      } else if (isElite(number)) {
        rank = 'نخبة';
        rankIcon = '🏅';
        rankColor = '🌟';
        specialMessage = 'التميز في عروقك!';
      }

      // دالة لحساب الطول الفعلي (مع الإيموجي)
      function getCharLength(text) {
        return Array.from(text).length;
      }

      // دالة لتقصير النص إذا تجاوز الطول المسموح
      function truncate(text, maxLen) {
        const len = getCharLength(text);
        if (len <= maxLen) return text;
        return Array.from(text).slice(0, maxLen - 1).join('') + '…';
      }

      // دالة لإنشاء الإطار مع المحتوى
      function buildFrame(contentLines) {
        const top = '' + ''.repeat(LINE_WIDTH - 0) + '';
        const bottom = '' + ''.repeat(LINE_WIDTH - 0) + '';
        let lines = [];
        lines.push(top);
        for (let line of contentLines) {
          // حساب الطول الفعلي للنص
          const lineLen = getCharLength(line);
          // إذا كان النص أطول من المساحة المتاحة، نقصره
          const maxContent = LINE_WIDTH - 4;
          let trimmed = line;
          if (lineLen > maxContent) {
            trimmed = truncate(line, maxContent);
          }
          // padding لضبط الطول
          const padded = trimmed.padEnd(maxContent, ' ');
          lines.push('│ ' + padded + ' ');
        }
        lines.push(bottom);
        return lines.join('\n');
      }

      // بناء الرسالة حسب المرحلة
      function buildMessage(powerBar, status, isFinal = false) {
        let lines = [];
        if (isFinal) {
          lines.push(`       ${botName}        `);
          lines.push(''.repeat(LINE_WIDTH - 4));
          lines.push('✅ النظام جاهز بالكامل!');
          lines.push(`⚡ الطاقة : 100% 🔋`);
          lines.push('🚀 جميع الخدمات متاحة');
          lines.push('📢 استمتع بالتجربة');
          lines.push('');
          lines.push(`👤 ${pushName}`);
          lines.push(`🔰 ${rankIcon} ${rank} ${rankColor}`);
          lines.push(`💬 ${specialMessage}`);
          lines.push('─'.repeat(LINE_WIDTH - 4));
          lines.push('💡 استخدم .اوامر');
        } else {
          lines.push(`       ${botName}        `);
          lines.push(''.repeat(LINE_WIDTH - 4));
          lines.push(`⚡ الحالة : ${status}`);
          lines.push(`👤 المستخدم : ${pushName}`);
          lines.push(`🔰 الرتبة : ${rankIcon} ${rank} ${rankColor}`);
          lines.push(`💠 الطاقة : ${powerBar}`);
          lines.push(`🛰️ الاتصال : مستقر ✓`);
          lines.push(`🕒 مدة التشغيل: ${uptimeStr}`);
          lines.push(`🏷️ الإصدار : v${version}`);
          lines.push(`🛡️ المالك : +218 923993720`);
          lines.push(`💬 ${specialMessage}`);
          lines.push('─'.repeat(LINE_WIDTH - 4));
          lines.push('💡 استخدم .اوامر');
        }
        return buildFrame(lines);
      }

      // إرسال الرسالة الأولى
      const sent = await sock.sendMessage(
        jid,
        {
          text: buildMessage(powerStages[0], '🔄 جاري التحميل...'),
          mentions: [sender]
        },
        { quoted: msg }
      );

      // تحديث الشريط تدريجياً
      for (let i = 1; i < powerStages.length; i++) {
        await sleep(180);
        await sock.sendMessage(
          jid,
          {
            edit: sent.key,
            text: buildMessage(powerStages[i], '⚡ تشغيل النظام...'),
            mentions: [sender]
          }
        );
      }

      // الرسالة النهائية
      await sleep(200);
      await sock.sendMessage(
        jid,
        {
          edit: sent.key,
          text: buildMessage('', '', true),
          mentions: [sender]
        }
      );

    } catch (err) {
      console.error('❌ Error in .تست:', err);
      await sock.sendMessage(msg.key.remoteJid, {
        text: '❌ حدث خطأ أثناء تنفيذ الأمر.'
      }, { quoted: msg });
    }
  }
};