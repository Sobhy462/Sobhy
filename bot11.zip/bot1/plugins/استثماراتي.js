// استثماراتي.js - عرض حالة الاستثمارات النشطة والمنتهية للمستخدم
const fs = require('fs');
const path = require('path');

const dataDir = path.join(__dirname, '../data/kingdom');
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

const MAIN_PATH = path.join(dataDir, 'main.json');
const INVESTMENTS_PATH = path.join(dataDir, 'investments.json');
const INVESTMENTS_HISTORY_PATH = path.join(dataDir, 'investments_history.json');

const allPaths = [MAIN_PATH, INVESTMENTS_PATH, INVESTMENTS_HISTORY_PATH];
for (const p of allPaths) {
    if (!fs.existsSync(p)) fs.writeFileSync(p, JSON.stringify({}, null, 2));
}

function loadJSON(file) { try { return JSON.parse(fs.readFileSync(file)); } catch { return {}; } }
function saveJSON(file, data) {
    try {
        if (fs.existsSync(file)) fs.writeFileSync(file + '.bak', fs.readFileSync(file));
        fs.writeFileSync(file, JSON.stringify(data, null, 2));
        return true;
    } catch (e) {
        console.error('❌ فشل حفظ:', file, e.message);
        return false;
    }
}

function userExists(jid) { return !!loadJSON(MAIN_PATH)[jid]; }

// ========== دوال الاستثمارات ==========
function loadInvestments() { return loadJSON(INVESTMENTS_PATH); }
function loadInvestmentsHistory() { return loadJSON(INVESTMENTS_HISTORY_PATH); }

function getInvestment(jid) {
    const investments = loadInvestments();
    return investments[jid] || null;
}

function getInvestmentHistory(jid) {
    const history = loadInvestmentsHistory();
    return history[jid] || [];
}

// ========== دالة الإرسال ==========
async function sendMessage(sock, chatId, lines, quoted = null, mentions = []) {
    if (!Array.isArray(lines)) lines = [lines];
    let msg = `📊 استـثـمـاراتـي 📊\n`;
    msg += `━━━━━━━━━━━━━━━━━━━━\n`;
    for (const line of lines) {
        msg += `${line}\n`;
    }
    msg += `━━━━━━━━━━━━━━━━━━━━\n`;
    msg += `𝘽𝙔┇𝑴𝑨𝑲𝑰𝑴𝑨`;
    await sock.sendMessage(chatId, { text: msg, mentions }, { quoted: quoted });
}

// ========== الأمر الرئيسي ==========
module.exports = {
    command: ['استثماراتي'],
    description: '📊 عرض حالة الاستثمارات النشطة والمنتهية',
    category: 'مملكة',
    usage: '.استثماراتي',
    async execute(sock, msg) {
        try {
            const chatId = msg.key.remoteJid;
            const sender = msg.key.participant || msg.key.remoteJid;

            if (!userExists(sender)) {
                await sendMessage(sock, chatId, [
                    '❌ ليس لديك مملكة!',
                    '📌 استخدم .لاعب جديد لتأسيس مملكتك.'
                ], msg, [sender]);
                return;
            }

            const lines = [`👤 @${sender.split('@')[0]}`, ''];

            // ===== التحقق من الاستثمار النشط =====
            const activeInvestment = getInvestment(sender);
            if (activeInvestment) {
                const now = Date.now();
                if (now < activeInvestment.finishTime) {
                    const remaining = activeInvestment.finishTime - now;
                    const minutes = Math.floor(remaining / (60 * 1000));
                    const seconds = Math.floor((remaining % (60 * 1000)) / 1000);
                    lines.push('📌 *استثمار نشط:*');
                    lines.push(`   💰 المبلغ: ${activeInvestment.amount} نقطة`);
                    lines.push(`   ⏳ المدة: ${Math.floor(activeInvestment.duration / (60 * 1000))} دقيقة`);
                    lines.push(`   ⏳ الوقت المتبقي: ${minutes} دقيقة ${seconds} ثانية`);
                } else {
                    // استثمار منتهي ولكن لم تُعالج نتيجته بعد (نادر)
                    lines.push('📌 *استثمار منتهي (في انتظار النتيجة):*');
                    lines.push(`   💰 المبلغ: ${activeInvestment.amount} نقطة`);
                    lines.push(`   ⏳ انتهى منذ ${Math.floor((now - activeInvestment.finishTime) / (60 * 1000))} دقيقة`);
                }
            } else {
                lines.push('📌 *لا يوجد استثمار نشط حالياً.*');
                lines.push('💡 استخدم .استثمار [المبلغ] للبدء.');
            }

            // ===== عرض تاريخ الاستثمارات (آخر 5) =====
            const history = getInvestmentHistory(sender);
            if (history.length > 0) {
                lines.push('');
                lines.push('📌 *آخر 5 استثمارات:*');
                const recent = history.slice(-5).reverse();
                for (const inv of recent) {
                    const date = new Date(inv.date).toLocaleString();
                    const result = inv.success ? `✅ ربح ${inv.profit || 0}` : `❌ خسارة ${inv.loss || 0}`;
                    lines.push(`   💰 ${inv.amount} نقطة | ${result} | ${date}`);
                }
            } else {
                lines.push('');
                lines.push('📌 *ليس لديك استثمارات سابقة.*');
            }

            await sendMessage(sock, chatId, lines, msg, [sender]);

        } catch (error) {
            console.error('✗ خطأ في أمر استثماراتي:', error);
            await sendMessage(sock, msg.key.remoteJid, [
                '❌ حدث خطأ أثناء عرض الاستثمارات.',
                '📌 حاول مرة أخرى لاحقاً.'
            ], msg);
        }
    }
};