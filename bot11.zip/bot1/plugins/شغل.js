// شغل.js - تحميل صوت من تيك توك (يدعم الروابط والبحث)
const axios = require('axios');
const fs = require('fs');
const path = require('path');

const audioPrice = 50;
const APIFY_TOKEN = 'apify_api_Nosx6ch9Ua28pFgV1TFeurHCsbflPn21ezuh';

const pointsPath = path.join(__dirname, '../data/points.json');

if (!fs.existsSync(path.join(__dirname, '../data'))) fs.mkdirSync(path.join(__dirname, '../data'), { recursive: true });
if (!fs.existsSync(pointsPath)) fs.writeFileSync(pointsPath, JSON.stringify({}, null, 2));

function loadPoints() {
    try {
        return JSON.parse(fs.readFileSync(pointsPath));
    } catch {
        return {};
    }
}

function savePoints(data) {
    fs.writeFileSync(pointsPath, JSON.stringify(data, null, 2));
}

function isTikTokLink(text) {
    return /https?:\/\/(www\.|vm\.|vt\.)?tiktok\.com\/\S+/i.test(text);
}

function formatDuration(seconds) {
    if (!seconds || isNaN(seconds)) return 'غير معروف';
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m}:${String(s).padStart(2, '0')}`;
}

// ========== دالة تنسيق النقاط ==========
function formatPoints(num) {
    if (num === undefined || num === null || isNaN(num)) return '0';
    num = Math.floor(num);
    if (num >= 1e15) return '∞';
    if (num >= 1e12) return (num / 1e12).toFixed(2) + ' تريليون';
    if (num >= 1e9) return (num / 1e9).toFixed(2) + ' مليار';
    if (num >= 1e6) return (num / 1e6).toFixed(2) + ' مليون';
    if (num >= 1e3) return (num / 1e3).toFixed(2) + ' ألف';
    return num.toString();
}

// ========== دالة الإرسال المنسقة ==========
async function sendMessage(sock, chatId, lines, quoted = null, mentions = []) {
    if (!Array.isArray(lines)) lines = [lines];
    let msg = `🎵 تـحـمـيـل صـوت تـيـك تـوك 🎵\n━━━━━━━━━━━━━━━━━━━━\n`;
    for (const line of lines) {
        if (line && line.trim()) msg += `${line}\n`;
    }
    msg += `━━━━━━━━━━━━━━━━━━━━\n𝘽𝙔┇𝑴𝑨𝑲𝑰𝑴𝑨`;
    await sock.sendMessage(chatId, { text: msg, mentions }, { quoted: quoted });
}

// ========== جلب البيانات عبر TikWM (للروابط والبحث) ==========
async function fetchViaTikWM(query, isLink = false) {
    try {
        let apiUrl;
        if (isLink) {
            apiUrl = `https://www.tikwm.com/api/?url=${encodeURIComponent(query)}`;
        } else {
            apiUrl = `https://www.tikwm.com/api/feed/search?keywords=${encodeURIComponent(query)}`;
        }
        const response = await axios.get(apiUrl, {
            timeout: 30000,
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                'Referer': 'https://www.tikwm.com/',
                'Origin': 'https://www.tikwm.com',
                'Accept': 'application/json, text/plain, */*',
                'Accept-Encoding': 'gzip, deflate, br',
                'Accept-Language': 'en-US,en;q=0.9'
            }
        });
        if (response.status === 200 && response.data?.code === 0) {
            if (isLink) {
                const data = response.data.data;
                if (data) {
                    return {
                        title: data.title || 'صوت تيك توك',
                        audio_url: data.music || data.music_info?.play || data.music_info?.url || data.play,
                        thumbnail: data.cover || '',
                        author: data.author?.nickname || 'مجهول',
                        duration: data.duration || 0,
                        videoUrl: query
                    };
                }
            } else {
                const videos = response.data.data?.videos;
                if (videos && videos.length) {
                    const video = videos[0];
                    return {
                        title: video.title || 'صوت تيك توك',
                        audio_url: video.music || video.music_info?.play || video.music_info?.url,
                        thumbnail: video.cover || '',
                        author: video.author?.nickname || 'مجهول',
                        duration: video.duration || 0,
                        videoUrl: `https://www.tiktok.com/@${video.author?.unique_id}/video/${video.video_id}`
                    };
                }
            }
        }
        return null;
    } catch (error) {
        console.error('❌ فشل جلب من TikWM:', error.message);
        return null;
    }
}

// ========== جلب البيانات عبر Apify (كبديل) ==========
async function fetchViaApify(query, isLink = false) {
    try {
        let searchQuery = String(query || '').trim();
        let videoIdMatch = null;

        if (isLink) {
            videoIdMatch = query.match(/\/video\/(\d+)/);
            if (videoIdMatch) {
                searchQuery = videoIdMatch[1];
            } else {
                searchQuery = query;
            }
        } else {
            if (!/\bedit\b/i.test(searchQuery)) {
                searchQuery = `${searchQuery} edit`;
            }
        }

        const apiUrl = 'https://api.apify.com/v2/acts/mu0i~tiktok-search-scraper/run-sync-get-dataset-items';

        const response = await axios.post(
            apiUrl,
            {
                queries: [searchQuery],
                resultType: 'videos',
                maxResultsPerQuery: 10,
                sortBy: 'relevance',
                includeDownloadUrls: true
            },
            {
                params: { token: APIFY_TOKEN },
                headers: { 'Content-Type': 'application/json' },
                timeout: 120000
            }
        );

        const data = Array.isArray(response.data) ? response.data : [];

        const videos = data
            .filter(v => v && v.url && !v.isPhotoPost)
            .map(v => ({
                title: v.description || 'صوت تيك توك',
                videoUrl: v.url,
                audio_url: v.music_url || v.audio_url || v.noWatermarkUrl || v.url,
                thumbnail: v.coverUrl || '',
                author: v.authorUsername || v.authorNickname || 'مجهول',
                duration: v.duration || 0
            }))
            .filter(v => v.audio_url);

        if (isLink && videoIdMatch) {
            const matched = videos.find(v => 
                v.videoUrl.includes(query) || 
                v.videoUrl.includes(videoIdMatch[1])
            );
            return matched || (videos.length ? videos[0] : null);
        }

        return videos.length ? videos[0] : null;

    } catch (error) {
        console.error('❌ فشل جلب من Apify:', error.message);
        return null;
    }
}

// ========== تحميل الصوت كـ Buffer ==========
async function downloadAudio(audioUrl) {
    try {
        const response = await axios.get(audioUrl, {
            responseType: 'arraybuffer',
            timeout: 60000,
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                'Referer': 'https://www.tiktok.com/'
            }
        });
        return Buffer.from(response.data);
    } catch (error) {
        console.error('❌ فشل تحميل الصوت:', error.message);
        return null;
    }
}

// ========== تحميل الصورة المصغرة ==========
async function downloadThumbnail(url) {
    try {
        if (!url) return null;
        const response = await axios.get(url, {
            responseType: 'arraybuffer',
            timeout: 15000,
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                'Referer': 'https://www.tikwm.com/',
                'Origin': 'https://www.tikwm.com'
            }
        });
        return Buffer.from(response.data);
    } catch (error) {
        console.error('Thumbnail download error:', error);
        return null;
    }
}

module.exports = {
    command: ['شغل'],
    category: 'وسائط',
    description: '🎵 تحميل الصوت الأصلي من تيك توك (البحث أو الرابط)',
    usage: '.شغل [كلمة البحث] أو .شغل [رابط الفيديو]',
    price: audioPrice,

    async execute(sock, msg, args) {
        let chatId, sender, points, userPoints, inputText;

        try {
            chatId = msg.key.remoteJid;
            sender = msg.key.participant || msg.key.remoteJid;

            points = loadPoints();
            userPoints = points[sender] || 0;

            // استخراج النص
            inputText = '';
            if (args && Array.isArray(args) && args.length) {
                inputText = args.join(' ').trim();
            }
            if (!inputText && msg.message?.conversation) {
                inputText = msg.message.conversation.replace(/^\.شغل\s*/i, '').trim();
            }
            if (!inputText && msg.message?.extendedTextMessage?.text) {
                inputText = msg.message.extendedTextMessage.text.replace(/^\.شغل\s*/i, '').trim();
            }

            if (!inputText) {
                const lines = [
                    '🎵 *تحميل صوت تيك توك*',
                    '',
                    '📌 الاستخدام:',
                    '.شغل [كلمة البحث] - بحث عن صوت',
                    '.شغل [رابط] - تحميل من رابط',
                    '',
                    `💰 السعر: ${audioPrice} نقطة`,
                    '',
                    '📝 أمثلة:',
                    '.شغل انا واخي',
                    '.شغل https://vt.tiktok.com/xxxxx'
                ];
                await sendMessage(sock, chatId, lines, msg);
                return;
            }

            if (userPoints < audioPrice) {
                const lines = [
                    '❌ *نقاط غير كافية*',
                    '',
                    `💰 السعر: ${audioPrice} نقطة`,
                    `🪙 رصيدك: ${formatPoints(userPoints)} نقطة`,
                    `💔 تحتاج: ${formatPoints(audioPrice - userPoints)} نقطة إضافية`
                ];
                await sendMessage(sock, chatId, lines, msg, [sender]);
                return;
            }

            // خصم النقاط مؤقتاً
            points[sender] = userPoints - audioPrice;
            savePoints(points);

            await sock.sendMessage(chatId, { react: { text: '⏳', key: msg.key } });

            const isLink = isTikTokLink(inputText);
            let audioData = null;

            // ===== جلب بيانات الصوت =====
            audioData = await fetchViaTikWM(inputText, isLink);
            if (!audioData) {
                console.log('⚠️ TikWM فشل، نحاول عبر Apify...');
                audioData = await fetchViaApify(inputText, isLink);
            }

            if (!audioData || !audioData.audio_url) {
                points[sender] = (points[sender] || 0) + audioPrice;
                savePoints(points);
                await sock.sendMessage(chatId, { react: { text: '❌', key: msg.key } });
                await sendMessage(sock, chatId, [
                    '❌ لا توجد نتائج أو لا يوجد صوت',
                    '💡 تم استرجاع نقاطك'
                ], msg);
                return;
            }

            const title = audioData.title || 'صوت تيك توك';
            const duration = formatDuration(audioData.duration);
            const thumbnail = audioData.thumbnail;
            const videoUrl = audioData.videoUrl || inputText;

            console.log('✅ تم جلب الفيديو:', videoUrl);

            // ===== تحميل الصورة المصغرة =====
            const thumbBuffer = await downloadThumbnail(thumbnail);

            // ===== تحميل الصوت =====
            let audioBuffer = await downloadAudio(audioData.audio_url);
            if (!audioBuffer || audioBuffer.length < 1000) {
                // إرسال الرابط فقط
                const caption = 
`『⏯️┇𝐒𝐀𝐓𝐔𝐑𝐍 𝐁𝐎𝐓 𝐓𝐈𝐊𝐓𝐎𝐊┇⏯️』

*❐═━━━━═╊⊰🪐⊱╉═━━━━═❐*
*❐↞┇الـعـنـوان📇↞ ${title.slice(0, 50)}${title.length > 50 ? '...' : ''} ┇*
*❐↞┇الـرابـط🖇️↞ ${videoUrl} ┇*
*❐↞┇الـمـدة⏱️↞ ${duration} ┇*
*❐↞┇الـنـقـاط💰↞ -${audioPrice} ┇*
*❐↞┇رصيدك🪙↞ ${formatPoints(points[sender])} ┇*
*❐═━━━━═╊⊰🪐⊱╉═━━━━═❐*
> *𝑩𝒀┇𝑴𝑨𝑲𝑰𝑴𝑨 𝑩𝑶𝑻*`;

                await sock.sendMessage(chatId, {
                    text: `⚠️ تعذر تحميل الصوت، إليك الرابط:\n${audioData.audio_url}\n\n${caption}`
                }, { quoted: msg });
                await sock.sendMessage(chatId, { react: { text: '⚠️', key: msg.key } });
                return;
            }

            // ===== الكابتشن الموحد =====
            const newBalance = points[sender];
            const caption = 
`『⏯️┇𝐒𝐀𝐓𝐔𝐑𝐍 𝐁𝐎𝐓 𝐓𝐈𝐊𝐓𝐎𝐊┇⏯️』

*❐═━━━━═╊⊰🪐⊱╉═━━━━═❐*
*❐↞┇الـعـنـوان📇↞ ${title.slice(0, 50)}${title.length > 50 ? '...' : ''} ┇*
*❐↞┇الـرابـط🖇️↞ ${videoUrl} ┇*
*❐↞┇الـمـدة⏱️↞ ${duration} ┇*
*❐↞┇الـنـقـاط💰↞ -${audioPrice} ┇*
*❐↞┇رصيدك🪙↞ ${formatPoints(newBalance)} ┇*
*❐═━━━━═╊⊰🪐⊱╉═━━━━═❐*
> *𝑩𝒀┇𝑴𝑨𝑲𝑰𝑴𝑨 𝑩𝑶𝑻*`;

            // ===== إرسال الصورة مع الكابتشن =====
            if (thumbBuffer) {
                await sock.sendMessage(chatId, {
                    image: thumbBuffer,
                    caption: caption
                }, { quoted: msg });
            } else {
                await sock.sendMessage(chatId, {
                    text: caption
                }, { quoted: msg });
            }

            // ===== إرسال الصوت =====
            try {
                await sock.sendMessage(chatId, {
                    audio: audioBuffer,
                    mimetype: 'audio/mpeg',
                    ptt: false,
                    fileName: `${title.slice(0, 50)}.mp3`
                }, { quoted: msg });
            } catch (audioError) {
                console.error('❌ فشل إرسال الصوت، نحاول كوثيقة:', audioError.message);
                try {
                    await sock.sendMessage(chatId, {
                        document: audioBuffer,
                        mimetype: 'audio/mpeg',
                        fileName: `${title.slice(0, 50)}.mp3`,
                        caption: caption
                    }, { quoted: msg });
                } catch (docError) {
                    console.error('❌ فشل إرسال كوثيقة، نرسل الرابط:', docError.message);
                    await sock.sendMessage(chatId, {
                        text: `⚠️ تعذر رفع الصوت، إليك الرابط:\n${audioData.audio_url}\n\n${caption}`
                    }, { quoted: msg });
                }
            }

            await sock.sendMessage(chatId, { react: { text: '✅', key: msg.key } });

        } catch (error) {
            console.error('❌ خطأ في شغل:', error);

            try {
                points = loadPoints();
                points[sender] = (points[sender] || 0) + audioPrice;
                savePoints(points);
            } catch (e) {}

            if (!chatId) chatId = msg.key?.remoteJid || 'unknown';
            if (!sender) sender = msg.key?.participant || msg.key?.remoteJid || 'unknown';

            await sock.sendMessage(chatId, { react: { text: '❌', key: msg.key } });

            let errorMsg = '❌ حدث خطأ أثناء التحميل';
            if (error.code === 'ECONNABORTED') errorMsg = '⏰ انتهت المهلة';
            else if (error.response?.status === 403) errorMsg = '🚫 تم رفض الطلب';
            else if (error.response?.status === 404) errorMsg = '🔍 لا توجد نتائج';
            else if (error.response?.status >= 500) errorMsg = '🚫 الخدمة غير متاحة';
            else if (error.message.includes('لا يوجد صوت')) errorMsg = '❌ لا يوجد صوت متاح';
            else if (error.message.includes('لا توجد نتائج')) errorMsg = '🔍 لا توجد نتائج للبحث';

            await sendMessage(sock, chatId, [
                `${errorMsg}`,
                '💡 تم استرجاع نقاطك',
                '🔄 حاول مرة أخرى لاحقاً'
            ], msg);
        }
    }
};