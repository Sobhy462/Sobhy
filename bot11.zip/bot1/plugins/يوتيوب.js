const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');
const https = require('https');

// ====== إعدادات ======
const TEMP_DIR = './temp';
const POINTS_FILE = path.join(__dirname, '../data/points.json');
const COMMAND_PRICE = 50; // سعر التحميل بالنقاط (اضبط حسب رغبتك)

// ====== دوال النقاط ======
function loadPoints() {
  if (!fs.existsSync(POINTS_FILE)) {
    fs.writeFileSync(POINTS_FILE, JSON.stringify({}, null, 2));
  }
  return JSON.parse(fs.readFileSync(POINTS_FILE));
}

function savePoints(data) {
  fs.writeFileSync(POINTS_FILE, JSON.stringify(data, null, 2));
}

// ====== دوال مساعدة ======
function formatDuration(seconds) {
  if (!seconds) return 'غير معروف';
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const secs = seconds % 60;
  if (hours > 0) return `${hours}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  return `${minutes}:${secs.toString().padStart(2, '0')}`;
}

function resolveShortUrl(link) {
  return new Promise((resolve) => {
    https.get(link, {
      headers: { 'User-Agent': 'Mozilla/5.0' },
      timeout: 5000
    }, (res) => {
      if (res.statusCode === 301 || res.statusCode === 302) {
        resolve(res.headers.location);
      } else {
        resolve(link);
      }
    }).on('error', () => resolve(link));
  });
}

// ====== التحميل عبر yt-dlp ======
function downloadYoutube(url, outputPath, isAudio = false) {
  return new Promise((resolve, reject) => {
    let args = [
      '--no-playlist',
      '--no-check-certificates',
      '--retries', '3',
      '--no-warnings',
      '--quiet',
      '-o', outputPath
    ];

    if (isAudio) {
      args.push('-f', 'bestaudio');
      args.push('--extract-audio');
      args.push('--audio-format', 'mp3');
      args.push('--audio-quality', '0');
    } else {
      args.push('-f', 'bestvideo+bestaudio/best');
    }

    args.push(url);

    const proc = spawn('yt-dlp', args, { timeout: isAudio ? 120000 : 180000 });
    let stderr = '';
    proc.stderr.on('data', (data) => { stderr += data.toString(); });
    proc.on('close', (code) => {
      if (code === 0 && fs.existsSync(outputPath) && fs.statSync(outputPath).size > 0) {
        resolve(outputPath);
      } else {
        reject(new Error(stderr || `yt-dlp exit code ${code}`));
      }
    });
    proc.on('error', reject);
  });
}

// ====== جلب معلومات الفيديو ======
async function fetchInfo(url) {
  return new Promise((resolve) => {
    const proc = spawn('yt-dlp', ['--dump-json', '--skip-download', '--no-playlist', url]);
    let output = '';
    proc.stdout.on('data', (data) => { output += data.toString(); });
    proc.on('close', () => {
      try {
        resolve(JSON.parse(output));
      } catch {
        resolve(null);
      }
    });
    proc.on('error', () => resolve(null));
  });
}

// ====== الأمر الرئيسي ======
module.exports = {
  command: 'يوتيوب',
  name: 'يوتيوب',
  category: 'عام',
  description: 'تحميل فيديو أو صوت من يوتيوب (نقاط)',
  usage: '.يوتيوب <رابط>   أو   .يوتيوب صوت <رابط>',

  async execute(sock, msg, args) {
    const chatId = msg.key.remoteJid;
    const sender = msg.key.participant || msg.key.remoteJid;

    // ====== قراءة النص ======
    const fullText = msg.message?.extendedTextMessage?.text ||
                     msg.message?.conversation ||
                     msg.message?.imageMessage?.caption || '';

    let isAudio = false;
    let url = '';
    const parts = fullText.trim().split(/\s+/);
    if (parts.length >= 2 && parts[0] === '.يوتيوب' && parts[1] === 'صوت') {
      isAudio = true;
      url = parts.slice(2).join(' ');
    } else if (parts.length >= 2 && parts[0] === '.يوتيوب') {
      url = parts.slice(1).join(' ');
    } else {
      return sock.sendMessage(chatId, {
        text: `📥 *أمر تحميل يوتيوب*\n\n📖 استخدم:\n.يوتيوب [الرابط]\n.يوتيوب صوت [الرابط]\n\n🎯 مثال:\n.يوتيوب https://youtu.be/...`
      }, { quoted: msg });
    }

    if (!url || !url.startsWith('http')) {
      return sock.sendMessage(chatId, { text: '❌ رابط غير صالح' }, { quoted: msg });
    }

    // دعم الروابط المختصرة
    if (url.includes('youtu.be')) {
      url = await resolveShortUrl(url);
    }

    // ====== التحقق من النقاط ======
    const points = loadPoints();
    const userPoints = points[sender] || 0;
    if (userPoints < COMMAND_PRICE) {
      return sock.sendMessage(chatId, {
        text: `❌ نقاطك غير كافية\n💰 السعر: ${COMMAND_PRICE}\n🪙 رصيدك: ${userPoints}`
      }, { quoted: msg });
    }

    // ====== رسالة "جاري التحميل..." ======
    const waitMsg = await sock.sendMessage(chatId, {
      text: isAudio ? '⏳ جاري تحميل الصوت...' : '⏳ جاري تجهيز الفيديو...'
    }, { quoted: msg });

    // دالة حذف رسالة الانتظار
    const deleteWait = async () => {
      try {
        if (waitMsg && waitMsg.key) {
          await sock.sendMessage(chatId, { delete: waitMsg.key });
        }
      } catch (_) {}
    };

    // ====== تجهيز الملف المؤقت ======
    if (!fs.existsSync(TEMP_DIR)) fs.mkdirSync(TEMP_DIR, { recursive: true });
    const id = Date.now() + '_' + Math.random().toString(36).substring(7);
    const outputPath = path.join(TEMP_DIR, isAudio ? `${id}.mp3` : `${id}.mp4`);

    try {
      // جلب معلومات الفيديو
      const info = await fetchInfo(url);
      if (info) {
        await sock.sendMessage(chatId, {
          text: `⏳ تحميل...\n${isAudio ? '🎵' : '🎥'} ${info.title?.substring(0, 50)}\n⏱️ ${formatDuration(info.duration)}`,
          edit: waitMsg.key
        }).catch(() => {});
      }

      // التحميل
      await downloadYoutube(url, outputPath, isAudio);

      // حذف رسالة الانتظار
      await deleteWait();

      // إرسال الملف
      const fileSizeMB = fs.statSync(outputPath).size / (1024 * 1024);
      if (isAudio) {
        await sock.sendMessage(chatId, {
          audio: { url: outputPath },
          mimetype: 'audio/mpeg',
          ptt: false,
          caption: `🎵 ${info?.title || 'صوت'}\n👤 ${info?.uploader || '?'}\n💾 ${fileSizeMB.toFixed(1)} MB`
        }, { quoted: msg });
      } else {
        if (fileSizeMB > 50) {
          await sock.sendMessage(chatId, {
            document: { url: outputPath },
            mimetype: 'video/mp4',
            fileName: `${info?.title?.replace(/[^\w\u0600-\u06FF]/g, '_') || 'video'}.mp4`,
            caption: `🎥 ${info?.title || 'فيديو'}\n👤 ${info?.uploader || '?'}\n⏱️ ${formatDuration(info?.duration)}\n💾 ${fileSizeMB.toFixed(1)} MB`
          }, { quoted: msg });
        } else {
          await sock.sendMessage(chatId, {
            video: { url: outputPath },
            caption: `🎥 ${info?.title || 'فيديو'}\n👤 ${info?.uploader || '?'}\n⏱️ ${formatDuration(info?.duration)}`,
            gifPlayback: false
          }, { quoted: msg });
        }
      }

      // خصم النقاط
      const updatedPoints = loadPoints();
      updatedPoints[sender] = (updatedPoints[sender] || 0) - COMMAND_PRICE;
      savePoints(updatedPoints);
      await sock.sendMessage(chatId, {
        text: `✅ تم التحميل\n💰 خصم ${COMMAND_PRICE} نقطة\n🪙 رصيدك: ${updatedPoints[sender]}`
      }, { quoted: msg });

    } catch (err) {
      console.error('❌ خطأ تحميل يوتيوب:', err);
      await deleteWait();
      await sock.sendMessage(chatId, {
        text: `❌ فشل التحميل\nالسبب: ${err.message.substring(0, 150)}\nلم يتم خصم نقاط.`
      }, { quoted: msg });
    } finally {
      setTimeout(() => {
        if (fs.existsSync(outputPath)) fs.unlinkSync(outputPath);
      }, 10000);
    }
  }
};