// سؤال.js - لعبة أسئلة عامة (الكل يشارك)

const fs = require('fs');
const path = require('path');

const pointsPath = path.join(__dirname, '../data/points.json');
const ranksPath = path.join(__dirname, '../data/ranks.json');

// ========== التأكد من وجود الملفات ==========
if (!fs.existsSync(pointsPath)) fs.writeFileSync(pointsPath, JSON.stringify({}, null, 2));
if (!fs.existsSync(ranksPath)) fs.writeFileSync(ranksPath, JSON.stringify({}, null, 2));

// ========== دوال مساعدة ==========
function loadJSON(file) {
    try { return JSON.parse(fs.readFileSync(file)); } 
    catch { return {}; }
}

function saveJSON(file, data) {
    fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

function getLevel(points) {
    if (points >= 1000000000) return '👑 DEVELOPER';
    if (points >= 100000000) return '🌀 KING OF POINTS';
    if (points >= 10000000) return '💀 BIG BOSS';
    if (points >= 1000000) return '🔥🔥 WTF';
    if (points >= 100000) return '🔪🩸 KILLER';
    if (points >= 10000) return '🦁 LEGEND';
    if (points >= 1000) return '💎 PRO';
    if (points >= 500) return '🔥 advanced';
    if (points >= 200) return '🌱 junior';
    return '🙂 beginner';
}

function formatNumber(num) {
    if (num === undefined || num === null || isNaN(num)) return '0';
    num = Math.floor(num);
    if (num >= 1e15) return '∞';
    if (num >= 1e12) return (num / 1e12).toFixed(2) + ' تريليون';
    if (num >= 1e9) return (num / 1e9).toFixed(2) + ' مليار';
    if (num >= 1e6) return (num / 1e6).toFixed(2) + ' مليون';
    if (num >= 1e3) return (num / 1e3).toFixed(2) + ' ألف';
    return num.toString();
}

// ========== دالة تطبيع النص ==========
function normalize(str) {
    return str.trim()
        .replace(/[أإآ]/g, 'ا')
        .replace(/[ى]/g, 'ي')
        .replace(/\s+/g, ' ')
        .toLowerCase();
}

function isMatching(input, target) {
    return normalize(input) === normalize(target);
}

// ========== دالة الإرسال بتنسيق موحد ==========
async function sendMessage(sock, chatId, lines, quoted = null, mentions = []) {
    if (!Array.isArray(lines)) {
        lines = [lines];
    }

    let msg = `❓ سـؤال عـام ❓\n`;
    msg += `━━━━━━━━━━━━━━━━━━━━\n`;
    for (const line of lines) {
        if (line && line.trim()) {
            msg += `${line}\n`;
        }
    }
    msg += `━━━━━━━━━━━━━━━━━━━━\n`;
    msg += `𝘽𝙔┇𝑴𝑨𝑲𝑰𝑴𝑨`;
    
    await sock.sendMessage(chatId, { 
        text: msg, 
        mentions 
    }, { 
        quoted: quoted 
    });
}

// ========== مستويات اللعبة ==========
const rewardMap = { سهل: 50, متوسط: 100, صعب: 200 };
const penaltyMap = { سهل: 50, متوسط: 100, صعب: 200 };
const timeMap = { سهل: 15000, متوسط: 20000, صعب: 30000 };

// ========== قائمة الأسئلة حسب المستوى ==========
const questions = {
    سهل: [
        { q: 'ما هي عاصمة مصر؟', a: 'القاهرة' },
        { q: 'ما هو أكبر محيط في العالم؟', a: 'المحيط الهادئ' },
        { q: 'كم عدد أركان الإسلام؟', a: 'خمسة' },
        { q: 'ما هو أسرع حيوان بري؟', a: 'الفهد' },
        { q: 'ما هي اللغة الرسمية في البرازيل؟', a: 'البرتغالية' },
        { q: 'كم عدد الكواكب في المجموعة الشمسية؟', a: 'ثمانية' },
        { q: 'من هو مؤسس فيسبوك؟', a: 'مارك زوكربيرغ' },
        { q: 'ما هي أصغر دولة في العالم؟', a: 'الفاتيكان' },
        { q: 'ما هو أطول نهر في العالم؟', a: 'النيل' },
        { q: 'كم عدد أيام السنة الكبيسة؟', a: '366' },
        { q: 'ما هو لون دم الأخطبوط؟', a: 'أزرق' },
        { q: 'من هو مؤلف رواية "المسخ"؟', a: 'فرانز كافكا' },
        { q: 'ما هي عملة المملكة المتحدة؟', a: 'الجنيه الإسترليني' },
        { q: 'ما هو أقدم لغة مكتوبة؟', a: 'السومرية' },
        { q: 'كم عدد أضلاع المثلث؟', a: 'ثلاثة' },
        { q: 'ما هو أكبر قارة في العالم؟', a: 'آسيا' },
        { q: 'من هو أول خليفة في الإسلام؟', a: 'أبو بكر الصديق' },
        { q: 'ما هي عاصمة اليابان؟', a: 'طوكيو' },
        { q: 'كم عدد سكان العالم تقريباً؟', a: '8 مليار' },
        { q: 'ما هو الغاز الذي نتنفسه؟', a: 'الأكسجين' },
        { q: 'ما هي سرعة الضوء؟', a: '300000 كم/ث' },
        { q: 'من هو مخترع المصباح الكهربائي؟', a: 'توماس إديسون' },
        { q: 'ما هي عاصمة أستراليا؟', a: 'كانبرا' },
        { q: 'كم عدد فصول السنة؟', a: 'أربعة' },
        { q: 'ما هي أكبر جزيرة في العالم؟', a: 'غرينلاند' },
        { q: 'من هو بطل فيلم "العراب"؟', a: 'مارلون براندو' },
        { q: 'ما هو الرقم القياسي لعدد القمم في جبال الهيمالايا؟', a: '14' },
        { q: 'ما هي أول دولة إسلامية؟', a: 'المدينة المنورة' },
        { q: 'ما هو أعلى جبل في العالم؟', a: 'إيفرست' },
        { q: 'كم عدد أسنان الإنسان البالغ؟', a: '32' }
    ],
    متوسط: [
        { q: 'من هو مؤسس الدولة العثمانية؟', a: 'عثمان الأول' },
        { q: 'في أي سنة انتهت الحرب العالمية الثانية؟', a: '1945' },
        { q: 'ما هي أطول سلسلة جبال في العالم؟', a: 'الأنديز' },
        { q: 'ما هو أكبر بحيرة في العالم؟', a: 'بحر قزوين' },
        { q: 'من هو مكتشف البنسلين؟', a: 'ألكسندر فليمنغ' },
        { q: 'ما هي عاصمة كندا؟', a: 'أوتاوا' },
        { q: 'كم عدد الدول في قارة أفريقيا؟', a: '54' },
        { q: 'من هو الفيلسوف اليوناني الذي قال "أنا لا أعرف شيئاً"؟', a: 'سقراط' },
        { q: 'ما هي أقرب كوكبة إلى الأرض؟', a: 'سنتورس' },
        { q: 'ما هو أعمق خندق في المحيط؟', a: 'خندق ماريانا' },
        { q: 'من هو الحائز على جائزة نوبل للسلام 2024؟', a: 'نيهون هيدانكيو' },
        { q: 'ما هي عاصمة روسيا؟', a: 'موسكو' },
        { q: 'كم عدد السعرات الحرارية في الكربوهيدرات؟', a: '4' },
        { q: 'من هو أوّل رئيس للولايات المتحدة؟', a: 'جورج واشنطن' },
        { q: 'ما هي أعلى قمة في أفريقيا؟', a: 'كيليمانجارو' },
        { q: 'ما هو أكبر صحراء في العالم؟', a: 'الصحراء الكبرى' },
        { q: 'من هو مؤلف "الأيام"؟', a: 'طه حسين' },
        { q: 'ما هي عملة اليورو؟', a: 'اليورو' },
        { q: 'كم عدد الأيام في السنة الميلادية؟', a: '365' },
        { q: 'ما هي العاصمة القديمة للبرازيل؟', a: 'ريو دي جانيرو' },
        { q: 'من هو مخترع التلفون؟', a: 'ألكسندر غراهام بيل' },
        { q: 'ما هو النبات الذي يستخدم في صناعة الشاي؟', a: 'الكاميليا' },
        { q: 'ما هي عاصمة الأرجنتين؟', a: 'بوينس آيرس' },
        { q: 'كم عدد ألوان الطيف؟', a: 'سبعة' },
        { q: 'من هو قائد معركة بدر؟', a: 'محمد ﷺ' },
        { q: 'ما هو أقدم مسجد في الإسلام؟', a: 'مسجد قباء' },
        { q: 'ما هي أكبر شركة في العالم؟', a: 'أبل' },
        { q: 'من هو صاحب نظرية النسبية؟', a: 'ألبرت أينشتاين' },
        { q: 'ما هي عاصمة الهند؟', a: 'نيودلهي' },
        { q: 'كم عدد محافظات مصر؟', a: '27' }
    ],
    صعب: [
        { q: 'ما هو العنصر الكيميائي الذي رمزه Fe؟', a: 'الحديد' },
        { q: 'من هو مكتشف قانون الجاذبية؟', a: 'إسحاق نيوتن' },
        { q: 'ما هي عاصمة كازاخستان؟', a: 'أستانا' },
        { q: 'كم عدد بروتوكولات الإنترنت الأساسية؟', a: '2' },
        { q: 'ما هي أطول كلمة في الإنجليزية؟', a: 'pneumonoultramicroscopicsilicovolcanoconiosis' },
        { q: 'من هو مؤسس علم الاجتماع؟', a: 'ابن خلدون' },
        { q: 'ما هي أكبر خلية في جسم الإنسان؟', a: 'البويضة' },
        { q: 'ما هي سرعة الصوت في الهواء؟', a: '343 م/ث' },
        { q: 'من هو مؤلف كتاب "الشفاء"؟', a: 'ابن سينا' },
        { q: 'ما هي عاصمة أذربيجان؟', a: 'باكو' },
        { q: 'كم عدد البيض الذي تضعه أنثى السلحفاة البحرية؟', a: '100' },
        { q: 'من هو مخترع الطباعة؟', a: 'يوهان غوتنبرغ' },
        { q: 'ما هو أقدم نوع من الزواحف؟', a: 'التواتارا' },
        { q: 'ما هي أكبر مجموعة عرقية في الصين؟', a: 'الهان' },
        { q: 'من هو الفيلسوف الذي أسس المدرسة الأفلاطونية؟', a: 'أفلاطون' },
        { q: 'ما هو أطول نفق في العالم؟', a: 'نفق غوتارد الأساسي' },
        { q: 'ما هي عاصمة جيبوتي؟', a: 'جيبوتي' },
        { q: 'كم عدد السعرات الحرارية في الغرام الواحد من الدهون؟', a: '9' },
        { q: 'من هو مخترع الإنترنت؟', a: 'فينت سيرف' },
        { q: 'ما هي أقدم حضارة معروفة؟', a: 'السومرية' },
        { q: 'ما هو الرقم الذي يرمز لـ 10 في نظام الأرقام الرومانية؟', a: 'X' },
        { q: 'من هو مؤسس علم النفس الحديث؟', a: 'سيغموند فرويد' },
        { q: 'ما هو أطول نهر في أوروبا؟', a: 'فولغا' },
        { q: 'ما هي أصغر دولة في أوروبا؟', a: 'الفاتيكان' },
        { q: 'من هو المكتشف الأوروبي لأمريكا؟', a: 'كريستوفر كولومبوس' },
        { q: 'ما هي عاصمة منغوليا؟', a: 'أولان باتور' },
        { q: 'كم عدد الجينات في جسم الإنسان؟', a: '20000' },
        { q: 'ما هو أكبر حيوان في المحيط؟', a: 'الحوت الأزرق' },
        { q: 'من هو مؤلف "الف ليلة وليلة"؟', a: 'غير معروف' },
        { q: 'ما هو أقدم خط في التاريخ؟', a: 'المسماري' }
    ]
};

// ========== الأمر الرئيسي ==========
module.exports = {
    command: ['سؤال', 'سوال'],
    description: '❓ أسئلة عامة متنوعة (الكل يشارك)',
    category: 'فعاليات',
    usage: '.سؤال [سهل|متوسط|صعب]',

    async execute(sock, msg) {
        try {
            const chatId = msg.key.remoteJid;
            const sender = msg.key.participant || msg.participant || msg.key.remoteJid;
            const senderNum = sender.split('@')[0];

            // ===== قراءة النص =====
            const fullText = msg.message?.conversation || 
                           msg.message?.extendedTextMessage?.text || '';
            const args = fullText.trim().split(/\s+/).slice(1);
            const inputLevel = (args[0] || 'سهل').trim();

            // ===== التحقق من المستوى =====
            const validLevels = ['سهل', 'متوسط', 'صعب'];
            if (!validLevels.includes(inputLevel)) {
                await sendMessage(sock, chatId, [
                    '❌ *مستوى غير صحيح*',
                    '',
                    '📌 المستويات المتاحة:',
                    '   🟢 سهل',
                    '   🟡 متوسط',
                    '   🔴 صعب',
                    '',
                    '📝 مثال: `.سؤال سهل`'
                ], msg);
                return;
            }

            // ===== اختيار سؤال عشوائي =====
            const levelQuestions = questions[inputLevel];
            if (!levelQuestions || levelQuestions.length === 0) {
                await sendMessage(sock, chatId, [
                    '❌ *لا توجد أسئلة في هذا المستوى*',
                    '',
                    '📌 اختر مستوى آخر'
                ], msg);
                return;
            }

            const selected = levelQuestions[Math.floor(Math.random() * levelQuestions.length)];
            const questionText = selected.q;
            const correctAnswer = selected.a;

            // ===== إرسال التحدي =====
            await sendMessage(sock, chatId, [
                `❓ *السؤال:*`,
                '',
                `📝 *${questionText}*`,
                '',
                `⏳ *الوقت:* ${timeMap[inputLevel] / 1000} ثواني`,
                `💰 *المكافأة:* +${rewardMap[inputLevel]} نقطة`,
                `⚠️ *العقاب:* -${penaltyMap[inputLevel]} نقطة (للمنشئ فقط)`,
                `👤 *المنشئ:* @${senderNum}`,
                '',
                '✍️ أرسل الإجابة الصحيحة',
                '✅ الجميع يمكنه المشاركة!'
            ], msg, [sender]);

            // ===== تحميل البيانات =====
            const points = loadJSON(pointsPath);
            const ranks = loadJSON(ranksPath);

            let ended = false;
            let timer = null;

            // ===== معالج الردود (الكل يشارك) =====
            const handler = async ({ messages }) => {
                for (const m of messages) {
                    if (ended) return;
                    if (m.key.remoteJid !== chatId) continue;
                    if (m.key.fromMe) continue;

                    const txt = m.message?.conversation || 
                               m.message?.extendedTextMessage?.text || '';
                    if (!txt) continue;

                    const answerer = m.key.participant || m.participant || m.key.remoteJid;

                    // ===== مقارنة الإجابة (باستخدام normalize) =====
                    if (isMatching(txt, correctAnswer)) {
                        ended = true;
                        clearTimeout(timer);
                        sock.ev.off('messages.upsert', handler);

                        // تحديث النقاط
                        points[answerer] = (points[answerer] || 0) + rewardMap[inputLevel];
                        ranks[answerer] = (ranks[answerer] || 0) + 1;
                        saveJSON(pointsPath, points);
                        saveJSON(ranksPath, ranks);

                        await sendMessage(sock, chatId, [
                            '🎉 *إجابة صحيحة!* 🎉',
                            '',
                            `🏆 *الفائز:* @${answerer.split('@')[0]}`,
                            `❓ *السؤال:* ${questionText}`,
                            `✅ *الإجابة:* ${correctAnswer}`,
                            `📊 *المستوى:* ${inputLevel}`,
                            `💰 *المكافأة:* +${rewardMap[inputLevel]} نقطة`,
                            `📈 *رصيدك:* ${formatNumber(points[answerer] || 0)} نقطة`,
                            `🏅 *الرتبة:* ${getLevel(points[answerer] || 0)}`,
                            `🎖️ *عدد الإجابات الصحيحة:* ${ranks[answerer] || 0}`
                        ], m, [answerer]);
                        return;
                    }
                }
            };

            sock.ev.on('messages.upsert', handler);

            // ===== المهلة =====
            timer = setTimeout(async () => {
                if (ended) return;
                ended = true;
                sock.ev.off('messages.upsert', handler);

                // خصم نقاط من المنشئ فقط (وليس من الكل)
                points[sender] = (points[sender] || 0) - penaltyMap[inputLevel];
                saveJSON(pointsPath, points);

                await sendMessage(sock, chatId, [
                    '⏰ *انتهى الوقت!*',
                    '',
                    `❓ *السؤال:* ${questionText}`,
                    `✅ *الإجابة الصحيحة:* ${correctAnswer}`,
                    `📊 *المستوى:* ${inputLevel}`,
                    `➖ *تم خصم:* ${penaltyMap[inputLevel]} نقطة من المنشئ`,
                    `📈 *رصيد المنشئ:* ${formatNumber(points[sender] || 0)} نقطة`,
                    `🏅 *رتبة المنشئ:* ${getLevel(points[sender] || 0)}`,
                    `👤 *المنشئ:* @${senderNum}`
                ], null, [sender]);

            }, timeMap[inputLevel]);

        } catch (error) {
            console.error('❌ خطأ في أمر سؤال:', error);
            await sendMessage(sock, msg.key.remoteJid, [
                '❌ *حدث خطأ*',
                '',
                `📝 ${error.message || 'خطأ غير معروف'}`,
                '',
                '📌 حاول مرة أخرى لاحقاً'
            ], msg);
        }
    }
};