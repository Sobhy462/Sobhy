// بيع.js - بيع المنتجات من المتجر (الأسلحة، الجنود، الإكسسوارات، الجرعات، الموارد، الذهب) مقابل نقاط - نسخة متوافقة مع نظام التخزين المنفصل
const fs = require('fs');
const path = require('path');

const pointsPath = path.join(__dirname, '../data/points.json');

// ===== مسارات التخزين المنفصل =====
const dataDir = path.join(__dirname, '../data/kingdom');
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

const MAIN_PATH = path.join(dataDir, 'main.json');
const SOLDIERS_PATH = path.join(dataDir, 'soldiers.json');
const WEAPONS_PATH = path.join(dataDir, 'weapons.json');
const ACCESSORIES_PATH = path.join(dataDir, 'accessories.json');
const POTIONS_PATH = path.join(dataDir, 'potions.json');
const SOULBOOK_PATH = path.join(dataDir, 'soulbook.json');
const COMPANION_PATH = path.join(dataDir, 'companion.json');
const ACTIVE_PATH = path.join(dataDir, 'active.json');
const RESOURCES_PATH = path.join(dataDir, 'resources.json');

// ===== التأكد من وجود جميع الملفات =====
const allPaths = [MAIN_PATH, SOLDIERS_PATH, WEAPONS_PATH, ACCESSORIES_PATH, POTIONS_PATH, SOULBOOK_PATH, COMPANION_PATH, ACTIVE_PATH, RESOURCES_PATH];
for (const p of allPaths) {
    if (!fs.existsSync(p)) fs.writeFileSync(p, JSON.stringify({}, null, 2));
}
if (!fs.existsSync(pointsPath)) fs.writeFileSync(pointsPath, JSON.stringify({}, null, 2));

function loadJSON(file) {
    try { return JSON.parse(fs.readFileSync(file)); } catch { return {}; }
}
function saveJSON(file, data) {
    try {
        if (fs.existsSync(file)) fs.writeFileSync(file + '.bak', fs.readFileSync(file));
        fs.writeFileSync(file, JSON.stringify(data, null, 2));
        return true;
    } catch (e) {
        console.error('❌ فشل حفظ الملف:', file, e.message);
        return false;
    }
}

// ========== دوال التخزين المنفصل ==========
function loadUserData(jid) {
    const main = loadJSON(MAIN_PATH)[jid] || {};
    const soldiers = loadJSON(SOLDIERS_PATH)[jid] || {};
    const weapons = loadJSON(WEAPONS_PATH)[jid] || {};
    const accessories = loadJSON(ACCESSORIES_PATH)[jid] || {};
    const potions = loadJSON(POTIONS_PATH)[jid] || {};
    const soulBook = loadJSON(SOULBOOK_PATH)[jid] || {};
    const companion = loadJSON(COMPANION_PATH)[jid] || null;
    const active = loadJSON(ACTIVE_PATH)[jid] || {};
    const resources = loadJSON(RESOURCES_PATH)[jid] || {};

    return {
        level: main.level || 1,
        prosperity: main.prosperity || 0,
        lands: main.lands || 0,
        gold: main.gold || 0,
        name: main.name || `مملكة @${jid.split('@')[0]}`,
        owner: main.owner || jid,
        nameChangesUsed: main.nameChangesUsed || 0,
        soldiers: soldiers,
        weapons: weapons,
        accessories: accessories,
        potions: potions,
        soulBook: soulBook,
        companion: companion,
        resources: resources,
        lastActive: active.lastActive || Date.now()
    };
}

function saveUserData(jid, data) {
    const main = loadJSON(MAIN_PATH);
    main[jid] = {
        level: data.level || 1,
        prosperity: data.prosperity || 0,
        lands: data.lands || 0,
        gold: data.gold || 0,
        name: data.name || `مملكة @${jid.split('@')[0]}`,
        owner: data.owner || jid,
        nameChangesUsed: data.nameChangesUsed || 0
    };
    saveJSON(MAIN_PATH, main);

    const soldiers = loadJSON(SOLDIERS_PATH);
    soldiers[jid] = data.soldiers || {};
    saveJSON(SOLDIERS_PATH, soldiers);

    const weapons = loadJSON(WEAPONS_PATH);
    weapons[jid] = data.weapons || {};
    saveJSON(WEAPONS_PATH, weapons);

    const accessories = loadJSON(ACCESSORIES_PATH);
    accessories[jid] = data.accessories || {};
    saveJSON(ACCESSORIES_PATH, accessories);

    const potions = loadJSON(POTIONS_PATH);
    potions[jid] = data.potions || {};
    saveJSON(POTIONS_PATH, potions);

    const soulBook = loadJSON(SOULBOOK_PATH);
    soulBook[jid] = data.soulBook || { pages: 0, spirits: [] };
    saveJSON(SOULBOOK_PATH, soulBook);

    const companion = loadJSON(COMPANION_PATH);
    companion[jid] = data.companion || null;
    saveJSON(COMPANION_PATH, companion);

    const active = loadJSON(ACTIVE_PATH);
    active[jid] = {
        lastActive: data.lastActive || Date.now()
    };
    saveJSON(ACTIVE_PATH, active);

    const resources = loadJSON(RESOURCES_PATH);
    resources[jid] = data.resources || {};
    saveJSON(RESOURCES_PATH, resources);
}

function userExists(jid) {
    const main = loadJSON(MAIN_PATH);
    return !!main[jid];
}

// ========== قائمة المنتجات الكاملة (للبحث والأسعار) ==========
// نفس قائمة fullProductsList من شراء.js، لكننا سنضيف إليها الموارد والذهب لأنها غير موجودة هناك
// سنضيف أيضاً أسعار البيع في كائن منفصل للبيع
const fullProductsList = [
    // أسلحة
    { id: 1, name: 'سيف حديدي', type: 'weapon', key: 'ironSword', cost: 150, sellPrice: 75 },
    { id: 2, name: 'درع ذهبي', type: 'weapon', key: 'goldenShield', cost: 250, sellPrice: 125 },
    { id: 3, name: 'قوس أسطوري', type: 'weapon', key: 'legendaryBow', cost: 300, sellPrice: 150 },
    { id: 4, name: 'سيف البرق', type: 'weapon', key: 'lightningSword', cost: 400, sellPrice: 200 },
    { id: 5, name: 'مطرقة العمالقة', type: 'weapon', key: 'giantHammer', cost: 550, sellPrice: 275 },
    { id: 6, name: 'قوس الموت', type: 'weapon', key: 'deathBow', cost: 700, sellPrice: 350 },
    { id: 7, name: 'فأس الدمار', type: 'weapon', key: 'destructionAxe', cost: 900, sellPrice: 450 },
    { id: 8, name: 'سيف الأبطال', type: 'weapon', key: 'heroSword', cost: 500, sellPrice: 250 },
    { id: 9, name: 'قوس الزمن', type: 'weapon', key: 'timeBow', cost: 850, sellPrice: 425 },
    { id: 10, name: 'نصل الأبدية', type: 'weapon', key: 'eternalBlade', cost: 1500, sellPrice: 750 },
    { id: 11, name: 'درع النار', type: 'weapon', key: 'fireShield', cost: 450, sellPrice: 225 },
    { id: 12, name: 'درع الملك', type: 'weapon', key: 'godShield', cost: 800, sellPrice: 400 },
    // جنود
    { id: 13, name: 'جندي عادي', type: 'soldier', key: 'normal', cost: 30, sellPrice: 15 },
    { id: 14, name: 'فارس', type: 'soldier', key: 'knight', cost: 80, sellPrice: 40 },
    { id: 15, name: 'رامٍ', type: 'soldier', key: 'archer', cost: 50, sellPrice: 25 },
    { id: 16, name: 'حارس النخبة', type: 'soldier', key: 'eliteGuard', cost: 150, sellPrice: 75 },
    { id: 17, name: 'منشق التنين', type: 'soldier', key: 'dragonSpearman', cost: 300, sellPrice: 150 },
    { id: 18, name: 'قائد أسطوري', type: 'soldier', key: 'legendaryCommander', cost: 600, sellPrice: 300 },
    // إكسسوارات
    { id: 34, name: 'خاتم القوة', type: 'accessory', key: 'powerRing', cost: 200, sellPrice: 100 },
    { id: 35, name: 'خاتم الحماية', type: 'accessory', key: 'protectionRing', cost: 200, sellPrice: 100 },
    { id: 36, name: 'تاج الملوك', type: 'accessory', key: 'kingsCrown', cost: 900, sellPrice: 450 },
    { id: 37, name: 'قناع الظل', type: 'accessory', key: 'shadowMask', cost: 400, sellPrice: 200 },
    { id: 38, name: 'قناع البطل', type: 'accessory', key: 'heroMask', cost: 700, sellPrice: 350 },
    // جرعات
    { id: 39, name: 'جرعة شفاء صغيرة', type: 'potion', key: 'smallHeal', cost: 50, sellPrice: 25 },
    { id: 40, name: 'جرعة شفاء كبيرة', type: 'potion', key: 'largeHeal', cost: 150, sellPrice: 75 },
    { id: 41, name: 'جرعة الطاقة', type: 'potion', key: 'energyPotion', cost: 200, sellPrice: 100 },
    { id: 42, name: 'جرعة شفاء مصنعة', type: 'potion', key: 'craftedHeal', cost: 300, sellPrice: 150 },
    // موارد (مضافة يدوياً)
    { id: 43, name: 'خشب', type: 'resource', key: 'wood', cost: null, sellPrice: 1 },
    { id: 44, name: 'حجر', type: 'resource', key: 'stone', cost: null, sellPrice: 1.5 },
    { id: 45, name: 'حديد', type: 'resource', key: 'iron', cost: null, sellPrice: 2 },
    // ذهب (مضاف يدوياً)
    { id: 46, name: 'ذهب', type: 'gold', key: 'gold', cost: null, sellPrice: 0.5 }
];

// ========== دالة الإرسال الفاخرة ==========
async function sendFancy(sock, chatId, lines, quoted = null, mentions = []) {
    let msg = `💰 بــيــع 💰\n`;
    msg += `━━━━━━━━━━━━━━━━━━━━\n`;
    for (const line of lines) {
        msg += `${line}\n`;
    }
    msg += `━━━━━━━━━━━━━━━━━━━━\n`;
    msg += `𝘽𝙔┇𝑴𝑨𝑲𝑰𝑴𝑨`;
    await sock.sendMessage(chatId, { text: msg, mentions }, { quoted: quoted });
}

// ========== دالة البحث عن المنتج ==========
function findProduct(identifier) {
    const id = parseInt(identifier);
    if (!isNaN(id) && id > 0) {
        const product = fullProductsList.find(p => p.id === id);
        if (product) return product;
    }
    
    const searchLower = identifier.toLowerCase().trim();
    let product = fullProductsList.find(p => p.name.toLowerCase() === searchLower);
    if (product) return product;
    
    product = fullProductsList.find(p => p.name.toLowerCase().includes(searchLower));
    if (product) return product;
    
    const keywords = searchLower.split(' ');
    let bestMatch = null;
    let bestScore = 0;
    for (const p of fullProductsList) {
        const nameLower = p.name.toLowerCase();
        let score = 0;
        for (const kw of keywords) {
            if (nameLower.includes(kw)) score++;
        }
        if (score > bestScore) {
            bestScore = score;
            bestMatch = p;
        }
    }
    return bestMatch;
}

// ========== الأمر الرئيسي ==========
module.exports = {
    command: 'بيع',
    description: '💰 بيع منتج من ممتلكاتك (أسلحة، جنود، إكسسوارات، جرعات، موارد، ذهب) مقابل نقاط',
    category: 'مملكة',
    async execute(sock, msg) {
        try {
            const chatId = msg.key.remoteJid;
            const sender = msg.key.participant || msg.participant || msg.key.remoteJid;

            const fullText = msg.message?.conversation || msg.message?.extendedTextMessage?.text || '';
            const args = fullText.trim().split(/\s+/);

            if (args.length < 2) {
                await sendFancy(sock, chatId, [
                    `⚠️ @${sender.split('@')[0]}`,
                    `📌 استخدم: .بيع [رقم المنتج أو اسمه] [العدد]`,
                    `📝 مثال: .بيع 1 3`,
                    `📝 مثال: .بيع درع ذهبي 2`,
                    `📝 مثال: .بيع خشب 50`
                ], msg, [sender]);
                return;
            }

            let quantity = 1;
            let productIdentifier = '';
            
            const lastArg = args[args.length - 1];
            const lastIsNumber = !isNaN(parseInt(lastArg)) && parseInt(lastArg) > 0;
            
            if (lastIsNumber) {
                quantity = parseInt(lastArg);
                productIdentifier = args.slice(1, -1).join(' ');
                if (!productIdentifier) productIdentifier = args[1];
            } else {
                productIdentifier = args.slice(1).join(' ');
            }

            const product = findProduct(productIdentifier);
            
            if (!product) {
                const availableProducts = fullProductsList
                    .filter(p => p.sellPrice !== undefined && p.sellPrice !== null)
                    .slice(0, 15)
                    .map(p => `  ${p.id}. ${p.name} (سعر البيع: ${p.sellPrice} نقطة للوحدة)`)
                    .join('\n');
                
                await sendFancy(sock, chatId, [
                    `❌ لا يوجد منتج بالاسم "${productIdentifier}".`,
                    `📌 المنتجات القابلة للبيع:`,
                    availableProducts,
                    `📌 استخدم .بيع لعرض القائمة الكاملة.`
                ], msg, [sender]);
                return;
            }

            if (!product.sellPrice || product.sellPrice <= 0) {
                await sendFancy(sock, chatId, [
                    `❌ لا يمكن بيع ${product.name}.`,
                    `📌 هذا المنتج غير قابل للبيع.`
                ], msg, [sender]);
                return;
            }

            if (quantity > 100) {
                await sendFancy(sock, chatId, [
                    `❌ لا يمكن بيع أكثر من 100 قطعة مرة واحدة.`
                ], msg, [sender]);
                return;
            }

            // ===== التحقق من وجود مملكة =====
            if (!userExists(sender)) {
                await sendFancy(sock, chatId, [
                    `❌ @${sender.split('@')[0]}، ليس لديك مملكة.`,
                    `📌 استخدم .لاعب جديد لتأسيس مملكتك.`
                ], msg, [sender]);
                return;
            }

            // ===== تحميل بيانات المستخدم =====
            const points = loadJSON(pointsPath);
            let user = loadUserData(sender);
            let userPoints = points[sender] || 0;

            // ===== تحديد الكمية المتاحة =====
            let available = 0;
            let category = product.type;

            if (category === 'weapon') {
                available = user.weapons[product.key] || 0;
            } else if (category === 'soldier') {
                available = user.soldiers[product.key] || 0;
            } else if (category === 'accessory') {
                available = user.accessories[product.key] || 0;
            } else if (category === 'potion') {
                available = user.potions[product.key] || 0;
            } else if (category === 'resource') {
                available = user.resources[product.key] || 0;
            } else if (category === 'gold') {
                available = user.gold || 0;
            } else {
                await sendFancy(sock, chatId, [
                    `❌ نوع المنتج غير قابل للبيع.`
                ], msg, [sender]);
                return;
            }

            if (available < quantity) {
                await sendFancy(sock, chatId, [
                    `❌ لا تملك ${quantity} من ${product.name}.`,
                    `📌 لديك فقط ${available} ${product.name}.`
                ], msg, [sender]);
                return;
            }

            // ===== حساب قيمة البيع =====
            const totalEarn = Math.floor(quantity * product.sellPrice);

            // ===== تطبيق البيع =====
            if (category === 'weapon') {
                user.weapons[product.key] = (user.weapons[product.key] || 0) - quantity;
            } else if (category === 'soldier') {
                user.soldiers[product.key] = (user.soldiers[product.key] || 0) - quantity;
            } else if (category === 'accessory') {
                user.accessories[product.key] = (user.accessories[product.key] || 0) - quantity;
            } else if (category === 'potion') {
                user.potions[product.key] = (user.potions[product.key] || 0) - quantity;
            } else if (category === 'resource') {
                user.resources[product.key] = (user.resources[product.key] || 0) - quantity;
            } else if (category === 'gold') {
                user.gold = (user.gold || 0) - quantity;
            }

            // ===== إضافة النقاط =====
            points[sender] = userPoints + totalEarn;
            user.lastActive = Date.now();

            // ===== حفظ التغييرات =====
            saveJSON(pointsPath, points);
            saveUserData(sender, user);

            const lines = [
                `🎉 @${sender.split('@')[0]}`,
                `✅ تم بيع *${quantity} × ${product.name}* بنجاح!`,
                ``,
                `💰 ربحت ${totalEarn} نقطة`,
                `💰 رصيدك الجديد: ${points[sender]} نقطة`,
                ``,
                `📌 استخدم .مخزن لعرض مقتنياتك`
            ];

            await sendFancy(sock, chatId, lines, msg, [sender]);

        } catch (error) {
            console.error('✗ خطأ في أمر بيع:', error);
            await sendFancy(sock, msg.key.remoteJid, [
                `❌ حدث خطأ أثناء عملية البيع.`,
                `📌 حاول مرة أخرى لاحقاً.`
            ], msg);
        }
    }
};