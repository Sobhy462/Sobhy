// استعادة.js - استعادة النسخ الاحتياطية لجميع ملفات المملكة (للمطورين فقط) - متوافق مع نظام التخزين المنفصل
const fs = require('fs');
const path = require('path');
const hay = require('../haykala/developer');

// ===== مسارات التخزين المنفصل =====
const dataDir = path.join(__dirname, '../data/kingdom');
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

// ===== قائمة جميع ملفات التخزين المنفصل =====
const FILES = {
    main: { file: 'main.json', desc: 'البيانات الرئيسية (المستوى، الاسم، الذهب، إلخ)' },
    resources: { file: 'resources.json', desc: 'الموارد (خشب، حجر، حديد)' },
    buildings: { file: 'buildings.json', desc: 'المباني ومستوياتها' },
    soldiers: { file: 'soldiers.json', desc: 'الجنود' },
    weapons: { file: 'weapons.json', desc: 'الأسلحة والدروع' },
    accessories: { file: 'accessories.json', desc: 'الإكسسوارات' },
    potions: { file: 'potions.json', desc: 'الجرعات' },
    spells: { file: 'spells.json', desc: 'التعاويذ المستخدمة' },
    stats: { file: 'stats.json', desc: 'إحصائيات المعارك' },
    active: { file: 'active.json', desc: 'البيانات النشطة (كولداون، استراحات، كهوف، إلخ)' },
    soulbook: { file: 'soulbook.json', desc: 'كتاب الروح' },
    companion: { file: 'companion.json', desc: 'الرفيق' },
    explored_caves: { file: 'explored_caves.json', desc: 'الكهوف المستكشفة' }
};

// ===== مسارات عامة أخرى (إذا كانت موجودة) =====
const EXTRA_FILES = {
    points: { file: path.join(__dirname, '../data/points.json'), desc: 'نقاط اللاعبين' },
    bank: { file: path.join(__dirname, '../data/bank.json'), desc: 'البنك (الودائع)' },
    loans: { file: path.join(__dirname, '../data/loans.json'), desc: 'القروض' },
    teams: { file: path.join(__dirname, '../data/teams.json'), desc: 'الفرق' },
    treaties: { file: path.join(__dirname, '../data/treaties.json'), desc: 'المعاهدات' },
    quests: { file: path.join(__dirname, '../data/quests.json'), desc: 'المهام' },
    stealActive: { file: path.join(__dirname, '../data/stealActive.json'), desc: 'بيانات السرقات النشطة' },
    stealLogs: { file: path.join(__dirname, '../data/stealLogs.json'), desc: 'سجلات السرقات' },
    hidden: { file: path.join(__dirname, '../data/hidden-points.json'), desc: 'المستخدمين المخفيين' }
};

// ========== دوال مساعدة ==========
function loadJSON(file) {
    try { return JSON.parse(fs.readFileSync(file)); }
    catch { return {}; }
}

function saveJSON(file, data) {
    try {
        fs.writeFileSync(file, JSON.stringify(data, null, 2));
        return true;
    } catch (e) {
        console.error('❌ فشل حفظ الملف:', file, e.message);
        return false;
    }
}

function getBackupPath(file) {
    return file + '.bak';
}

function backupExists(file) {
    return fs.existsSync(getBackupPath(file));
}

// ========== دالة الإرسال ==========
async function sendMessage(sock, chatId, lines, quoted = null, mentions = []) {
    if (!Array.isArray(lines)) lines = [lines];
    let msg = `🔄 اسـتـعـادة الـمـمـالـك 🔄\n`;
    msg += `━━━━━━━━━━━━━━━━━━━━\n`;
    for (const line of lines) {
        if (line && line.trim()) {
            msg += `${line}\n`;
        }
    }
    msg += `━━━━━━━━━━━━━━━━━━━━\n`;
    msg += `𝘽𝙔┇𝑴𝑨𝑲𝑰𝑴𝑨`;
    await sock.sendMessage(chatId, { text: msg, mentions }, { quoted: quoted });
}

// ========== الأمر الرئيسي ==========
module.exports = {
    command: ['استعادة', 'استرجاع', 'رجع'],
    description: '🔄 استعادة جميع النسخ الاحتياطية للمملكة (للمطورين فقط)',
    category: 'نظام',
    usage: '.استعادة',
    example: '.استعادة',

    async execute(sock, msg) {
        try {
            const chatId = msg.key.remoteJid;
            const sender = msg.key.participant || msg.key.remoteJid;

            // ===== التحقق من الصلاحيات =====
            const senderLid = hay.toLid(sender);
            if (!(hay.isFounder(senderLid) || hay.isOwnerbot(senderLid) || hay.isDeveloper(senderLid))) {
                return await sendMessage(sock, chatId, ['🚫 هذا الأمر مخصص للمطورين فقط.'], msg, [sender]);
            }

            // ===== قائمة الملفات التي لها نسخ احتياطية =====
            const availableBackups = [];
            const allFiles = { ...FILES, ...EXTRA_FILES };

            for (const [key, info] of Object.entries(allFiles)) {
                const filePath = typeof info === 'string' ? info : info.file;
                const fullPath = path.isAbsolute(filePath) ? filePath : path.join(dataDir, filePath);
                if (fs.existsSync(getBackupPath(fullPath))) {
                    const stat = fs.statSync(getBackupPath(fullPath));
                    availableBackups.push({
                        key,
                        name: info.desc || key,
                        path: fullPath,
                        backupPath: getBackupPath(fullPath),
                        size: Math.round(stat.size / 1024),
                        mtime: stat.mtime
                    });
                }
            }

            if (availableBackups.length === 0) {
                await sendMessage(sock, chatId, [
                    '❌ لا توجد نسخ احتياطية لأي ملف من ملفات المملكة.',
                    '',
                    '📌 تأكد من وجود ملفات `.bak` في مجلد `data/kingdom`.',
                    '📌 أيضاً تأكد من وجود ملفات `.bak` في مجلد `data` للملفات العامة.'
                ], msg, [sender]);
                return;
            }

            // ===== عرض معلومات عن النسخ الاحتياطية الموجودة =====
            const totalSize = availableBackups.reduce((sum, b) => sum + b.size, 0);
            const totalFiles = availableBackups.length;

            let backupList = '';
            for (const b of availableBackups) {
                const date = b.mtime.toLocaleString();
                backupList += `   • ${b.name}: ${b.size} كيلوبايت (${date})\n`;
            }

            await sendMessage(sock, chatId, [
                '📊 *النسخ الاحتياطية المتوفرة*',
                '',
                `📦 عدد الملفات: ${totalFiles}`,
                `📦 الحجم الإجمالي: ${totalSize} كيلوبايت`,
                '',
                '📋 *القائمة:*',
                backupList || '   (لا توجد تفاصيل)',
                '',
                '⚠️ سيتم استعادة جميع هذه الملفات من النسخ الاحتياطية.',
                '📌 هل أنت متأكد؟ اكتب `تأكيد` خلال 30 ثانية.'
            ], msg, [sender]);

            // ===== انتظار التأكيد =====
            const confirmHandler = async ({ messages }) => {
                for (const m of messages) {
                    const from = m.key.participant || m.participant || m.key.remoteJid;
                    if (from !== sender) continue;
                    const txt = m.message?.conversation || m.message?.extendedTextMessage?.text || '';
                    if (txt.trim().toLowerCase() === 'تأكيد') {
                        try {
                            let restoredCount = 0;
                            let failed = [];

                            // ===== استعادة كل ملف =====
                            for (const b of availableBackups) {
                                try {
                                    // عمل نسخة من الملف الحالي (احتياطي إضافي)
                                    if (fs.existsSync(b.path)) {
                                        fs.renameSync(b.path, b.path + '.old');
                                    }
                                    // استعادة النسخة الاحتياطية
                                    fs.copyFileSync(b.backupPath, b.path);
                                    restoredCount++;
                                } catch (e) {
                                    failed.push(`${b.name}: ${e.message}`);
                                }
                            }

                            // ===== عرض النتيجة =====
                            let lines = [
                                `✅ تم استعادة الملفات بنجاح!`,
                                '',
                                `📊 عدد الملفات المستعادة: ${restoredCount}/${availableBackups.length}`
                            ];

                            if (failed.length > 0) {
                                lines.push('', '⚠️ *فشل استعادة بعض الملفات:*');
                                for (const err of failed) {
                                    lines.push(`   ❌ ${err}`);
                                }
                            }

                            lines.push('', '📌 أعد تشغيل البوت لتطبيق التغييرات بالكامل.');

                            await sendMessage(sock, chatId, lines, m, [sender]);
                            sock.ev.off('messages.upsert', confirmHandler);
                            return;
                        } catch (e) {
                            await sendMessage(sock, chatId, [
                                `❌ فشل الاستعادة: ${e.message}`
                            ], m, [sender]);
                            sock.ev.off('messages.upsert', confirmHandler);
                            return;
                        }
                    } else {
                        await sendMessage(sock, chatId, ['❌ تم إلغاء عملية الاستعادة.'], m, [sender]);
                        sock.ev.off('messages.upsert', confirmHandler);
                        return;
                    }
                }
            };

            sock.ev.on('messages.upsert', confirmHandler);
            setTimeout(() => {
                sock.ev.off('messages.upsert', confirmHandler);
            }, 30000);

        } catch (error) {
            console.error('✗ خطأ في أمر استعادة:', error);
            await sendMessage(sock, msg.key.remoteJid, [
                '❌ حدث خطأ أثناء تنفيذ الأمر.',
                '📌 حاول مرة أخرى لاحقاً.'
            ], msg);
        }
    }
};