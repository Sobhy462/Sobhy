const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');
const https = require('https');
const { promisify } = require('util');
const execPromise = promisify(require('child_process').exec);

const ytdlp = 'yt-dlp';
const commandPrice = 50;

const pointsFile = path.join(__dirname, '../data/points.json');
const tempDir = path.join(__dirname, '../temp');
const cookiesFile = path.join(__dirname, '../data/cookies.txt'); // ملف كوكيز اختياري

// قائمة المواقع المدعومة
const supportedSites = [
  'tiktok.com', 'vm.tiktok', 'vt.tiktok',
  'youtube.com', 'youtu.be',
  'instagram.com', 'instagr.am',
  'facebook.com', 'fb.watch',
  'twitter.com', 'x.com',
  'reddit.com',
  'vimeo.com',
  'dailymotion.com',
  'twitch.tv'
];

// ========== دوال النقاط ==========
function loadPoints() {
  if (!fs.existsSync(pointsFile)) {
    fs.writeFileSync(pointsFile, JSON.stringify({}, null, 2));
  }
  return JSON.parse(fs.readFileSync(pointsFile));
}

function savePoints(data) {
  fs.writeFileSync(pointsFile, JSON.stringify(data, null, 2));
}

// ========== دوال مساعدة ==========
function getSiteName(url) {
  if (url.includes('tiktok')) return '📱 TikTok';
  if (url.includes('youtube') || url.includes('youtu.be')) return '▶️ YouTube';
  if (url.includes('instagram')) return '📸 Instagram';
  if (url.includes('facebook') || url.includes('fb.watch')) return '👥 Facebook';
  if (url.includes('twitter') || url.includes('x.com')) return '🐦 Twitter/X';
  if (url.includes('reddit')) return '🤖 Reddit';
  if (url.includes('vimeo')) return '🎬 Vimeo';
  if (url.includes('dailymotion')) return '🎞️ Dailymotion';
  if (url.includes('twitch')) return '🎮 Twitch';
  return '🌐 رابط آخر';
}

function formatDuration(seconds) {
  if (!seconds) return 'غير معروف';
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const secs = seconds % 60;
  if (hours > 0) return `${hours}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  return `${minutes}:${secs.toString().padStart(2, '0')}`;
}

async function resolveShortUrl(link, maxRedirects = 3) {
  return new Promise((resolve) => {
    let redirects = 0;
    const request = (url) => {
      https.get(url, {
        headers: { 'User-Agent': 'Mozilla/5.0' },
        timeout: 5000
      }, (res) => {
        if ((res.statusCode === 301 || res.statusCode === 302) && redirects < maxRedirects) {
          redirects++;
          request(res.headers.location);
        } else {
          resolve(url);
        }
      }).on('error', () => resolve(link));
    };
    request(link);
  });
}

// التحقق من وجود ملف كوكيز صالح
function getCookieArgs() {
  // إذا كان ملف الكوكيز موجوداً وصالحاً، استخدمه
  if (fs.existsSync(cookiesFile) && fs.statSync(cookiesFile).size > 100) {
    return [`--cookies`, cookiesFile];
  }
  // وإلا حاول استخدام كوكيز من متصفح Chrome (يفضل أن يكون مفتوحاً ومسجلاً)
  return [`--cookies-from-browser`, `chrome`];
}

// ========== دوال التحميل ==========

// التحميل عبر yt-dlp مع دعم الكوكيز
function downloadWithYtdlp(url, outputPath, isAudio = false) {
  return new Promise((resolve, reject) => {
    // بناء الأوامر
    let args = [
      '--no-playlist',
      '--no-check-certificates',
      '--retries', '5',
      '--fragment-retries', '5',
      '--socket-timeout', '30',
      '--user-agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
      '--no-warnings',
      '--quiet',
      '-o', outputPath
    ];

    // إضافة الكوكيز إذا كان الموقع يحتاجها (إنستغرام، فيسبوك)
    if (url.includes('instagram.com') || url.includes('instagr.am') ||
        url.includes('facebook.com') || url.includes('fb.watch')) {
      const cookieOpts = getCookieArgs();
      args = args.concat(cookieOpts);
      console.log('✅ استخدام كوكيز للتحميل');
    }

    // تحديد صيغة التحميل
    if (isAudio) {
      args.push('-f', 'bestaudio');
      args.push('--extract-audio');
      args.push('--audio-format', 'mp3');
      args.push('--audio-quality', '0');
    } else {
      args.push('-f', 'bestvideo+bestaudio/best');
    }

    args.push(url);

    const proc = spawn(ytdlp, args, { timeout: isAudio ? 120000 : 180000 });
    let stderr = '';
    proc.stderr.on('data', (data) => { stderr += data.toString(); });
    proc.on('close', (code) => {
      if (code === 0 && fs.existsSync(outputPath) && fs.statSync(outputPath).size > 0) {
        resolve(outputPath);
      } else {
        const errorMsg = stderr || `yt-dlp exit code ${code}`;
        // إذا كان الخطأ بسبب تسجيل الدخول، نرمي رسالة واضحة
        if (errorMsg.includes('cookies') || errorMsg.includes('logged-in') || errorMsg.includes('login') || errorMsg.includes('empty media')) {
          reject(new Error('يتطلب هذا المنشور تسجيل الدخول. تأكد من أن متصفح Chrome مفتوح ومسجل، أو استخدم ملف كوكيز صالح.'));
        } else {
          reject(new Error(errorMsg));
        }
      }
    });
    proc.on('error', reject);
  });
}

// تحميل إنستغرام عبر واجهة برمجة تطبيقات (API) خارجية (بديل)
async function downloadInstagramViaAPI(url, outputPath) {
  return new Promise((resolve, reject) => {
    const apiUrl = `https://igram.world/api/instagram/post?url=${encodeURIComponent(url)}`;
    const request = https.get(apiUrl, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'Accept': 'application/json'
      }
    }, (response) => {
      let data = '';
      response.on('data', chunk => data += chunk);
      response.on('end', () => {
        try {
          const json = JSON.parse(data);
          if (json && json.video_url) {
            const fileStream = fs.createWriteStream(outputPath);
            https.get(json.video_url, (fileRes) => {
              if (fileRes.statusCode === 200) {
                fileRes.pipe(fileStream);
                fileStream.on('finish', () => resolve(outputPath));
                fileStream.on('error', reject);
              } else {
                reject(new Error(`فشل تحميل الفيديو من API: ${fileRes.statusCode}`));
              }
            }).on('error', reject);
          } else {
            reject(new Error('لم يتم العثور على رابط الفيديو من API'));
          }
        } catch (e) {
          reject(new Error(`خطأ في معالجة استجابة API: ${e.message}`));
        }
      });
    }).on('error', reject);
    request.end();
  });
}

// تحميل فيسبوك عبر واجهة برمجة تطبيقات (API) خارجية (بديل)
async function downloadFacebookViaAPI(url, outputPath) {
  return new Promise((resolve, reject) => {
    const apiUrl = `https://api.fbdown.net/api/download?url=${encodeURIComponent(url)}`;
    const request = https.get(apiUrl, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'Accept': 'application/json'
      }
    }, (response) => {
      let data = '';
      response.on('data', chunk => data += chunk);
      response.on('end', () => {
        try {
          const json = JSON.parse(data);
          const videoUrl = json.video_url || json.download_link || (json.data && json.data.video_url);
          if (videoUrl) {
            const fileStream = fs.createWriteStream(outputPath);
            https.get(videoUrl, (fileRes) => {
              if (fileRes.statusCode === 200) {
                fileRes.pipe(fileStream);
                fileStream.on('finish', () => resolve(outputPath));
                fileStream.on('error', reject);
              } else {
                reject(new Error(`فشل تحميل الفيديو من fbdown: ${fileRes.statusCode}`));
              }
            }).on('error', reject);
          } else {
            reject(new Error('لم يتم العثور على رابط الفيديو من fbdown'));
          }
        } catch (e) {
          reject(new Error(`خطأ في معالجة استجابة fbdown: ${e.message}`));
        }
      });
    }).on('error', reject);
    request.end();
  });
}

// تحميل عبر Cobalt API (بديل سريع)
async function downloadWithCobalt(url, outputPath, isAudio = false) {
  return new Promise((resolve, reject) => {
    const requestBody = {
      url: url,
      vQuality: '1080',
      vCodec: 'h264',
      isAudioOnly: isAudio,
      filenamePattern: 'basic'
    };
    const options = {
      hostname: 'api.cobalt.tools',
      port: 443,
      path: '/api/json',
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'User-Agent': 'Mozilla/5.0'
      }
    };
    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          if (!data.trim().startsWith('{')) {
            throw new Error('استجابة غير متوقعة من Cobalt');
          }
          const response = JSON.parse(data);
          if (response.status === 'success' && response.url) {
            const fileStream = fs.createWriteStream(outputPath);
            https.get(response.url, (fileRes) => {
              if (fileRes.statusCode === 200) {
                fileRes.pipe(fileStream);
                fileStream.on('finish', () => resolve(outputPath));
                fileStream.on('error', reject);
              } else {
                reject(new Error(`فشل تحميل من Cobalt: ${fileRes.statusCode}`));
              }
            }).on('error', reject);
          } else {
            reject(new Error(response.text || 'Cobalt API error'));
          }
        } catch (e) {
          reject(new Error(`Cobalt فشل: ${e.message}`));
        }
      });
    });
    req.on('error', reject);
    req.write(JSON.stringify(requestBody));
    req.end();
  });
}

// تحميل تيك توك عبر API خاصة (بديل)
async function downloadWithTikAPI(url, outputPath) {
  return new Promise((resolve, reject) => {
    const apiUrl = `https://api.tikmate.app/api/download?url=${encodeURIComponent(url)}`;
    const request = https.get(apiUrl, (response) => {
      let data = '';
      response.on('data', chunk => data += chunk);
      response.on('end', () => {
        try {
          const json = JSON.parse(data);
          if (json && json.url) {
            const file = fs.createWriteStream(outputPath);
            https.get(json.url, (fileRes) => {
              fileRes.pipe(file);
              file.on('finish', () => resolve(outputPath));
              file.on('error', reject);
            }).on('error', reject);
          } else {
            reject(new Error('لم يتم العثور على رابط التحميل من TikAPI'));
          }
        } catch (e) {
          reject(e);
        }
      });
    }).on('error', reject);
    request.end();
  });
}

// ========== الوظيفة الرئيسية للتحميل (ذكية) ==========
async function downloadMedia(url, outputPath, isAudio = false) {
  // 1. المحاولة الأولى: yt-dlp مع كوكيز (الأفضل للمواقع المحمية)
  try {
    console.log('🔄 محاولة التحميل عبر yt-dlp مع كوكيز...');
    await downloadWithYtdlp(url, outputPath, isAudio);
    console.log('✅ تم التحميل عبر yt-dlp');
    return;
  } catch (ytError) {
    console.warn('⚠️ yt-dlp فشل:', ytError.message);
    // إذا كان الخطأ يتطلب تسجيل دخول، ننتقل للبدائل
  }

  // 2. حسب الموقع، جرب واجهات برمجة تطبيقات متخصصة
  if (url.includes('instagram.com') || url.includes('instagr.am')) {
    try {
      console.log('🔄 محاولة التحميل عبر Instagram API...');
      await downloadInstagramViaAPI(url, outputPath);
      console.log('✅ تم التحميل عبر Instagram API');
      return;
    } catch (instaErr) {
      console.warn('⚠️ Instagram API فشل:', instaErr.message);
    }
  }

  if (url.includes('facebook.com') || url.includes('fb.watch')) {
    try {
      console.log('🔄 محاولة التحميل عبر Facebook API...');
      await downloadFacebookViaAPI(url, outputPath);
      console.log('✅ تم التحميل عبر Facebook API');
      return;
    } catch (fbErr) {
      console.warn('⚠️ Facebook API فشل:', fbErr.message);
    }
  }

  // 3. جرب Cobalt كحل ثانوي (يدعم عدة مواقع)
  try {
    console.log('🔄 محاولة التحميل عبر Cobalt API...');
    await downloadWithCobalt(url, outputPath, isAudio);
    console.log('✅ تم التحميل عبر Cobalt');
    return;
  } catch (cobaltErr) {
    console.warn('⚠️ Cobalt فشل:', cobaltErr.message);
  }

  // 4. إذا كان تيك توك ولم ينجح السابق، جرب TikAPI
  if (url.includes('tiktok.com') && !isAudio) {
    try {
      console.log('🔄 محاولة التحميل عبر TikAPI...');
      await downloadWithTikAPI(url, outputPath);
      console.log('✅ تم التحميل عبر TikAPI');
      return;
    } catch (tikErr) {
      console.warn('⚠️ TikAPI فشل:', tikErr.message);
    }
  }

  // إذا وصلنا هنا، كل المحاولات فشلت
  throw new Error(`❌ فشل تحميل المحتوى من ${getSiteName(url)}.

🔍 الأسباب المحتملة:
• المنشور خاص أو محذوف.
• تحتاج إلى تسجيل الدخول (تأكد من أن متصفح Chrome مفتوح ومسجل).
• الخدمات الخارجية غير متاحة حالياً.

💡 نصائح:
• تأكد من تثبيت yt-dlp وتحديثه: yt-dlp -U
• تأكد من تسجيل الدخول إلى الموقع في متصفح Chrome.
• حاول استخدام رابط منشور عام.`);
}

// ========== جلب معلومات الفيديو ==========
async function fetchVideoInfo(url) {
  try {
    const cmd = `${ytdlp} --dump-json --skip-download --no-playlist "${url}"`;
    const { stdout } = await execPromise(cmd, { timeout: 15000 });
    return JSON.parse(stdout);
  } catch (e) {
    console.warn('⚠️ فشل جلب المعلومات:', e.message);
    return null;
  }
}

// ========== الأمر الرئيسي ==========
module.exports = {
  command: 'تحميل',
  name: 'تحميل',
  category: 'وسائط',
  description: 'تحميل فيديو أو صوت من أي موقع (نقاط)',
  usage: '.تحميل <رابط>   أو   .تحميل صوت <رابط>',

  async execute(sock, msg, args) {
    const chatId = msg.key.remoteJid;
    const sender = msg.key.participant || msg.key.remoteJid;

    // التحقق من النقاط
    const points = loadPoints();
    const userPoints = points[sender] || 0;
    if (userPoints < commandPrice) {
      return sock.sendMessage(chatId, {
        text: `❌ نقاطك غير كافية\n💰 السعر: ${commandPrice}\n🪙 رصيدك: ${userPoints}`
      }, { quoted: msg });
    }

    // قراءة الأمر
    let fullText = msg.message?.extendedTextMessage?.text ||
                   msg.message?.conversation ||
                   msg.message?.imageMessage?.caption || '';
    let isAudioOnly = false;
    let url = '';
    const parts = fullText.trim().split(/\s+/);
    if (parts.length >= 2 && parts[0] === '.تحميل' && parts[1] === 'صوت') {
      isAudioOnly = true;
      url = parts.slice(2).join(' ');
    } else if (parts.length >= 2 && parts[0] === '.تحميل') {
      url = parts.slice(1).join(' ');
    } else {
      return sock.sendMessage(chatId, {
        text: '❌ استخدم:\n.تحميل [الرابط]\n.تحميل صوت [الرابط]'
      }, { quoted: msg });
    }

    if (!url || !url.startsWith('http')) {
      return sock.sendMessage(chatId, { text: '❌ رابط غير صالح' }, { quoted: msg });
    }

    const isSupported = supportedSites.some(site => url.includes(site));
    if (!isSupported) {
      return sock.sendMessage(chatId, {
        text: `❌ موقع غير مدعوم\nالمدعومة: ${supportedSites.join(', ')}`
      }, { quoted: msg });
    }

    // حل الروابط المختصرة
    if (url.includes('vm.tiktok') || url.includes('vt.tiktok') || url.includes('youtu.be') || url.includes('fb.watch') || url.includes('instagr.am')) {
      url = await resolveShortUrl(url);
    }

    // إرسال رسالة "جاري التحميل..."
    const waitMsg = await sock.sendMessage(chatId, {
      text: isAudioOnly ? '⏳ جاري تحميل الصوت...' : '⏳ جاري تجهيز التحميل...'
    }, { quoted: msg });

    // دالة مساعدة لحذف رسالة الانتظار
    const deleteWaitMessage = async () => {
      try {
        if (waitMsg && waitMsg.key) {
          await sock.sendMessage(chatId, { delete: waitMsg.key });
          console.log('🗑️ تم حذف رسالة الانتظار');
        }
      } catch (err) {
        console.warn('⚠️ فشل حذف رسالة الانتظار:', err.message);
      }
    };

    if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true });
    const id = Date.now() + '_' + Math.random().toString(36).substring(7);
    const outputPath = path.join(tempDir, isAudioOnly ? `${id}.mp3` : `${id}.mp4`);

    try {
      // جلب المعلومات (اختياري)
      let videoInfo = null;
      try {
        videoInfo = await fetchVideoInfo(url);
      } catch (e) { /* نتجاهل */ }

      // تحديث رسالة الانتظار بمعلومات الفيديو إن أمكن
      if (videoInfo && !isAudioOnly) {
        await sock.sendMessage(chatId, {
          text: `⏳ تحميل...\n📹 ${videoInfo.title?.substring(0, 50)}\n⏱️ ${formatDuration(videoInfo.duration)}\n👤 ${videoInfo.uploader || '?'}`,
          edit: waitMsg.key
        }).catch(() => {});
      } else if (videoInfo && isAudioOnly) {
        await sock.sendMessage(chatId, {
          text: `⏳ تحميل صوت...\n🎵 ${videoInfo.title?.substring(0, 50)}`,
          edit: waitMsg.key
        }).catch(() => {});
      }

      // تنفيذ التحميل
      await downloadMedia(url, outputPath, isAudioOnly);

      // حذف رسالة الانتظار بعد نجاح التحميل
      await deleteWaitMessage();

      // إرسال الملف
      const fileSizeMB = fs.statSync(outputPath).size / (1024 * 1024);
      if (isAudioOnly) {
        await sock.sendMessage(chatId, {
          audio: { url: outputPath },
          mimetype: 'audio/mpeg',
          ptt: false,
          caption: `🎵 ${videoInfo?.title || 'صوت'}\n👤 ${videoInfo?.uploader || '?'}\n💾 ${fileSizeMB.toFixed(1)} MB`
        }, { quoted: msg });
      } else {
        if (fileSizeMB > 50) {
          await sock.sendMessage(chatId, {
            document: { url: outputPath },
            mimetype: 'video/mp4',
            fileName: `${videoInfo?.title?.replace(/[^\w\u0600-\u06FF]/g, '_') || 'video'}.mp4`,
            caption: `🎥 ${videoInfo?.title || 'فيديو'}\n👤 ${videoInfo?.uploader || '?'}\n⏱️ ${formatDuration(videoInfo?.duration)}\n💾 ${fileSizeMB.toFixed(1)} MB`
          }, { quoted: msg });
        } else {
          await sock.sendMessage(chatId, {
            video: { url: outputPath },
            caption: `🎥 ${videoInfo?.title || 'فيديو'}\n👤 ${videoInfo?.uploader || '?'}\n⏱️ ${formatDuration(videoInfo?.duration)}`,
            gifPlayback: false
          }, { quoted: msg });
        }
      }

      // خصم النقاط
      const updatedPoints = loadPoints();
      updatedPoints[sender] = (updatedPoints[sender] || 0) - commandPrice;
      savePoints(updatedPoints);
      await sock.sendMessage(chatId, {
        text: `✅ تم التحميل\n💰 خصم ${commandPrice} نقطة\n🪙 رصيدك: ${updatedPoints[sender]}`
      }, { quoted: msg });

    } catch (err) {
      console.error('❌ خطأ التحميل:', err);
      // حذف رسالة الانتظار في حالة الفشل أيضاً
      await deleteWaitMessage();
      await sock.sendMessage(chatId, {
        text: `❌ فشل التحميل\nالسبب: ${err.message.substring(0, 150)}\nلم يتم خصم نقاط.`
      }, { quoted: msg });
    } finally {
      // تنظيف الملف المؤقت بعد 10 ثوانٍ من انتهاء العملية
      setTimeout(() => {
        if (fs.existsSync(outputPath)) {
          fs.unlinkSync(outputPath);
          console.log(`🧹 تم حذف الملف المؤقت: ${outputPath}`);
        }
      }, 10000);
    }
  }
};