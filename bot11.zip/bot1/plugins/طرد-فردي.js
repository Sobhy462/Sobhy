const { jidDecode } = require('@whiskeysockets/baileys');
const hay = require('../haykala/developer');

// فك التشفير وتحويله إلى @lid
const decode = jid => (jidDecode(jid)?.user || jid.split('@')[0]) + '@lid';

// التحقق من صلاحية المشرف في المجموعة
async function isGroupAdmin(sock, chatId, jid) {
  try {
    const groupMetadata = await sock.groupMetadata(chatId);
    const participant = groupMetadata.participants.find(p => p.id === jid);
    return participant?.admin === 'superadmin' || participant?.admin === 'admin';
  } catch {
    return false;
  }
}

module.exports = {
  category: 'ادارة',
  command: "طرد",
  description: "طرد عضو أو عدة أعضاء من المجموعة دفعة واحدة (مع قفل مؤقت ومنشن).",
  usage: ".طرد @العضو1 @العضو2 ... أو رد على رسالة",

  async execute(sock, msg) {
    try {
      const chatId = msg.key.remoteJid;
      const sender = msg.key.participant || msg.key.remoteJid;

      if (!sender || !chatId) return;

      const senderLid = hay.toLid(sender);

      // صلاحيات المرسل (بدون Elite)
      const isSenderFounder = hay.isFounder(senderLid);
      const isSenderOwnerbot = hay.isOwnerbot(senderLid);
      const isSenderDeveloper = hay.isDeveloper(senderLid);
      const isSenderAdmin = await isGroupAdmin(sock, chatId, sender);

      // السماح فقط: مالك البوت، مطور، أو مشرف
      if (!(isSenderFounder || isSenderOwnerbot || isSenderDeveloper || isSenderAdmin)) {
        await sock.sendMessage(chatId, {
          text: 'ذل من لا صلاحيات له 😂🫵',
        }, { quoted: msg });
        return;
      }

      if (!chatId.endsWith('@g.us')) {
        return await sock.sendMessage(chatId, {
          text: '❌ هذا الأمر يعمل فقط داخل المجموعات.',
        }, { quoted: msg });
      }

      const metadata = await sock.groupMetadata(chatId);

      // ========== جمع جميع المستهدفين ==========
      let targetJids = [];

      // 1. منشنات متعددة
      if (msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.length) {
        targetJids = msg.message.extendedTextMessage.contextInfo.mentionedJid;
      }

      // 2. في حالة الرد على رسالة (إذا لم يكن هناك منشنات)
      if (targetJids.length === 0 && msg.message?.extendedTextMessage?.contextInfo?.participant) {
        targetJids = [msg.message.extendedTextMessage.contextInfo.participant];
      }

      if (targetJids.length === 0) {
        return sock.sendMessage(chatId, {
          text: '❌ لم يتم تحديد أي عضو للطرد. استخدم منشنات أو رد على رسالة العضو.',
        }, { quoted: msg });
      }

      // ========== تصفية الأهداف الصالحة للطرد ==========
      const validTargets = [];
      const errorMessages = [];

      for (const rawTarget of targetJids) {
        // تحويل الـ JID إلى Lid للتحقق من الرتبة
        const targetLid = hay.toLid(rawTarget);

        // لا يطرد نفسه أو البوت
        if (rawTarget === sock.user.id || rawTarget === sender) {
          errorMessages.push(`❌ لا يمكن طرد ${rawTarget.split('@')[0]}`);
          continue;
        }

        // التحقق من وجود العضو في المجموعة
        const participant = metadata.participants.find(p => p.id === rawTarget);
        if (!participant) {
          errorMessages.push(`⚠️ ${rawTarget.split('@')[0]} ليس في المجموعة`);
          continue;
        }

        // رتبة الهدف
        const isTargetFounder = hay.isFounder(targetLid);
        const isTargetOwnerbot = hay.isOwnerbot(targetLid);
        const isTargetDeveloper = hay.isDeveloper(targetLid);
        const isTargetAdmin = participant.admin === 'superadmin' || participant.admin === 'admin';

        // التدرج الهرمي للطرد (بدون Elite)
        let canKick = false;
        let reason = '';

        if (isSenderFounder) {
          canKick = true; // الاونر يطرد أي شخص
        } else if (isSenderOwnerbot && !isTargetFounder) {
          canKick = true;
        } else if (isSenderDeveloper && !isTargetFounder && !isTargetOwnerbot && !isTargetDeveloper) {
          canKick = true;
        } else if (isSenderAdmin && !isTargetFounder && !isTargetOwnerbot && !isTargetDeveloper && !isTargetAdmin) {
          canKick = true; // المشرف يطرد الأعضاء العاديين فقط
        }

        if (canKick) {
          validTargets.push(rawTarget);
        } else {
          const name = rawTarget.split('@')[0];
          if (isSenderAdmin) {
            reason = ' (رتبة أعلى أو مساوية للمشرف)';
          } else if (isSenderDeveloper) {
            reason = ' (رتبة أعلى أو مساوية للمطور)';
          } else if (isSenderOwnerbot) {
            reason = ' (لا يمكن طرد الاونر بوت)';
          } else {
            reason = ' (رتبة أعلى أو مساوية)';
          }
          errorMessages.push(`🚫 لا يمكن طرده ${reason}`);
        }
      }

      // إرسال رسائل الأخطاء إن وجدت
      if (errorMessages.length > 0) {
        await sock.sendMessage(chatId, {
          text: errorMessages.join('\n')
        }, { quoted: msg });
      }

      if (validTargets.length === 0) {
        return; // لا يوجد أعضاء صالحين للطرد
      }

      // ========== تنفيذ الطرد الجماعي مع القفل والفتح ==========
      
      // قفل المجموعة مؤقتاً
      await sock.groupSettingUpdate(chatId, 'announcement');

      // منشن جماعي للمستهدفين
      const mentionsText = validTargets.map(jid => `@${jid.split('@')[0]}`).join(' ');
      await sock.sendMessage(chatId, {
        text: `${mentionsText} شوف فوق ☝️☝️`,
        mentions: validTargets
      }, { quoted: msg });

      // انتظار ثانية (اختياري)
      await new Promise(resolve => setTimeout(resolve, 1000));

      // طرد الكل دفعة واحدة
      await sock.groupParticipantsUpdate(chatId, validTargets, 'remove');

      // رسالة تأكيد بعد الطرد
      const removedCount = validTargets.length;
      await sock.sendMessage(chatId, {
        text: `اقصد تحت 🥰🥰`
      });

      // فتح المجموعة
      await sock.groupSettingUpdate(chatId, 'not_announcement');

    } catch (error) {
      console.error('✗ خطأ في أمر الطرد:', error);
      // محاولة فتح المجموعة في حال حدوث خطأ
      try {
        await sock.groupSettingUpdate(msg.key.remoteJid, 'not_announcement');
      } catch (err) {
        console.error('✗ خطأ في محاولة فتح المجموعة بعد الخطأ:', err);
      }
      await sock.sendMessage(msg.key.remoteJid, {
        text: 'حدث خطأ أثناء تنفيذ الأمر.'
      }, { quoted: msg });
    }
  }
};