// تيك.js - تحميل فيديو من تيك توك (يدعم الروابط والبحث، يرسل فيديو)
const axios = require('axios');
const fs = require('fs');
const path = require('path');

// ========== إعدادات الأسعار ==========
const SEARCH_PRICE = 100;
const LINK_PRICE = 50;
const APIFY_TOKEN = 'apify_api_Nosx6ch9Ua28pFgV1TFeurHCsbflPn21ezuh';

// ========== مسار ملف النقاط ==========
const pointsPath = path.join(__dirname, '../data/points.json');

if (!fs.existsSync(path.join(__dirname, '../data'))) 
    fs.mkdirSync(path.join(__dirname, '../data'), { recursive: true });
if (!fs.existsSync(pointsPath)) 
    fs.writeFileSync(pointsPath, JSON.stringify({}, null, 2));

// ========== دوال النقاط ==========
function loadPoints() {
    try {
        return JSON.parse(fs.readFileSync(pointsPath));
    } catch {
        return {};
    }
}

function savePoints(data) {
    fs.writeFileSync(pointsPath, JSON.stringify(data, null, 2));
}

// ========== التحقق من الرابط ==========
function isTikTokLink(text) {
    return /https?:\/\/(www\.|vm\.|vt\.)?tiktok\.com\/\S+/i.test(text);
}

// ========== دالة إرسال الرسائل المنسقة (احتياطي) ==========
async function sendMessage(sock, chatId, lines, quoted = null, mentions = []) {
    if (!Array.isArray(lines)) lines = [lines];

    let msg = `🎵 تـحـمـيـل تـيـك تـوك 🎵\n`;
    msg += `━━━━━━━━━━━━━━━━━━━━\n`;
    for (const line of lines) {
        msg += `${line}\n`;
    }
    msg += `━━━━━━━━━━━━━━━━━━━━\n`;
    msg += `𝘽𝙔┇𝑴𝑨𝑲𝑰𝑴𝑨`;
    await sock.sendMessage(chatId, { text: msg, mentions }, { quoted: quoted });
}

// ========== جلب الفيديو عبر TikWM (للروابط - كان يعمل سابقاً) ==========
async function fetchViaTikWM(url) {
    try {
        const response = await axios.get(`https://www.tikwm.com/api/?url=${encodeURIComponent(url)}`, {
            timeout: 30000,
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                'Referer': 'https://www.tikwm.com/',
                'Origin': 'https://www.tikwm.com',
                'Accept': 'application/json, text/plain, */*',
                'Accept-Encoding': 'gzip, deflate, br',
                'Accept-Language': 'en-US,en;q=0.9'
            }
        });
        if (response.status === 200 && response.data?.code === 0 && response.data?.data) {
            const data = response.data.data;
            return {
                title: data.title || 'فيديو تيك توك',
                page_url: url,
                video_url: data.play || data.wmplay || data.hdplay || data.play,
                cover_url: data.cover || '',
                author: data.author?.nickname || 'مجهول',
                views: data.play_count || 0,
                likes: data.digg_count || 0,
                comments: data.comment_count || 0,
                shares: data.share_count || 0,
                duration: data.duration || 0
            };
        }
        return null;
    } catch (error) {
        console.error('❌ فشل جلب من TikWM:', error.message);
        return null;
    }
}

// ========== جلب الفيديو عبر Apify (للبحث أو كبديل للروابط) ==========
async function fetchViaApify(query, isLink = false) {
    try {
        let searchQuery = String(query || '').trim();
        let videoIdMatch = null;
        
        if (isLink) {
            // استخراج video ID من الرابط
            videoIdMatch = query.match(/\/video\/(\d+)/);
            if (videoIdMatch) {
                searchQuery = videoIdMatch[1];
            } else {
                // إذا لم نجد ID، نستخدم الرابط نفسه ككلمة بحث
                searchQuery = query;
            }
        } else {
            // إضافة "edit" للبحث عن إيديتات
            if (!/\bedit\b/i.test(searchQuery)) {
                searchQuery = `${searchQuery} edit`;
            }
        }

        const apiUrl = 'https://api.apify.com/v2/acts/mu0i~tiktok-search-scraper/run-sync-get-dataset-items';

        const response = await axios.post(
            apiUrl,
            {
                queries: [searchQuery],
                resultType: 'videos',
                maxResultsPerQuery: 10,
                sortBy: 'relevance',
                includeDownloadUrls: true
            },
            {
                params: { token: APIFY_TOKEN },
                headers: { 'Content-Type': 'application/json' },
                timeout: 120000
            }
        );

        const data = Array.isArray(response.data) ? response.data : [];

        const videos = data
            .filter(video => video && video.url && !video.isPhotoPost)
            .map(video => ({
                title: video.description || 'فيديو تيك توك',
                page_url: video.url,
                video_url: video.noWatermarkUrl || video.url,
                cover_url: video.coverUrl || null,
                author: video.authorUsername || video.authorNickname || 'مجهول',
                views: Number(video.playCount || 0),
                likes: Number(video.likeCount || 0),
                comments: Number(video.commentCount || 0),
                shares: Number(video.shareCount || 0),
                duration: video.duration || 0
            }))
            .filter(v => v.video_url);

        if (isLink && videoIdMatch) {
            // نحاول مطابقة الرابط الأصلي مع النتائج
            const matched = videos.find(v => 
                v.page_url.includes(query) || 
                v.page_url.includes(videoIdMatch[1])
            );
            return matched || (videos.length ? videos[0] : null);
        }

        if (isLink && !videoIdMatch) {
            // إذا لم نجد video ID، نأخذ أول نتيجة
            return videos.length ? videos[0] : null;
        }

        // للبحث: نختار أول فيديو يعمل
        for (const vid of videos) {
            try {
                const head = await axios.head(vid.video_url, { timeout: 5000 });
                if (head.status === 200) return vid;
            } catch (e) {
                continue;
            }
        }
        return videos.length ? videos[0] : null;

    } catch (error) {
        console.error('❌ فشل جلب من Apify:', error.message);
        return null;
    }
}

// ========== تحميل الفيديو كـ Buffer ==========
async function downloadVideo(videoUrl) {
    try {
        const response = await axios.get(videoUrl, {
            responseType: 'arraybuffer',
            timeout: 90000,
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                'Referer': 'https://www.tiktok.com/'
            },
            maxContentLength: Infinity,
            maxBodyLength: Infinity
        });
        return Buffer.from(response.data);
    } catch (error) {
        console.error('❌ فشل تحميل الفيديو:', error.message);
        return null;
    }
}

// ========== الأمر الرئيسي ==========
module.exports = {
    command: ['تيك'],
    category: 'وسائط',
    description: '🎵 تحميل فيديو من تيك توك (بحث أو رابط)',
    usage: '.تيك [بحث أو رابط]',
    price: { search: SEARCH_PRICE, link: LINK_PRICE },

    async execute(sock, msg, args) {
        let chatId, sender, points, userPoints, inputText;

        try {
            chatId = msg.key.remoteJid;
            sender = msg.key.participant || msg.key.remoteJid;

            points = loadPoints();
            userPoints = points[sender] || 0;

            // استخراج النص
            inputText = '';
            if (args && Array.isArray(args)) {
                inputText = args.join(' ').trim();
            }
            if (!inputText && msg.message?.conversation) {
                inputText = msg.message.conversation.replace(/^\.تيك\s*/, '').trim();
            }
            if (!inputText && msg.message?.extendedTextMessage?.text) {
                inputText = msg.message.extendedTextMessage.text.replace(/^\.تيك\s*/, '').trim();
            }

            // عرض المساعدة
            if (!inputText) {
                const lines = [
                    '🎵 *تحميل فيديو تيك توك*',
                    '',
                    '📌 الاستخدام:',
                    '.تيك [اسم البحث] - بحث عن فيديو (100 نقطة)',
                    '.تيك [رابط] - تحميل من رابط (50 نقطة)',
                    '',
                    '💰 الأسعار:',
                    `• بحث: ${SEARCH_PRICE} نقطة`,
                    `• رابط: ${LINK_PRICE} نقطة`,
                    '',
                    '📝 أمثلة:',
                    '.تيك انمي',
                    '.تيك https://vt.tiktok.com/xxxxx'
                ];
                await sendMessage(sock, chatId, lines, msg);
                return;
            }

            const isLink = isTikTokLink(inputText);
            const price = isLink ? LINK_PRICE : SEARCH_PRICE;

            if (userPoints < price) {
                const lines = [
                    '❌ *نقاط غير كافية*',
                    '',
                    `💰 السعر: ${price} نقطة`,
                    `🪙 رصيدك: ${userPoints} نقطة`,
                    `💔 تحتاج: ${price - userPoints} نقطة إضافية`
                ];
                await sendMessage(sock, chatId, lines, msg, [sender]);
                return;
            }

            // خصم النقاط مؤقتاً
            points[sender] = userPoints - price;
            savePoints(points);

            await sock.sendMessage(chatId, { react: { text: '⏳', key: msg.key } });

            // ===== جلب الفيديو =====
            let video = null;

            if (isLink) {
                // المحاولة الأولى: عبر TikWM (كان يعمل سابقاً)
                video = await fetchViaTikWM(inputText);
                // إذا فشل، نستخدم Apify كبديل
                if (!video) {
                    console.log('⚠️ TikWM فشل، نحاول عبر Apify...');
                    video = await fetchViaApify(inputText, true);
                }
            } else {
                // بحث: عبر Apify
                video = await fetchViaApify(inputText, false);
            }

            if (!video) {
                points[sender] = (points[sender] || 0) + price;
                savePoints(points);
                await sock.sendMessage(chatId, { react: { text: '❌', key: msg.key } });
                await sendMessage(sock, chatId, [
                    '❌ لا توجد نتائج',
                    '💡 تم استرجاع نقاطك'
                ], msg);
                return;
            }

            // ===== تحضير الكابتشن الموحد =====
            let title = String(video.title || 'فيديو تيك توك').replace(/\n/g, ' ').trim();
            if (title.length > 80) title = title.substring(0, 80) + '...';

            const newBalance = points[sender];

            const caption = 
`🎬 *${title}*

👤 *الحساب:* @${video.author}
👁️ *المشاهدات:* ${video.views.toLocaleString()}
❤️ *الإعجابات:* ${video.likes.toLocaleString()}
💬 *التعليقات:* ${video.comments.toLocaleString()}
${isLink ? '🔗 رابط' : '🔍 بحث: ' + inputText}

🔗 *رابط المشاهدة:* ${video.page_url}

✅ تم الإرسال بنجاح
💰 تم خصم ${price} نقطة
🪙 رصيدك: ${newBalance} نقطة`;

            // ===== تحميل الفيديو =====
            let videoBuffer = await downloadVideo(video.video_url);
            if (!videoBuffer) {
                console.log('⚠️ محاولة تحميل من الرابط العادي...');
                videoBuffer = await downloadVideo(video.page_url);
            }

            if (!videoBuffer || videoBuffer.length < 1000) {
                // إرسال الرابط مع الكابتشن (بدون فيديو)
                await sock.sendMessage(chatId, {
                    text: `⚠️ تعذر تحميل الفيديو، إليك الرابط:\n${video.page_url}\n\n${caption}`
                }, { quoted: msg });
                await sock.sendMessage(chatId, { react: { text: '⚠️', key: msg.key } });
                return;
            }

            // ===== إرسال الفيديو (وليس مستند) =====
            try {
                await sock.sendMessage(chatId, {
                    video: videoBuffer,
                    caption: caption,
                    mimetype: 'video/mp4'
                }, { quoted: msg });
                console.log('✅ تم الإرسال كفيديو');
            } catch (videoError) {
                console.error('❌ فشل إرسال كفيديو، نحاول كوثيقة:', videoError.message);
                // محاولة إرسال كوثيقة كحل أخير
                try {
                    await sock.sendMessage(chatId, {
                        document: videoBuffer,
                        mimetype: 'video/mp4',
                        fileName: `تيك_${Date.now()}.mp4`,
                        caption: caption
                    }, { quoted: msg });
                    console.log('✅ تم الإرسال كوثيقة');
                } catch (docError) {
                    console.error('❌ فشل إرسال كوثيقة أيضاً:', docError.message);
                    await sock.sendMessage(chatId, {
                        text: `⚠️ تعذر رفع الفيديو، إليك الرابط:\n${video.page_url}\n\n${caption}`
                    }, { quoted: msg });
                }
            }

            await sock.sendMessage(chatId, { react: { text: '✅', key: msg.key } });

        } catch (error) {
            console.error('❌ خطأ في تيك:', error);

            try {
                points = loadPoints();
                const price = isTikTokLink(inputText) ? LINK_PRICE : SEARCH_PRICE;
                points[sender] = (points[sender] || 0) + price;
                savePoints(points);
            } catch (e) {}

            if (!chatId) chatId = msg.key?.remoteJid || 'unknown';
            if (!sender) sender = msg.key?.participant || msg.key?.remoteJid || 'unknown';

            await sock.sendMessage(chatId, { react: { text: '❌', key: msg.key } });

            let errorMsg = '❌ فشل التحميل';
            if (error.code === 'ECONNABORTED') errorMsg = '⏰ انتهت المهلة';
            else if (error.response?.status === 403) errorMsg = '🚫 تم رفض الطلب';
            else if (error.response?.status === 404) errorMsg = '🔍 لا توجد نتائج';
            else if (error.response?.status >= 500) errorMsg = '🚫 الخدمة غير متاحة';
            else if (error.message.includes('لا يوجد فيديو')) errorMsg = '❌ لم نجد فيديو';
            else if (error.message.includes('لا توجد نتائج')) errorMsg = '🔍 لا توجد نتائج للبحث';

            await sendMessage(sock, chatId, [
                `${errorMsg}`,
                '💡 تم استرجاع نقاطك',
                '🔄 حاول مرة أخرى لاحقاً'
            ], msg);
        }
    }
};