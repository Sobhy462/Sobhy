// المطور.js - عرض معلومات مطور البوت

module.exports = {
    command: ['المطور', 'مطوري', 'owner'],
    description: '👨‍💻 يعرض معلومات مطور البوت وروابط التواصل',
    category: 'المطور',

    async execute(sock, msg) {
        try {
            const chatId = msg.key.remoteJid;
            const developerName = '𓆩 𝑺𝑨𝑻𝑼𝑹𝑵 𓆪';
            const developerPhone = '+218 92-3993720';
            const developerEmail = 'a81284293@gmail.com';

            const whatsappChannel = 'https://whatsapp.com/channel/0029Vb84qzoEKyZPmnwxDQ3d';
            const whatsappGroup = 'https://chat.whatsapp.com/FL43hcmEAU7JIXVTRsayqT';
            const telegramChannel = 'https://t.me/SATURN_BOOT';
            const instagram = 'https://www.instagram.com/saturn_boot?igsh=MWx4amd2YjBwMnBlZQ==';
            const youtube = 'https://www.youtube.com/@SATURN_BOOT';

            const vcard = `BEGIN:VCARD
VERSION:3.0
FN:${developerName}
TEL;type=CELL;waid=218923993720:${developerPhone}
EMAIL:${developerEmail}
NOTE: لا حد يحكي معي إلا للضرورة بالخاص
END:VCARD`;

            // ===== إرسال جهة الاتصال =====
            await sock.sendMessage(
                chatId,
                {
                    contacts: {
                        displayName: `مطور ${developerName}`,
                        contacts: [{ vcard }]
                    }
                },
                { quoted: msg }
            );

            // ===== إرسال المعلومات (بدون externalAdReply) =====
            const text = `╭── 🎯 *مـعـلـومـات الـمـطـور* ──╮

╰─➤ 👤 *الاسـم:* ${developerName}
╰─➤ 📞 *الرقم:* ${developerPhone}
╰─➤ ✉️ *الإيميل:* ${developerEmail}

━━━━━━━━━━━━━━━

╰─🎥 *قـنـاة الـيـوتـيـوب:*
🔗 ${youtube}

━━━━━━━━━━━━━━━

╰─📸 *حـسـاب الإنـسـتـغـرام:*
🔗 ${instagram}

━━━━━━━━━━━━━━━

╰─💬 *قـنـاة واتـسـاب الـرسـمـيـة:*
🔗 ${whatsappChannel}

━━━━━━━━━━━━━━━

╰─👥 *مـجـمـوعـة الـدعـم:*
🔗 ${whatsappGroup}

━━━━━━━━━━━━━━━

╰─📂 *قـنـاة تـلـيـجـرام لـمـلـفـات الـبـوت + الـشـرح:*
🔗 ${telegramChannel}

━━━━━━━━━━━━━━━

╰─🚫 *مـلاحـظـة هـامـة:*
⛔ الرجاء عدم الإرسال في الخاص إلا للضرورة فقط.

━━━━━━━━━━━━━━━

✨ مَا هَذَا كُلُّهُ إِلَّا مِن فَضْلِ رَبِّي ✨

╰── ❖ 𝑺𝑨𝑻𝑼𝑹𝑵 ❖ ──╯
⚡ حَيْثُ تَتَوَّجُ الْكَلِمَاتُ تَاجَ الْبَقَاءِ ⚡`;

            await sock.sendMessage(
                chatId,
                {
                    text: text
                },
                { quoted: msg }
            );

        } catch (err) {
            console.error('❌ خطأ في أمر المطور:', err);
            await sock.sendMessage(
                msg.key.remoteJid,
                {
                    text: '❌ حصل خطأ أثناء عرض معلومات المطور.'
                },
                { quoted: msg }
            );
        }
    }
};