// توك.js - تحميل فيديو + صوت من تيك توك (يدعم الروابط والبحث)
const axios = require('axios');
const fs = require('fs');
const path = require('path');

const commandPrice = 200;
const APIFY_TOKEN = 'apify_api_Nosx6ch9Ua28pFgV1TFeurHCsbflPn21ezuh';

const pointsPath = path.join(__dirname, '../data/points.json');

if (!fs.existsSync(path.join(__dirname, '../data'))) fs.mkdirSync(path.join(__dirname, '../data'), { recursive: true });
if (!fs.existsSync(pointsPath)) fs.writeFileSync(pointsPath, JSON.stringify({}, null, 2));

function loadPoints() {
    try {
        return JSON.parse(fs.readFileSync(pointsPath));
    } catch {
        return {};
    }
}

function savePoints(data) {
    fs.writeFileSync(pointsPath, JSON.stringify(data, null, 2));
}

function isTikTokLink(text) {
    return /https?:\/\/(www\.|vm\.|vt\.)?tiktok\.com\/\S+/i.test(text);
}

// ========== دالة الإرسال المنسقة ==========
async function sendMessage(sock, chatId, lines, quoted = null, mentions = []) {
    if (!Array.isArray(lines)) lines = [lines];

    let msg = `🎵 تـحـمـيـل تـيـك تـوك 🎵\n`;
    msg += `━━━━━━━━━━━━━━━━━━━━\n`;
    for (const line of lines) {
        msg += `${line}\n`;
    }
    msg += `━━━━━━━━━━━━━━━━━━━━\n`;
    msg += `𝘽𝙔┇𝑴𝑨𝑲𝑰𝑴𝑨`;
    await sock.sendMessage(chatId, { text: msg, mentions }, { quoted: quoted });
}

// ========== جلب البيانات عبر TikWM (للروابط) ==========
async function fetchViaTikWM(url) {
    try {
        const response = await axios.get(`https://www.tikwm.com/api/?url=${encodeURIComponent(url)}`, {
            timeout: 30000,
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                'Referer': 'https://www.tikwm.com/',
                'Origin': 'https://www.tikwm.com',
                'Accept': 'application/json, text/plain, */*',
                'Accept-Encoding': 'gzip, deflate, br',
                'Accept-Language': 'en-US,en;q=0.9'
            }
        });
        if (response.status === 200 && response.data?.code === 0 && response.data?.data) {
            const data = response.data.data;
            return {
                title: data.title || 'فيديو تيك توك',
                page_url: url,
                video_url: data.play || data.wmplay || data.hdplay || data.play,
                audio_url: data.music || data.music_info?.play || data.music_info?.url,
                cover_url: data.cover || '',
                author: data.author?.nickname || 'مجهول',
                views: data.play_count || 0,
                likes: data.digg_count || 0,
                comments: data.comment_count || 0,
                shares: data.share_count || 0,
                duration: data.duration || 0
            };
        }
        return null;
    } catch (error) {
        console.error('❌ فشل جلب من TikWM:', error.message);
        return null;
    }
}

// ========== جلب البيانات عبر Apify (للبحث أو كبديل للروابط) ==========
async function fetchViaApify(query, isLink = false) {
    try {
        let searchQuery = String(query || '').trim();
        let videoIdMatch = null;

        if (isLink) {
            videoIdMatch = query.match(/\/video\/(\d+)/);
            if (videoIdMatch) {
                searchQuery = videoIdMatch[1];
            } else {
                searchQuery = query;
            }
        } else {
            if (!/\bedit\b/i.test(searchQuery)) {
                searchQuery = `${searchQuery} edit`;
            }
        }

        const apiUrl = 'https://api.apify.com/v2/acts/mu0i~tiktok-search-scraper/run-sync-get-dataset-items';

        const response = await axios.post(
            apiUrl,
            {
                queries: [searchQuery],
                resultType: 'videos',
                maxResultsPerQuery: 10,
                sortBy: 'relevance',
                includeDownloadUrls: true
            },
            {
                params: { token: APIFY_TOKEN },
                headers: { 'Content-Type': 'application/json' },
                timeout: 120000
            }
        );

        const data = Array.isArray(response.data) ? response.data : [];

        const videos = data
            .filter(v => v && v.url && !v.isPhotoPost)
            .map(v => ({
                title: v.description || 'فيديو تيك توك',
                page_url: v.url,
                video_url: v.noWatermarkUrl || v.url,
                audio_url: v.music_url || v.audio_url || v.noWatermarkUrl || v.url, // قد لا يكون هناك رابط موسيقى منفصل
                cover_url: v.coverUrl || null,
                author: v.authorUsername || v.authorNickname || 'مجهول',
                views: Number(v.playCount || 0),
                likes: Number(v.likeCount || 0),
                comments: Number(v.commentCount || 0),
                shares: Number(v.shareCount || 0),
                duration: v.duration || 0
            }))
            .filter(v => v.video_url);

        if (isLink && videoIdMatch) {
            const matched = videos.find(v => 
                v.page_url.includes(query) || 
                v.page_url.includes(videoIdMatch[1])
            );
            return matched || (videos.length ? videos[0] : null);
        }

        if (isLink && !videoIdMatch) {
            return videos.length ? videos[0] : null;
        }

        // للبحث: نأخذ أول فيديو
        return videos.length ? videos[0] : null;

    } catch (error) {
        console.error('❌ فشل جلب من Apify:', error.message);
        return null;
    }
}

// ========== تحميل الوسائط كـ Buffer ==========
async function downloadMedia(url) {
    try {
        const response = await axios.get(url, {
            responseType: 'arraybuffer',
            timeout: 90000,
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                'Referer': 'https://www.tiktok.com/'
            },
            maxContentLength: Infinity,
            maxBodyLength: Infinity
        });
        return Buffer.from(response.data);
    } catch (error) {
        console.error('❌ فشل تحميل الوسائط:', error.message);
        return null;
    }
}

module.exports = {
    command: ['توك', 'تيكتوك'],
    category: 'وسائط',
    description: '🎬 تحميل فيديو + صوت من تيك توك (بحث أو رابط)',
    usage: '.توك [بحث أو رابط]',
    price: commandPrice,

    async execute(sock, msg, args) {
        let chatId, sender, points, userPoints, inputText;

        try {
            chatId = msg.key.remoteJid;
            sender = msg.key.participant || msg.key.remoteJid;

            points = loadPoints();
            userPoints = points[sender] || 0;

            // استخراج النص
            inputText = '';
            if (args && Array.isArray(args) && args.length) {
                inputText = args.join(' ').trim();
            }
            if (!inputText && msg.message?.conversation) {
                inputText = msg.message.conversation.replace(/^\.توك\s*/i, '').trim();
            }
            if (!inputText && msg.message?.extendedTextMessage?.text) {
                inputText = msg.message.extendedTextMessage.text.replace(/^\.توك\s*/i, '').trim();
            }

            // عرض المساعدة
            if (!inputText) {
                const lines = [
                    '🎬 *تحميل تيك توك (فيديو + صوت)*',
                    '',
                    '📌 الاستخدام:',
                    '.توك [اسم البحث] - بحث عن فيديو',
                    '.توك [رابط] - تحميل من رابط',
                    '',
                    `💰 السعر: ${commandPrice} نقطة`,
                    '',
                    '📝 أمثلة:',
                    '.توك انمي',
                    '.توك https://vt.tiktok.com/xxxxx'
                ];
                await sendMessage(sock, chatId, lines, msg);
                return;
            }

            // التحقق من الرصيد
            if (userPoints < commandPrice) {
                const lines = [
                    '❌ *نقاط غير كافية*',
                    '',
                    `💰 السعر: ${commandPrice} نقطة`,
                    `🪙 رصيدك: ${userPoints} نقطة`,
                    `💔 تحتاج: ${commandPrice - userPoints} نقطة إضافية`
                ];
                await sendMessage(sock, chatId, lines, msg, [sender]);
                return;
            }

            // خصم النقاط مؤقتاً
            points[sender] = userPoints - commandPrice;
            savePoints(points);

            await sock.sendMessage(chatId, { react: { text: '⏳', key: msg.key } });

            const isLink = isTikTokLink(inputText);
            let videoData = null;

            // ===== جلب بيانات الفيديو =====
            if (isLink) {
                videoData = await fetchViaTikWM(inputText);
                if (!videoData) {
                    console.log('⚠️ TikWM فشل، نحاول عبر Apify...');
                    videoData = await fetchViaApify(inputText, true);
                }
            } else {
                videoData = await fetchViaApify(inputText, false);
            }

            if (!videoData || !videoData.video_url) {
                points[sender] = (points[sender] || 0) + commandPrice;
                savePoints(points);
                await sock.sendMessage(chatId, { react: { text: '❌', key: msg.key } });
                await sendMessage(sock, chatId, [
                    '❌ لا توجد نتائج',
                    '💡 تم استرجاع نقاطك'
                ], msg);
                return;
            }

            // ===== تحضير الكابتشن الموحد =====
            let title = String(videoData.title || 'فيديو تيك توك').replace(/\n/g, ' ').trim();
            if (title.length > 80) title = title.substring(0, 80) + '...';

            const newBalance = points[sender];

            const caption = 
`🎬 *${title}*

👤 *الحساب:* @${videoData.author}
👁️ *المشاهدات:* ${videoData.views.toLocaleString()}
❤️ *الإعجابات:* ${videoData.likes.toLocaleString()}
💬 *التعليقات:* ${videoData.comments.toLocaleString()}
${isLink ? '🔗 رابط' : '🔍 بحث: ' + inputText}

🔗 *رابط المشاهدة:* ${videoData.page_url}

✅ تم الإرسال بنجاح
💰 تم خصم ${commandPrice} نقطة
🪙 رصيدك: ${newBalance} نقطة`;

            // ===== تحميل الفيديو والصوت =====
            let videoBuffer = await downloadMedia(videoData.video_url);
            if (!videoBuffer) {
                console.log('⚠️ محاولة تحميل الفيديو من الرابط العادي...');
                videoBuffer = await downloadMedia(videoData.page_url);
            }

            // محاولة الحصول على الصوت (قد لا يكون متاحاً في Apify)
            let audioBuffer = null;
            if (videoData.audio_url) {
                audioBuffer = await downloadMedia(videoData.audio_url);
                if (!audioBuffer || audioBuffer.length < 1000) {
                    console.log('⚠️ الصوت غير متاح، سيتم إرسال الفيديو فقط');
                    audioBuffer = null;
                }
            }

            if (!videoBuffer || videoBuffer.length < 1000) {
                // إرسال الرابط مع الكابتشن
                await sock.sendMessage(chatId, {
                    text: `⚠️ تعذر تحميل الفيديو، إليك الرابط:\n${videoData.page_url}\n\n${caption}`
                }, { quoted: msg });
                await sock.sendMessage(chatId, { react: { text: '⚠️', key: msg.key } });
                return;
            }

            // ===== إرسال الفيديو =====
            let videoSent = false;
            try {
                await sock.sendMessage(chatId, {
                    video: videoBuffer,
                    caption: caption,
                    mimetype: 'video/mp4'
                }, { quoted: msg });
                videoSent = true;
                console.log('✅ تم إرسال الفيديو');
            } catch (videoError) {
                console.error('❌ فشل إرسال الفيديو، نحاول كوثيقة:', videoError.message);
                try {
                    await sock.sendMessage(chatId, {
                        document: videoBuffer,
                        mimetype: 'video/mp4',
                        fileName: `توك_${Date.now()}.mp4`,
                        caption: caption
                    }, { quoted: msg });
                    videoSent = true;
                    console.log('✅ تم إرسال الفيديو كوثيقة');
                } catch (docError) {
                    console.error('❌ فشل إرسال كوثيقة، نرسل الرابط:', docError.message);
                    await sock.sendMessage(chatId, {
                        text: `⚠️ تعذر رفع الفيديو، إليك الرابط:\n${videoData.page_url}\n\n${caption}`
                    }, { quoted: msg });
                }
            }

            // ===== إرسال الصوت (إذا وجد) =====
            if (audioBuffer && audioBuffer.length > 1000) {
                try {
                    await sock.sendMessage(chatId, {
                        audio: audioBuffer,
                        mimetype: 'audio/mpeg',
                        ptt: false,
                        fileName: `${title}.mp3`
                    }, { quoted: msg });
                    console.log('✅ تم إرسال الصوت');
                } catch (audioError) {
                    console.error('❌ فشل إرسال الصوت:', audioError.message);
                    if (videoData.audio_url) {
                        await sock.sendMessage(chatId, {
                            text: `⚠️ تعذر رفع الصوت، إليك الرابط:\n${videoData.audio_url}`
                        }, { quoted: msg });
                    }
                }
            } else {
                // إذا لم يكن هناك صوت، نرسل إشعاراً
                if (videoSent) {
                    await sock.sendMessage(chatId, {
                        text: `⚠️ لم يتم العثور على صوت لهذا الفيديو.`
                    }, { quoted: msg });
                }
            }

            await sock.sendMessage(chatId, { react: { text: '✅', key: msg.key } });

        } catch (error) {
            console.error('❌ خطأ في توك:', error);

            try {
                points = loadPoints();
                points[sender] = (points[sender] || 0) + commandPrice;
                savePoints(points);
            } catch (e) {}

            if (!chatId) chatId = msg.key?.remoteJid || 'unknown';
            if (!sender) sender = msg.key?.participant || msg.key?.remoteJid || 'unknown';

            await sock.sendMessage(chatId, { react: { text: '❌', key: msg.key } });

            let errorMsg = '❌ فشل التحميل';
            if (error.code === 'ECONNABORTED') errorMsg = '⏰ انتهت المهلة';
            else if (error.response?.status === 403) errorMsg = '🚫 تم رفض الطلب';
            else if (error.response?.status === 404) errorMsg = '🔍 لا توجد نتائج';
            else if (error.response?.status >= 500) errorMsg = '🚫 الخدمة غير متاحة';
            else if (error.message.includes('لا يوجد فيديو')) errorMsg = '❌ لم نجد فيديو';
            else if (error.message.includes('لا توجد نتائج')) errorMsg = '🔍 لا توجد نتائج للبحث';

            await sendMessage(sock, chatId, [
                `${errorMsg}`,
                '💡 تم استرجاع نقاطك',
                '🔄 حاول مرة أخرى لاحقاً'
            ], msg);
        }
    }
};