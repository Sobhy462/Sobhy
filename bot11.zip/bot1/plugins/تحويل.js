// تحويل.js - تحويل نقاط من شخص لآخر (نسخة محسنة مع تجاهل المنشنات عند استخراج المبلغ)
const fs = require('fs');
const path = require('path');

const pointsPath = path.join(__dirname, '../data/points.json');
const MAX_TRANSFER = 5000000;

// التأكد من وجود المجلد والملف
if (!fs.existsSync(path.dirname(pointsPath))) {
    fs.mkdirSync(path.dirname(pointsPath), { recursive: true });
}
if (!fs.existsSync(pointsPath)) {
    fs.writeFileSync(pointsPath, JSON.stringify({}, null, 2));
}

function loadPoints() {
    try {
        const data = fs.readFileSync(pointsPath, 'utf8');
        return JSON.parse(data);
    } catch (err) {
        console.error('❌ خطأ في قراءة points.json:', err.message);
        return {};
    }
}

function savePoints(data) {
    try {
        if (fs.existsSync(pointsPath)) {
            fs.writeFileSync(pointsPath + '.bak', fs.readFileSync(pointsPath));
        }
        fs.writeFileSync(pointsPath, JSON.stringify(data, null, 2));
        const check = JSON.parse(fs.readFileSync(pointsPath, 'utf8'));
        return true;
    } catch (err) {
        console.error('❌ فشل حفظ points.json:', err.message);
        return false;
    }
}

// ========== دالة الإرسال ==========
async function sendMessage(sock, chatId, lines, quoted = null, mentions = []) {
    if (!Array.isArray(lines)) {
        lines = [lines];
    }

    let msg = `💸 تـحـويـل الـنـقـاط 💸\n`;
    msg += `━━━━━━━━━━━━━━━━━━━━\n`;
    for (const line of lines) {
        msg += `${line}\n`;
    }
    msg += `━━━━━━━━━━━━━━━━━━━━\n`;
    msg += `𝘽𝙔┇𝑴𝑨𝑲𝑰𝑴𝑨`;
    await sock.sendMessage(chatId, { text: msg, mentions }, { quoted: quoted });
}

module.exports = {
    command: ['تحويل', 'منح'],
    category: 'عام',
    description: '💰 تحويل نقاط من شخص لآخر',
    usage: '.تحويل [@منشن أو رد أو رقم] [المبلغ]',
    example: '.تحويل @منشن 500',

    async execute(sock, m) {
        try {
            const chatId = m.key.remoteJid;
            const senderId = m.key.participant || m.participant || m.key.remoteJid;

            const fullText = m.message?.conversation || m.message?.extendedTextMessage?.text || '';
            const args = fullText.trim().split(/\s+/);

            const mentioned = m.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
            const quoted = m.message?.extendedTextMessage?.contextInfo?.participant || null;

            // ===== استخراج الهدف =====
            let targetId = null;

            if (mentioned.length > 0) {
                targetId = mentioned[0];
            } else if (quoted) {
                targetId = quoted;
            } else if (args.length >= 2) {
                const raw = args[1].replace(/\D/g, '');
                if (raw && raw.length >= 9) {
                    targetId = `${raw}@s.whatsapp.net`;
                }
            }

            // ===== استخراج المبلغ (تجاهل المنشنات) =====
            let amount = 0;
            for (let i = 1; i < args.length; i++) {
                const arg = args[i];
                // تجاهل الكلمات التي تبدأ بـ @ أو تحتوي على @ (منشنات)
                if (arg.startsWith('@') || arg.includes('@')) continue;
                const num = parseInt(arg.replace(/\D/g, ''));
                if (!isNaN(num) && num > 0) {
                    amount = num;
                    break;
                }
            }

            // ===== عرض المساعدة =====
            if (!targetId || amount <= 0) {
                const lines = [
                    '💰 *تحويل النقاط*',
                    '',
                    '📌 الاستخدام:',
                    '.تحويل [@منشن] [المبلغ]',
                    '.تحويل [الرقم] [المبلغ]',
                    '(رد على رسالة الشخص) .تحويل [المبلغ]',
                    '',
                    '📝 أمثلة:',
                    '.تحويل @منشن 500',
                    '.تحويل 200 @منشن',
                    '.تحويل 500 (رد على رسالة)',
                    '',
                    `⚠️ الحد الأقصى: ${MAX_TRANSFER} نقطة`
                ];
                await sendMessage(sock, chatId, lines, m);
                return;
            }

            // ===== التحقق من صحة المبلغ =====
            if (amount > MAX_TRANSFER) {
                await sendMessage(sock, chatId, [
                    `❌ الحد الأقصى للتحويل هو ${MAX_TRANSFER} نقطة.`
                ], m);
                return;
            }

            if (targetId === senderId) {
                await sendMessage(sock, chatId, [
                    '❌ لا يمكنك تحويل النقاط لنفسك.'
                ], m);
                return;
            }

            // ===== قراءة النقاط =====
            const points = loadPoints();

            if (!points[senderId]) points[senderId] = 0;
            if (!points[targetId]) points[targetId] = 0;

            const senderPoints = points[senderId];

            if (senderPoints < amount) {
                await sendMessage(sock, chatId, [
                    `❌ رصيدك غير كافي.`,
                    `🪙 رصيدك الحالي: ${senderPoints}`,
                    `💰 المطلوب: ${amount}`,
                    `💔 تحتاج: ${amount - senderPoints} نقطة إضافية`
                ], m);
                return;
            }

            // ===== تنفيذ التحويل =====
            points[senderId] -= amount;
            points[targetId] += amount;

            const saved = savePoints(points);
            if (!saved) {
                await sendMessage(sock, chatId, [
                    '❌ حدث خطأ أثناء حفظ البيانات، حاول مرة أخرى.'
                ], m);
                return;
            }

            const checkPoints = loadPoints();
            if (checkPoints[senderId] !== points[senderId] || checkPoints[targetId] !== points[targetId]) {
                await sendMessage(sock, chatId, [
                    '⚠️ تحذير: قد لا يكون التحويل قد تم بشكل صحيح، تحقق من رصيدك.'
                ], m);
                return;
            }

            const lines = [
                `✅ تم تحويل *${amount}* نقطة بنجاح!`,
                '',
                `👤 من: @${senderId.split('@')[0]}`,
                `📥 إلى: @${targetId.split('@')[0]}`,
                `💰 رصيدك الحالي: ${points[senderId]} نقطة`
            ];

            await sendMessage(sock, chatId, lines, m, [senderId, targetId]);

        } catch (err) {
            console.error('❌ خطأ في أمر تحويل:', err);
            await sendMessage(sock, m.key.remoteJid, [
                '❌ حدث خطأ أثناء التحويل.',
                '📌 حاول مرة أخرى لاحقاً.'
            ], m);
        }
    }
};