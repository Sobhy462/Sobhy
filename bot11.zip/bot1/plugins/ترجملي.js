// ترجملي.js - ترجمة ونطق النصوص (مجاني)

const fs = require('fs');
const path = require('path');
const axios = require('axios');

// ========== معلومات اللغات ==========
const langsInfo = {
    'عربي': { code: 'ar', flag: '🇸🇦', features: 'لغة القرآن الكريم 🌙' },
    'انجليزي': { code: 'en', flag: '🇬🇧', features: 'الأكثر انتشاراً 🌍' },
    'فرنسي': { code: 'fr', flag: '🇫🇷', features: 'لغة الثقافة والفن 🎨' },
    'ألماني': { code: 'de', flag: '🇩🇪', features: 'لغة الصناعة والتكنولوجيا 🔧' },
    'إسباني': { code: 'es', flag: '🇪🇸', features: 'منتشرة في أمريكا اللاتينية 🌎' },
    'روسي': { code: 'ru', flag: '🇷🇺', features: 'لغة قوية سياسياً وعسكرياً' },
    'هندي': { code: 'hi', flag: '🇮🇳', features: 'لغة بوليوود والسينما 🎬' },
    'إيطالي': { code: 'it', flag: '🇮🇹', features: 'لغة الفن والموسيقى 🎵' },
    'صيني': { code: 'zh-CN', flag: '🇨🇳', features: 'الأكثر نطقاً في العالم' },
    'ياباني': { code: 'ja', flag: '🇯🇵', features: 'لغة الأنمي والمانجا ⚡' },
    'تركي': { code: 'tr', flag: '🇹🇷', features: 'لغة المسلسلات التركية 📺' },
    'كوري': { code: 'ko', flag: '🇰🇷', features: 'لغة الكيبوب والدراما 🎶' },
    'فارسي': { code: 'fa', flag: '🇮🇷', features: 'لغة الشعر والأدب 📖' },
    'برتغالي': { code: 'pt', flag: '🇵🇹', features: 'لغة البرازيل والكرة ⚽' },
    'هولندي': { code: 'nl', flag: '🇳🇱', features: 'لغة الطواحين 🌷' },
    'سويدي': { code: 'sv', flag: '🇸🇪', features: 'لغة الفايكنج ⚔️' },
    'يوناني': { code: 'el', flag: '🇬🇷', features: 'لغة الحضارة القديمة 🏛️' }
};

// ========== دالة الإرسال بتنسيق موحد ==========
async function sendMessage(sock, chatId, lines, quoted = null, mentions = []) {
    if (!Array.isArray(lines)) {
        lines = [lines];
    }

    let msg = `🌐 الـتـرجـمـة 🌐\n`;
    msg += `━━━━━━━━━━━━━━━━━━━━\n`;
    for (const line of lines) {
        msg += `${line}\n`;
    }
    msg += `━━━━━━━━━━━━━━━━━━━━\n`;
    msg += `𝘽𝙔┇𝑴𝑨𝑲𝑰𝑴𝑨`;
    
    await sock.sendMessage(chatId, { 
        text: msg, 
        mentions 
    }, { 
        quoted: quoted 
    });
}

// ========== دالة الترجمة ==========
async function translate(text, lang) {
    try {
        const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=${lang}&dt=t&q=${encodeURIComponent(text)}`;
        const res = await axios.get(url, {
            timeout: 10000,
            headers: { 'User-Agent': 'Mozilla/5.0' }
        });
        return res.data?.[0]?.map(x => x[0]).join('') || null;
    } catch {
        return null;
    }
}

// ========== دالة تحويل النص إلى صوت ==========
async function tts(text, lang, file) {
    const url = `https://translate.google.com/translate_tts?ie=UTF-8&q=${encodeURIComponent(text)}&tl=${lang}&client=tw-ob`;
    const res = await axios.get(url, {
        responseType: 'stream',
        timeout: 15000,
        headers: { 'User-Agent': 'Mozilla/5.0' }
    });
    const writer = fs.createWriteStream(file);
    res.data.pipe(writer);
    return new Promise((ok, err) => {
        writer.on('finish', ok);
        writer.on('error', err);
    });
}

// ========== دالة عرض اللغات ==========
function getLanguagesList() {
    const lines = ['📚 *اللغات المدعومة:*', ''];
    const langs = Object.keys(langsInfo);
    const half = Math.ceil(langs.length / 2);
    const firstCol = langs.slice(0, half);
    const secondCol = langs.slice(half);
    
    for (let i = 0; i < Math.max(firstCol.length, secondCol.length); i++) {
        const left = firstCol[i] ? `${langsInfo[firstCol[i]].flag} ${firstCol[i]}` : '';
        const right = secondCol[i] ? `${langsInfo[secondCol[i]].flag} ${secondCol[i]}` : '';
        if (left && right) {
            lines.push(`   ${left.padEnd(20)} ${right}`);
        } else if (left) {
            lines.push(`   ${left}`);
        } else if (right) {
            lines.push(`   ${right}`);
        }
    }
    
    lines.push('');
    lines.push('💡 استخدم: `.ترجملي لغة` (رد على رسالة)');
    lines.push('📝 مثال: `.ترجملي انجليزي`');
    lines.push('🎵 سيتم إرسال الترجمة نصاً وصوتاً');
    
    return lines;
}

// ========== الأمر الرئيسي ==========
module.exports = {
    command: ['ترجملي', 'ترجمة'],
    description: '🌐 ترجمة ونطق النصوص (مجاني)',
    category: 'عام',
    usage: '.ترجملي لغة (رد على رسالة)',

    async execute(sock, msg) {
        try {
            const chatId = msg.key.remoteJid;
            const sender = msg.key.participant || msg.key.remoteJid;
            const senderNumber = sender.split('@')[0];

            // ===== قراءة النص =====
            const fullText = msg.message?.conversation || 
                            msg.message?.extendedTextMessage?.text || '';

            // ===== التحقق من وجود رسالة مقتبسة =====
            const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
            
            // ===== عرض قائمة اللغات =====
            if (!fullText || fullText.trim() === '.ترجملي' || fullText.trim() === '.ترجمة') {
                const lines = getLanguagesList();
                return sendMessage(sock, chatId, lines, msg);
            }

            // ===== استخراج اسم اللغة =====
            const parts = fullText.trim().split(/\s+/);
            parts.shift(); // إزالة الأمر
            const langName = parts.join(' ').trim();

            // ===== إذا كان يريد وصف اللغات =====
            if (langName === 'وصف' || langName === 'اللغات' || langName === 'help') {
                const lines = getLanguagesList();
                return sendMessage(sock, chatId, lines, msg);
            }

            // ===== البحث عن اللغة =====
            const langKey = Object.keys(langsInfo).find(l => l.toLowerCase() === langName.toLowerCase());
            if (!langKey) {
                const lines = [
                    '❌ *لغة غير مدعومة*',
                    '',
                    '📚 اللغات المتاحة:',
                    ...Object.keys(langsInfo).map(l => `   ${langsInfo[l].flag} ${l}`),
                    '',
                    '📌 استخدم `.ترجملي وصف` لعرض القائمة كاملة'
                ];
                return sendMessage(sock, chatId, lines, msg);
            }

            // ===== التحقق من الرد على رسالة =====
            if (!quoted) {
                const lines = [
                    '⚠️ *يرجى الرد على رسالة نصية*',
                    '',
                    '📌 الصيغة: رد على رسالة ثم `.ترجملي لغة`',
                    '',
                    'مثال: `.ترجملي انجليزي` (رد على رسالة)'
                ];
                return sendMessage(sock, chatId, lines, msg);
            }

            // ===== استخراج النص من الرسالة المقتبسة =====
            const text =
                quoted.conversation ||
                quoted.extendedTextMessage?.text ||
                quoted.imageMessage?.caption ||
                quoted.videoMessage?.caption ||
                quoted.documentMessage?.caption ||
                null;

            if (!text) {
                return sendMessage(sock, chatId, [
                    '⚠️ *ما لقيت نص أترجمه*',
                    '',
                    '📌 تأكد من أن الرسالة المقتبسة تحتوي على نص',
                    '📌 يدعم: نصوص، تعليق صور، تعليق فيديوهات'
                ], msg);
            }

            // ===== رسالة جاري الترجمة =====
            await sock.sendMessage(chatId, {
                text: `⏳ *جاري الترجمة إلى ${langKey}...*\n━━━━━━━━━━━━━━━━━━━━\n${langsInfo[langKey].flag} ${langsInfo[langKey].features}`
            }, { quoted: msg });

            // ===== الترجمة =====
            const result = await translate(text, langsInfo[langKey].code);
            if (!result) {
                return sendMessage(sock, chatId, [
                    '❌ *فشلت الترجمة*',
                    '',
                    '📌 حاول مرة أخرى أو جرب لغة أخرى'
                ], msg);
            }

            // ===== إرسال الترجمة =====
            const translateMsg = 
                `🌐 *الترجمة — ${langsInfo[langKey].flag} ${langKey}*\n` +
                `━━━━━━━━━━━━━━━━━━━━\n` +
                `${result}\n` +
                `━━━━━━━━━━━━━━━━━━━━\n` +
                `📌 *الميزة:* ${langsInfo[langKey].features}\n` +
                `━━━━━━━━━━━━━━━━━━━━\n` +
                `𝘽𝙔┇𝑴𝑨𝑲𝑰𝑴𝑨`;

            await sock.sendMessage(chatId, {
                text: translateMsg,
                mentions: [sender]
            }, { quoted: msg });

            // ===== إنشاء وإرسال الصوت =====
            try {
                const file = path.join(__dirname, `tts_${Date.now()}.mp3`);
                await tts(result, langsInfo[langKey].code, file);

                if (fs.existsSync(file)) {
                    await sock.sendMessage(chatId, {
                        audio: fs.readFileSync(file),
                        mimetype: 'audio/mpeg',
                        ptt: false
                    }, { quoted: msg });
                    
                    fs.unlinkSync(file);
                }
            } catch (e) {
                console.log('⚠️ فشل إنشاء الصوت:', e.message);
                // لا نوقف التنفيذ إذا فشل الصوت
            }

        } catch (error) {
            console.error('❌ خطأ في أمر ترجملي:', error);
            
            const lines = [
                '❌ *حدث خطأ*',
                '',
                `📝 ${error.message || 'خطأ غير معروف'}`,
                '',
                '📌 حاول مرة أخرى لاحقاً'
            ];
            
            await sendMessage(sock, msg.key.remoteJid, lines, msg);
        }
    }
};