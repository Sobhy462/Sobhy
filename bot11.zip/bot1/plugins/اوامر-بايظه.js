// بايظه.js - فحص الأوامر البايظة أو الناقصة أو المتكررة

const fs = require('fs');
const path = require('path');

// ========== دالة الإرسال الموحدة ==========
async function sendMessage(sock, chatId, lines, quoted = null, mentions = []) {
    if (!Array.isArray(lines)) {
        lines = [lines];
    }

    let msg = `🔍 فـحـص الأوامر 🔍\n`;
    msg += `━━━━━━━━━━━━━━━━━━━━\n`;
    for (const line of lines) {
        if (line && line.trim()) {
            msg += `${line}\n`;
        }
    }
    msg += `━━━━━━━━━━━━━━━━━━━━\n`;
    msg += `𝘽𝙔┇𝑴𝑨𝑲𝑰𝑴𝑨`;

    await sock.sendMessage(chatId, { text: msg, mentions }, { quoted: quoted });
}

module.exports = {
    command: ['بايظه', 'فحص', 'مكرر'],
    category: 'نظام',
    description: '🔍 يكتشف الأوامر البايظة أو الناقصة أو المتكررة',
    status: 'on',
    version: '1.0',

    async execute(sock, msg) {
        try {
            const chatId = msg.key.remoteJid;
            const pluginDir = path.join(process.cwd(), 'plugins');

            // ===== التحقق من وجود مجلد الإضافات =====
            if (!fs.existsSync(pluginDir)) {
                await sendMessage(sock, chatId, [
                    '❌ *مجلد الإضافات غير موجود*',
                    '',
                    '📌 تأكد من وجود مجلد `plugins` في مسار البوت'
                ], msg);
                return;
            }

            // ===== قراءة الملفات =====
            const files = fs.readdirSync(pluginDir).filter(f => f.endsWith('.js'));
            if (files.length === 0) {
                await sendMessage(sock, chatId, [
                    '📭 *لا توجد ملفات إضافات*',
                    '',
                    '📌 مجلد `plugins` فارغ'
                ], msg);
                return;
            }

            const badPlugins = [];
            const seenCommands = new Map();

            // ===== فحص كل ملف =====
            for (const file of files) {
                const filePath = path.join(pluginDir, file);
                let plugin;
                try {
                    // مسح الكاش لإعادة التحميل
                    delete require.cache[require.resolve(filePath)];
                    plugin = require(filePath);
                } catch (err) {
                    badPlugins.push({
                        file: file,
                        issue: `❌ خطأ في التحميل: ${err.message.substring(0, 50)}`
                    });
                    continue;
                }

                // التحقق من وجود `command` و `execute`
                const cmds = plugin.command;
                const hasCommand = cmds && (Array.isArray(cmds) ? cmds.length > 0 : true);
                const hasExecute = typeof plugin.execute === 'function';

                if (!hasCommand) {
                    badPlugins.push({ file, issue: '⚠️ مفيش command' });
                }
                if (!hasExecute) {
                    badPlugins.push({ file, issue: '⚠️ مفيش execute' });
                }

                // التحقق من الأوامر المكررة
                if (Array.isArray(cmds)) {
                    for (const cmd of cmds) {
                        const lowerCmd = cmd.toLowerCase();
                        if (seenCommands.has(lowerCmd)) {
                            badPlugins.push({
                                file,
                                issue: `🔁 مكرر مع ${seenCommands.get(lowerCmd)}`
                            });
                        } else {
                            seenCommands.set(lowerCmd, file);
                        }
                    }
                } else if (typeof cmds === 'string') {
                    const lowerCmd = cmds.toLowerCase();
                    if (seenCommands.has(lowerCmd)) {
                        badPlugins.push({
                            file,
                            issue: `🔁 مكرر مع ${seenCommands.get(lowerCmd)}`
                        });
                    } else {
                        seenCommands.set(lowerCmd, file);
                    }
                }
            }

            // ===== عرض النتائج =====
            if (badPlugins.length === 0) {
                await sendMessage(sock, chatId, [
                    '✅ *مفيش أوامر بايظة ولا مكررة*',
                    '',
                    `📊 *عدد الملفات:* ${files.length}`,
                    '🎯 *كله تمام يا نجم*'
                ], msg);
                return;
            }

            const lines = [
                `⚠️ *تم العثور على ${badPlugins.length} مشكلة*`,
                '',
                `📊 *إجمالي الملفات:* ${files.length}`
            ];

            badPlugins.forEach((p, i) => {
                lines.push('');
                lines.push(`*${i + 1}. ${p.file}*`);
                lines.push(`   ${p.issue}`);
            });

            lines.push('');
            lines.push('📌 *نصيحة:* أصلح الملفات التي بها مشاكل');

            await sendMessage(sock, chatId, lines, msg);

        } catch (error) {
            console.error('❌ خطأ في أمر بايظه:', error);
            await sendMessage(sock, msg.key.remoteJid, [
                '❌ *حدث خطأ أثناء الفحص*',
                '',
                `📝 ${error.message || 'خطأ غير معروف'}`,
                '',
                '📌 حاول مرة أخرى لاحقاً'
            ], msg);
        }
    }
};