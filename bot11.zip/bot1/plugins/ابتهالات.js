// ابتهالات.js - تحميل ابتهالات دينية مقابل نقاط (نسخة محسنة)
const axios = require('axios');
const fs = require('fs');
const path = require('path');

const commandPrice = 50;
const APIFY_TOKEN = 'apify_api_Nosx6ch9Ua28pFgV1TFeurHCsbflPn21ezuh';

const pointsPath = path.join(__dirname, '../data/points.json');

if (!fs.existsSync(path.join(__dirname, '../data'))) fs.mkdirSync(path.join(__dirname, '../data'), { recursive: true });
if (!fs.existsSync(pointsPath)) fs.writeFileSync(pointsPath, JSON.stringify({}, null, 2));

function loadPoints() {
    try {
        return JSON.parse(fs.readFileSync(pointsPath));
    } catch {
        return {};
    }
}

function savePoints(data) {
    fs.writeFileSync(pointsPath, JSON.stringify(data, null, 2));
}

// ========== تنسيق النقاط ==========
function formatPoints(num) {
    if (num === undefined || num === null || isNaN(num)) return '0';
    num = Math.floor(num);
    if (num >= 1e15) return '∞';
    if (num >= 1e12) return (num / 1e12).toFixed(2) + ' تريليون';
    if (num >= 1e9) return (num / 1e9).toFixed(2) + ' مليار';
    if (num >= 1e6) return (num / 1e6).toFixed(2) + ' مليون';
    if (num >= 1e3) return (num / 1e3).toFixed(2) + ' ألف';
    return num.toString();
}

// ========== دالة الإرسال الموحدة ==========
async function sendMessage(sock, chatId, lines, quoted = null, mentions = []) {
    if (!Array.isArray(lines)) lines = [lines];
    let msg = `🎙️ ابـتـهـالات دينـيـة 🎙️\n━━━━━━━━━━━━━━━━━━━━\n`;
    for (const line of lines) {
        if (line && line.trim()) msg += `${line}\n`;
    }
    msg += `━━━━━━━━━━━━━━━━━━━━\n𝘽𝙔┇𝑴𝑨𝑲𝑰𝑴𝑨`;
    await sock.sendMessage(chatId, { text: msg, mentions }, { quoted: quoted });
}

// ========== البحث عبر TikWM (مع تجربة صيغ متعددة) ==========
async function searchViaTikWM(query) {
    const searchQueries = [
        `ابتهال ${query}`,
        `${query} ابتهال`,
        `${query} ديني`,
        `ابتهال ${query} ديني`,
        `${query} انشاد ديني`
    ];
    for (const searchTerm of searchQueries) {
        try {
            const apiUrl = `https://www.tikwm.com/api/feed/search?keywords=${encodeURIComponent(searchTerm)}`;
            const res = await axios.get(apiUrl, {
                timeout: 30000,
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                    'Referer': 'https://www.tikwm.com/',
                    'Origin': 'https://www.tikwm.com',
                    'Accept': 'application/json, text/plain, */*',
                    'Accept-Encoding': 'gzip, deflate, br',
                    'Accept-Language': 'en-US,en;q=0.9'
                }
            });
            if (res.status === 200 && res.data.code === 0 && res.data.data?.videos?.length > 0) {
                return res.data.data.videos;
            }
        } catch (e) {
            console.log(`⚠️ فشل البحث بـ "${searchTerm}":`, e.message);
        }
    }
    return [];
}

// ========== البحث عبر Apify (بديل) ==========
async function searchViaApify(query) {
    try {
        const apiUrl = 'https://api.apify.com/v2/acts/mu0i~tiktok-search-scraper/run-sync-get-dataset-items';
        const response = await axios.post(
            apiUrl,
            {
                queries: [`ابتهال ${query}`],
                resultType: 'videos',
                maxResultsPerQuery: 10,
                sortBy: 'relevance',
                includeDownloadUrls: true
            },
            {
                params: { token: APIFY_TOKEN },
                headers: { 'Content-Type': 'application/json' },
                timeout: 120000
            }
        );
        const data = Array.isArray(response.data) ? response.data : [];
        if (!data.length) return [];
        // تحويل البيانات إلى نفس شكل TikWM
        return data.map(v => ({
            title: v.description || 'ابتهال ديني',
            music: v.music_url || v.audio_url || v.noWatermarkUrl || v.url,
            music_info: {
                title: v.description || 'ابتهال ديني',
                play: v.music_url || v.audio_url || v.noWatermarkUrl || v.url
            },
            author: {
                nickname: v.authorUsername || v.authorNickname || 'مجهول'
            }
        })).filter(v => v.music);
    } catch (error) {
        console.error('❌ فشل جلب من Apify:', error.message);
        return [];
    }
}

// ========== تحميل الصوت ==========
async function downloadAudio(url) {
    try {
        const response = await axios.get(url, {
            responseType: 'arraybuffer',
            timeout: 60000,
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                'Referer': 'https://www.tiktok.com/'
            }
        });
        return Buffer.from(response.data);
    } catch (error) {
        console.error('❌ فشل تحميل الصوت:', error.message);
        return null;
    }
}

// ========== الأمر الرئيسي ==========
module.exports = {
    command: ['ابتهالات', 'ابتهال', 'انشاد'],
    category: 'وسائط',
    description: '🎙️ تحميل ابتهالات دينية مقابل نقاط',
    usage: '.ابتهالات [اسم الابتهال أو المنشد]',
    price: commandPrice,

    async execute(sock, msg, args) {
        let chatId, sender, points, userPoints, searchText;

        try {
            chatId = msg.key.remoteJid;
            sender = msg.key.participant || msg.key.remoteJid;

            points = loadPoints();
            userPoints = points[sender] || 0;

            // استخراج النص
            searchText = '';
            if (args && Array.isArray(args)) {
                searchText = args.join(' ').trim();
            }
            if (!searchText && msg.message?.conversation) {
                searchText = msg.message.conversation.replace(/^\.(ابتهالات|ابتهال|انشاد)\s*/i, '').trim();
            }
            if (!searchText && msg.message?.extendedTextMessage?.text) {
                searchText = msg.message.extendedTextMessage.text.replace(/^\.(ابتهالات|ابتهال|انشاد)\s*/i, '').trim();
            }

            // عرض المساعدة
            if (!searchText) {
                const lines = [
                    '📖 *كيفية الاستخدام:*',
                    '',
                    '📌 `.ابتهالات [اسم الابتهال أو المنشد]`',
                    '',
                    '📝 *أمثلة:*',
                    '   `.ابتهالات النقشبندي`',
                    '   `.ابتهالات مولاي`',
                    '   `.ابتهالات طه`',
                    '',
                    `💰 *السعر:* ${commandPrice} نقطة`,
                    `🪙 *رصيدك:* ${formatPoints(userPoints)} نقطة`,
                    '🎙️ *المصدر:* تيك توك'
                ];
                await sendMessage(sock, chatId, lines, msg, [sender]);
                return;
            }

            // التحقق من الرصيد
            if (userPoints < commandPrice) {
                const lines = [
                    '❌ *رصيد غير كافٍ*',
                    '',
                    `💰 سعر الخدمة: *${commandPrice} نقطة*`,
                    `💰 رصيدك الحالي: *${formatPoints(userPoints)} نقطة*`,
                    `💰 المتبقي: *${formatPoints(commandPrice - userPoints)} نقطة*`,
                    '',
                    '📌 يمكنك كسب النقاط عبر:',
                    '   • الفوز في المعارك ⚔️',
                    '   • هزيمة الوحوش 🐉',
                    '   • المشاركة في الفعاليات 🎯'
                ];
                await sendMessage(sock, chatId, lines, msg, [sender]);
                return;
            }

            // خصم النقاط مؤقتاً
            points[sender] = userPoints - commandPrice;
            savePoints(points);

            await sock.sendMessage(chatId, { react: { text: '⏳', key: msg.key } });

            // ===== البحث =====
            let videos = await searchViaTikWM(searchText);
            if (!videos.length) {
                console.log('⚠️ TikWM فشل، نحاول عبر Apify...');
                videos = await searchViaApify(searchText);
            }

            if (!videos.length) {
                points[sender] = (points[sender] || 0) + commandPrice;
                savePoints(points);
                await sock.sendMessage(chatId, { react: { text: '❌', key: msg.key } });
                await sendMessage(sock, chatId, [
                    '🔍 *لا توجد نتائج*',
                    '',
                    `📌 لم نجد ابتهالات لـ "${searchText}"`,
                    '📌 جرب كلمات بحث مختلفة مثل:',
                    '   • اسم منشد معروف (النقشبندي، طه)',
                    '   • كلمات الابتهال (مولاي، طه)',
                    '   • نوع الابتهال (ديني، إنشاد)',
                    '💡 تم استرجاع نقاطك'
                ], msg);
                return;
            }

            // ===== اختيار فيديو عشوائي =====
            const video = videos[Math.floor(Math.random() * videos.length)];
            const audioUrl = video.music || video.music_info?.play || video.music_info?.url;

            if (!audioUrl) {
                points[sender] = (points[sender] || 0) + commandPrice;
                savePoints(points);
                await sock.sendMessage(chatId, { react: { text: '❌', key: msg.key } });
                await sendMessage(sock, chatId, [
                    '❌ *لا يوجد صوت متاح*',
                    '',
                    '📌 هذا الفيديو لا يحتوي على صوت قابل للتحميل',
                    '💡 تم استرجاع نقاطك'
                ], msg);
                return;
            }

            // ===== تحميل الصوت =====
            let audioBuffer = await downloadAudio(audioUrl);
            if (!audioBuffer || audioBuffer.length < 1000) {
                // إرسال الرابط بدلاً من الصوت
                const videoTitle = video.title || searchText;
                const newBalance = points[sender];
                await sock.sendMessage(chatId, {
                    text: `⚠️ تعذر تحميل الصوت، إليك الرابط:\n${audioUrl}\n\n` +
                          `🎙️ *ابتهال ديني*\n` +
                          `📌 *العنوان:* ${videoTitle}\n` +
                          `🔍 *البحث:* ${searchText}\n` +
                          `💰 *تم خصم:* ${commandPrice} نقطة\n` +
                          `🪙 *الرصيد المتبقي:* ${formatPoints(newBalance)} نقطة`
                }, { quoted: msg });
                await sock.sendMessage(chatId, { react: { text: '⚠️', key: msg.key } });
                return;
            }

            // ===== إرسال الصوت =====
            const videoTitle = video.title || searchText;
            const newBalance = points[sender];
            const caption =
`🎙️ *ابتهال ديني*

📌 *العنوان:* ${videoTitle}
🔍 *البحث:* ${searchText}

✅ تم الإرسال بنجاح
💰 تم خصم ${commandPrice} نقطة
🪙 الرصيد المتبقي: ${formatPoints(newBalance)} نقطة`;

            try {
                await sock.sendMessage(chatId, {
                    audio: audioBuffer,
                    mimetype: 'audio/mpeg',
                    ptt: false,
                    fileName: `${videoTitle}.mp3`,
                    caption: caption
                }, { quoted: msg });
            } catch (audioError) {
                console.error('❌ فشل إرسال الصوت، نحاول كوثيقة:', audioError.message);
                try {
                    await sock.sendMessage(chatId, {
                        document: audioBuffer,
                        mimetype: 'audio/mpeg',
                        fileName: `${videoTitle}.mp3`,
                        caption: caption
                    }, { quoted: msg });
                } catch (docError) {
                    console.error('❌ فشل إرسال كوثيقة، نرسل الرابط:', docError.message);
                    await sock.sendMessage(chatId, {
                        text: `⚠️ تعذر رفع الصوت، إليك الرابط:\n${audioUrl}\n\n${caption}`
                    }, { quoted: msg });
                }
            }

            await sock.sendMessage(chatId, { react: { text: '✅', key: msg.key } });

        } catch (error) {
            console.error('❌ خطأ في ابتهالات:', error);

            try {
                points = loadPoints();
                points[sender] = (points[sender] || 0) + commandPrice;
                savePoints(points);
            } catch (e) {}

            if (!chatId) chatId = msg.key?.remoteJid || 'unknown';
            if (!sender) sender = msg.key?.participant || msg.key?.remoteJid || 'unknown';

            await sock.sendMessage(chatId, { react: { text: '❌', key: msg.key } });

            let errorMsg = '❌ حدث خطأ أثناء التحميل';
            if (error.code === 'ECONNABORTED') errorMsg = '⏰ انتهت المهلة';
            else if (error.response?.status === 403) errorMsg = '🚫 تم رفض الطلب';
            else if (error.response?.status === 404) errorMsg = '🔍 لا توجد نتائج';
            else if (error.response?.status >= 500) errorMsg = '🚫 الخدمة غير متاحة';

            await sendMessage(sock, chatId, [
                `${errorMsg}`,
                '💡 تم استرجاع نقاطك',
                '🔄 حاول مرة أخرى لاحقاً'
            ], msg);
        }
    }
};