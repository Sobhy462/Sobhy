// تصنيف.js - عرض أفضل 10 ممالك من حيث القوة (النقاط والمستوى مخفيان للمطورين والمخفيين، مع إخفاء المنشن فقط للمخفيين) + عرض الفرق في الأسفل
const fs = require('fs');
const path = require('path');
const { isFounder, isOwnerbot, isDeveloper, toLid } = require('../haykala/developer');

const pointsPath = path.join(__dirname, '../data/points.json');
const hiddenPath = path.join(__dirname, '../data/hidden-points.json');
const teamsPath = path.join(__dirname, '../data/teams.json');

// ===== مسارات التخزين المنفصل =====
const dataDir = path.join(__dirname, '../data/kingdom');
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

const MAIN_PATH = path.join(dataDir, 'main.json');
const SOLDIERS_PATH = path.join(dataDir, 'soldiers.json');
const WEAPONS_PATH = path.join(dataDir, 'weapons.json');
const ACCESSORIES_PATH = path.join(dataDir, 'accessories.json');
const STATS_PATH = path.join(dataDir, 'stats.json');
const ACTIVE_PATH = path.join(dataDir, 'active.json');

// ===== التأكد من وجود جميع الملفات =====
const allPaths = [MAIN_PATH, SOLDIERS_PATH, WEAPONS_PATH, ACCESSORIES_PATH, STATS_PATH, ACTIVE_PATH];
for (const p of allPaths) {
    if (!fs.existsSync(p)) fs.writeFileSync(p, JSON.stringify({}, null, 2));
}
if (!fs.existsSync(pointsPath)) fs.writeFileSync(pointsPath, JSON.stringify({}, null, 2));
if (!fs.existsSync(hiddenPath)) fs.writeFileSync(hiddenPath, JSON.stringify([], null, 2));
if (!fs.existsSync(teamsPath)) fs.writeFileSync(teamsPath, JSON.stringify({}, null, 2));

function loadJSON(file) { try { return JSON.parse(fs.readFileSync(file)); } catch { return {}; } }
function saveJSON(file, data) { 
    try {
        if (fs.existsSync(file)) fs.writeFileSync(file + '.bak', fs.readFileSync(file));
        fs.writeFileSync(file, JSON.stringify(data, null, 2));
        return true;
    } catch (e) {
        console.error('❌ فشل حفظ الملف:', file, e.message);
        return false;
    }
}

// ========== دوال التخزين المنفصل ==========
function loadUserData(jid) {
    const main = loadJSON(MAIN_PATH)[jid] || {};
    const soldiers = loadJSON(SOLDIERS_PATH)[jid] || {};
    const weapons = loadJSON(WEAPONS_PATH)[jid] || {};
    const accessories = loadJSON(ACCESSORIES_PATH)[jid] || {};
    const stats = loadJSON(STATS_PATH)[jid] || {};
    const active = loadJSON(ACTIVE_PATH)[jid] || {};

    return {
        level: main.level || 1,
        prosperity: main.prosperity || 0,
        lands: main.lands || 0,
        gold: main.gold || 0,
        name: main.name || `مملكة @${jid.split('@')[0]}`,
        owner: main.owner || jid,
        nameChangesUsed: main.nameChangesUsed || 0,
        soldiers: soldiers,
        weapons: weapons,
        accessories: accessories,
        pvpWins: stats.pvpWins || 0,
        pvpLosses: stats.pvpLosses || 0,
        monstersDefeated: stats.monstersDefeated || 0,
        lastActive: active.lastActive || Date.now()
    };
}

function userExists(jid) {
    const main = loadJSON(MAIN_PATH);
    return !!main[jid];
}

// ===== نظام الإخفاء =====
function getHiddenList() {
    try {
        if (fs.existsSync(hiddenPath)) {
            return JSON.parse(fs.readFileSync(hiddenPath));
        }
    } catch {}
    return [];
}

function isHiddenUser(jid) {
    try {
        const lid = toLid(jid);
        if (isFounder(lid) || isOwnerbot(lid) || isDeveloper(lid)) {
            return true;
        }
    } catch {}
    const hidden = getHiddenList();
    return hidden.includes(jid);
}

// ===== حساب القوة (للترتيب) =====
function calculateStats(level, soldiers, weapons, accessories) {
    soldiers = soldiers || {};
    weapons = weapons || {};
    accessories = accessories || {};
    let baseHealth = 100 + (level - 1) * 20;
    let baseAttack = 10 + (level - 1) * 5;
    let baseDefense = 5 + (level - 1) * 3;
    let totalAttack = baseAttack
        + (soldiers.normal || 0) * 2 + (soldiers.knight || 0) * 5
        + (soldiers.archer || 0) * 4 + (soldiers.eliteGuard || 0) * 8
        + (soldiers.dragonSpearman || 0) * 15 + (soldiers.legendaryCommander || 0) * 30
        + (weapons.ironSword || 0) * 10 + (weapons.legendaryBow || 0) * 20
        + (weapons.lightningSword || 0) * 40 + (weapons.giantHammer || 0) * 60
        + (weapons.deathBow || 0) * 80 + (weapons.destructionAxe || 0) * 100
        + (weapons.heroSword || 0) * 50 + (weapons.timeBow || 0) * 70
        + (weapons.eternalBlade || 0) * 120
        + (accessories.powerRing || 0) * 10 + (accessories.kingsCrown || 0) * 30
        + (accessories.heroMask || 0) * 20;
    let totalDefense = baseDefense
        + (soldiers.knight || 0) * 2 + (soldiers.eliteGuard || 0) * 4
        + (soldiers.dragonSpearman || 0) * 8 + (soldiers.legendaryCommander || 0) * 15
        + (weapons.goldenShield || 0) * 15 + (weapons.fireShield || 0) * 40
        + (weapons.godShield || 0) * 80
        + (accessories.protectionRing || 0) * 10 + (accessories.kingsCrown || 0) * 30
        + (accessories.shadowMask || 0) * 15 + (accessories.heroMask || 0) * 20;
    return { health: baseHealth, attack: totalAttack, defense: totalDefense };
}

function calculatePower(user) {
    const stats = calculateStats(user.level, user.soldiers, user.weapons, user.accessories);
    const soldierWeights = { normal: 1, knight: 3, archer: 2, eliteGuard: 5, dragonSpearman: 10, legendaryCommander: 20 };
    const weaponWeights = { ironSword: 2, goldenShield: 3, legendaryBow: 5, lightningSword: 8, giantHammer: 10, deathBow: 15, destructionAxe: 20, heroSword: 12, timeBow: 18, eternalBlade: 25, fireShield: 8, godShield: 18 };
    const accessoryWeights = { powerRing: 2, protectionRing: 2, kingsCrown: 8, shadowMask: 4, heroMask: 5 };
    let soldierPower = 0;
    for (const [type, count] of Object.entries(user.soldiers || {})) soldierPower += (soldierWeights[type] || 0) * count;
    let weaponPower = 0;
    for (const [type, count] of Object.entries(user.weapons || {})) weaponPower += (weaponWeights[type] || 0) * count;
    let accessoryPower = 0;
    for (const [type, count] of Object.entries(user.accessories || {})) accessoryPower += (accessoryWeights[type] || 0) * count;
    return Math.round(stats.health + stats.attack * 2 + stats.defense * 1.5 + user.level * 100 + user.prosperity * 50 + user.lands * 30 + soldierPower * 5 + weaponPower * 3 + accessoryPower * 2);
}

// ========== دالة جلب قائمة الفرق (مع إرجاع معلومات القائد) ==========
function getTeamsList(teamsData, kingdomData) {
    const teams = Object.entries(teamsData);
    if (teams.length === 0) return null;

    const result = [];
    for (const [teamName, teamData] of teams) {
        const leader = teamData.leader;
        const members = teamData.members || [];
        const memberCount = members.length + 1;

        let leaderName = 'غير معروف';
        const leaderUser = kingdomData[leader];
        if (leaderUser && leaderUser.name) {
            leaderName = leaderUser.name;
        } else if (leader) {
            leaderName = `@${leader.split('@')[0]}`;
        }

        result.push({
            name: teamName,
            leader: leaderName,
            leaderJid: leader,
            memberCount: memberCount,
            members: members,
            createdAt: teamData.createdAt || Date.now()
        });
    }
    return result;
}

// ========== دالة الإرسال ==========
async function sendMessage(sock, chatId, lines, quoted = null, mentions = []) {
    if (!Array.isArray(lines)) {
        lines = [lines];
    }

    let msg = `🏆 تـصـنـيـف الـمـمـالـك 🏆\n`;
    msg += `━━━━━━━━━━━━━━━━━━━━\n`;
    for (const line of lines) {
        if (line && line.trim()) {
            msg += `${line}\n`;
        }
    }
    msg += `━━━━━━━━━━━━━━━━━━━━\n`;
    msg += `𝘽𝙔┇𝑴𝑨𝑲𝑰𝑴𝑨`;
    await sock.sendMessage(chatId, { text: msg, mentions }, { quoted: quoted });
}

// ========== الأمر الرئيسي ==========
module.exports = {
    command: ['تصنيف', 'ترتيب', 'مماليك'],
    description: '🏆 عرض أفضل 10 ممالك من حيث القوة + قائمة الفرق في الأسفل (إخفاء المنشن فقط للمخفيين)',
    category: 'مملكة',
    usage: '.تصنيف',

    async execute(sock, msg) {
        try {
            const chatId = msg.key.remoteJid;
            const points = loadJSON(pointsPath);
            const teamsData = loadJSON(teamsPath);

            // ===== جمع جميع المستخدمين من النظام المنفصل =====
            const mainData = loadJSON(MAIN_PATH);
            const entries = Object.entries(mainData);

            if (entries.length === 0) {
                await sendMessage(sock, chatId, [
                    '📊 لا توجد مملكات مسجلة بعد.',
                    '',
                    '📌 كن أول من يؤسس مملكة بـ .لاعب جديد'
                ], msg);
                return;
            }

            // ===== حساب القوة لكل مملكة =====
            const ranked = entries.map(([jid, main]) => {
                const user = loadUserData(jid);
                const power = calculatePower(user);
                const userPoints = points[jid] || 0;
                const hidden = isHiddenUser(jid);
                return { jid, user, power, points: userPoints, hidden };
            });

            // ===== ترتيب تنازلي =====
            ranked.sort((a, b) => b.power - a.power);

            // ===== أخذ أفضل 10 =====
            const top = ranked.slice(0, 10);

            const lines = [
                '🏆 *أقوى 10 ممالك*',
                '',
                `📊 إجمالي الممالك: ${ranked.length}`,
                ''
            ];

            const mentions = [];

            top.forEach((item, index) => {
                const medal = index === 0 ? '🥇' : index === 1 ? '🥈' : index === 2 ? '🥉' : `${index + 1}.`;
                // ✅ إظهار اسم المملكة دائماً، ولا نضيف منشن إذا كان مخفياً
                const name = item.user.name || `مملكة @${item.jid.split('@')[0]}`;
                const pointsDisplay = item.hidden ? '🔒 مخفي' : item.points.toLocaleString();
                const levelDisplay = item.hidden ? '🔒 مخفي' : item.user.level;
                lines.push(`${medal} ${name}`);
                lines.push(`   💪 القوة: ${item.power.toLocaleString()}`);
                lines.push(`   💰 النقاط: ${pointsDisplay}`);
                lines.push(`   📈 المستوى: ${levelDisplay}`);
                lines.push(''); // سطر فارغ للفصل بين الممالك
                if (!item.hidden) {
                    mentions.push(item.jid);
                }
            });

            // ===== عرض الفرق في الأسفل مع إخفاء المنشن للقادة المخفيين =====
            const mainDataForTeams = {};
            for (const [jid, main] of Object.entries(loadJSON(MAIN_PATH))) {
                mainDataForTeams[jid] = { name: main.name };
            }

            const teamsList = getTeamsList(teamsData, mainDataForTeams);
            if (teamsList && teamsList.length > 0) {
                lines.push('━━━━━━━━━━━━━━━━━━━━');
                lines.push(`🏴 *قائمة الفرق (${teamsList.length})*`);
                lines.push('');

                for (const team of teamsList) {
                    const isLeaderHidden = isHiddenUser(team.leaderJid);
                    // ✅ نعرض اسم القائد كما هو، ولا نضيف منشن إذا كان مخفياً
                    const leaderDisplay = team.leader;
                    lines.push(`   🏴 *${team.name}*`);
                    lines.push(`      👑 القائد: ${leaderDisplay}`);
                    lines.push(`      👥 الأعضاء: ${team.memberCount}`);
                    lines.push('');
                    if (!isLeaderHidden && team.leaderJid) {
                        mentions.push(team.leaderJid);
                    }
                }

                lines.push('📌 *للانضمام:* .انضمام [اسم الفريق]');
                lines.push('📌 *لعرض فريقك:* .فريقي');
            } else {
                lines.push('━━━━━━━━━━━━━━━━━━━━');
                lines.push('📊 لا توجد فرق مسجلة حالياً.');
                lines.push('📌 كن أول من يؤسس فريق بـ .فريق جديد [الاسم]');
            }

            await sendMessage(sock, chatId, lines, msg, mentions);

        } catch (error) {
            console.error('✗ خطأ في أمر تصنيف:', error);
            await sendMessage(sock, msg.key.remoteJid, [
                '❌ حدث خطأ أثناء عرض التصنيف.',
                '📌 حاول مرة أخرى لاحقاً.'
            ], msg);
        }
    }
};