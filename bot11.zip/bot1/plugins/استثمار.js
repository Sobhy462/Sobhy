// استثمار.js - استثمار نقاط مع مدة انتظار ونتيجة متوقعة (ربح/خسارة) - نظام متكامل مع كولداون ومضاعفات
const fs = require('fs');
const path = require('path');

const dataDir = path.join(__dirname, '../data/kingdom');
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

const MAIN_PATH = path.join(dataDir, 'main.json');
const POINTS_PATH = path.join(__dirname, '../data/points.json');
const INVESTMENTS_PATH = path.join(dataDir, 'investments.json');

const allPaths = [MAIN_PATH, POINTS_PATH, INVESTMENTS_PATH];
for (const p of allPaths) {
    if (!fs.existsSync(p)) fs.writeFileSync(p, JSON.stringify({}, null, 2));
}

function loadJSON(file) { try { return JSON.parse(fs.readFileSync(file)); } catch { return {}; } }
function saveJSON(file, data) {
    try {
        if (fs.existsSync(file)) fs.writeFileSync(file + '.bak', fs.readFileSync(file));
        fs.writeFileSync(file, JSON.stringify(data, null, 2));
        return true;
    } catch (e) {
        console.error('❌ فشل حفظ:', file, e.message);
        return false;
    }
}

function userExists(jid) { return !!loadJSON(MAIN_PATH)[jid]; }

// ========== دوال الاستثمارات ==========
function loadInvestments() { return loadJSON(INVESTMENTS_PATH); }
function saveInvestments(data) { saveJSON(INVESTMENTS_PATH, data); }

function getInvestment(jid) {
    const investments = loadInvestments();
    return investments[jid] || null;
}

function setInvestment(jid, data) {
    const investments = loadInvestments();
    investments[jid] = data;
    saveInvestments(investments);
}

function deleteInvestment(jid) {
    const investments = loadInvestments();
    delete investments[jid];
    saveInvestments(investments);
}

// ========== حساب المدة بناءً على المبلغ ==========
function calculateDuration(amount) {
    // قاعدة: كل 100 نقطة = 1 دقيقة، مع حد أدنى 5 دقائق وحد أقصى 60 دقيقة
    let minutes = Math.floor(amount / 100);
    if (minutes < 5) minutes = 5;
    if (minutes > 60) minutes = 60;
    // إضافة عشوائية بسيطة (-2 إلى +2 دقيقة)
    minutes += Math.floor(Math.random() * 5) - 2;
    if (minutes < 3) minutes = 3;
    if (minutes > 65) minutes = 65;
    return minutes * 60 * 1000; // تحويل إلى ميلي ثانية
}

// ========== حساب نتيجة الاستثمار ==========
function calculateResult(amount) {
    // فرصة الربح 55%، الخسارة 45%
    const isWin = Math.random() < 0.55;
    let result = { success: isWin, multiplier: 0, change: 0, newAmount: 0, text: '' };

    if (isWin) {
        // مضاعف بين 1.5 و 3.5 (أضعاف)
        const multiplier = (Math.random() * 2) + 1.5; // 1.5 - 3.5
        const profit = Math.floor(amount * multiplier);
        result.multiplier = multiplier;
        result.change = profit;
        result.newAmount = amount + profit;
        result.text = `🎉 ربحت ${profit} نقطة (مضاعف ${multiplier.toFixed(1)}x)`;
    } else {
        // خسارة بين 20% و 80% من المبلغ
        const lossPercent = (Math.random() * 0.6) + 0.2; // 0.2 - 0.8
        const loss = Math.floor(amount * lossPercent);
        result.change = -loss;
        result.newAmount = amount - loss;
        if (result.newAmount < 0) result.newAmount = 0;
        result.text = `💔 خسرت ${loss} نقطة (${Math.round(lossPercent * 100)}%)`;
    }
    return result;
}

// ========== دالة معالجة نتيجة الاستثمار ==========
async function processInvestment(sock, jid, chatId) {
    const investment = getInvestment(jid);
    if (!investment) return;

    const now = Date.now();
    if (now < investment.finishTime) return; // لم يحن الوقت بعد

    // قراءة النقاط الحالية
    const points = loadJSON(POINTS_PATH);
    const currentPoints = points[jid] || 0;

    // حساب النتيجة
    const result = calculateResult(investment.amount);

    // تحديث النقاط
    const newPoints = currentPoints + result.change;
    points[jid] = newPoints;
    saveJSON(POINTS_PATH, points);

    // حذف الاستثمار من الملف
    deleteInvestment(jid);

    // إرسال رسالة النتيجة
    const senderNum = jid.split('@')[0];
    await sock.sendMessage(chatId, {
        text: `💼 نـتـيـجـة الاسـتـثـمـار 💼\n━━━━━━━━━━━━━━━━━━━━\n👤 @${senderNum}\n💰 المبلغ المستثمر: ${investment.amount} نقطة\n📊 ${result.text}\n💰 رصيدك الجديد: ${newPoints} نقطة\n━━━━━━━━━━━━━━━━━━━━\n𝘽𝙔┇𝑴𝑨𝑲𝑰𝑴𝑨`,
        mentions: [jid]
    }).catch(() => {});
}

// ========== دالة الإرسال ==========
async function sendMessage(sock, chatId, lines, quoted = null, mentions = []) {
    if (!Array.isArray(lines)) lines = [lines];
    let msg = `💼 اسـتـثـمـار 💼\n`;
    msg += `━━━━━━━━━━━━━━━━━━━━\n`;
    for (const line of lines) {
        msg += `${line}\n`;
    }
    msg += `━━━━━━━━━━━━━━━━━━━━\n`;
    msg += `𝘽𝙔┇𝑴𝑨𝑲𝑰𝑴𝑨`;
    await sock.sendMessage(chatId, { text: msg, mentions }, { quoted: quoted });
}

// ========== الأمر الرئيسي ==========
module.exports = {
    command: ['استثمار'],
    description: '💼 استثمار نقاط مع مدة انتظار ونتيجة متوقعة (ربح/خسارة)',
    category: 'مملكة',
    usage: '.استثمار [المبلغ]',
    example: '.استثمار 800',

    async execute(sock, msg) {
        try {
            const chatId = msg.key.remoteJid;
            const sender = msg.key.participant || msg.key.remoteJid;

            if (!userExists(sender)) {
                await sendMessage(sock, chatId, [
                    '❌ ليس لديك مملكة!',
                    '📌 استخدم .لاعب جديد لتأسيس مملكتك.'
                ], msg, [sender]);
                return;
            }

            const fullText = msg.message?.conversation || msg.message?.extendedTextMessage?.text || '';
            const args = fullText.trim().split(/\s+/);

            if (args.length < 2) {
                await sendMessage(sock, chatId, [
                    '📌 الاستخدام:',
                    '.استثمار [المبلغ]',
                    '',
                    '📝 مثال: .استثمار 800',
                    '📌 الحد الأدنى 100 نقطة، الحد الأقصى 50000 نقطة.',
                    '⏳ المدة تعتمد على المبلغ (تقريباً دقيقة لكل 100 نقطة).',
                    '📌 يمكنك تنفيذ استثمار واحد فقط في كل مرة.'
                ], msg, [sender]);
                return;
            }

            const amount = parseInt(args[1]);
            if (isNaN(amount) || amount < 100) {
                await sendMessage(sock, chatId, [
                    '❌ المبلغ يجب أن يكون رقماً لا يقل عن 100 نقطة.'
                ], msg, [sender]);
                return;
            }

            if (amount > 50000) {
                await sendMessage(sock, chatId, [
                    '❌ الحد الأقصى للاستثمار هو 50000 نقطة.'
                ], msg, [sender]);
                return;
            }

            // ===== التحقق من وجود استثمار نشط =====
            const activeInvestment = getInvestment(sender);
            if (activeInvestment) {
                const now = Date.now();
                if (now < activeInvestment.finishTime) {
                    const remaining = activeInvestment.finishTime - now;
                    const minutes = Math.floor(remaining / (60 * 1000));
                    const seconds = Math.floor((remaining % (60 * 1000)) / 1000);
                    await sendMessage(sock, chatId, [
                        '⏳ لديك استثمار نشط بالفعل!',
                        `📌 المبلغ المستثمر: ${activeInvestment.amount} نقطة`,
                        `⏳ الوقت المتبقي: ${minutes} دقيقة ${seconds} ثانية`,
                        '📌 انتظر حتى انتهاء المدة لتستثمر مرة أخرى.'
                    ], msg, [sender]);
                    return;
                } else {
                    // إذا انتهت المدة ولكن لم يتم معالجتها (لأي سبب)
                    await processInvestment(sock, sender, chatId);
                    // بعد المعالجة، نسمح بالاستثمار مرة أخرى
                }
            }

            // ===== تحميل النقاط =====
            const points = loadJSON(POINTS_PATH);
            const userPoints = points[sender] || 0;

            if (userPoints < amount) {
                await sendMessage(sock, chatId, [
                    `❌ رصيدك لا يكفي!`,
                    `💰 رصيدك الحالي: ${userPoints} نقطة`,
                    `💰 المبلغ المطلوب: ${amount} نقطة`
                ], msg, [sender]);
                return;
            }

            // ===== خصم المبلغ فوراً =====
            points[sender] = userPoints - amount;
            saveJSON(POINTS_PATH, points);

            // ===== حساب المدة =====
            const duration = calculateDuration(amount);
            const finishTime = Date.now() + duration;
            const minutes = Math.floor(duration / (60 * 1000));

            // ===== حفظ الاستثمار =====
            const investmentData = {
                amount: amount,
                startTime: Date.now(),
                duration: duration,
                finishTime: finishTime,
                status: 'pending'
            };
            setInvestment(sender, investmentData);

            // ===== إرسال رسالة التأكيد =====
            await sendMessage(sock, chatId, [
                `✅ تم استثمار ${amount} نقطة بنجاح!`,
                `⏳ المدة المتوقعة: ${minutes} دقيقة`,
                `💰 رصيدك الحالي: ${points[sender]} نقطة`,
                '',
                '📌 ستتلقى النتيجة تلقائياً عند انتهاء المدة.',
                '💡 يمكنك متابعة استثماراتك بـ .استثماراتي'
            ], msg, [sender]);

            // ===== تعيين المؤقت =====
            setTimeout(() => {
                processInvestment(sock, sender, chatId);
            }, duration + 2000); // زيادة 2 ثانية للتأكد من انتهاء المدة

        } catch (error) {
            console.error('✗ خطأ في أمر استثمار:', error);
            await sendMessage(sock, msg.key.remoteJid, [
                '❌ حدث خطأ أثناء تنفيذ الأمر.',
                '📌 حاول مرة أخرى لاحقاً.'
            ], msg);
        }
    }
};