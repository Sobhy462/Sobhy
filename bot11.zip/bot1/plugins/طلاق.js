// طلاق.js - نظام الطلاق والخلع (مع صورة من resources)
// حقوق ©️ 𝑴𝑨𝑲𝑰𝑴𝑨
const fs = require('fs');
const path = require('path');

const baseDir = path.join(__dirname, '..');
const dataDir = path.join(baseDir, 'data');
const resourcesDir = path.join(baseDir, 'resources');

const marriageFile = path.join(dataDir, 'marriages.json');
const pointsFile = path.join(dataDir, 'points.json');

// 🔥 المسار الثابت للصورة (في مجلد resources)
const divorceImagePath = path.join(resourcesDir, 'ط.jpg');

// التأكد من وجود المجلدات والملفات
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });
if (!fs.existsSync(resourcesDir)) fs.mkdirSync(resourcesDir, { recursive: true });
if (!fs.existsSync(marriageFile)) fs.writeFileSync(marriageFile, '{}');
if (!fs.existsSync(pointsFile)) fs.writeFileSync(pointsFile, '{}');

// ========== دوال JSON ==========
function loadJSON(file) {
  try { return JSON.parse(fs.readFileSync(file)); } catch { return {}; }
}

function saveJSON(file, data) {
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

// ========== دوال مساعدة محسنة ==========
function getPoints(jid) {
  const points = loadJSON(pointsFile);
  return points[jid] || 0;
}

function setPoints(jid, amount) {
  const points = loadJSON(pointsFile);
  points[jid] = amount;
  saveJSON(pointsFile, points);
}

function addPoints(jid, amount) {
  const points = loadJSON(pointsFile);
  points[jid] = (points[jid] || 0) + amount;
  saveJSON(pointsFile, points);
}

function getWifeValue(wife) {
  if (Array.isArray(wife)) return wife[1] || wife[0] || '';
  return wife || '';
}

function isMarried(jid, marriages) {
  for (const [husband, wifeData] of Object.entries(marriages)) {
    const wife = getWifeValue(wifeData);
    if (husband === jid || wife === jid) return true;
  }
  return false;
}

function getPartner(jid, marriages) {
  for (const [husband, wifeData] of Object.entries(marriages)) {
    const wife = getWifeValue(wifeData);
    if (husband === jid) return wife;
    if (wife === jid) return husband;
  }
  return null;
}

function getMarriagePair(jid, marriages) {
  for (const [husband, wifeData] of Object.entries(marriages)) {
    const wife = getWifeValue(wifeData);
    if (husband === jid || wife === jid) {
      return { husband, wife };
    }
  }
  return null;
}

// ========== دالة الإرسال مع الصورة ==========
async function sendWithImage(sock, chatId, imagePath, caption, quoted = null, mentions = []) {
  const validMentions = Array.isArray(mentions) ? mentions.filter(jid => jid && typeof jid === 'string' && jid.includes('@')) : [];
  const footer = `\n\n╭───────⎈───────╮\n🔥  𝑩𝑶𝑻: 『𝑴𝑨𝑲𝑰𝑴𝑨』\n📛 𝘼𝙇𝙇 𝙍𝙄𝙂𝙃𝙏𝙎 𝙍𝙀𝙎𝙀𝙍𝙑𝙀𝘿 ©️\n╰───────⎈───────╯\n𝘽𝙔┇𝑴𝑨𝑲𝑰𝑴𝑨`;
  const finalCaption = caption + footer;

  if (fs.existsSync(imagePath)) {
    try {
      const imageBuffer = fs.readFileSync(imagePath);
      await sock.sendMessage(chatId, {
        image: imageBuffer,
        caption: finalCaption,
        mentions: validMentions
      }, { quoted: quoted });
      return;
    } catch (err) {
      console.error('خطأ في إرسال صورة الطلاق:', err);
    }
  }
  await sock.sendMessage(chatId, {
    text: finalCaption,
    mentions: validMentions
  }, { quoted: quoted });
}

// ========== دالة الإرسال النصي (احتياطي) ==========
async function sendWithFooter(sock, chatId, content, quoted = null, mentions = []) {
  const validMentions = Array.isArray(mentions) ? mentions.filter(jid => jid && typeof jid === 'string' && jid.includes('@')) : [];
  const footer = `\n\n╭───────⎈───────╮\n🔥  𝑩𝑶𝑻: 『𝑴𝑨𝑲𝑰𝑴𝑨』\n📛 𝘼𝙇𝙇 𝙍𝙄𝙂𝙃𝙏𝙎 𝙍𝙀𝙎𝙀𝙍𝙑𝙀𝘿 ©️\n╰───────⎈───────╯\n𝘽𝙔┇𝑴𝑨𝑲𝑰𝑴𝑨`;
  const finalText = content + footer;
  await sock.sendMessage(chatId, {
    text: finalText,
    mentions: validMentions
  }, { quoted: quoted });
}

// ========== استخراج المنشن ==========
function extractMentionFromText(text) {
  const match = text.match(/@(\d+)/);
  if (match) {
    return `${match[1]}@s.whatsapp.net`;
  }
  return null;
}

// ========== الأمر الرئيسي ==========
module.exports = {
  command: ['طلاق'],
  category: 'عرس',
  description: 'الزوج يطلق أو الزوجة تخلع (يتم خصم 1000 نقطة من الطالب وإضافتها للآخر)',
  usage: '.طلاق (رد على الطرف الآخر أو منشنه)',

  async execute(sock, msg, args = []) {
    const sender = msg.key.participant || msg.key.remoteJid || '';
    const chatId = msg.key.remoteJid;

    // استخراج الهدف (منشن أو رد)
    const contextInfo = msg.message?.extendedTextMessage?.contextInfo || {};
    const mentionedJid = contextInfo.mentionedJid || [];
    const quotedParticipant = contextInfo.participant;

    let target = null;

    if (mentionedJid.length > 0) {
      target = mentionedJid[0];
    } else if (quotedParticipant) {
      target = quotedParticipant;
    } else if (args.length > 0) {
      const fullText = args.join(' ');
      const extracted = extractMentionFromText(fullText);
      if (extracted) {
        target = extracted;
      } else {
        const num = args[0].replace(/\D/g, '');
        if (num) target = num + '@s.whatsapp.net';
      }
    }

    if (!target) {
      await sendWithFooter(sock, chatId,
        '⚠️ يرجى الرد على رسالة الزوج/الزوجة أو منشنه/ها مع الأمر.\n📌 مثال: .طلاق @منشن',
        msg
      );
      return;
    }

    if (target === sender) {
      await sendWithFooter(sock, chatId, '🤦 لا يمكنك تنفيذ هذا الأمر على نفسك.', msg);
      return;
    }

    // تحميل البيانات
    const marriages = loadJSON(marriageFile);
    const points = loadJSON(pointsFile);

    // التحقق من وجود زواج بين الطرفين
    const pair = getMarriagePair(sender, marriages);
    if (!pair) {
      await sendWithFooter(sock, chatId, '❌ أنت لست متزوجاً!', msg, [sender]);
      return;
    }

    // التحقق من أن الهدف هو الزوج/الزوجة بالفعل
    if (pair.husband !== target && pair.wife !== target) {
      await sendWithFooter(sock, chatId,
        '❌ هذا الشخص ليس زوجك/زوجتك.',
        msg, [sender, target]
      );
      return;
    }

    // تحديد نوع الفسخ
    let type = '';
    let actorName = '';
    let targetName = '';

    if (sender === pair.husband) {
      type = 'طلاق';
      actorName = 'الزوج';
      targetName = 'الزوجة';
    } else {
      type = 'خلع';
      actorName = 'الزوجة';
      targetName = 'الزوج';
    }

    const cost = 1000;
    const senderPoints = getPoints(sender);

    if (senderPoints < cost) {
      await sendWithFooter(sock, chatId,
        `❌ لا تملك ${cost} نقطة ${type === 'طلاق' ? 'للطلاق' : 'للخلع'}.\n💰 رصيدك الحالي: ${senderPoints} نقطة`,
        msg, [sender]
      );
      return;
    }

    // تنفيذ الطلاق/الخلع
    const newSenderPoints = senderPoints - cost;
    setPoints(sender, newSenderPoints);
    addPoints(target, cost);

    // حذف الزواج
    delete marriages[pair.husband];
    saveJSON(marriageFile, marriages);

    // رسالة النجاح مع الصورة
    const successCaption = `
💔 *تم ${type === 'طلاق' ? 'الطلاق' : 'الخلع'} بنجاح* 💔

┏━━━━━━━━━━━━━━━┓
📋 *نوع الفسخ:* ${type === 'طلاق' ? 'طلاق' : 'خلع'}
👤 *الطالب (${actorName}):* @${sender.split('@')[0]}
👤 *الطرف الآخر (${targetName}):* @${target.split('@')[0]}
💸 *الرسوم:* ${cost} نقطة (خصمت من ${actorName})
💰 *رصيد ${actorName} الحالي:* ${newSenderPoints} نقطة
💎 *تم إضافة ${cost} نقطة إلى ${targetName}*
┗━━━━━━━━━━━━━━━┛

📌 يمكنكما الزواج مرة أخرى باستخدام .زواج @منشن
    `;

    await sendWithImage(sock, chatId, divorceImagePath, successCaption, msg, [sender, target]);
  }
};