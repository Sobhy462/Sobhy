// استكشاف.js - إرسال مستكشفين لاكتشاف أراضٍ جديدة والبحث عن الكنوز (حد أقصى 3 محاولات يومياً)
const fs = require('fs');
const path = require('path');

const pointsPath = path.join(__dirname, '../data/points.json');
const EXPLORE_PATH = path.join(__dirname, '../data/explore.json');

// ===== مسارات التخزين المنفصل =====
const dataDir = path.join(__dirname, '../data/kingdom');
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

const MAIN_PATH = path.join(dataDir, 'main.json');
const RESOURCES_PATH = path.join(dataDir, 'resources.json');
const SOLDIERS_PATH = path.join(dataDir, 'soldiers.json');
const WEAPONS_PATH = path.join(dataDir, 'weapons.json');
const ACCESSORIES_PATH = path.join(dataDir, 'accessories.json');
const POTIONS_PATH = path.join(dataDir, 'potions.json');
const SOULBOOK_PATH = path.join(dataDir, 'soulbook.json');
const COMPANION_PATH = path.join(dataDir, 'companion.json');
const STATS_PATH = path.join(dataDir, 'stats.json');
const ACTIVE_PATH = path.join(dataDir, 'active.json');

// ===== الثوابت =====
const MAX_DAILY_EXPLORES = 3; // الحد الأقصى لعدد محاولات الاستكشاف في اليوم

// ===== التأكد من وجود الملفات =====
const allPaths = [MAIN_PATH, RESOURCES_PATH, SOLDIERS_PATH, WEAPONS_PATH, ACCESSORIES_PATH, POTIONS_PATH, SOULBOOK_PATH, COMPANION_PATH, STATS_PATH, ACTIVE_PATH];
for (const p of allPaths) {
    if (!fs.existsSync(p)) fs.writeFileSync(p, JSON.stringify({}, null, 2));
}
if (!fs.existsSync(pointsPath)) fs.writeFileSync(pointsPath, JSON.stringify({}, null, 2));
if (!fs.existsSync(EXPLORE_PATH)) fs.writeFileSync(EXPLORE_PATH, JSON.stringify({}, null, 2));

function loadJSON(file) { try { return JSON.parse(fs.readFileSync(file)); } catch { return {}; } }
function saveJSON(file, data) {
    try {
        if (fs.existsSync(file)) fs.writeFileSync(file + '.bak', fs.readFileSync(file));
        fs.writeFileSync(file, JSON.stringify(data, null, 2));
        return true;
    } catch (e) {
        console.error('❌ فشل حفظ:', file, e.message);
        return false;
    }
}

// ========== دوال التخزين المنفصل ==========
function loadUserData(jid) {
    const main = loadJSON(MAIN_PATH)[jid] || {};
    const resources = loadJSON(RESOURCES_PATH)[jid] || {};
    const soldiers = loadJSON(SOLDIERS_PATH)[jid] || {};
    const weapons = loadJSON(WEAPONS_PATH)[jid] || {};
    const accessories = loadJSON(ACCESSORIES_PATH)[jid] || {};
    const potions = loadJSON(POTIONS_PATH)[jid] || {};
    const soulBook = loadJSON(SOULBOOK_PATH)[jid] || {};
    const companion = loadJSON(COMPANION_PATH)[jid] || null;
    const stats = loadJSON(STATS_PATH)[jid] || {};
    const active = loadJSON(ACTIVE_PATH)[jid] || {};

    return {
        level: main.level || 1,
        prosperity: main.prosperity || 0,
        lands: main.lands || 0,
        gold: main.gold || 0,
        name: main.name || `مملكة @${jid.split('@')[0]}`,
        owner: main.owner || jid,
        nameChangesUsed: main.nameChangesUsed || 0,
        resources: resources,
        soldiers: soldiers,
        weapons: weapons,
        accessories: accessories,
        potions: potions,
        soulBook: soulBook,
        companion: companion,
        pvpWins: stats.pvpWins || 0,
        pvpLosses: stats.pvpLosses || 0,
        monstersDefeated: stats.monstersDefeated || 0,
        lastActive: active.lastActive || Date.now()
    };
}

function saveUserData(jid, data) {
    const main = loadJSON(MAIN_PATH);
    main[jid] = {
        level: data.level || 1,
        prosperity: data.prosperity || 0,
        lands: data.lands || 0,
        gold: data.gold || 0,
        name: data.name || `مملكة @${jid.split('@')[0]}`,
        owner: data.owner || jid,
        nameChangesUsed: data.nameChangesUsed || 0
    };
    saveJSON(MAIN_PATH, main);

    const resources = loadJSON(RESOURCES_PATH);
    resources[jid] = data.resources || {};
    saveJSON(RESOURCES_PATH, resources);

    const soldiers = loadJSON(SOLDIERS_PATH);
    soldiers[jid] = data.soldiers || {};
    saveJSON(SOLDIERS_PATH, soldiers);

    const weapons = loadJSON(WEAPONS_PATH);
    weapons[jid] = data.weapons || {};
    saveJSON(WEAPONS_PATH, weapons);

    const accessories = loadJSON(ACCESSORIES_PATH);
    accessories[jid] = data.accessories || {};
    saveJSON(ACCESSORIES_PATH, accessories);

    const potions = loadJSON(POTIONS_PATH);
    potions[jid] = data.potions || {};
    saveJSON(POTIONS_PATH, potions);

    const soulBook = loadJSON(SOULBOOK_PATH);
    soulBook[jid] = data.soulBook || { pages: 0, spirits: [] };
    saveJSON(SOULBOOK_PATH, soulBook);

    const companion = loadJSON(COMPANION_PATH);
    companion[jid] = data.companion || null;
    saveJSON(COMPANION_PATH, companion);

    const stats = loadJSON(STATS_PATH);
    stats[jid] = {
        pvpWins: data.pvpWins || 0,
        pvpLosses: data.pvpLosses || 0,
        monstersDefeated: data.monstersDefeated || 0
    };
    saveJSON(STATS_PATH, stats);

    const active = loadJSON(ACTIVE_PATH);
    active[jid] = {
        lastActive: data.lastActive || Date.now()
    };
    saveJSON(ACTIVE_PATH, active);
}

function userExists(jid) {
    const main = loadJSON(MAIN_PATH);
    return !!main[jid];
}

// ========== دوال الاستكشاف ==========
function loadExplores() { return loadJSON(EXPLORE_PATH); }
function saveExplores(data) { saveJSON(EXPLORE_PATH, data); }

// ========== دالة إعادة تعيين المحاولات اليومية ==========
function resetDailyAttemptsIfNeeded(exploreData) {
    const now = new Date();
    const today = now.toDateString();
    for (const [jid, data] of Object.entries(exploreData)) {
        if (data.lastResetDate !== today) {
            data.dailyAttempts = 0;
            data.lastResetDate = today;
        }
    }
    return exploreData;
}

// ========== قائمة المكافآت المحتملة ==========
const rewardsPool = [
    // نقاط
    { type: 'points', amount: 100, weight: 20, name: '100 نقطة' },
    { type: 'points', amount: 250, weight: 15, name: '250 نقطة' },
    { type: 'points', amount: 500, weight: 10, name: '500 نقطة' },
    { type: 'points', amount: 1000, weight: 5, name: '1000 نقطة' },
    // موارد
    { type: 'wood', amount: 50, weight: 15, name: '50 خشب' },
    { type: 'wood', amount: 100, weight: 10, name: '100 خشب' },
    { type: 'stone', amount: 30, weight: 15, name: '30 حجر' },
    { type: 'stone', amount: 60, weight: 10, name: '60 حجر' },
    { type: 'iron', amount: 20, weight: 15, name: '20 حديد' },
    { type: 'iron', amount: 40, weight: 10, name: '40 حديد' },
    // أسلحة ودروع
    { type: 'weapon', key: 'goldenShield', name: '🛡️ درع ذهبي', count: 1, weight: 8 },
    { type: 'weapon', key: 'fireShield', name: '🔥 درع النار', count: 1, weight: 5 },
    { type: 'weapon', key: 'godShield', name: '✨ درع الملك', count: 1, weight: 3 },
    { type: 'weapon', key: 'ironSword', name: '🗡️ سيف حديدي', count: 1, weight: 10 },
    { type: 'weapon', key: 'legendaryBow', name: '🏹 قوس أسطوري', count: 1, weight: 7 },
    { type: 'weapon', key: 'lightningSword', name: '⚔️ سيف البرق', count: 1, weight: 6 },
    { type: 'weapon', key: 'eternalBlade', name: '⚔️ نصل الأبدية', count: 1, weight: 4 },
    // جنود
    { type: 'soldier', key: 'eliteGuard', name: '🛡️ حارس النخبة', count: 3, weight: 8 },
    { type: 'soldier', key: 'dragonSpearman', name: '🐉 منشق التنين', count: 2, weight: 6 },
    { type: 'soldier', key: 'legendaryCommander', name: '⚔️ قائد أسطوري', count: 1, weight: 4 },
    // إكسسوارات
    { type: 'accessory', key: 'powerRing', name: '💍 خاتم القوة', count: 1, weight: 8 },
    { type: 'accessory', key: 'protectionRing', name: '💍 خاتم الحماية', count: 1, weight: 8 },
    { type: 'accessory', key: 'shadowMask', name: '🎭 قناع الظل', count: 1, weight: 6 },
    { type: 'accessory', key: 'kingsCrown', name: '👑 تاج الملوك', count: 1, weight: 4 },
    // جرعات
    { type: 'potion', key: 'largeHeal', name: '🧪 جرعة شفاء كبيرة', count: 3, weight: 8 },
    { type: 'potion', key: 'energyPotion', name: '🧪 جرعة الطاقة', count: 2, weight: 6 },
    { type: 'potion', key: 'craftedHeal', name: '🧪 جرعة شفاء مصنعة', count: 2, weight: 5 },
    // صفحات روح
    { type: 'soulPage', amount: 2, weight: 10, name: '2 صفحة روح' },
    { type: 'soulPage', amount: 5, weight: 6, name: '5 صفحات روح' },
    // رفقاء
    { type: 'companion', key: 'dragon', name: '🐦 تنين أسطوري', power: 15, weight: 3 },
    { type: 'companion', key: 'otherworldDragon', name: '🐦 تنين العالم الآخر', power: 25, weight: 2 },
];

// دالة اختيار عشوائي بالوزن
function weightedRandom(arr) {
    const totalWeight = arr.reduce((sum, item) => sum + item.weight, 0);
    let random = Math.random() * totalWeight;
    for (const item of arr) {
        random -= item.weight;
        if (random <= 0) return item;
    }
    return arr[0];
}

// ========== توليد مكافآت الاستكشاف ==========
function generateExploreRewards(playerLevel) {
    const rewards = [];
    const count = Math.floor(Math.random() * 3) + 2;

    let legendaryChance = Math.min(5 + Math.floor(playerLevel / 100), 15);
    let rareChance = Math.min(20 + Math.floor(playerLevel / 50), 40);

    for (let i = 0; i < count; i++) {
        const roll = Math.random() * 100;
        let item;
        if (roll < legendaryChance) {
            const pool = rewardsPool.filter(r => r.weight >= 5 && (r.type === 'weapon' || r.type === 'companion' || r.type === 'accessory'));
            item = pool.length > 0 ? weightedRandom(pool) : weightedRandom(rewardsPool);
        } else if (roll < legendaryChance + rareChance) {
            const pool = rewardsPool.filter(r => r.weight >= 8);
            item = pool.length > 0 ? weightedRandom(pool) : weightedRandom(rewardsPool);
        } else {
            item = weightedRandom(rewardsPool);
        }
        rewards.push(item);
    }
    return rewards;
}

// ========== دالة الإرسال ==========
async function sendMessage(sock, chatId, lines, quoted = null, mentions = []) {
    if (!Array.isArray(lines)) lines = [lines];
    let msg = `🗺️ الاسـتـكـشـاف 🗺️\n`;
    msg += `━━━━━━━━━━━━━━━━━━━━\n`;
    for (const line of lines) {
        msg += `${line}\n`;
    }
    msg += `━━━━━━━━━━━━━━━━━━━━\n`;
    msg += `𝘽𝙔┇𝑴𝑨𝑲𝑰𝑴𝑨`;
    await sock.sendMessage(chatId, { text: msg, mentions }, { quoted: quoted });
}

// ========== الأمر الرئيسي ==========
module.exports = {
    command: ['استكشاف', 'مستكشف'],
    description: `🗺️ إرسال مستكشفين لاكتشاف أراضٍ جديدة والبحث عن الكنوز (حد أقصى ${MAX_DAILY_EXPLORES} محاولة يومياً)`,
    category: 'مملكة',
    usage: '.استكشاف',
    example: '.استكشاف',

    async execute(sock, msg) {
        try {
            const chatId = msg.key.remoteJid;
            const sender = msg.key.participant || msg.key.remoteJid;

            // ===== 1. التحقق من وجود مملكة =====
            if (!userExists(sender)) {
                await sendMessage(sock, chatId, [
                    `❌ @${sender.split('@')[0]}، ليس لديك مملكة.`,
                    '📌 استخدم .لاعب جديد لتأسيس مملكتك.'
                ], msg, [sender]);
                return;
            }

            // ===== 2. تحميل بيانات الاستكشاف وإعادة تعيين اليومية =====
            let explores = loadExplores();
            explores = resetDailyAttemptsIfNeeded(explores);

            // التأكد من وجود بيانات للمستخدم
            if (!explores[sender]) {
                explores[sender] = {
                    dailyAttempts: 0,
                    lastResetDate: new Date().toDateString(),
                    active: false,
                    startTime: 0,
                    duration: 0,
                    rewards: []
                };
            }

            const userExplore = explores[sender];
            const today = new Date().toDateString();

            // ===== 3. التحقق من عدد المحاولات اليومية =====
            if (userExplore.dailyAttempts >= MAX_DAILY_EXPLORES) {
                await sendMessage(sock, chatId, [
                    `⛔ @${sender.split('@')[0]}، لقد استنفذت جميع محاولات الاستكشاف اليومية (${MAX_DAILY_EXPLORES}).`,
                    `📌 يمكنك المحاولة مرة أخرى غداً.`,
                    `💡 عد غداً لإرسال المستكشفين في مهمة جديدة.`
                ], msg, [sender]);
                return;
            }

            // ===== 4. التحقق من وجود رحلة استكشافية نشطة =====
            if (userExplore.active) {
                const elapsed = Date.now() - userExplore.startTime;
                const remaining = userExplore.duration - elapsed;
                if (remaining > 0) {
                    const minutes = Math.ceil(remaining / 60000);
                    await sendMessage(sock, chatId, [
                        `⏳ @${sender.split('@')[0]}، المستكشفون في مهمة بالفعل!`,
                        `📌 سيعودون بعد حوالي ${minutes} دقيقة.`,
                        `💡 انتظر حتى يعودوا لإرسالهم في مهمة جديدة.`
                    ], msg, [sender]);
                    return;
                }
            }

            // ===== 5. تحديث عدد المحاولات اليومية =====
            userExplore.dailyAttempts += 1;
            userExplore.lastResetDate = today;

            // ===== 6. إرسال المستكشفين =====
            const user = loadUserData(sender);
            const exploreDuration = Math.floor(Math.random() * 5) + 5; // 5-10 دقائق
            const durationMs = exploreDuration * 60 * 1000;

            // توليد المكافآت المنتظرة
            const rewards = generateExploreRewards(user.level);

            // حفظ حالة الاستكشاف
            userExplore.active = true;
            userExplore.startTime = Date.now();
            userExplore.duration = durationMs;
            userExplore.rewards = rewards;
            saveExplores(explores);

            // ===== 7. رسالة البداية =====
            const remainingAttempts = MAX_DAILY_EXPLORES - userExplore.dailyAttempts;
            await sendMessage(sock, chatId, [
                `🗺️ @${sender.split('@')[0]} أرسل مستكشفيه لاكتشاف أراضٍ جديدة!`,
                ``,
                `⏳ المدة المتوقعة: ${exploreDuration} دقيقة`,
                `🔍 المستكشفون يبحثون عن كنوز وأراضٍ خصبة...`,
                `📊 المحاولات المتبقية اليوم: ${remainingAttempts}`,
                ``,
                `📌 سنخبرك عندما يعودون بما وجدوه.`
            ], msg, [sender]);

            // ===== 8. ضبط المؤقت للرد =====
            setTimeout(async () => {
                try {
                    const currentExplores = loadExplores();
                    const explore = currentExplores[sender];
                    if (!explore || !explore.active) return;

                    // ===== 9. تطبيق المكافآت =====
                    const points = loadJSON(pointsPath);
                    let userData = loadUserData(sender);
                    let rewardsText = [];
                    let totalPoints = 0;

                    // إزالة حالة الاستكشاف النشط
                    explore.active = false;
                    saveExplores(currentExplores);

                    // تطبيق كل مكافأة
                    for (const reward of explore.rewards) {
                        if (reward.type === 'points') {
                            points[sender] = (points[sender] || 0) + reward.amount;
                            totalPoints += reward.amount;
                            rewardsText.push(`💰 ${reward.amount} نقطة`);
                        } else if (reward.type === 'wood') {
                            userData.resources.wood = (userData.resources.wood || 0) + reward.amount;
                            rewardsText.push(`🪵 ${reward.amount} خشب`);
                        } else if (reward.type === 'stone') {
                            userData.resources.stone = (userData.resources.stone || 0) + reward.amount;
                            rewardsText.push(`🪨 ${reward.amount} حجر`);
                        } else if (reward.type === 'iron') {
                            userData.resources.iron = (userData.resources.iron || 0) + reward.amount;
                            rewardsText.push(`⛏️ ${reward.amount} حديد`);
                        } else if (reward.type === 'weapon') {
                            userData.weapons[reward.key] = (userData.weapons[reward.key] || 0) + (reward.count || 1);
                            rewardsText.push(`⚔️ ${reward.name} × ${reward.count || 1}`);
                        } else if (reward.type === 'soldier') {
                            userData.soldiers[reward.key] = (userData.soldiers[reward.key] || 0) + (reward.count || 1);
                            rewardsText.push(`👥 ${reward.name} × ${reward.count || 1}`);
                        } else if (reward.type === 'accessory') {
                            userData.accessories[reward.key] = (userData.accessories[reward.key] || 0) + (reward.count || 1);
                            rewardsText.push(`💍 ${reward.name} × ${reward.count || 1}`);
                        } else if (reward.type === 'potion') {
                            userData.potions[reward.key] = (userData.potions[reward.key] || 0) + (reward.count || 1);
                            rewardsText.push(`🧪 ${reward.name} × ${reward.count || 1}`);
                        } else if (reward.type === 'soulPage') {
                            userData.soulBook.pages = (userData.soulBook.pages || 0) + reward.amount;
                            rewardsText.push(`📖 ${reward.amount} صفحة روح`);
                        } else if (reward.type === 'companion') {
                            userData.companion = { name: reward.name, power: reward.power };
                            rewardsText.push(`🐦 ${reward.name} (قوته ${reward.power}%)`);
                        }
                    }

                    // زيادة الأراضي
                    const newLands = Math.floor(Math.random() * 5) + 2;
                    userData.lands = (userData.lands || 0) + newLands;
                    rewardsText.push(`🌍 ${newLands} أراضي جديدة`);

                    // حفظ البيانات
                    saveJSON(pointsPath, points);
                    saveUserData(sender, userData);

         // ===== 10. رسالة النتيجة =====
                    const totalRewards = rewardsText.join(' | ');
                    const remaining = MAX_DAILY_EXPLORES - (currentExplores[sender]?.dailyAttempts || 0);
                    const lines = [
                        `🗺️ @${sender.split('@')[0]}، عاد المستكشفون!`,
                        ``,
                        `🎉 *اكتشفوا أراضٍ جديدة ووجدوا كنوزاً!*`,
                        ``,
                        `📦 *المكتشفات:*`,
                        `   ${totalRewards}`,
                        ``,
                        `🌍 *الأراضي الجديدة:* +${newLands} (الإجمالي: ${userData.lands})`,
                        ...(totalPoints > 0 ? [`💰 *إجمالي النقاط المكتسبة:* ${totalPoints}`] : []),
                        ``,
                        `📊 *مملكتك الآن:*`,
                        `💰 نقاط: ${points[sender] || 0}`,
                        `🪵 خشب: ${userData.resources.wood || 0}`,
                        `🪨 حجر: ${userData.resources.stone || 0}`,
                        `⛏️ حديد: ${userData.resources.iron || 0}`,
                        `📖 صفحات روح: ${userData.soulBook.pages || 0}`,
                        ...(userData.companion ? [`🐦 الرفيق: ${userData.companion.name}`] : []),
                        ``,
                        `📊 المحاولات المتبقية اليوم: ${remaining}`,
                        `📌 استخدم .استكشاف مرة أخرى لإرسال المستكشفين في مهمة جديدة.`
                    ];

                    await sock.sendMessage(chatId, { 
                        text: `🗺️ الاسـتـكـشـاف 🗺️\n━━━━━━━━━━━━━━━━━━━━\n${lines.join('\n')}\n━━━━━━━━━━━━━━━━━━━━\n𝘽𝙔┇𝑴𝑨𝑲𝑰𝑴𝑨`,
                        mentions: [sender]
                    });

                } catch (err) {
                    console.error('✗ خطأ في رد الاستكشاف:', err);
                }
            }, durationMs);

        } catch (error) {
            console.error('✗ خطأ في أمر استكشاف:', error);
            await sendMessage(sock, msg.key.remoteJid, [
                '❌ حدث خطأ أثناء الاستكشاف.',
                '📌 حاول مرة أخرى لاحقاً.'
            ], msg);
        }
    }
};