// شغلي.js - تحميل صوت من يوتيوب (يدعم البحث والرابط) - نسخة محسنة لتجاوز 403
const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');
const os = require('os');
const https = require('https');

const pointsPath = path.join(__dirname, '../data/points.json');
const audioPrice = 100;

// ========== البحث عن yt-dlp ==========
function getYTDLP() {
    return new Promise((resolve) => {
        const possiblePaths = [
            '/data/data/com.termux/files/usr/bin/yt-dlp',
            'yt-dlp'
        ];
        for (const p of possiblePaths) {
            try {
                if (p === 'yt-dlp') {
                    const which = spawn('which', ['yt-dlp']);
                    let found = '';
                    which.stdout.on('data', (data) => { found = data.toString().trim(); });
                    which.on('close', () => {
                        if (found) resolve(found);
                    });
                } else if (fs.existsSync(p)) {
                    resolve(p);
                    return;
                }
            } catch (e) {}
        }
        try {
            const which = spawn('which', ['yt-dlp']);
            let found = '';
            which.stdout.on('data', (data) => { found = data.toString().trim(); });
            which.on('close', () => {
                if (found) resolve(found);
                else resolve(null);
            });
        } catch (e) {
            resolve(null);
        }
    });
}

// ========== دوال النقاط ==========
function loadPoints() {
    try {
        if (!fs.existsSync(pointsPath)) fs.writeFileSync(pointsPath, '{}');
        return JSON.parse(fs.readFileSync(pointsPath));
    } catch {
        return {};
    }
}

function savePoints(data) {
    fs.writeFileSync(pointsPath, JSON.stringify(data, null, 2));
}

// ========== تنسيق النقاط ==========
function formatPoints(num) {
    if (num === undefined || num === null || isNaN(num)) return '0';
    num = Math.floor(num);
    if (num >= 1e15) return '∞';
    if (num >= 1e12) return (num / 1e12).toFixed(2) + ' تريليون';
    if (num >= 1e9) return (num / 1e9).toFixed(2) + ' مليار';
    if (num >= 1e6) return (num / 1e6).toFixed(2) + ' مليون';
    if (num >= 1e3) return (num / 1e3).toFixed(2) + ' ألف';
    return num.toString();
}

// ========== دالة الإرسال المنسقة ==========
async function sendMessage(sock, chatId, lines, quoted = null, mentions = []) {
    if (!Array.isArray(lines)) lines = [lines];
    let msg = `🎵 تـحـمـيـل صـوت يـوتـيـوب 🎵\n━━━━━━━━━━━━━━━━━━━━\n`;
    for (const line of lines) {
        if (line && line.trim()) msg += `${line}\n`;
    }
    msg += `━━━━━━━━━━━━━━━━━━━━\n𝘽𝙔┇𝑴𝑨𝑲𝑰𝑴𝑨`;
    await sock.sendMessage(chatId, { text: msg, mentions }, { quoted: quoted });
}

// ========== تنسيق المدة ==========
function formatDuration(seconds) {
    if (!seconds || isNaN(seconds)) return 'غير معروف';
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = seconds % 60;
    if (h > 0) return `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
    return `${m}:${String(s).padStart(2, '0')}`;
}

// ========== تحميل الصورة ==========
function downloadImage(url, dest) {
    return new Promise((resolve, reject) => {
        const file = fs.createWriteStream(dest);
        https.get(url, (res) => {
            if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
                return downloadImage(res.headers.location, dest).then(resolve).catch(reject);
            }
            if (res.statusCode !== 200) return reject(new Error('فشل تحميل الصورة'));
            res.pipe(file);
            file.on('finish', () => { file.close(resolve); });
        }).on('error', reject);
    });
}

// ========== تشغيل yt-dlp مع خيارات تجاوز 403 ==========
function runYTDLP(ytdlpPath, args = []) {
    return new Promise((resolve, reject) => {
        // خيارات إضافية لتجاوز الحجب
        const defaultArgs = [
            '--no-check-certificate',
            '--geo-bypass',
            '--user-agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        ];
        const fullArgs = [...defaultArgs, ...args];
        console.log('🔄 تشغيل yt-dlp:', ytdlpPath, fullArgs.join(' '));
        const child = spawn(ytdlpPath, fullArgs, { env: process.env });
        let stdout = '', stderr = '';

        child.stdout.on('data', (data) => { stdout += data.toString(); });
        child.stderr.on('data', (data) => { stderr += data.toString(); });
        child.on('error', reject);
        child.on('close', (code) => {
            console.log('yt-dlp exited with code', code);
            console.log('stdout:', stdout);
            console.log('stderr:', stderr);
            if (code === 0) resolve(stdout.trim());
            else reject(new Error(stderr || stdout || 'فشل تنفيذ yt-dlp'));
        });
    });
}

// ========== التحقق من رابط يوتيوب ==========
function isYouTubeLink(text) {
    return /https?:\/\/(www\.|m\.)?(youtube\.com|youtu\.be)\/\S+/i.test(text);
}

// ========== الأمر الرئيسي ==========
module.exports = {
    command: ['شغلي'],
    category: 'وسائط',
    description: '🎵 تحميل صوت من يوتيوب (بحث أو رابط)',
    usage: '.شغلي [اسم الفيديو أو الرابط]',
    price: audioPrice,

    async execute(sock, msg, args) {
        let chatId, sender, points, userPoints, query;

        try {
            chatId = msg.key.remoteJid;
            sender = msg.key.participant || msg.key.remoteJid;

            points = loadPoints();
            userPoints = points[sender] || 0;

            // استخراج النص
            query = '';
            if (args && Array.isArray(args)) {
                query = args.join(' ').trim();
            }
            if (!query && msg.message?.conversation) {
                query = msg.message.conversation.replace(/^\.شغلي\s*/i, '').trim();
            }
            if (!query && msg.message?.extendedTextMessage?.text) {
                query = msg.message.extendedTextMessage.text.replace(/^\.شغلي\s*/i, '').trim();
            }

            // عرض المساعدة
            if (!query) {
                const lines = [
                    '🎵 *تحميل صوت من يوتيوب*',
                    '',
                    '📌 الاستخدام:',
                    '.شغلي [اسم الفيديو] - بحث عن صوت',
                    '.شغلي [رابط] - تحميل من رابط',
                    '',
                    `💰 السعر: ${audioPrice} نقطة`,
                    '',
                    '📝 أمثلة:',
                    '.شغلي سكن الليل فيروز',
                    '.شغلي https://youtu.be/xxxxx'
                ];
                await sendMessage(sock, chatId, lines, msg);
                return;
            }

            // التحقق من الرصيد
            if (userPoints < audioPrice) {
                const lines = [
                    '❌ *نقاط غير كافية*',
                    '',
                    `💰 السعر: ${audioPrice} نقطة`,
                    `🪙 رصيدك: ${formatPoints(userPoints)} نقطة`,
                    `💔 تحتاج: ${formatPoints(audioPrice - userPoints)} نقطة إضافية`
                ];
                await sendMessage(sock, chatId, lines, msg, [sender]);
                return;
            }

            // خصم النقاط مؤقتاً
            points[sender] = userPoints - audioPrice;
            savePoints(points);

            await sock.sendMessage(chatId, { react: { text: '⏳', key: msg.key } });

            // ===== العثور على مسار yt-dlp =====
            const ytdlpPath = await getYTDLP();
            if (!ytdlpPath) {
                points[sender] = (points[sender] || 0) + audioPrice;
                savePoints(points);
                await sock.sendMessage(chatId, { react: { text: '❌', key: msg.key } });
                await sendMessage(sock, chatId, [
                    '❌ yt-dlp غير مثبت على النظام',
                    '📌 لتثبيته: `pkg install yt-dlp`',
                    '💡 تم استرجاع نقاطك'
                ], msg);
                return;
            }

            // ===== تحضير الملفات المؤقتة =====
            const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'ytaudio-'));
            const thumbPath = path.join(tempDir, 'thumb.jpg');
            const audioPath = path.join(tempDir, 'audio.mp3');

            let videoUrl, title, durationRaw, thumbnail;
            const isLink = isYouTubeLink(query);

            // ===== جلب معلومات الفيديو (مع خيارات إضافية لتجاوز 403) =====
            let infoResult;
            try {
                const infoArgs = [
                    '--print', '%(title)s|||%(webpage_url)s|||%(duration)s|||%(thumbnail)s',
                    '--skip-download', '--no-playlist',
                    '--extractor-args', 'youtube:player_client=android,web;skip=dash'
                ];
                if (isLink) {
                    infoArgs.push(query);
                } else {
                    infoArgs.push(`ytsearch1:${query}`, '--default-search', 'ytsearch');
                }
                infoResult = await runYTDLP(ytdlpPath, infoArgs);
            } catch (infoError) {
                fs.rmSync(tempDir, { recursive: true, force: true });
                points[sender] = (points[sender] || 0) + audioPrice;
                savePoints(points);
                await sock.sendMessage(chatId, { react: { text: '❌', key: msg.key } });
                await sendMessage(sock, chatId, [
                    `❌ فشل جلب معلومات الفيديو: ${infoError.message || 'خطأ غير معروف'}`,
                    '💡 تم استرجاع نقاطك',
                    '🔄 حاول مرة أخرى'
                ], msg);
                return;
            }

            if (!infoResult) {
                fs.rmSync(tempDir, { recursive: true, force: true });
                points[sender] = (points[sender] || 0) + audioPrice;
                savePoints(points);
                await sock.sendMessage(chatId, { react: { text: '❌', key: msg.key } });
                await sendMessage(sock, chatId, ['❌ لم يتم العثور على نتائج', '💡 تم استرجاع نقاطك'], msg);
                return;
            }

            const parts = infoResult.split('|||');
            title = parts[0] || 'بدون عنوان';
            videoUrl = parts[1] || query;
            durationRaw = parseInt(parts[2]) || 0;
            thumbnail = parts[3] || null;

            const duration = formatDuration(durationRaw);

            // ===== تحميل الصورة المصغرة =====
            if (thumbnail) {
                try { await downloadImage(thumbnail, thumbPath); } catch (e) { console.log('⚠️ فشل تحميل الصورة'); }
            }

            // ===== تحميل الصوت (مع خيارات إضافية) =====
            try {
                const audioArgs = [
                    '-x', '--audio-format', 'mp3', '--audio-quality', '0',
                    '--extract-audio', '--no-playlist',
                    '--extractor-args', 'youtube:player_client=android,web;skip=dash',
                    videoUrl, '-o', audioPath
                ];
                await runYTDLP(ytdlpPath, audioArgs);
            } catch (audioError) {
                fs.rmSync(tempDir, { recursive: true, force: true });
                points[sender] = (points[sender] || 0) + audioPrice;
                savePoints(points);
                await sock.sendMessage(chatId, { react: { text: '❌', key: msg.key } });
                await sendMessage(sock, chatId, [
                    `❌ فشل تحميل الصوت: ${audioError.message || 'خطأ غير معروف'}`,
                    '💡 تأكد من اتصال الإنترنت وحاول مرة أخرى',
                    '💡 تم استرجاع نقاطك'
                ], msg);
                return;
            }

            // ===== التحقق من وجود ملف الصوت =====
            let audioFile = null;
            if (fs.existsSync(audioPath)) {
                audioFile = audioPath;
            } else {
                const files = fs.readdirSync(tempDir).filter(f => f.endsWith('.mp3'));
                if (files.length) {
                    audioFile = path.join(tempDir, files[0]);
                }
            }

            if (!audioFile) {
                fs.rmSync(tempDir, { recursive: true, force: true });
                points[sender] = (points[sender] || 0) + audioPrice;
                savePoints(points);
                await sock.sendMessage(chatId, { react: { text: '❌', key: msg.key } });
                await sendMessage(sock, chatId, ['❌ لم يتم العثور على ملف الصوت', '💡 تم استرجاع نقاطك'], msg);
                return;
            }

            // ===== الرصيد الجديد =====
            const newBalance = points[sender];

            // ===== الكابتشن =====
            const caption = 
`『⏯️┇𝐒𝐀𝐓𝐔𝐑𝐍 𝐁𝐎𝐓 𝐘𝐎𝐔𝐓𝐔𝐁𝐄┇⏯️』

*❐═━━━━═╊⊰🪐⊱╉═━━━━═❐*
*❐↞┇الـعـنـوان📇↞ ${title} ┇*
*❐↞┇الـرابـط🖇️↞ ${videoUrl} ┇*
*❐↞┇الـمـدة⏱️↞ ${duration} ┇*
*❐↞┇الـنـقـاط💰↞ -${audioPrice} ┇*
*❐↞┇رصيدك🪙↞ ${formatPoints(newBalance)} ┇*
*❐═━━━━═╊⊰🪐⊱╉═━━━━═❐*
> *𝑩𝒀┇𝑴𝑨𝑲𝑰𝑴𝑨 𝑩𝑶𝑻*`;

            await sock.sendMessage(chatId, { react: { text: '✅', key: msg.key } });

            // ===== إرسال الصورة مع الكابتشن =====
            if (fs.existsSync(thumbPath)) {
                await sock.sendMessage(chatId, {
                    image: fs.readFileSync(thumbPath),
                    caption: caption
                }, { quoted: msg });
            } else {
                await sock.sendMessage(chatId, { text: caption }, { quoted: msg });
            }

            // ===== إرسال الصوت =====
            const audioBuffer = fs.readFileSync(audioFile);
            try {
                await sock.sendMessage(chatId, {
                    audio: audioBuffer,
                    mimetype: 'audio/mpeg',
                    fileName: `${title}.mp3`,
                    ptt: false
                }, { quoted: msg });
            } catch (audioError) {
                console.error('❌ فشل إرسال الصوت، نحاول كوثيقة:', audioError.message);
                try {
                    await sock.sendMessage(chatId, {
                        document: audioBuffer,
                        mimetype: 'audio/mpeg',
                        fileName: `${title}.mp3`,
                        caption: caption
                    }, { quoted: msg });
                } catch (docError) {
                    console.error('❌ فشل إرسال كوثيقة، نرسل الرابط:', docError.message);
                    await sock.sendMessage(chatId, {
                        text: `⚠️ تعذر رفع الصوت، إليك الرابط:\n${videoUrl}\n\n${caption}`
                    }, { quoted: msg });
                }
            }

            // ===== تنظيف الملفات المؤقتة =====
            try { fs.rmSync(tempDir, { recursive: true, force: true }); } catch (e) {}

        } catch (error) {
            console.error('❌ خطأ في شغلي:', error);

            try {
                points = loadPoints();
                points[sender] = (points[sender] || 0) + audioPrice;
                savePoints(points);
            } catch (e) {}

            if (!chatId) chatId = msg.key?.remoteJid || 'unknown';
            if (!sender) sender = msg.key?.participant || msg.key?.remoteJid || 'unknown';

            await sock.sendMessage(chatId, { react: { text: '❌', key: msg.key } });

            let errorMsg = '❌ حدث خطأ أثناء التحميل';
            if (error.message?.includes('ytsearch')) errorMsg = '🔍 لا توجد نتائج للبحث';
            else if (error.message?.includes('timeout')) errorMsg = '⏰ انتهت المهلة';
            else if (error.code === 'ENOENT') errorMsg = '❌ yt-dlp غير مثبت، يرجى تثبيته';
            else if (error.message?.includes('403')) errorMsg = '🚫 تم رفض الطلب (403)، قد يكون الرابط محجوباً أو الفيديو غير متاح';

            await sendMessage(sock, chatId, [
                `${errorMsg}`,
                '💡 تم استرجاع نقاطك',
                '🔄 حاول مرة أخرى'
            ], msg);
        }
    }
};