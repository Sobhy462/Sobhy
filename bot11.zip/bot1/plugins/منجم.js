// منجم.js - استكشاف منجم للحصول على حديد وأحجار كريمة ونقاط (مع تايمر موثوق)
const fs = require('fs');
const path = require('path');

const dataDir = path.join(__dirname, '../data/kingdom');
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

const MAIN_PATH = path.join(dataDir, 'main.json');
const RESOURCES_PATH = path.join(dataDir, 'resources.json');
const TIMERS_PATH = path.join(dataDir, 'timers.json'); // ✅ ملف منفصل للتواقيت

const allPaths = [MAIN_PATH, RESOURCES_PATH, TIMERS_PATH];
for (const p of allPaths) {
    if (!fs.existsSync(p)) fs.writeFileSync(p, JSON.stringify({}, null, 2));
}

function loadJSON(file) { try { return JSON.parse(fs.readFileSync(file)); } catch { return {}; } }
function saveJSON(file, data) {
    try {
        fs.writeFileSync(file, JSON.stringify(data, null, 2));
        // ✅ التحقق من الحفظ بقراءة الملف
        const check = JSON.parse(fs.readFileSync(file));
        return true;
    } catch (e) {
        console.error('❌ فشل حفظ:', file, e.message);
        return false;
    }
}

function loadUserData(jid) {
    const main = loadJSON(MAIN_PATH)[jid] || {};
    const resources = loadJSON(RESOURCES_PATH)[jid] || {};
    const timers = loadJSON(TIMERS_PATH)[jid] || {};
    return {
        level: main.level || 1,
        resources: resources,
        // ✅ جميع التواقيت من ملف منفصل
        lastMine: timers.lastMine || 0,
        mineCount: timers.mineCount || 0,
        lastSea: timers.lastSea || 0,
        seaCount: timers.seaCount || 0,
        lastForest: timers.lastForest || 0,
        forestCount: timers.forestCount || 0,
        lastDungeon: timers.lastDungeon || 0,
        dungeonCount: timers.dungeonCount || 0
    };
}

function saveUserData(jid, data) {
    // حفظ البيانات الرئيسية
    const main = loadJSON(MAIN_PATH);
    main[jid] = { level: data.level || 1 };
    saveJSON(MAIN_PATH, main);

    // حفظ الموارد
    const resources = loadJSON(RESOURCES_PATH);
    resources[jid] = data.resources || {};
    saveJSON(RESOURCES_PATH, resources);

    // ✅ حفظ التواقيت في ملف منفصل
    const timers = loadJSON(TIMERS_PATH);
    if (!timers[jid]) timers[jid] = {};
    timers[jid] = {
        ...timers[jid],
        lastMine: data.lastMine || 0,
        mineCount: data.mineCount || 0,
        lastSea: data.lastSea || 0,
        seaCount: data.seaCount || 0,
        lastForest: data.lastForest || 0,
        forestCount: data.forestCount || 0,
        lastDungeon: data.lastDungeon || 0,
        dungeonCount: data.dungeonCount || 0
    };
    saveJSON(TIMERS_PATH, timers);
}

function userExists(jid) { return !!loadJSON(MAIN_PATH)[jid]; }

async function sendMessage(sock, chatId, lines, quoted = null, mentions = []) {
    if (!Array.isArray(lines)) lines = [lines];
    let msg = `⛏️ اسـتـكـشـاف مـنـجـم ⛏️\n━━━━━━━━━━━━━━━━━━━━\n`;
    for (const line of lines) msg += `${line}\n`;
    msg += `━━━━━━━━━━━━━━━━━━━━\n𝘽𝙔┇𝑴𝑨𝑲𝑰𝑴𝑨`;
    await sock.sendMessage(chatId, { text: msg, mentions }, { quoted: quoted });
}

module.exports = {
    command: 'منجم',
    description: '⛏️ استكشاف منجم للحصول على حديد وأحجار كريمة ونقاط',
    category: 'مملكة',
    usage: '.منجم',
    async execute(sock, msg) {
        try {
            const chatId = msg.key.remoteJid;
            const sender = msg.key.participant || msg.key.remoteJid;

            if (!userExists(sender)) {
                await sendMessage(sock, chatId, ['❌ ليس لديك مملكة!'], msg, [sender]);
                return;
            }

            const user = loadUserData(sender);
            const now = Date.now();
            // كولداون 12 ساعة
            if (user.lastMine && (now - user.lastMine) < 12 * 60 * 60 * 1000) {
                const remaining = 12 * 60 * 60 * 1000 - (now - user.lastMine);
                const hours = Math.floor(remaining / (60 * 60 * 1000));
                const mins = Math.floor((remaining % (60 * 60 * 1000)) / (60 * 1000));
                await sendMessage(sock, chatId, [
                    `⏳ انتظر ${hours} ساعة ${mins} دقيقة قبل استكشاف المنجم مرة أخرى.`
                ], msg, [sender]);
                return;
            }

            const level = user.level;
            const ironBonus = Math.floor(level * 0.5) + 10;
            const gems = Math.floor(Math.random() * 5) + 1;
            const points = Math.floor(Math.random() * 50) + (level * 2);

            user.resources.iron = (user.resources.iron || 0) + ironBonus;
            user.lastMine = now;
            user.mineCount = (user.mineCount || 0) + 1;
            saveUserData(sender, user);

            const pointsPath = path.join(__dirname, '../data/points.json');
            const pts = loadJSON(pointsPath);
            pts[sender] = (pts[sender] || 0) + points;
            saveJSON(pointsPath, pts);

            await sendMessage(sock, chatId, [
                `✅ استكشفت المنجم بنجاح!`,
                `⛏️ حصلت على:`,
                `   +${ironBonus} حديد`,
                `   💎 ${gems} أحجار كريمة (رمزية)`,
                `   💰 +${points} نقطة`,
                `📊 عدد مرات الاستكشاف: ${user.mineCount}`
            ], msg, [sender]);

        } catch (error) {
            console.error('✗ خطأ في منجم:', error);
            await sendMessage(sock, msg.key.remoteJid, ['❌ حدث خطأ.'], msg);
        }
    }
};