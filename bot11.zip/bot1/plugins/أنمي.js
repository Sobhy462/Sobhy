// انمي.js - البحث عن معلومات الأنمي من AniList مع ترجمة القصة

const axios = require('axios');

// ========== ترجمة التصنيفات ==========
const genreMap = {
    'Action': 'أكشن',
    'Adventure': 'مغامرة',
    'Comedy': 'كوميديا',
    'Drama': 'دراما',
    'Fantasy': 'فانتازيا',
    'Supernatural': 'خارق للطبيعة',
    'Romance': 'رومانسية',
    'Slice of Life': 'حياتي',
    'Mystery': 'غموض',
    'Psychological': 'نفسي',
    'Sci-Fi': 'خيال علمي',
    'Horror': 'رعب',
    'Thriller': 'إثارة',
    'Sports': 'رياضة',
    'Music': 'موسيقى',
    'School': 'مدرسي',
    'Historical': 'تاريخي',
    'Mecha': 'ميكا',
    'Shounen': 'شونين',
    'Shoujo': 'شوجو',
    'Seinen': 'سينن',
    'Josei': 'جوسي',
    'Ecchi': 'إيتشي',
    'Harem': 'حريم',
    'Magic': 'سحر',
    'Martial Arts': 'فنون قتالية',
    'Parody': 'محاكاة ساخرة',
    'Samurai': 'ساموراي',
    'Vampire': 'مصاصو دماء',
    'Demons': 'شياطين',
    'Angels': 'ملائكة',
    'Military': 'عسكري',
    'Police': 'شرطي',
    'Space': 'فضاء',
    'Isekai': 'إيسيكاي'
};

// ========== ترجمة الحالة ==========
const statusMap = {
    'FINISHED': '✅ منتهي',
    'RELEASING': '🔄 قيد العرض',
    'NOT_YET_RELEASED': '⏳ لم يصدر بعد',
    'CANCELLED': '❌ ملغي',
    'HIATUS': '⏸️ متوقف مؤقتاً',
    'UNKNOWN': 'غير معروف'
};

// ========== ترجمة النوع ==========
const formatMap = {
    'TV': '📺 مسلسل تلفزيوني',
    'TV_SHORT': '📺 مسلسل قصير',
    'MOVIE': '🎬 فيلم',
    'SPECIAL': '⭐ خاص',
    'OVA': '📀 أوفا',
    'ONA': '💻 أونا',
    'MUSIC': '🎵 موسيقي',
    'MANGA': '📖 مانجا',
    'NOVEL': '📚 رواية',
    'ONE_SHOT': '📄 فصل واحد'
};

// ========== دالة الإرسال بتنسيق موحد ==========
async function sendMessage(sock, chatId, lines, quoted = null, mentions = []) {
    if (!Array.isArray(lines)) {
        lines = [lines];
    }

    let msg = `🎌 مـعـلـومـات الأنـمـي 🎌\n`;
    msg += `━━━━━━━━━━━━━━━━━━━━\n`;
    for (const line of lines) {
        if (line && line.trim()) {
            msg += `${line}\n`;
        }
    }
    msg += `━━━━━━━━━━━━━━━━━━━━\n`;
    msg += `𝘽𝙔┇𝑴𝑨𝑲𝑰𝑴𝑨`;
    
    await sock.sendMessage(chatId, { 
        text: msg, 
        mentions 
    }, { 
        quoted: quoted 
    });
}

// ========== دالة الترجمة ==========
async function translateText(text) {
    try {
        if (!text || text.length < 10) return text;
        
        const cleanText = text.replace(/[^a-zA-Z0-9\u0600-\u06FF\s.,!?()']/g, ' ');
        
        const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=en&tl=ar&dt=t&q=${encodeURIComponent(cleanText)}`;
        const response = await axios.get(url, {
            timeout: 10000,
            headers: { 'User-Agent': 'Mozilla/5.0' }
        });
        
        if (response.data?.[0]) {
            return response.data[0].map(x => x[0]).join('');
        }
        return text;
    } catch (error) {
        console.log('⚠️ فشل الترجمة، سيتم عرض النص الأصلي');
        return text;
    }
}

// ========== دالة تنسيق النص ==========
function cleanText(text) {
    if (!text) return 'لا توجد معلومات متوفرة';
    return text.replace(/<[^>]+>/g, '').trim();
}

// ========== ترجمة التصنيفات ==========
function translateGenres(genres) {
    if (!genres || genres.length === 0) return 'غير معروف';
    return genres.map(g => genreMap[g] || g).join('، ');
}

// ========== استخراج اسم الكاتب ==========
function getStaffNames(staff) {
    if (!staff || !staff.edges) return 'غير معروف';
    
    const mainStaff = staff.edges
        .filter(edge => edge.role === 'Story' || edge.role === 'Original Story' || edge.role === 'Writer')
        .map(edge => edge.node.name.full);
    
    return mainStaff.length > 0 ? mainStaff.join('، ') : 'غير معروف';
}

// ========== الأمر الرئيسي ==========
module.exports = {
    command: ['أنمي'],
    description: '🎌 البحث عن معلومات الأنمي من AniList',
    category: 'عام',
    usage: '.انمي اسم الأنمي',

    async execute(sock, msg) {
        try {
            const chatId = msg.key.remoteJid;
            const sender = msg.key.participant || msg.key.remoteJid;

            // ===== قراءة النص =====
            const fullText = msg.message?.conversation || 
                            msg.message?.extendedTextMessage?.text || 
                            msg.message?.imageMessage?.caption || '';

            // ===== استخراج اسم الأنمي =====
            const parts = fullText.trim().split(' ').slice(1);
            
            if (parts.length === 0) {
                const lines = [
                    '❗ *يرجى كتابة اسم الأنمي*',
                    '',
                    '📌 الصيغة: `.انمي اسم الأنمي`',
                    '',
                    '📝 مثال: `.انمي ناروتو`',
                    '📝 مثال: `.انمي ون بيس`',
                    '📝 مثال: `.انمي سولو ليفلينج`'
                ];
                return sendMessage(sock, chatId, lines, msg);
            }

            const queryText = parts.join(' ');

            // ===== استعلام AniList =====
            const query = `
                query ($search: String) {
                    Media(search: $search, type: ANIME) {
                        title {
                            romaji
                            english
                            native
                        }
                        description(asHtml: false)
                        coverImage {
                            large
                        }
                        siteUrl
                        averageScore
                        episodes
                        startDate {
                            year
                        }
                        status
                        format
                        genres
                        studios {
                            edges {
                                node {
                                    name
                                }
                                isMain
                            }
                        }
                        staff {
                            edges {
                                role
                                node {
                                    name {
                                        full
                                    }
                                }
                            }
                        }
                        popularity
                        favourites
                    }
                }
            `;

            // ===== إرسال طلب البحث =====
            const response = await axios.post('https://graphql.anilist.co', {
                query,
                variables: { search: queryText }
            }, {
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                timeout: 15000
            });

            const anime = response.data.data.Media;

            if (!anime) {
                const lines = [
                    '❌ *لم يتم العثور على الأنمي*',
                    '',
                    '📌 حاول كتابة الاسم بشكل صحيح',
                    '📌 تأكد من الإملاء',
                    '',
                    '💡 مثال: `.انمي ناروتو`',
                    '💡 مثال: `.انمي ون بيس`'
                ];
                return sendMessage(sock, chatId, lines, msg);
            }

            // ===== استخراج المعلومات =====
            const titleEnglish = anime.title?.english || anime.title?.romaji || 'غير معروف';
            const titleNative = anime.title?.native || 'غير متوفر';
            const description = cleanText(anime.description || 'لا توجد معلومات متوفرة');
            const score = anime.averageScore ? `${anime.averageScore}%` : 'غير متوفر';
            const episodes = anime.episodes ? `${anime.episodes} حلقة` : 'غير معروف';
            const year = anime.startDate?.year || 'غير معروفة';
            const status = statusMap[anime.status] || anime.status || 'غير معروف';
            const format = formatMap[anime.format] || anime.format || 'غير معروف';
            const genres = translateGenres(anime.genres);
            const popularity = anime.popularity || 0;
            const favourites = anime.favourites || 0;
            const staff = getStaffNames(anime.staff);

            // ===== استخراج الاستوديوهات =====
            let studioNames = [];
            if (anime.studios?.edges) {
                studioNames = anime.studios.edges
                    .filter(e => e.isMain)
                    .map(e => e.node.name);
            }
            const studios = studioNames.length > 0 ? studioNames.join('، ') : 'غير معروف';

            // ===== ترجمة القصة للعربية (بدون رسالة انتظار) =====
            let translatedDescription = description;
            
            if (description && description.length > 10) {
                const hasEnglish = /[a-zA-Z]/.test(description);
                if (hasEnglish) {
                    translatedDescription = await translateText(description);
                }
            }

            // ===== بناء الرسالة =====
            const lines = [
                `📺 *الاسم:* ${titleEnglish}`,
                `🈷️ *الاسم الياباني:* ${titleNative}`,
                `✍️ *الكاتب:* ${staff}`,
                `━━━━━━━━━━━━━━━━━━━━`,
                `⭐ *التقييم:* ${score}`,
                `🎬 *الحلقات:* ${episodes}`,
                `📅 *السنة:* ${year}`,
                `📊 *الحالة:* ${status}`,
                `🎞️ *النوع:* ${format}`,
                `🏢 *الاستوديو:* ${studios}`,
                `🏷️ *التصنيفات:* ${genres}`,
                `━━━━━━━━━━━━━━━━━━━━`,
                `❤️ *المفضلة:* ${favourites.toLocaleString()}`,
                `👥 *الشعبية:* ${popularity.toLocaleString()}`,
                `━━━━━━━━━━━━━━━━━━━━`,
                `📖 *القصة:*`,
                `${translatedDescription}`,
                `━━━━━━━━━━━━━━━━━━━━`,
                `🔗 *الرابط:* ${anime.siteUrl || 'غير متوفر'}`
            ];

            // ===== إرسال الصورة مع المعلومات =====
            if (anime.coverImage?.large) {
                await sock.sendMessage(chatId, {
                    image: { url: anime.coverImage.large },
                    caption: lines.join('\n'),
                    mentions: [sender]
                }, { quoted: msg });
            } else {
                await sendMessage(sock, chatId, lines, msg, [sender]);
            }

        } catch (error) {
            console.error('❌ خطأ في أمر انمي:', error);

            let lines = [
                '❌ *حدث خطأ*',
                '',
                `📝 ${error.message || 'خطأ غير معروف'}`,
                '',
                '📌 حاول مرة أخرى لاحقاً',
                '📌 تأكد من كتابة الاسم بشكل صحيح'
            ];

            if (error.code === 'ECONNABORTED' || error.code === 'ETIMEDOUT') {
                lines = [
                    '⏳ *انتهت المهلة*',
                    '',
                    '📌 الخادم بطيء، حاول مرة أخرى',
                    '📌 أو جرب اسماً آخر'
                ];
            }

            await sendMessage(sock, msg.key.remoteJid, lines, msg);
        }
    }
};