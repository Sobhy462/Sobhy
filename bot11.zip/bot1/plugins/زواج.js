// زواج.js - نظام الزواج المتكامل (مع صورة عشوائية من resources/1.jpg إلى 14.jpg)
// حقوق ©️ 𝑴𝑨𝑲𝑰𝑴𝑨
const fs = require('fs');
const path = require('path');

const baseDir = path.join(__dirname, '..');
const dataDir = path.join(baseDir, 'data');
const resourcesDir = path.join(baseDir, 'resources');

const marriageFile = path.join(dataDir, 'marriages.json');
const pointsFile = path.join(dataDir, 'points.json');
const requestsFile = path.join(dataDir, 'marriage_requests.json');

// التأكد من وجود المجلدات والملفات
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });
if (!fs.existsSync(resourcesDir)) fs.mkdirSync(resourcesDir, { recursive: true });
if (!fs.existsSync(marriageFile)) fs.writeFileSync(marriageFile, '{}');
if (!fs.existsSync(pointsFile)) fs.writeFileSync(pointsFile, '{}');
if (!fs.existsSync(requestsFile)) fs.writeFileSync(requestsFile, '{}');

// ========== دوال JSON ==========
function loadJSON(file) {
  try { return JSON.parse(fs.readFileSync(file)); } catch { return {}; }
}

function saveJSON(file, data) {
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

// ========== دالة استخراج النص ==========
function getMessageText(msg) {
  try {
    if (msg.message?.conversation) return msg.message.conversation;
    if (msg.message?.extendedTextMessage?.text) return msg.message.extendedTextMessage.text;
    if (msg.message?.imageMessage?.caption) return msg.message.imageMessage.caption;
    if (msg.message?.videoMessage?.caption) return msg.message.videoMessage.caption;
    if (msg.message?.documentMessage?.caption) return msg.message.documentMessage.caption;
    if (msg.message?.buttonsResponseMessage?.selectedDisplayText)
      return msg.message.buttonsResponseMessage.selectedDisplayText;
    if (msg.message?.listResponseMessage?.singleSelectReply?.selectedDisplayText)
      return msg.message.listResponseMessage.singleSelectReply.selectedDisplayText;
    for (const key of Object.keys(msg.message || {})) {
      if (msg.message[key]?.text) return msg.message[key].text;
      if (msg.message[key]?.caption) return msg.message[key].caption;
    }
    return '';
  } catch {
    return '';
  }
}

// ========== دوال النقاط ==========
function getPoints(jid) {
  const points = loadJSON(pointsFile);
  return points[jid] || 0;
}

function setPoints(jid, amount) {
  const points = loadJSON(pointsFile);
  points[jid] = amount;
  saveJSON(pointsFile, points);
}

function addPoints(jid, amount) {
  const points = loadJSON(pointsFile);
  points[jid] = (points[jid] || 0) + amount;
  saveJSON(pointsFile, points);
}

function findRequestById(id, db) {
  if (db[id]) return id;
  const alt1 = id.replace(/@s\.whatsapp\.net/, '@lid');
  if (db[alt1]) return alt1;
  const alt2 = id.replace(/@lid/, '@s.whatsapp.net');
  if (db[alt2]) return alt2;
  return null;
}

function isMarried(jid, marriages) {
  for (const [husband, wifeArray] of Object.entries(marriages)) {
    const wife = wifeArray[1] || wifeArray;
    if (husband === jid || wife === jid) return true;
  }
  return false;
}

function getPartner(jid, marriages) {
  for (const [husband, wifeArray] of Object.entries(marriages)) {
    const wife = wifeArray[1] || wifeArray;
    if (husband === jid) return wife;
    if (wife === jid) return husband;
  }
  return null;
}

function getMarriagePair(jid, marriages) {
  for (const [husband, wifeArray] of Object.entries(marriages)) {
    const wife = wifeArray[1] || wifeArray;
    if (husband === jid || wife === jid) {
      return { husband, wife };
    }
  }
  return null;
}

const EXPIRATION_TIME = 2 * 60 * 1000; // دقيقتين

function cleanupExpiredRequests(requests) {
  const now = Date.now();
  let changed = false;
  for (const key in requests) {
    if (now - (requests[key].time || 0) > EXPIRATION_TIME) {
      delete requests[key];
      changed = true;
    }
  }
  return changed;
}

const couplesEmojis = ['💑', '👩‍❤️‍👨', '💕', '💞', '💖', '💘', '👩‍❤️‍👩', '👨‍❤️‍👨'];
function getRandomEmoji() {
  return couplesEmojis[Math.floor(Math.random() * couplesEmojis.length)];
}

// ========== دالة الحصول على صورة عشوائية من 1.jpg إلى 14.jpg ==========
function getRandomWeddingImage() {
  try {
    const availableImages = [];
    for (let i = 1; i <= 14; i++) {
      const fileName = `${i}.jpg`;
      const filePath = path.join(resourcesDir, fileName);
      if (fs.existsSync(filePath)) {
        availableImages.push(filePath);
      }
    }

    if (availableImages.length === 0) {
      console.warn('⚠️ لا توجد صور في مجلد resources (1.jpg - 14.jpg)');
      return null;
    }

    const randomIndex = Math.floor(Math.random() * availableImages.length);
    const selected = availableImages[randomIndex];
    console.log(`✅ تم اختيار الصورة: ${path.basename(selected)}`);
    return selected;
  } catch (error) {
    console.error('❌ خطأ في اختيار الصورة:', error);
    return null;
  }
}

// ========== دالة إرسال الصورة (عشوائية) ==========
async function sendMarriageImage(sock, chatId, caption, quoted = null, mentions = []) {
  const validMentions = Array.isArray(mentions) ? mentions.filter(jid => jid && typeof jid === 'string' && jid.includes('@')) : [];
  const footer = `\n\n╭───────⎈───────╮\n🔥  𝑩𝑶𝑻: 『𝑴𝑨𝑲𝑰𝑴𝑨』\n📛 𝘼𝙇𝙇 𝙍𝙄𝙂𝙃𝙏𝙎 𝙍𝙀𝙎𝙀𝙍𝙑𝙀𝘿 ©️\n╰───────⎈───────╯\n𝘽𝙔┇𝑴𝑨𝑲𝑰𝑴𝑨`;
  const finalCaption = caption + footer;

  // اختيار صورة عشوائية
  const imagePath = getRandomWeddingImage();
  if (imagePath && fs.existsSync(imagePath)) {
    try {
      const imageBuffer = fs.readFileSync(imagePath);
      await sock.sendMessage(chatId, {
        image: imageBuffer,
        caption: finalCaption,
        mentions: validMentions
      }, { quoted: quoted });
      console.log('✅ تم إرسال الصورة بنجاح:', path.basename(imagePath));
      return;
    } catch (err) {
      console.error('❌ خطأ في إرسال الصورة:', err);
    }
  } else {
    console.warn('⚠️ لا توجد صور متاحة، سيتم إرسال النص فقط.');
  }

  // في حال فشل الصورة، نرسل النص فقط
  await sock.sendMessage(chatId, {
    text: finalCaption,
    mentions: validMentions
  }, { quoted: quoted });
}

// ========== دالة الإرسال النصي ==========
async function sendWithFooter(sock, chatId, content, quoted = null, mentions = []) {
  const validMentions = Array.isArray(mentions) ? mentions.filter(jid => jid && typeof jid === 'string' && jid.includes('@')) : [];
  const footer = `\n\n╭───────⎈───────╮\n🔥  𝑩𝑶𝑻: 『𝑴𝑨𝑲𝑰𝑴𝑨』\n📛 𝘼𝙇𝙇 𝙍𝙄𝙂𝙃𝙏𝙎 𝙍𝙀𝙎𝙀𝙍𝙑𝙀𝘿 ©️\n╰───────⎈───────╯\n𝘽𝙔┇𝑴𝑨𝑲𝑰𝑴𝑨`;
  const finalText = content + footer;
  await sock.sendMessage(chatId, {
    text: finalText,
    mentions: validMentions
  }, { quoted: quoted });
}

// ========== استخراج المنشن ==========
function extractMentionFromText(text) {
  const match = text.match(/@(\d+)/);
  if (match) {
    return `${match[1]}@s.whatsapp.net`;
  }
  return null;
}

// ========== معالج الرسائل للردود ==========
const activeListeners = new Map();

async function setupMessageListener(sock, chatId) {
  if (activeListeners.has(chatId)) return;
  
  const listener = async (event) => {
    try {
      if (event.type !== 'notify') return;
      const m = event.messages[0];
      if (!m.message) return;
      if (m.key.remoteJid !== chatId) return;
      
      const sender = m.key.participant || m.key.remoteJid;
      const text = getMessageText(m);
      const content = text.trim().toLowerCase();
      
      if (content !== 'موافقة' && content !== 'رفض') return;
      
      const requests = loadJSON(requestsFile);
      const requestKey = findRequestById(sender, requests);
      if (!requestKey) return;
      
      const proposer = requests[requestKey].from;
      const marriages = loadJSON(marriageFile);
      
      if (content === 'موافقة') {
        if (isMarried(proposer, marriages) || isMarried(sender, marriages)) {
          await sendWithFooter(sock, chatId, 
            '❌ أحد الطرفين متزوج حالياً ولا يمكن إتمام الزواج.',
            m, [sender, proposer]
          );
          delete requests[requestKey];
          saveJSON(requestsFile, requests);
          return;
        }
        
        const requiredPoints = 500;
        const proposerPoints = getPoints(proposer);
        
        if (proposerPoints < requiredPoints) {
          await sendWithFooter(sock, chatId,
            `❌ مقدم الطلب (@${proposer.split('@')[0]}) لا يملك ${requiredPoints} نقطة كافية.\n💰 نقاطه الحالية: ${proposerPoints}`,
            m, [sender, proposer]
          );
          return;
        }
        
        marriages[proposer] = [proposer, sender];
        saveJSON(marriageFile, marriages);
        
        setPoints(proposer, proposerPoints - requiredPoints);
        addPoints(sender, 1000);
        
        delete requests[requestKey];
        saveJSON(requestsFile, requests);
        
        const caption = `
💍💞 *✨ تهانينا بمناسبة الزواج ✨* 💞💍

┏━━━━━━━━━━━━━━━┓
👰 *الزوجة:* @${sender.split('@')[0]}
🤵 *الزوج:* @${proposer.split('@')[0]}
👨‍⚖️ *المأذون:* 𝑴𝑨𝑲𝑰𝑴𝑨
🔮 *المهر:* 1000 نقطة (أُضيفت للعروسة)
💸 *الرسوم:* 500 نقطة (خصمت من العريس)
┗━━━━━━━━━━━━━━━┛

🌹 بارك الله لكما وجمع بينكما في خير 🌹
        `;
        
        await sendMarriageImage(sock, chatId, caption, m, [sender, proposer]);
        return;
      }
      
      if (content === 'رفض') {
        delete requests[requestKey];
        saveJSON(requestsFile, requests);
        
        await sendWithFooter(sock, chatId, `
❌💔 *تم رفض طلب الزواج!* 💔❌

┏━━━━━━━━━━━━━━━┓
👤 *الرافض:* @${sender.split('@')[0]}
📨 *الطالب:* @${proposer.split('@')[0]}
🗑️ *تم حذف الطلب من السجل*
┗━━━━━━━━━━━━━━━┛

🔕 *نتمنى لك حظًا أوفر في المرات القادمة.*
        `, m, [sender, proposer]);
        return;
      }
      
    } catch (err) {
      console.error('خطأ في مستمع الزواج:', err);
    }
  };
  
  sock.ev.on('messages.upsert', listener);
  activeListeners.set(chatId, listener);
}

// ========== الأمر الرئيسي ==========
module.exports = {
  command: ['زواج'],
  category: 'عرس',
  description: 'نظام الزواج المتكامل (طلب، عرض، طلاق)',
  usage: '.زواج @منشن  (طلب زواج)\n.زواج عرض  (عرض الزيجات)\n.طلاق  (الطلاق)',

  async execute(sock, msg, args = []) {
    const sender = msg.key.participant || msg.key.remoteJid || '';
    const chatId = msg.key.remoteJid;

    await setupMessageListener(sock, chatId);

    const marriages = loadJSON(marriageFile);
    const points = loadJSON(pointsFile);
    const requests = loadJSON(requestsFile);

    const expiredRemoved = cleanupExpiredRequests(requests);
    if (expiredRemoved) saveJSON(requestsFile, requests);

    const fullText = getMessageText(msg);
    const parts = fullText.trim().split(/\s+/);
    const command = parts[0] || '';
    const argsFromText = parts.slice(1);

    let target = null;
    const contextInfo = msg.message?.extendedTextMessage?.contextInfo || {};
    const mentionedJid = contextInfo.mentionedJid || [];
    const quotedParticipant = contextInfo.participant;

    if (mentionedJid.length > 0) {
      target = mentionedJid[0];
    } else if (quotedParticipant) {
      target = quotedParticipant;
    } else {
      const extracted = extractMentionFromText(fullText);
      if (extracted) target = extracted;
    }

    // ==========================================
    // 1. عرض حالة الزواج (.زواج بدون أوامر)
    // ==========================================
    if (argsFromText.length === 0 && !target) {
      const married = isMarried(sender, marriages);
      if (married) {
        const partner = getPartner(sender, marriages);
        const pair = getMarriagePair(sender, marriages);
        const isHusband = sender === pair.husband;
        const myName = isHusband ? 'زوج' : 'زوجة';
        const partnerName = isHusband ? 'زوجة' : 'زوج';
        
        await sendWithFooter(sock, chatId, `
💍 *حالة الزواج* 💍

┏━━━━━━━━━━━━━━━┓
👤 *أنت:* ${myName} (@${sender.split('@')[0]})
👤 *${partnerName}:* @${partner.split('@')[0]}
📅 *تاريخ الزواج:* ${new Date().toISOString().split('T')[0]}
┗━━━━━━━━━━━━━━━┓

📌 استخدم .زواج طلاق لفسخ الزواج
        `, msg, [sender, partner]);
      } else {
        await sendWithFooter(sock, chatId, `
💔 *أنت أعزب/عزباء* 💔

📌 استخدم .زواج @منشن لتقديم طلب زواج
📌 استخدم .زواج عرض لمشاهدة الزيجات المسجلة
        `, msg, [sender]);
      }
      return;
    }

    // ==========================================
    // 2. عرض قائمة الزيجات (.زواج عرض)
    // ==========================================
    if (argsFromText.length > 0 && argsFromText[0].toLowerCase() === 'عرض') {
      const entries = Object.entries(marriages);
      if (entries.length === 0) {
        await sendWithFooter(sock, chatId, '❌ لا توجد زيجات مسجلة حالياً.', msg);
        return;
      }

      const displayed = new Set();
      let text = `┏━━━━━━━━━━━━━━━┓\n`;
      text += `💖 *قائمة الزيجات المسجلة* 💖\n`;
      text += `┗━━━━━━━━━━━━━━━┛\n\n`;
      text += `📋 *عدد الزيجات:* ${entries.length}\n\n`;

      for (const [husband, wifeArray] of entries) {
        const wife = wifeArray[1] || wifeArray;
        if (!husband || !wife) continue;
        if (displayed.has(husband) || displayed.has(wife)) continue;
        const emoji = getRandomEmoji();
        const husbandUser = husband.split('@')[0];
        const wifeUser = wife.split('@')[0];
        text += `${emoji}\n`;
        text += `👰‍♀️ *زوجة:* @${wifeUser}\n`;
        text += `🤵‍♂️ *زوج:* @${husbandUser}\n`;
        text += `───────────────\n`;
        displayed.add(husband);
        displayed.add(wife);
      }

      text += `\n💐 نتمنى للجميع حياة مليئة بالحب والسعادة 💐\n`;

      const mentionsArray = Array.from(displayed).filter(jid => jid && typeof jid === 'string' && jid.includes('@'));
      await sendWithFooter(sock, chatId, text, msg, mentionsArray);
      return;
    }

    // ==========================================
    // 3. الطلاق (.زواج طلاق)
    // ==========================================
    if (argsFromText.length > 0 && argsFromText[0].toLowerCase() === 'طلاق') {
      try {
        const divorceModule = require('./طلاق.js');
        await divorceModule.execute(sock, msg, argsFromText.slice(1));
      } catch (e) {
        console.error('خطأ في تحميل ملف طلاق:', e);
        await sendWithFooter(sock, chatId, '❌ حدث خطأ في تنفيذ الطلاق. تأكد من وجود ملف طلاق.js.', msg);
      }
      return;
    }

    // ==========================================
    // 4. طلب زواج (.زواج @منشن أو رد)
    // ==========================================
    if (!target && argsFromText.length > 0) {
      const possibleMention = argsFromText[0];
      if (possibleMention.startsWith('@')) {
        const num = possibleMention.replace(/\D/g, '');
        if (num) target = num + '@s.whatsapp.net';
      }
    }

    if (!target) {
      await sendWithFooter(sock, chatId,
        '👰‍♀️ يرجى منشن الشخص أو الرد على رسالته.\n📌 مثال: .زواج @منشن\n📌 أو: .زواج عرض',
        msg
      );
      return;
    }

    if (target === sender) {
      await sendWithFooter(sock, chatId, '🤦‍♂️ لا يمكنك الزواج من نفسك.', msg);
      return;
    }

    if (isMarried(sender, marriages) || isMarried(target, marriages)) {
      await sendWithFooter(sock, chatId,
        '💔 أحد الطرفين متزوج مسبقاً. الرجاء الطلاق أولاً.',
        msg
      );
      return;
    }

    if (requests[target] && requests[target].from === sender) {
      await sendWithFooter(sock, chatId,
        `⚠️ لديك طلب زواج معلق لهذا الشخص. يرجى انتظار الرد.`,
        msg
      );
      return;
    }

    requests[target] = {
      from: sender,
      time: Date.now()
    };
    saveJSON(requestsFile, requests);

    await sendWithFooter(sock, chatId, `
💌✨ *طلب زواج جديد وصل!* ✨💌

┏━━━━━━ ⍣ ━━━━━━┓
👨‍💼 *السائل (العريس):* @${sender.split('@')[0]}
👰 *المخيّرة (العروسة):* @${target.split('@')[0]}
🧞‍♂️ *المأذون:* 𝑴𝑨𝑲𝑰𝑴𝑨
┗━━━━━━ ⍣ ━━━━━━┛

💰 *تفاصيل الزواج:*
• 1000 نقطة تُضاف للمخيّرة عند الموافقة.
• 500 نقطة تُخصم من السائل عند القبول.

📝 *للرد على الطلب:*
✅ للقبول، أرسلي: *موافقة*
❌ للرفض، أرسلي: *رفض*

🤍 نتمنى لكم التوفيق والحب الحلال 🤍
    `, msg, [target, sender]);
  }
};