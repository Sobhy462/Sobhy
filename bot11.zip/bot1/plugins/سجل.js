// سجل.js - تسجيل لقب لشخص (للنخبة والمشرفين والمطور والأونر والمؤسس)

const fs = require('fs');
const path = require('path');
const { downloadMediaMessage } = require('@whiskeysockets/baileys');
const { isElite } = require('../haykala/elite.js');
const hay = require('../haykala/developer');

// ========== المسارات ==========
const profilesFile = path.join(__dirname, '../data/profiles.json');
const pointsFile = path.join(__dirname, '../data/points.json');
const imagesFolder = path.join(__dirname, '../data/profiles_images');

// ========== التأكد من وجود المجلدات والملفات ==========
if (!fs.existsSync(profilesFile)) fs.writeFileSync(profilesFile, '{}');
if (!fs.existsSync(pointsFile)) fs.writeFileSync(pointsFile, '{}');
if (!fs.existsSync(imagesFolder)) fs.mkdirSync(imagesFolder, { recursive: true });

// ========== دوال التحميل والحفظ ==========
function loadProfiles() {
    try { return JSON.parse(fs.readFileSync(profilesFile)); } catch { return {}; }
}

function saveProfiles(data) {
    fs.writeFileSync(profilesFile, JSON.stringify(data, null, 2));
}

function loadPoints() {
    try { return JSON.parse(fs.readFileSync(pointsFile)); } catch { return {}; }
}

function savePoints(data) {
    fs.writeFileSync(pointsFile, JSON.stringify(data, null, 2));
}

// ========== دالة الإرسال الموحدة ==========
async function sendMessage(sock, chatId, lines, quoted = null, mentions = []) {
    if (!Array.isArray(lines)) {
        lines = [lines];
    }

    let msg = `📝 *نـظـام الـتـسـجـيـل* 📝\n`;
    msg += `━━━━━━━━━━━━━━━━━━━━\n`;
    for (const line of lines) {
        if (line && line.trim()) {
            msg += `${line}\n`;
        }
    }
    msg += `━━━━━━━━━━━━━━━━━━━━\n`;
    msg += `𝘽𝙔┇𝑴𝑨𝑲𝑰𝑴𝑨`;

    await sock.sendMessage(chatId, { text: msg, mentions }, { quoted: quoted });
}

// ========== دوال الصلاحيات ==========
function normalizeLid(lid) {
    if (typeof lid === 'string' && !lid.endsWith('@lid')) {
        return lid + '@lid';
    }
    return lid;
}

function getRank(jid) {
    // الترتيب:  أونر > مطور > نخبة > مشرف > عضو
    if (hay.isFounder(jid)) return 5;
    if (hay.isOwnerbot(jid)) return 4;
    if (hay.isDeveloper(jid)) return 3;
    if (isElite(jid)) return 2;
    return 0; // عضو عادي
}

function getRankName(rank) {
    if (rank === 5) return 'الاونر بوت 👑';
    if (rank === 4) return 'الأونر 💎';
    if (rank === 3) return 'المطور 💠';
    if (rank === 2) return 'النخبة 🛡️';
    if (rank === 1) return 'مشرف 🛠️';
    return 'عضو 👤';
}

async function checkPermission(sock, chatId, executor, target) {
    const executorRank = getRank(executor);
    const targetRank = getRank(target);

    // التحقق من صلاحية التنفيذ
    if (executorRank < 2) {
        // أقل من نخبة (عضو عادي)
        return { allowed: false, reason: 'هذا الأمر للنخبة والمشرفين 🤧' };
    }

    // التحقق من المشرفين في المجموعة (إذا كان المستخدم مشرف)
    let isTargetAdmin = false;
    if (chatId && chatId.endsWith('@g.us')) {
        try {
            const metadata = await sock.groupMetadata(chatId);
            const participant = metadata.participants.find(p => p.id === target);
            isTargetAdmin = participant?.admin === 'admin' || participant?.admin === 'superadmin';
        } catch (e) {}
    }

    // إذا كان المستهدف مشرف في المجموعة والمستخدم ليس مشرف أو أعلى
    if (isTargetAdmin && executorRank < 1) {
        return { allowed: false, reason: '⛔ لا يمكنك تسجيل لقب لمشرف في المجموعة.' };
    }

    // لا يمكن تسجيل لقب لشخص أعلى رتبة
    if (targetRank > executorRank) {
        return { allowed: false, reason: `⛔ لا يمكنك تسجيل لقب لشخص أعلى منك رتبة (${getRankName(targetRank)}).` };
    }

    // لا يمكن تسجيل لقب لشخص نفس الرتبة (إلا الاونر)
    if (targetRank === executorRank && executorRank < 5) {
        return { allowed: false, reason: `⛔ لا يمكنك تسجيل لقب لشخص بنفس رتبتك (${getRankName(executorRank)}).` };
    }

    return { allowed: true };
}

// ========== دوال البطاقة ==========
function getProfile(jid) {
    const profiles = loadProfiles();
    return profiles[jid] || null;
}

function setProfile(jid, nickname, age, gender, imagePath) {
    const profiles = loadProfiles();
    profiles[jid] = { nickname, age, gender, image: imagePath || null };
    saveProfiles(profiles);
}

function isTitleTaken(title, excludeUser = null) {
    const profiles = loadProfiles();
    for (const [user, data] of Object.entries(profiles)) {
        if (user === excludeUser) continue;
        if (data.nickname && data.nickname.toLowerCase() === title.toLowerCase()) {
            return true;
        }
    }
    return false;
}

function addPoints(jid, amount) {
    const points = loadPoints();
    points[jid] = (points[jid] || 0) + amount;
    savePoints(points);
    return points[jid];
}

// ========== دالة جلب صورة حساب الشخص ==========
async function fetchProfilePicture(sock, jid) {
    try {
        // محاولة جلب صورة حساب الشخص
        const ppUrl = await sock.profilePictureUrl(jid, 'image');
        if (ppUrl) {
            // تحميل الصورة وحفظها
            const response = await fetch(ppUrl);
            const buffer = await response.arrayBuffer();
            const filename = `profile_${Date.now()}_${Math.random().toString(36).substring(7)}.jpg`;
            const imagePath = path.join(imagesFolder, filename);
            fs.writeFileSync(imagePath, Buffer.from(buffer));
            return imagePath;
        }
    } catch (e) {
        // فشل جلب الصورة
        console.log('⚠️ فشل جلب صورة الحساب:', e.message);
    }
    return null;
}

// ========== دالة استخراج المنشن ==========
function extractMentions(msg) {
    const contextInfo = msg.message?.extendedTextMessage?.contextInfo || {};
    if (contextInfo.mentionedJid && contextInfo.mentionedJid.length > 0) {
        return contextInfo.mentionedJid;
    }
    
    const text = msg.message?.conversation || msg.message?.extendedTextMessage?.text || '';
    const mentionMatch = text.match(/@(\d+)/);
    if (mentionMatch) {
        return [`${mentionMatch[1]}@s.whatsapp.net`];
    }
    
    if (contextInfo.participant) {
        return [contextInfo.participant];
    }
    
    return [];
}

// ========== الأمر الرئيسي ==========
module.exports = {
    command: ['سجل', 'سجله'],
    category: 'نظام',
    description: '📝 تسجيل لقب لشخص مع الصورة والعمر والجنس',
    usage: '.سجل @منشن اللقب العمر الجنس\nأو بالرد على صورة: .سجل @منشن اللقب العمر الجنس',

    async execute(sock, msg) {
        try {
            const chatId = msg.key.remoteJid;
            const sender = msg.key.participant || msg.key.remoteJid;
            const senderNumber = sender.split('@')[0];

            const body = msg.message?.conversation || msg.message?.extendedTextMessage?.text || '';
            const args = body.split(/\s+/).slice(1);

            // ===== التحقق من وجود منشن =====
            let mentionedJids = extractMentions(msg);
            const quotedSender = msg.message?.extendedTextMessage?.contextInfo?.participant || null;

            let target = null;
            if (mentionedJids.length > 0) {
                target = mentionedJids[0];
            } else if (quotedSender) {
                target = quotedSender;
            }

            if (!target) {
                await sendMessage(sock, chatId, [
                    '❌ *يجب منشن الشخص أو الرد على رسالته.*',
                    '',
                    '📝 الاستخدام:',
                    '.سجل @منشن اللقب العمر الجنس',
                    '.سجل @منشن اللقب العمر الجنس (مع الرد على صورة)',
                    '',
                    '📌 مثال: .سجل @احمد المحارب 25 ذكر'
                ], msg);
                return;
            }

            // ===== التحقق من وجود لقب في الوسائط =====
            let argsText = body.split(/\s+/).slice(1);
            // إزالة المنشن من الوسائط
            argsText = argsText.filter(arg => !arg.startsWith('@'));

            if (argsText.length < 3) {
                await sendMessage(sock, chatId, [
                    '❌ *يجب كتابة اللقب والعمر والجنس.*',
                    '',
                    '📝 الاستخدام:',
                    '.سجل @منشن اللقب العمر الجنس',
                    '',
                    '📌 مثال: .سجل @احمد المحارب 25 ذكر'
                ], msg);
                return;
            }

            // ===== التحقق من الصلاحيات =====
            const permission = await checkPermission(sock, chatId, sender, target);
            if (!permission.allowed) {
                await sendMessage(sock, chatId, [
                    permission.reason
                ], msg, [target]);
                return;
            }

            // ===== استخراج البيانات =====
            const age = parseInt(argsText[argsText.length - 2]);
            const gender = argsText[argsText.length - 1];
            const title = argsText.slice(0, argsText.length - 2).join(' ');

            if (isNaN(age) || age < 1 || age > 120) {
                await sendMessage(sock, chatId, [
                    '❌ *العمر يجب أن يكون رقماً بين 1 و 120.*'
                ], msg, [target]);
                return;
            }

            // ===== التحقق من اللقب =====
            if (isTitleTaken(title, target)) {
                await sendMessage(sock, chatId, [
                    `❌ *اللقب "${title}" مأخوذ بالفعل!*`,
                    '',
                    '📌 اختر لقباً آخر.'
                ], msg, [target]);
                return;
            }

            // ===== جلب الصورة =====
            let imagePath = null;

            // 1. التحقق من وجود صورة مرفقة (رد على صورة)
            const quotedMsg = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
            if (quotedMsg?.imageMessage) {
                try {
                    const imageBuffer = await downloadMediaMessage(
                        { key: msg.key, message: quotedMsg },
                        'buffer',
                        {},
                        { reuploadRequest: sock }
                    );
                    const filename = `profile_${Date.now()}_${Math.random().toString(36).substring(7)}.jpg`;
                    imagePath = path.join(imagesFolder, filename);
                    fs.writeFileSync(imagePath, imageBuffer);
                } catch (e) {
                    console.error('❌ فشل تحميل الصورة المرفقة:', e);
                }
            }

            // 2. إذا لم توجد صورة مرفقة، نحاول جلب صورة حساب الشخص
            if (!imagePath) {
                imagePath = await fetchProfilePicture(sock, target);
                if (imagePath) {
                    console.log(`✅ تم جلب صورة حساب ${target.split('@')[0]}`);
                }
            }

            // ===== حفظ البيانات =====
            setProfile(target, title, age, gender, imagePath);
            const newPoints = addPoints(target, 100);

            const targetDisplay = target.split('@')[0];
            const executorDisplay = senderNumber;

            // ===== بناء رسالة النجاح =====
            const lines = [
                '✅ *تم تسجيل اللقب بنجاح!*',
                '',
                `👤 *الشخص:* @${targetDisplay}`,
                `🏷️ *اللقب:* ${title}`,
                `📅 *العمر:* ${age} سنة`,
                `⚥ *الجنس:* ${gender}`,
                `💰 *المكافأة:* +100 نقطة (الرصيد: ${newPoints})`,
                `👮 *بواسطة:* @${executorDisplay}`,
                '',
                '📸 *الصورة:* ' + (imagePath ? '✅ تم حفظها' : '❌ لا توجد صورة')
            ];

            const mentions = [target, sender];
            await sendMessage(sock, chatId, lines, msg, mentions);

        } catch (error) {
            console.error('❌ خطأ في أمر سجل:', error);
            await sendMessage(sock, msg.key.remoteJid, [
                '❌ *حدث خطأ*',
                '',
                `📝 ${error.message || 'خطأ غير معروف'}`,
                '',
                '📌 حاول مرة أخرى لاحقاً'
            ], msg);
        }
    }
};