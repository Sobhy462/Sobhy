// اوامر.js - قائمة الأوامر بحسب الفئة (نسخة مستقرة مع دعم الأوامر المباشرة)
// يدعم: .اوامر، .قائمة، .menu، .قسم، .اقسام، .الاوامر
// يدعم أيضاً كتابة اسم القسم مباشرة: .تسلية، .عرس، .العاب، ... إلخ (مضاف في command)
// تم التعديل: يعمل كـ Reply على رسالة الأمر

const fs = require('fs');
const path = require('path');

// ========== إيموجيات الأقسام ==========
const categoryIcons = {
    'خاصة': '🔒',
    'عام': '🌐',
    'ادارة': '👑',
    'العاب': '🎮',
    'تسلية': '🎯',
    'ترفيه': '🎪',
    'ديني': '🕌',
    'نظام': '⚙️',
    'المطور': '💻',
    'يوتيوب': '▶️',
    'AI': '🤖',
    'وسائط': '🎬',
    'خدمات': '🛠️',
    'متجر': '🛒',
    'مالية': '💰',
    'مملكة': '🏰',
    'مرح': '😄',
    'ملصقات': '🏷️',
    'أدوات': '🔧',
    'فعاليات': '🎊',
    'عرس': '💍',
    'مهام': '📋',
    'نقابات': '⚔️',
    'أخرى': '📦',
    'بنك': '🏦',
    'تحرش': '👀'
};

// ========== الأوامر الثابتة المطلوب إضافتها ==========
const staticCommands = {
    'خاصة': [
        { cmd: 'اقفل', desc: '🔒 قفل أمر عالمياً' },
        { cmd: 'افتح', desc: '🔓 فتح أمر عالمياً' },
        { cmd: 'المقفولة', desc: '📋 عرض الأوامر المقفولة' },
        { cmd: 'بان', desc: '⛔ حظر مستخدم' },
        { cmd: 'فك', desc: '✅ فك الحظر عن مستخدم' },
        { cmd: 'بان فك', desc: '✅ فك الحظر عن مستخدم' },
        { cmd: 'تفعيل', desc: '▶️ تفعيل مجلد (زرف)' },
        { cmd: 'تعطيل', desc: '⏹️ تعطيل مجلد (زرف)' }
    ],
    'عام': [
        { cmd: 'تفاعل', desc: '😎 تعيين تفاعل لنفسك' },
        { cmd: 'استقبال', desc: '📋 .استقبال قفل استقبال الأعضاء' },
        { cmd: 'وداع', desc: '💔 .وداع قفل  رسائل الوداع' },
        { cmd: 'ترحيب', desc: '🌷 .ترحيب قفل رسائل الترحيب' },
        { cmd: 'رد تلقائي', desc: '🤖 لتشغيل الردود التلقائية' },
        // ====== أوامر بدون نقطة (تعمل كأوامر نصية) ======
        { cmd: 'اتكلم', desc: '🗣️ تشغيل الردود التلقائية (بدون نقطة)' },
        { cmd: 'تشغيل الردود', desc: '▶️ تشغيل الردود التلقائية (بدون نقطة)' },
        { cmd: 'اكتم', desc: '🔇 إيقاف الردود التلقائية (بدون نقطة)' },
        { cmd: 'اطفي الردود', desc: '🔇 إيقاف الردود التلقائية (بدون نقطة)' },
        { cmd: 'أخرس', desc: '🔇 إيقاف الردود التلقائية (بدون نقطة)' }
    ]
};

// ========== قائمة الأوامر التي تعمل بدون نقطة ==========
const noDotCommands = ['اتكلم', 'تشغيل الردود', 'اكتم', 'اطفي الردود', 'أخرس'];

// ========== إيموجيات الأوامر ==========
function getCommandEmoji(commandName) {
    const emojiMap = {
        'اونر': '👑',
        'ايقاف': '⏹️',
        'اوامر': '📋',
        'مطور': '💻',
        'نخبة': '⭐',
        'ادمن': '👥',
        'bot': '🤖',
        'lids': '🆔',
        'zarf_control': '⚙️',
        'تبادل': '📊',
        'منشن': '📢',
        'م': '📢',
        'مخفي': '👥',
        'حماية': '🛡️',
        'حماية-الاشراف': '🛡️',
        'طرد': '🚫',
        'طرد-فردي': '🚫',
        'حظر': '⛔',
        'حظر_كلمات': '⛔',
        'تقييد': '🔇',
        'رفع': '⬆️',
        'تنزيل': '⬇️',
        'تعيين': '📌',
        'ترقية': '⬆️',
        'ادارة': '👑',
        'تنظيف': '🧹',
        'حذف': '🗑️',
        'مسح': '🧹',
        'تثبيت': '📌',
        'الغاء': '❌',
        'قفل': '🔒',
        'قفل-توقيت': '⏰',
        'فتح': '🔓',
        'كتم': '🔇',
        'منع': '🚫',
        'رابط': '🔗',
        'لينك': '🔗',
        'لرابط': '🔗',
        'باتش': '📦',
        'نسخة': '📋',
        'نشر': '📤',
        'تشغيل': '▶️',
        'شغل': '▶️',
        'ريستارت': '🔄',
        'تحديث': '🔄',
        'نسخ': '📋',
        'جلب': '📥',
        'استخراج': '📥',
        'قائمة': '📋',
        'لعبة': '🎮',
        'العاب': '🎮',
        'تسلية': '🎯',
        'ترفيه': '🎪',
        'مرح': '😄',
        'نكتة': '😂',
        'مزح': '😜',
        'تحدي': '⚔️',
        'مسابقة': '🏆',
        'احجية': '🧩',
        'لغز': '🧩',
        'تخمين': '🤔',
        'تخمين صور': '🖼️',
        'تخمين_الشخصية': '👤',
        'اكس_او': '❌⭕',
        'نرد': '🎲',
        'قرعة': '🎲',
        'حظ': '🍀',
        'حظي': '🍀',
        'تست': '🧪',
        'تست اسرع': '⚡',
        'اسال': '❓',
        'سوال': '❓',
        'سؤال عشوائي': '❓',
        'احكي': '💬',
        'شاتي': '💬',
        'نقاشي': '💬',
        'توك': '🎞️',
        'تيك': '📺',
        'تك': '🎧',
        'توست': '🍞',
        'ديث نوت': '📓',
        'انمي': '🎌',
        'انميات': '🎌',
        'لانمي': '🎌',
        'مياو': '🐱',
        'بوسة': '😘',
        'حب': '❤️',
        'مدح': '👍',
        'قرآن': '📖',
        'اذكار': '🕌',
        'دعاء': '🤲',
        'صلاه': '🕌',
        'ديني': '🕌',
        'حديث': '📜',
        'تفسير': '📚',
        'فقه': '📚',
        'سيره': '📖',
        'صحابة': '👥',
        'انبياء': '👤',
        'اسماء الله': '🕌',
        'ابتهالات': '🎵',
        'اذان': '🔊',
        'موعظه': '📢',
        'كفاره': '🕋',
        'بدعة': '⚠️',
        'تعويذ': '🛡️',
        'اسلام': '☪️',
        'اية': '📖',
        'سنن': '📜',
        'دولة': '🏳️',
        'عاصمة': '🏛️',
        'صورة': '🖼️',
        'صوره': '🖼️',
        'لصوره': '🖼️',
        'فيديو': '🎬',
        'لفيديو': '🎬',
        'بحث-فيديو-يوتيوب': '▶️',
        'يوتيوب': '▶️',
        'اغنيه': '🎵',
        'اغنية': '🎵',
        'موسيقى': '🎶',
        'صوت': '🎤',
        'لصوت': '🎤',
        'فيلم': '🎥',
        'مسلسل': '📺',
        'ملصق': '🏷️',
        'ملصقات': '🏷️',
        'ايموجي': '😊',
        'زخرف': '✨',
        'نص-فني': '🎨',
        'كتابة': '✍️',
        'شعر': '📝',
        'قصة': '📖',
        'مال': '💰',
        'فلوس': '💰',
        'حساب': '🧮',
        'تحويل': '💸',
        'رصيد': '💳',
        'ايداع': '🏦',
        'سحب': '🏦',
        'سداد': '💳',
        'سلفني': '🤝',
        'شراء': '🛍️',
        'بيع': '🏪',
        'متجر': '🛒',
        'مخزن': '📦',
        'بنك': '🏦',
        'عملات': '🪙',
        'ضريبة': '💰',
        'بوت': '🤖',
        'ماكيما': '👩‍💻',
        'المطور': '💻',
        'تطوير': '⚙️',
        'تحسين': '🔧',
        'تصحيح': '✅',
        'كونيكت': '🕹️',
        'معلومات': 'ℹ️',
        'مساعدة': '❓',
        'حالة': '📊',
        'تقييم': '⭐',
        'تصنيف': '📊',
        'تصنيفي': '📊',
        'بروفايل': '👤',
        'رتب': '🏅',
        'نقاط': '⭐',
        'مهامي': '📋',
        'مهمة': '📋',
        'مملكة': '🏰',
        'مملكتي': '🏰',
        'بحث عن مملكة': '🔍',
        'تغير_اسم_المملكة': '✏️',
        'استعادة مملكة': '🔄',
        'انشاء فريق': '👥',
        'فريقي': '👥',
        'غزو': '⚔️',
        'هجوم': '⚔️',
        'دفاع': '🛡️',
        'معاهده': '📜',
        'ولاء': '🤝',
        'خنق': '😤',
        'ضرب': '👊',
        'ركل': '🦶',
        'صفع': '✋',
        'عض': '🦷',
        'لحس': '👅',
        'عبد': '🧎',
        'سرقة': '🦹',
        'تهكير': '💻',
        'اختراق': '💻',
        'قتل': '🔪',
        'قاتل': '🔪',
        'اغتصاب': '👅',
        'تحرش': '🫦',
        'تنمر': '🫣',
        'شاذ': '🥵',
        'زنجي': '👁️',
        'ارسم': '🎨',
        'رسم': '🎨',
        'صياغه': '✍️',
        'حكمة': '💡',
        'نصيحة': '💡',
        'معاني': '📖',
        'علم': '🇪🇬',
        'حيوان': '🐾',
        'فاكهة': '🍎',
        'طيور': '🐦',
        'سمك': '🐟',
        'وحش': '👹',
        'خروف': '🐑',
        'عجلة': '🎡',
        'تواصل': '📞',
        'اتصل': '📞',
        'خاص': '🔒',
        'سرية': '🔐',
        'مفرد': '📝',
        'جمع': '📝',
        'عكس': '🔄',
        'حرف': '🔤',
        'حروف': '🔤',
        'معجزة': '✨',
        'فعالية_اعلام': '📢',
        'استطلاع': '📊',
        'استمارة': '📋',
        'قوانين': '📜',
        'حقوق': '⚖️',
        'شكوى': '📝',
        'شغلي': '📋',
        'خطيبتي': '💍',
        'زواج': '💑',
        'طلاق': '💔',
        'زوجني': '💍',
        'زوجهم': '💑',
        'انضمام': '🥳',
        'خروج': '🚪',
        'دخل': '💰',
        'خش': '🚪',
        'عين': '👁️',
        'تامل': '🧘',
        'جمال': '✨',
        'انوثه': '👩',
        'ذكوره': '👨',
        'ابكي': '😢',
        'زحلق': '🛝',
        'قنابل': '💣',
        'مؤبد': '⛓️',
        'سجن': '⛓️',
        'اعدام': '💀',
        'هش للطرد': '⚠️',
        'هيروغليفي': '🪐'
    };
    
    if (emojiMap[commandName]) return emojiMap[commandName];
    for (const [key, emoji] of Object.entries(emojiMap)) {
        if (commandName.includes(key) || key.includes(commandName)) return emoji;
    }
    const defaultEmojis = {
        'ا': '📌', 'ب': '📌', 'ت': '🎯', 'ث': '📌', 'ج': '📌',
        'ح': '🛡️', 'خ': '📌', 'د': '🕌', 'ذ': '📌', 'ر': '📌',
        'ز': '📌', 'س': '📌', 'ش': '📌', 'ص': '📌', 'ض': '📌',
        'ط': '🚫', 'ظ': '📌', 'ع': '🌐', 'غ': '📌', 'ف': '📌',
        'ق': '📋', 'ك': '📌', 'ل': '🎮', 'م': '📌', 'ن': '📌',
        'ه': '📌', 'و': '📌', 'ي': '▶️',
    };
    return defaultEmojis[commandName.charAt(0)] || '◉';
}

// ============================================================
// 📋 الأمر الرئيسي
// ============================================================

let cachedCategories = null;

function loadCommands() {
    if (cachedCategories) return cachedCategories;
    
    const pluginsDir = path.join(__dirname, '..', 'plugins');
    // نبدأ بالفئات الثابتة مع الأقسام المطلوبة
    const categories = {
        'خاصة': [],
        'عام': []
    };
    
    // 1. إضافة الأوامر الثابتة يدوياً
    for (const [category, commands] of Object.entries(staticCommands)) {
        if (!categories[category]) categories[category] = [];
        for (const cmdObj of commands) {
            const emoji = getCommandEmoji(cmdObj.cmd);
            // نضيف علامة (بدون نقطة) للأوامر التي لا تحتاج نقطة
            const noDotTag = noDotCommands.includes(cmdObj.cmd) ? ' ⚡' : '';
            const cmdDisplay = `✦ ${emoji} \`${cmdObj.cmd}\`${noDotTag}`;
            // نضيف الوصف إن وجد
            const fullDisplay = cmdObj.desc ? `${cmdDisplay}\n📝 ${cmdObj.desc}` : cmdDisplay;
            categories[category].push(fullDisplay);
        }
    }
    
    // 2. تحميل الأوامر من مجلد plugins (إذا كان موجوداً)
    if (fs.existsSync(pluginsDir)) {
        const pluginFiles = fs.readdirSync(pluginsDir).filter(f => f.endsWith('.js'));
        for (const file of pluginFiles) {
            try {
                const plugin = require(path.join(pluginsDir, file));
                if (plugin.hidden) continue;
                if (!plugin.command) continue;
                
                // نتحقق من اسم الأمر
                const cmdName = Array.isArray(plugin.command) ? plugin.command[0] : plugin.command;
                
                // نتخطى الأوامر الثابتة حتى لا تتكرر
                let isStatic = false;
                for (const [cat, cmds] of Object.entries(staticCommands)) {
                    if (cmds.some(c => c.cmd === cmdName || c.cmd === cmdName.toLowerCase())) {
                        isStatic = true;
                        break;
                    }
                }
                if (isStatic) continue;
                
                let cmdDisplay = '';
                if (Array.isArray(plugin.command)) {
                    const commandsWithEmoji = plugin.command.map(cmd => {
                        const emoji = getCommandEmoji(cmd);
                        return `${emoji} \`${cmd}\``;
                    });
                    cmdDisplay = `✦ ${commandsWithEmoji.join(' ✦ ')}`;
                } else {
                    const emoji = getCommandEmoji(plugin.command);
                    cmdDisplay = `✦ ${emoji} \`${plugin.command}\``;
                }
                if (plugin.description) {
                    cmdDisplay += `\n ${plugin.description}`;
                }
                
                // نضعه في الفئة المناسبة حسب category المحددة في plugin
                const categoryName = plugin.category || 'أخرى';
                if (!categories[categoryName]) categories[categoryName] = [];
                categories[categoryName].push(cmdDisplay);
                
            } catch (err) {
                console.error(`❌ خطأ في تحميل ${file}:`, err.message);
            }
        }
    }
    
    // إزالة التكرارات وترتيب كل قسم
    for (const cat in categories) {
        categories[cat] = [...new Set(categories[cat])];
        categories[cat].sort((a, b) => a.localeCompare(b, 'ar'));
    }
    
    cachedCategories = categories;
    return categories;
}

module.exports = {
    status: "on",
    name: 'قائمة الأوامر',
    // نضع أسماء الأقسام هنا لتعمل مباشرة
    command: [
        'اوامر', 'قائمة', 'menu', 'قسم', 'اقسام', 'الاوامر',
        'خاصة', 'عام', 'ادارة', 'العاب', 'تسلية',
        'ديني', 'نظام', 'نقابات', 'وسائط', 'فعاليات', 'ترفيه', 'خدمات', 'عرس', 'مرح', 'أدوات', 'أخرى'
    ],
    category: 'نظام',
    description: '📋 قائمة الأوامر بحسب الفئة',
    hidden: false,
    version: '7.2',

    async execute(sock, msg) {
        try {
            const chatId = msg.key.remoteJid;
            const sender = msg.key.participant || msg.key.remoteJid;
            const number = sender.split('@')[0];
            const pushName = msg.pushName || "Unknown";

            const body = msg.message?.extendedTextMessage?.text || 
                        msg.message?.conversation || '';
            const parts = body.trim().split(' ');
            const commandName = parts[0]?.replace('.', '') || '';
            const args = parts.slice(1);

            const categories = loadCommands();
            // ترتيب الأقسام
            const sortedCategories = Object.keys(categories).sort((a, b) => a.localeCompare(b, 'ar'));

            const now = new Date();
            const timeStr = now.toLocaleTimeString('ar-EG');
            const dateStr = now.toISOString().split('T')[0];

            let requestedCategory = null;

            // ========== 1. الأمر المباشر (مثل .خاصة) ==========
            if (sortedCategories.includes(commandName)) {
                requestedCategory = commandName;
            }

            // ========== 2. الأوامر الرئيسية (مثل .اوامر) ==========
            const mainCommands = ['اوامر', 'قائمة', 'menu', 'قسم', 'اقسام', 'الاوامر'];
            if (!requestedCategory && mainCommands.includes(commandName)) {
                if (args.length === 0) {
                    await showMainMenu(sock, chatId, sender, number, pushName, timeStr, dateStr, sortedCategories, msg);
                    return;
                } else {
                    let search = args.join(' ').trim();
                    if (!isNaN(search)) {
                        const index = parseInt(search) - 1;
                        if (index >= 0 && index < sortedCategories.length) {
                            requestedCategory = sortedCategories[index];
                        }
                    } else {
                        // البحث عن قسم
                        const found = sortedCategories.find(cat => cat === search || cat.includes(search));
                        if (found) requestedCategory = found;
                    }
                }
            }

            // ========== 3. إذا تم تحديد فئة، اعرضها ==========
            if (requestedCategory && categories[requestedCategory]) {
                await showCategory(sock, chatId, sender, number, pushName, timeStr, dateStr, requestedCategory, categories, msg);
                return;
            }

            // ========== 4. إذا كان هناك اسم فئة ولكن غير موجود ==========
            if (requestedCategory) {
                let errorMsg = `❌ *القسم "${requestedCategory}" غير موجود*\n\n`;
                errorMsg += `📋 الأقسام المتاحة:\n`;
                let i = 1;
                for (const cat of sortedCategories) {
                    const icon = categoryIcons[cat] || '📌';
                    errorMsg += ` ${i} ➺ ${icon} ${cat}\n`;
                    i++;
                }
                errorMsg += `\n💡 استخدم .اوامر لعرض الأقسام بشكل منظم.`;
                await sock.sendMessage(chatId, {
                    text: errorMsg,
                    mentions: [sender]
                }, { quoted: msg }); // ✅ تمت الإضافة
                return;
            }

            // ========== 5. أمر غير معروف ==========
            await sock.sendMessage(chatId, {
                text: `❌ *أمر غير معروف*\n\n💡 استخدم .اوامر لعرض قائمة الأقسام.`,
                mentions: [sender]
            }, { quoted: msg }); // ✅ تمت الإضافة

        } catch (error) {
            console.error('❌ خطأ في عرض الأوامر:', error);
            await sock.sendMessage(msg.key.remoteJid, {
                text: `❌ حدث خطأ أثناء عرض الأوامر:\n${error.message}`
            }, { quoted: msg }); // ✅ تمت الإضافة
        }
    }
};

// ===== دوال مساعدة =====

async function showMainMenu(sock, chatId, sender, number, pushName, timeStr, dateStr, sortedCategories, msg) {
    let menu = `╔══════ ≪ °❈° ≫ ══════╗
       MORDKAY&RIGHY 𝑩𝑶𝑻      
╚══════ ≪ °❈° ≫ ══════╝

✧ المستخدم: @${number}
✧ الاسم: ${pushName}
✧ الوقت: ${timeStr}
✧ التاريخ: ${dateStr}

❖ ── *قائمة الأقسام* ── ❖\n`;

    let i = 1;
    for (const cat of sortedCategories) {
        const icon = categoryIcons[cat] || '📌';
        const count = loadCommands()[cat]?.length || 0;
        menu += ` ${i} ◎ ${icon} ${cat}\n`;
        i++;
    }
    
    menu += `\n❖ ──────────────── ❖\n\n`;
    menu += `⚡ *كيفية الاستخدام:*\n`;
    menu += `• .قسم [اسم القسم]\n`;
    menu += `• .قسم [رقم القسم]\n`;
    menu += `• .[اسم القسم] مباشرة\n\n`;
    menu += `📌 أمثلة:\n`;
    menu += `• .قسم تسلية\n`;
    menu += `• .قسم 1\n`;
    menu += `• .فعاليات`;

    menu += `
❖ ──────────────── ❖

╔══════ ≪ °❈° ≫ ══════╗
      𝑴𝑨𝑲𝑰𝑴𝑨      
╚══════ ≪ °❈° ≫ ══════╝`;

    const imgPath = path.join(__dirname, '..', 'image.jpeg');
    if (fs.existsSync(imgPath)) {
        try {
            const imageBuffer = fs.readFileSync(imgPath);
            await sock.sendMessage(chatId, {
                image: imageBuffer,
                caption: menu,
                mentions: [sender]
            }, { quoted: msg }); // ✅ تم التعديل: أصبح رداً
        } catch (uploadErr) {
            console.error('❌ فشل رفع الصورة:', uploadErr.message);
            await sock.sendMessage(chatId, {
                text: menu,
                mentions: [sender]
            }, { quoted: msg }); // ✅ تم التعديل: أصبح رداً
        }
    } else {
        await sock.sendMessage(chatId, {
            text: menu,
            mentions: [sender]
        }, { quoted: msg }); // ✅ تم التعديل: أصبح رداً
    }
}

async function showCategory(sock, chatId, sender, number, pushName, timeStr, dateStr, categoryName, categories, msg) {
    const icon = categoryIcons[categoryName] || '📌';
    let menu = `╔══════ ≪ °❈° ≫ ══════╗
       MORDKAY&RIGHY 𝑩𝑶𝑻      
╚══════ ≪ °❈° ≫ ══════╝

✧ المستخدم: @${number}
✧ الاسم: ${pushName}
✧ الوقت: ${timeStr}
✧ التاريخ: ${dateStr}

❖ ── *${icon} قسم: ${categoryName}* ── ❖\n`;
    menu += `────────────────────\n`;
    menu += categories[categoryName].join('\n\n');

    menu += `
❖ ──────────────── ❖

⚡ الأوامر التي تحمل علامة ⚡ تعمل بدون نقطة (مثل: اتكلم، اكتم)

╔══════ ≪ °❈° ≫ ══════╗
      MORDKAY&RIGHY      
╚══════ ≪ °❈° ≫ ══════╝`;

    const imgPath = path.join(__dirname, '..', 'image.jpeg');
    if (fs.existsSync(imgPath)) {
        try {
            const imageBuffer = fs.readFileSync(imgPath);
            await sock.sendMessage(chatId, {
                image: imageBuffer,
                caption: menu,
                mentions: [sender]
            }, { quoted: msg }); // ✅ تم التعديل: أصبح رداً
        } catch (uploadErr) {
            console.error('❌ فشل رفع الصورة:', uploadErr.message);
            await sock.sendMessage(chatId, {
                text: menu,
                mentions: [sender]
            }, { quoted: msg }); // ✅ تم التعديل: أصبح رداً
        }
    } else {
        await sock.sendMessage(chatId, {
            text: menu,
            mentions: [sender]
        }, { quoted: msg }); // ✅ تم التعديل: أصبح رداً
    }
}