// خريطة.js - عرض خريطة المناطق المتاحة للاستكشاف (منجم، بحر، غابة، مغارة) مع المتطلبات والكولداون
const fs = require('fs');
const path = require('path');

const dataDir = path.join(__dirname, '../data/kingdom');
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

const MAIN_PATH = path.join(dataDir, 'main.json');
const TIMERS_PATH = path.join(dataDir, 'timers.json');

const allPaths = [MAIN_PATH, TIMERS_PATH];
for (const p of allPaths) {
    if (!fs.existsSync(p)) fs.writeFileSync(p, JSON.stringify({}, null, 2));
}

function loadJSON(file) { try { return JSON.parse(fs.readFileSync(file)); } catch { return {}; } }

function loadUserData(jid) {
    const main = loadJSON(MAIN_PATH)[jid] || {};
    const timers = loadJSON(TIMERS_PATH)[jid] || {};
    return {
        level: main.level || 1,
        lastMine: timers.lastMine || 0,
        mineCount: timers.mineCount || 0,
        lastSea: timers.lastSea || 0,
        seaCount: timers.seaCount || 0,
        lastForest: timers.lastForest || 0,
        forestCount: timers.forestCount || 0,
        lastDungeon: timers.lastDungeon || 0,
        dungeonCount: timers.dungeonCount || 0
    };
}

function userExists(jid) { return !!loadJSON(MAIN_PATH)[jid]; }

// ========== دالة الإرسال ==========
async function sendMessage(sock, chatId, lines, quoted = null, mentions = []) {
    if (!Array.isArray(lines)) lines = [lines];
    let msg = `🗺️ خـريـطـة الـمـمـلـكـة 🗺️\n`;
    msg += `━━━━━━━━━━━━━━━━━━━━\n`;
    for (const line of lines) {
        msg += `${line}\n`;
    }
    msg += `━━━━━━━━━━━━━━━━━━━━\n`;
    msg += `𝘽𝙔┇𝑴𝑨𝑲𝑰𝑴𝑨`;
    await sock.sendMessage(chatId, { text: msg, mentions }, { quoted: quoted });
}

// ========== الأمر الرئيسي ==========
module.exports = {
    command: ['خريطة', 'مناطق'],
    description: '🗺️ عرض خريطة المناطق المتاحة للاستكشاف (منجم، بحر، غابة، مغارة)',
    category: 'مملكة',
    usage: '.خريطة',
    async execute(sock, msg) {
        try {
            const chatId = msg.key.remoteJid;
            const sender = msg.key.participant || msg.key.remoteJid;

            if (!userExists(sender)) {
                await sendMessage(sock, chatId, [
                    '❌ ليس لديك مملكة!',
                    '📌 استخدم .لاعب جديد لتأسيس مملكتك.'
                ], msg, [sender]);
                return;
            }

            const user = loadUserData(sender);
            const level = user.level;
            const now = Date.now();

            // تعريف المناطق
            const areas = [
                {
                    name: '⛏️ المنجم',
                    emoji: '⛏️',
                    key: 'Mine',
                    requiredLevel: 1,
                    cooldown: 12 * 60 * 60 * 1000, // 12 ساعة
                    lastTime: user.lastMine,
                    count: user.mineCount,
                    desc: 'يحصل على حديد وأحجار كريمة ونقاط'
                },
                {
                    name: '🌳 الغابة',
                    emoji: '🌳',
                    key: 'Forest',
                    requiredLevel: 3,
                    cooldown: 4 * 60 * 60 * 1000, // 4 ساعات
                    lastTime: user.lastForest,
                    count: user.forestCount,
                    desc: 'يحصل على خشب نادر ورفقاء'
                },
                {
                    name: '🌊 البحر',
                    emoji: '🌊',
                    key: 'Sea',
                    requiredLevel: 5,
                    cooldown: 6 * 60 * 60 * 1000, // 6 ساعات
                    lastTime: user.lastSea,
                    count: user.seaCount,
                    desc: 'يحصل على كنوز وأسلحة'
                },
                {
                    name: '🕯️ المغارة',
                    emoji: '🕯️',
                    key: 'Dungeon',
                    requiredLevel: 10,
                    cooldown: 24 * 60 * 60 * 1000, // 24 ساعة
                    lastTime: user.lastDungeon,
                    count: user.dungeonCount,
                    desc: 'مخاطرة عالية، مكافآت كبيرة (ذهب، نقاط، أسلحة نادرة)'
                }
            ];

            // بناء الرسالة
            let lines = [
                `👑 @${sender.split('@')[0]}`,
                `📈 مستواك: ${level}`,
                `━━━━━━━━━━━━━━━━━━━━`,
                `📌 *المناطق المتاحة للاستكشاف:*`,
                ''
            ];

            for (const area of areas) {
                const available = level >= area.requiredLevel;
                const isOnCooldown = area.lastTime && (now - area.lastTime) < area.cooldown;
                let statusText = '';
                let remainingTime = '';

                if (!available) {
                    statusText = `🔒 يحتاج مستوى ${area.requiredLevel}`;
                } else if (isOnCooldown) {
                    const remaining = area.cooldown - (now - area.lastTime);
                    const hours = Math.floor(remaining / (60 * 60 * 1000));
                    const mins = Math.floor((remaining % (60 * 60 * 1000)) / (60 * 1000));
                    remainingTime = `⏳ متبقي ${hours} ساعة ${mins} دقيقة`;
                    statusText = `⏳ في انتظار التبريد (${remainingTime})`;
                } else {
                    statusText = `✅ متاحة الآن`;
                }

                const countText = area.count > 0 ? `تم استكشافها ${area.count} مرة` : 'لم تستكشف بعد';

                lines.push(`• ${area.name}`);
                lines.push(`   📋 ${area.desc}`);
                lines.push(`   📊 الحالة: ${statusText}`);
                lines.push(`   📈 عدد المرات: ${countText}`);
                lines.push('');
            }

            // نصائح
            lines.push(`━━━━━━━━━━━━━━━━━━━━`);
            lines.push(`💡 استخدم الأوامر التالية لاستكشاف:`);
            lines.push(`   .منجم    .غابة    .بحر    .مغارة`);

            await sendMessage(sock, chatId, lines, msg, [sender]);

        } catch (error) {
            console.error('✗ خطأ في أمر خريطة:', error);
            await sendMessage(sock, msg.key.remoteJid, [
                '❌ حدث خطأ أثناء عرض الخريطة.',
                '📌 حاول مرة أخرى لاحقاً.'
            ], msg);
        }
    }
};