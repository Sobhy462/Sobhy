// سرقة.js - نظام سرقة النقاط بين اللاعبين (مع إخفاء الرصيد للمخفيين) - نسخة سريعة وآمنة
const fs = require('fs');
const path = require('path');
const hay = require('../haykala/developer');

// ===== مسارات الملفات =====
const pointsPath = path.join(__dirname, '../data/points.json');
const hiddenPath = path.join(__dirname, '../data/hidden-points.json');
const treatiesPath = path.join(__dirname, '../data/treaties.json');
const logsPath = path.join(__dirname, '../data/stealLogs.json');
const activePath = path.join(__dirname, '../data/stealActive.json');

// ===== التأكد من وجود جميع الملفات =====
const allPaths = [pointsPath, hiddenPath, treatiesPath, logsPath, activePath];
for (const p of allPaths) {
    const dir = path.dirname(p);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    if (!fs.existsSync(p)) {
        fs.writeFileSync(p, p.endsWith('.json') ? JSON.stringify({}, null, 2) : '{}');
    }
}

// ========== دوال تحميل وحفظ JSON ==========
function loadJSON(file, fallback = {}) {
    try { return JSON.parse(fs.readFileSync(file)); } catch { return fallback; }
}
function saveJSON(file, data) {
    try {
        if (fs.existsSync(file)) fs.writeFileSync(file + '.bak', fs.readFileSync(file));
        fs.writeFileSync(file, JSON.stringify(data, null, 2));
        return true;
    } catch (e) {
        console.error('❌ فشل حفظ:', file, e.message);
        return false;
    }
}
function getNumber(jid) { return jid ? jid.toString().replace(/[^0-9]/g, '') : ''; }

// ========== دوال الإخفاء ==========
function getHidden() {
    const data = loadJSON(hiddenPath, []);
    return data.map(item => item.toString().replace(/[^0-9]/g, '')).filter(n => n);
}

function isHidden(user) {
    const userNum = getNumber(user);
    if (!userNum) return false;
    const hiddenList = getHidden();
    return hiddenList.includes(userNum);
}

// ========== دوال الرتب ==========
function isFounder(jid) {
    try { const lid = hay.toLid(jid); return hay.isFounder(lid); } catch { return false; }
}
function isOwnerbot(jid) {
    try { const lid = hay.toLid(jid); return hay.isOwnerbot(lid); } catch { return false; }
}
function isDeveloper(jid) {
    try { const lid = hay.toLid(jid); return hay.isDeveloper(lid); } catch { return false; }
}

// ========== هرم الصلاحيات للسرقة ==========
function canSteal(actor, target) {
    const actorIsFounder = isFounder(actor);
    const actorIsOwner = isOwnerbot(actor);
    const actorIsDev = isDeveloper(actor);
    const targetIsFounder = isFounder(target);
    const targetIsOwner = isOwnerbot(target);
    const targetIsDev = isDeveloper(target);

    if (actorIsFounder) return true;
    if (actorIsOwner) {
        if (targetIsFounder) return false;
        return true;
    }
    if (actorIsDev) {
        if (targetIsFounder || targetIsOwner) return false;
        return true;
    }
    if (targetIsFounder || targetIsOwner || targetIsDev) return false;
    return true;
}

// ========== دوال المعاهدات ==========
function loadTreaties() { return loadJSON(treatiesPath, {}); }

function getActiveTreaty(jid1, jid2, treaties) {
    for (const [key, treaty] of Object.entries(treaties)) {
        if (treaty.status === 'accepted') {
            if ((treaty.party1 === jid1 && treaty.party2 === jid2) ||
                (treaty.party1 === jid2 && treaty.party2 === jid1)) {
                return treaty;
            }
        }
    }
    return null;
}

// ========== دوال بيانات السرقات النشطة ==========
function loadStealData() {
    return loadJSON(activePath, {});
}

function saveStealData(data) {
    saveJSON(activePath, data);
}

function getStealInfo(jid) {
    const data = loadStealData();
    const jidNum = getNumber(jid);
    if (!data[jidNum]) {
        data[jidNum] = {
            targetCounts: {},
            cooldown: 0
        };
        saveStealData(data);
    }
    return data[jidNum];
}

function updateStealInfo(jid, targetJid) {
    const data = loadStealData();
    const jidNum = getNumber(jid);
    const targetNum = getNumber(targetJid);
    if (!data[jidNum]) data[jidNum] = { targetCounts: {}, cooldown: 0 };
    const now = Date.now();
    const targetData = data[jidNum].targetCounts[targetNum] || { count: 0, lastTime: 0 };
    
    if (targetData.lastTime && (now - targetData.lastTime) > 10 * 60 * 1000) {
        data[jidNum].targetCounts[targetNum] = { count: 1, lastTime: now };
    } else {
        data[jidNum].targetCounts[targetNum] = { count: (targetData.count || 0) + 1, lastTime: now };
    }
    saveStealData(data);
}

function checkTargetStealLimit(jid, targetJid) {
    const data = loadStealData();
    const jidNum = getNumber(jid);
    const targetNum = getNumber(targetJid);
    if (!data[jidNum]) return { canSteal: true, count: 0, remaining: 0 };
    const targetData = data[jidNum].targetCounts[targetNum];
    if (!targetData) return { canSteal: true, count: 0, remaining: 0 };
    const now = Date.now();
    if (targetData.lastTime && (now - targetData.lastTime) > 10 * 60 * 1000) {
        return { canSteal: true, count: 0, remaining: 0 };
    }
    if (targetData.count >= 5) {
        const elapsed = now - targetData.lastTime;
        const remaining = 10 * 60 * 1000 - elapsed;
        if (remaining > 0) {
            return { canSteal: false, count: targetData.count, remaining };
        } else {
            return { canSteal: true, count: 0, remaining: 0 };
        }
    }
    return { canSteal: true, count: targetData.count, remaining: 0 };
}

// ========== الكول داون العام ==========
const cooldown = new Map();
const COOLDOWN_TIME = 8 * 1000; // 8 ثواني

// ========== تحديد الرتبة ==========
function getLevel(points) {
    if (points >= 1000000000) return '👑 DEVELOPER';
    if (points >= 100000000) return '🌀 KING OF POINTS';
    if (points >= 10000000) return '💀 BIG BOSS';
    if (points >= 1000000) return '🔥 WTF';
    if (points >= 100000) return '🔪 KILLER';
    if (points >= 10000) return '🦁 LEGEND';
    if (points >= 1000) return '💎 PRO';
    if (points >= 500) return '⚡ ADVANCED';
    if (points >= 200) return '🌱 JUNIOR';
    if (points < -10) return '🪫 NOOB';
    return '🐣 NEWBIE';
}

// ========== تسجيل السرقات ==========
function logSteal(sender, target, amount, success) {
    const logs = loadJSON(logsPath, {});
    const key = `${getNumber(sender)}_${getNumber(target)}_${Date.now()}`;
    logs[key] = { sender: getNumber(sender), target: getNumber(target), amount, success, date: new Date().toISOString() };
    saveJSON(logsPath, logs);
}

// ========== مراحل السرقة (سريعة) ==========
const combinedSteps = [
    { emoji: '🔴', text: 'جار التسلل إلى الخزنة...', num: 5, delay: 200 },
    { emoji: '🟠', text: 'تجاوز أنظمة الحماية...', num: 4, delay: 200 },
    { emoji: '🟡', text: 'اقتراب من الخزنة...', num: 3, delay: 200 },
    { emoji: '🟢', text: 'كسر القفل...', num: 2, delay: 200 },
    { emoji: '🟩', text: 'جمع النقود...', num: 1, delay: 200 },
    { emoji: '🟦', text: 'الهروب من المكان...', num: 0, delay: 200 }
];

// ========== دالة الإرسال ==========
async function sendMessage(sock, chatId, lines, quoted = null, mentions = []) {
    if (!Array.isArray(lines)) lines = [lines];
    let msg = `💀 عـمـلـيـة سـرقـة 💀\n`;
    msg += `━━━━━━━━━━━━━━━━━━━━\n`;
    for (const line of lines) {
        msg += `${line}\n`;
    }
    msg += `━━━━━━━━━━━━━━━━━━━━\n`;
    msg += `𝘽𝙔┇𝑴𝑨𝑲𝑰𝑴𝑨`;
    await sock.sendMessage(chatId, { text: msg, mentions }, { quoted: quoted });
}

// ========== الأمر الرئيسي ==========
module.exports = {
    command: ['سرقة', 'سرقه'],
    description: '💀 سرقة نقاط من لاعب آخر (مع إخفاء رصيد المخفيين) - نسخة سريعة وآمنة',
    category: 'عام',
    usage: '.سرقة (رد على رسالة الضحية أو @منشن)',

    async execute(sock, msg) {
        try {
            const chatId = msg.key.remoteJid;
            const sender = msg.key.participant || msg.participant || msg.key.remoteJid;
            const context = msg.message?.extendedTextMessage?.contextInfo || {};
            const targetJid = context.mentionedJid?.[0] || context.participant;

            // التحقق من وجود ضحية
            if (!targetJid) {
                await sendMessage(sock, chatId, [
                    '❌ يجب المنشن أو الرد على الضحية',
                    '',
                    '📝 استخدم: .سرقة (رد على رسالة الضحية)',
                    '📝 أو: .سرقة @منشن'
                ], msg, [sender]);
                return;
            }

            // لا يمكن سرقة النفس
            if (getNumber(sender) === getNumber(targetJid)) {
                await sendMessage(sock, chatId, [
                    '❌ لا يمكنك سرقة نفسك!'
                ], msg, [sender]);
                return;
            }

            // ===== التحقق من المعاهدة =====
            const treaties = loadTreaties();
            const activeTreaty = getActiveTreaty(sender, targetJid, treaties);
            if (activeTreaty) {
                await sendMessage(sock, chatId, [
                    '🤝 لا يمكنك سرقة حليفك!',
                    `📌 هناك معاهدة سلام بينك وبين @${getNumber(targetJid)}.`,
                    '❌ السرقة ممنوعة في وجود معاهدة.'
                ], msg, [sender, targetJid]);
                return;
            }

            // ===== التحقق من صلاحية السرقة =====
            if (!canSteal(sender, targetJid)) {
                let roleName = '';
                if (isFounder(targetJid)) roleName = 'المالك';
                else if (isOwnerbot(targetJid)) roleName = 'مالك البوت';
                else if (isDeveloper(targetJid)) roleName = 'المطور';
                else roleName = 'هذا الشخص';

                await sendMessage(sock, chatId, [
                    `🚫 لا يمكنك سرقة ${roleName}`
                ], msg, [sender]);
                return;
            }

            // ===== الكول داون العام =====
            if (cooldown.has(sender)) {
                const timeLeft = cooldown.get(sender) - Date.now();
                if (timeLeft > 0) {
                    const sec = Math.ceil(timeLeft / 1000);
                    await sendMessage(sock, chatId, [
                        `⏳ انتظر ${sec} ثانية قبل المحاولة مرة أخرى.`
                    ], msg, [sender]);
                    return;
                }
            }

            // ===== الحد على نفس الضحية (5 مرات ثم استراحة 10 دقائق) =====
            const limitCheck = checkTargetStealLimit(sender, targetJid);
            if (!limitCheck.canSteal) {
                const remainingTime = limitCheck.remaining;
                const sec = Math.ceil(remainingTime / 1000);
                const minutes = Math.floor(sec / 60);
                const seconds = sec % 60;
                await sendMessage(sock, chatId, [
                    `⏳ *استراحة 10 دقائق قبل سرقة هذا الشخص مرة أخرى*`,
                    `👤 @${getNumber(sender)}، لقد سرقت @${getNumber(targetJid)} 5 مرات.`,
                    `⏳ المتبقي: *${minutes} دقيقة ${seconds} ثانية*`,
                    `📌 يمكنك سرقة أي شخص آخر خلال هذه الفترة.`
                ], msg, [sender, targetJid]);
                return;
            }

            // ===== تحميل النقاط (مرة واحدة في البداية لعرضها) =====
            const points = loadJSON(pointsPath, {});
            if (!points[sender]) points[sender] = 0;
            if (!points[targetJid]) points[targetJid] = 0;
            let senderPoints = points[sender];
            let targetPoints = points[targetJid];

            // ===== التحقق من أن الضحية لديه نقاط كافية =====
            if (targetPoints < 5) {
                await sendMessage(sock, chatId, [
                    `❌ @${getNumber(targetJid)} ليس لديه نقاط كافية للسرقة (اقل من 5 نقاط).`
                ], msg, [sender, targetJid]);
                return;
            }

            // ===== حساب المستوى (من نظام الممالك إن وجد) =====
            let attackerLevel = 1;
            try {
                const mainPath = path.join(__dirname, '../data/kingdom/main.json');
                if (fs.existsSync(mainPath)) {
                    const mainData = loadJSON(mainPath, {});
                    if (mainData[sender]) attackerLevel = mainData[sender].level || 1;
                }
            } catch (e) {}

            // ===== رسالة البداية =====
            const senderNum = getNumber(sender);
            const targetNum = getNumber(targetJid);

            const startMsg = await sock.sendMessage(chatId, {
                text: `💀 عـمـلـيـة سـرقـة 💀\n━━━━━━━━━━━━━━━━━━━━\n🎯 عملية سرقة\n👤 السارق: @${senderNum}\n👤 الضحية: @${targetNum}\n💰 نقاط الضحية: ${targetPoints}\n⏳ جارٍ التحميل...\n━━━━━━━━━━━━━━━━━━━━\n𝘽𝙔┇𝑴𝑨𝑲𝑰𝑴𝑨`,
                mentions: [sender, targetJid]
            }, { quoted: msg });

            // ========== المراحل (سريعة) ==========
            for (let i = 0; i < combinedSteps.length; i++) {
                const step = combinedSteps[i];
                await new Promise(resolve => setTimeout(resolve, step.delay || 200));

                await sock.sendMessage(chatId, {
                    text: `💀 عـمـلـيـة سـرقـة 💀\n━━━━━━━━━━━━━━━━━━━━\n🎯 عملية سرقة\n👤 السارق: @${senderNum}\n👤 الضحية: @${targetNum}\n💰 نقاط الضحية: ${targetPoints}\n⏳ ${step.emoji} ${step.num}    ${step.text}\n━━━━━━━━━━━━━━━━━━━━\n𝘽𝙔┇𝑴𝑨𝑲𝑰𝑴𝑨`,
                    edit: startMsg.key,
                    mentions: [sender, targetJid]
                }).catch(() => {});
            }

            // ========== إعادة قراءة النقاط الحالية (للتأكد من عدم تغيرها أثناء المراحل) ==========
            const currentPoints = loadJSON(pointsPath, {});
            const senderCurrent = currentPoints[sender] || 0;
            let targetCurrent = currentPoints[targetJid] || 0;

            // ===== التأكد من أن الضحية لا يزال لديه نقاط كافية =====
            if (targetCurrent < 5) {
                await sock.sendMessage(chatId, {
                    text: `💀 عـمـلـيـة سـرقـة 💀\n━━━━━━━━━━━━━━━━━━━━\n❌ فشلت العملية!\n👤 الضحية @${targetNum} قام بسحب نقوده أثناء العملية.\n💰 رصيده الحالي: ${targetCurrent} نقطة\n━━━━━━━━━━━━━━━━━━━━\n𝘽𝙔┇𝑴𝑨𝑲𝑰𝑴𝑨`,
                    edit: startMsg.key,
                    mentions: [sender, targetJid]
                }).catch(() => {});
                return;
            }

            // ===== حساب المبلغ المسروق بناءً على الرصيد الحالي للضحية =====
            const maxStealBase = 1000 + (attackerLevel * 50);
            const maxSteal = Math.min(targetCurrent, maxStealBase);

            // ===== تنفيذ السرقة =====
            const successChance = Math.min(0.65, 0.4 + (attackerLevel * 0.01));
            const isSuccess = Math.random() < successChance;

            let amount = 0;
            let newSenderPoints = senderCurrent;
            let newTargetPoints = targetCurrent;

            if (isSuccess) {
                const stealPercent = Math.min(0.4, 0.2 + (attackerLevel * 0.002));
                amount = Math.floor(targetCurrent * stealPercent);
                amount = Math.min(amount, maxSteal);
                amount = Math.max(1, amount);
                if (targetCurrent - amount < 5) {
                    amount = targetCurrent - 5;
                }

                newSenderPoints = senderCurrent + amount;
                newTargetPoints = targetCurrent - amount;

                logSteal(sender, targetJid, amount, true);
            } else {
                const lossPercent = Math.min(0.2, 0.05 + (attackerLevel * 0.001));
                amount = Math.floor(senderCurrent * lossPercent);
                amount = Math.max(1, Math.min(amount, 500));
                if (senderCurrent - amount < 5) {
                    amount = senderCurrent - 5;
                }

                newSenderPoints = senderCurrent - amount;
                newTargetPoints = targetCurrent + amount;

                logSteal(sender, targetJid, amount, false);
            }

            // ========== حفظ النقاط ==========
            currentPoints[sender] = newSenderPoints;
            currentPoints[targetJid] = newTargetPoints;
            saveJSON(pointsPath, currentPoints);

            // ========== تحديث بيانات السرقة ==========
            updateStealInfo(sender, targetJid);
            cooldown.set(sender, Date.now() + COOLDOWN_TIME);

            // ========== النتيجة النهائية ==========
            const icon = isSuccess ? '🎉' : '💥';
            const title = isSuccess ? 'نـجـاح الـسـرقـة' : 'فـشـل الـسـرقـة';
            const resultText = isSuccess ? `💰 سرقت ${amount} نقطة` : `💸 خسرت ${amount} نقطة (غرامة)`;

            const targetIsHidden = isHidden(targetJid);
            const senderRank = getLevel(newSenderPoints);
            const targetRank = targetIsHidden ? '🔒 مخفي' : getLevel(newTargetPoints);
            const targetPointsDisplay = targetIsHidden ? '🔒 مخفي' : `${newTargetPoints} نقطة`;

            const updatedLimit = checkTargetStealLimit(sender, targetJid);
            const remainingCount = updatedLimit.canSteal ? (5 - updatedLimit.count) : 0;

            await sock.sendMessage(chatId, {
                text: `💀 عـمـلـيـة سـرقـة 💀\n━━━━━━━━━━━━━━━━━━━━\n${icon} ${title} ${icon}\n👤 السارق: @${senderNum}\n👤 الضحية: @${targetNum}\n📊 ${resultText}\n💰 رصيد السارق: ${newSenderPoints} نقطة\n🎖️ رتبته: ${senderRank}\n💰 رصيد الضحية: ${targetPointsDisplay}\n🎖️ رتبته: ${targetRank}\n📊 عدد السرقات المتبقية على هذا الشخص: ${remainingCount}/5\n━━━━━━━━━━━━━━━━━━━━\n𝘽𝙔┇𝑴𝑨𝑲𝑰𝑴𝑨`,
                edit: startMsg.key,
                mentions: [sender, targetJid]
            }).catch(() => {});

        } catch (error) {
            console.error('✗ خطأ في أمر سرقة:', error);
            await sendMessage(sock, msg.key.remoteJid, [
                '❌ حدث خطأ أثناء تنفيذ الأمر.',
                '📌 حاول مرة أخرى لاحقاً.'
            ], msg);
        }
    }
};