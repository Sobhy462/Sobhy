// حروف.js - لعبة الحروف: اكتب كلمة تبدأ بالحرف المطلوب (نسخة محسنة بدون خطوط)
const fs = require('fs');
const path = require('path');

// ============================================================
// 📁 إعدادات الملفات
// ============================================================
const pointsFile = path.join(__dirname, '../data/points.json');
const gameFile = path.join(__dirname, '../data/games.json');

function loadPoints() {
    if (!fs.existsSync(pointsFile)) {
        fs.writeFileSync(pointsFile, JSON.stringify({}, null, 2));
    }
    return JSON.parse(fs.readFileSync(pointsFile));
}

function savePoints(data) {
    fs.writeFileSync(pointsFile, JSON.stringify(data, null, 2));
}

function loadGame() {
    if (!fs.existsSync(gameFile)) {
        fs.writeFileSync(gameFile, JSON.stringify({}, null, 2));
    }
    return JSON.parse(fs.readFileSync(gameFile));
}

function saveGame(data) {
    fs.writeFileSync(gameFile, JSON.stringify(data, null, 2));
}

// ============================================================
// 🏆 نظام التصنيف
// ============================================================
function getLevel(points) {
    if (points >= 1000000000) return '👑 إمبراطور الحروف';
    if (points >= 100000000) return '🌀 ملك الكلمات';
    if (points >= 10000000) return '💀 سيد القاموس';
    if (points >= 1000000) return '🔥🔥 معجم ناطق';
    if (points >= 100000) return '🔪🩸 صياد الكلمات';
    if (points >= 10000) return '🦁 أستاذ اللغة';
    if (points >= 1000) return '💎 متقدم';
    if (points >= 500) return '🔥 مبتدئ';
    if (points >= 200) return '🌱 متعلم';
    return '🐣 جديد';
}

// ============================================================
// 📝 قواعد اللعبة
// ============================================================
const REWARD = 50;
const PENALTY = 30;
const TIME_LIMIT = 20000; // 20 ثانية

// الحروف العربية
const ARABIC_LETTERS = 'أبتثجحخدذرزسشصضطظعغفقكلمنهوي';
const LETTERS = ARABIC_LETTERS.split('');

// كلمات عربية للتحقق
const ARABIC_WORDS = {
    أ: ['أحمد', 'أمير', 'أمان', 'أسد', 'أرض', 'أمل', 'أكل', 'أب', 'أخت', 'أخ', 'أذن', 'أساس', 'أسلوب', 'أصبع', 'أضواء', 'أزرق', 'أبيض', 'أحمر', 'أخضر', 'أصفر'],
    ب: ['باب', 'بيت', 'بحر', 'بطل', 'بسمة', 'بنت', 'بلد', 'بابا', 'بدر', 'برتقال', 'بساط', 'بصلة', 'بطيخ', 'بقدونس', 'بحرية', 'بنفسج', 'برق', 'بريق'],
    ت: ['تمساح', 'تفاحة', 'تاج', 'تأمين', 'تبر', 'تحت', 'تراب', 'تسجيل', 'تلفاز', 'توت', 'تاجر', 'تلميذ', 'تنورة', 'تحدي', 'تقدم', 'تطور'],
    ث: ['ثلج', 'ثعلب', 'ثابت', 'ثانوية', 'ثريا', 'ثعبان', 'ثمن', 'ثوم', 'ثور', 'ثلاجة', 'ثري', 'ثغرة', 'ثقة', 'ثبات'],
    ج: ['جبل', 'جسر', 'جمل', 'جمال', 'جندي', 'جديد', 'جيران', 'جناح', 'جائزة', 'جرة', 'جعفر', 'جهاد', 'جوع', 'جوعان'],
    ح: ['حب', 'حلم', 'حوت', 'حليب', 'حجر', 'حديد', 'حبل', 'حارس', 'حزين', 'حصان', 'حمام', 'حناء', 'حياة', 'حرير', 'حقيقة'],
    خ: ['خبز', 'خريف', 'خادم', 'خالد', 'خروف', 'خضر', 'خنجر', 'خيمة', 'خيط', 'خبير', 'خذلان', 'خدود', 'خوف', 'خيال'],
    د: ['دار', 'دب', 'دجاج', 'درة', 'دكتور', 'دنيا', 'دموع', 'دواء', 'دين', 'دبابة', 'دجاجة', 'دراجة', 'دفتر', 'دليل', 'دموي'],
    ذ: ['ذهب', 'ذئب', 'ذرة', 'ذكي', 'ذكر', 'ذنب', 'ذوق', 'ذيل', 'ذات', 'ذعذع', 'ذهاب', 'ذرة', 'ذكريات'],
    ر: ['رجل', 'ريح', 'رغيف', 'راية', 'رئيس', 'رحلة', 'رمان', 'رمح', 'رمضان', 'ربيع', 'رعد', 'رقص', 'رسالة', 'رسم', 'رغبة'],
    ز: ['زهرة', 'زيت', 'زجاج', 'زمان', 'زعيم', 'زوج', 'زفاف', 'زنجبيل', 'زرد', 'زينة', 'زئبق', 'زورق', 'زاوية'],
    س: ['سيف', 'سلام', 'سحاب', 'سكر', 'سماء', 'سيرة', 'سجاد', 'سفر', 'سلاح', 'سند', 'سور', 'سوس', 'سعادة', 'سؤال', 'سحر'],
    ش: ['شمس', 'شعر', 'شجرة', 'شباب', 'شجاع', 'شراب', 'شطيرة', 'شوكة', 'شهيد', 'شهر', 'شهاب', 'شرشف', 'شوق', 'شرفة', 'شروق'],
    ص: ['صقر', 'صبر', 'صلاة', 'صديق', 'صورة', 'صوت', 'صيف', 'صحن', 'صحافة', 'صحراء', 'صداقة', 'صلاح', 'صحيح', 'صغير'],
    ض: ['ضيف', 'ضوء', 'ضد', 'ضحك', 'ضرب', 'ضريبة', 'ضمير', 'ضواحي', 'ضفاف', 'ضرس', 'ضبع', 'ضفدع', 'ضمان', 'ضجة'],
    ط: ['طائر', 'طريق', 'طاولة', 'طبيب', 'طلب', 'طماطم', 'طيران', 'طوفان', 'طابق', 'طارق', 'طاهر', 'طاعة', 'طبخ', 'طبيعة'],
    ظ: ['ظل', 'ظرف', 'ظالم', 'ظهيرة', 'ظهور', 'ظبي', 'ظن', 'ظريف', 'ظاهر', 'ظلوم', 'ظلام', 'ظلمة'],
    ع: ['عين', 'علم', 'عسل', 'علي', 'عندب', 'عصفور', 'عرش', 'عطاء', 'عمر', 'عنب', 'عودة', 'عجيب', 'عالم', 'عمل', 'عزيز'],
    غ: ['غداء', 'غزال', 'غريب', 'غصن', 'غيم', 'غرفة', 'غسيل', 'غضب', 'غفران', 'غامض', 'غناء', 'غوص', 'غابة', 'غالي'],
    ف: ['فيل', 'فجر', 'فستان', 'فهد', 'فرح', 'فضل', 'فطيرة', 'فم', 'فن', 'فكرة', 'فلفل', 'فناء', 'فارس', 'فجر'],
    ق: ['قلب', 'قمر', 'قلم', 'قائد', 'قصة', 'قصر', 'قطار', 'قفز', 'قمرة', 'قناع', 'قوس', 'قيراط', 'قريب', 'قديم'],
    ك: ['كتاب', 'كأس', 'كلمة', 'كرسي', 'كلب', 'كرامة', 'كعكة', 'كثير', 'كبير', 'كشاف', 'كنز', 'كوكب', 'كمال', 'كريم'],
    ل: ['ليل', 'لبن', 'لون', 'لغة', 'لجام', 'لطيف', 'لقاء', 'لؤلؤة', 'ليمون', 'ليث', 'لوز', 'لعب', 'لحظ', 'لطافة'],
    م: ['ماء', 'ملك', 'مطر', 'مسجد', 'مدرسة', 'مريض', 'مفتاح', 'مؤمن', 'موسيقى', 'مينا', 'مجادل', 'مغني', 'مال', 'مجد'],
    ن: ['نار', 'نجم', 'نوم', 'نهر', 'نصر', 'نظارة', 'نمر', 'نواف', 'نارنج', 'نشيد', 'نسر', 'نافذة', 'نقي', 'نور'],
    ه: ['هلال', 'هواء', 'هندسة', 'هوية', 'هجرة', 'هادئ', 'هجوم', 'هيكل', 'هزار', 'هيام', 'هنود', 'هدية', 'هدف'],
    و: ['ورد', 'وطن', 'وليد', 'وسادة', 'ورق', 'وادي', 'وعد', 'وجه', 'وقت', 'وهم', 'واحة', 'وصال', 'وضوح', 'وزن'],
    ي: ['يد', 'يوم', 'ياسمين', 'يعقوب', 'يمين', 'يراع', 'يسار', 'يوسف', 'ينبوع', 'يهودي', 'يقطين', 'يقين', 'ياقوت']
};

// ============================================================
// دالة التحقق من صحة الكلمة
// ============================================================
function isValidWord(word, letter) {
    if (word.length < 2) return false;
    if (!word.startsWith(letter)) return false;

    const wordsList = ARABIC_WORDS[letter] || [];
    if (wordsList.includes(word)) return true;

    const arabicRegex = /^[\u0600-\u06FF]+$/;
    if (arabicRegex.test(word) && word.length >= 2) {
        if (!ARABIC_WORDS[letter]) ARABIC_WORDS[letter] = [];
        if (!ARABIC_WORDS[letter].includes(word)) {
            ARABIC_WORDS[letter].push(word);
        }
        return true;
    }
    return false;
}

// ============================================================
// دالة الإرسال
// ============================================================
async function sendMessage(sock, chatId, lines, quoted = null, mentions = []) {
    if (!Array.isArray(lines)) {
        lines = [lines];
    }

    let msg = `🔠 لـعـبـة الـحـروف 🔠\n`;
    msg += `━━━━━━━━━━━━━━━━━━━━\n`;
    for (const line of lines) {
        msg += `${line}\n`;
    }
    msg += `━━━━━━━━━━━━━━━━━━━━\n`;
    msg += `𝘽𝙔┇𝑴𝑨𝑲𝑰𝑴𝑨`;
    await sock.sendMessage(chatId, { text: msg, mentions }, { quoted: quoted });
}

// ============================================================
// 📋 الأمر الرئيسي
// ============================================================
module.exports = {
    command: ['حروف'],
    description: '🔠 لعبة الحروف: اكتب كلمة تبدأ بالحرف المطلوب',
    usage: '.حروف',
    category: 'فعاليات',

    async execute(sock, msg) {
        try {
            const chatId = msg.key.remoteJid;
            const sender = msg.key.participant || msg.participant || msg.key.remoteJid;

            if (!chatId.endsWith('@g.us')) {
                await sendMessage(sock, chatId, [
                    '❌ هذه اللعبة تعمل في المجموعات فقط.'
                ], msg);
                return;
            }

            const games = loadGame();
            if (games[chatId] && games[chatId].active) {
                await sendMessage(sock, chatId, [
                    '⚠️ هناك لعبة نشطة حالياً، انتظر حتى تنتهي.'
                ], msg);
                return;
            }

            const letter = LETTERS[Math.floor(Math.random() * LETTERS.length)];

            games[chatId] = {
                active: true,
                letter: letter,
                started: Date.now(),
                winner: null
            };
            saveGame(games);

            const lines = [
                '🔠 *فعالية الحروف*',
                '',
                `📝 المطلوب: اكتب كلمة تبدأ بحرف`,
                `🅰️ الحرف: *${letter}*`,
                '',
                '📜 *القوانين:*',
                '1️⃣ الكلمة تبدأ بنفس الحرف',
                '2️⃣ الكلمة تكون على الأقل حرفين',
                '3️⃣ أول واحد يكتب صح يفوز 🎊',
                '',
                `💰 الجائزة: ${REWARD} نقطة`,
                `⏳ الوقت: ${TIME_LIMIT/1000} ثانية`
            ];

            await sendMessage(sock, chatId, lines, msg, [sender]);

            // ============================================================
            // 📨 معالج الإجابات
            // ============================================================
            const handler = async ({ messages }) => {
                for (const m of messages) {
                    try {
                        const gameData = loadGame();
                        if (!gameData[chatId] || !gameData[chatId].active) {
                            sock.ev.off('messages.upsert', handler);
                            return;
                        }

                        if (m.key.remoteJid !== chatId) continue;

                        const txt = m.message?.conversation || m.message?.extendedTextMessage?.text || '';
                        if (!txt) continue;

                        const answer = txt.trim();
                        const answerer = m.key.participant || m.participant || m.key.remoteJid;

                        const currentLetter = gameData[chatId].letter;

                        if (!answer.startsWith(currentLetter)) continue;
                        if (answer.length < 2) continue;

                        const isValid = isValidWord(answer, currentLetter);

                        if (isValid) {
                            clearTimeout(timeout);
                            sock.ev.off('messages.upsert', handler);

                            gameData[chatId].active = false;
                            gameData[chatId].winner = answerer;
                            saveGame(gameData);

                            const points = loadPoints();
                            points[answerer] = (points[answerer] || 0) + REWARD;
                            savePoints(points);

                            const resultLines = [
                                '🎉 *مبروك!*',
                                '',
                                `👑 الفائز: @${answerer.split('@')[0]}`,
                                `📝 الكلمة: *${answer}*`,
                                `🅰️ الحرف: *${currentLetter}*`,
                                `💰 +${REWARD} نقطة`,
                                `📊 نقاطك: ${points[answerer]}`,
                                `🏅 رتبتك: ${getLevel(points[answerer])}`
                            ];

                            await sendMessage(sock, chatId, resultLines, m, [answerer]);
                            return;
                        }
                    } catch (err) {
                        console.error('❌ خطأ في المعالج:', err);
                    }
                }
            };

            sock.ev.on('messages.upsert', handler);

            // ============================================================
            // ⏰ المهلة الزمنية
            // ============================================================
            const timeout = setTimeout(async () => {
                const gameData = loadGame();
                if (!gameData[chatId] || !gameData[chatId].active) return;

                gameData[chatId].active = false;
                saveGame(gameData);

                sock.ev.off('messages.upsert', handler);

                const lines = [
                    '⏰ *انتهى الوقت!*',
                    '',
                    `🅰️ الحرف كان: *${gameData[chatId].letter}*`,
                    '',
                    '💡 حاول مرة أخرى بـ .حروف'
                ];

                await sendMessage(sock, chatId, lines, msg, [sender]);
            }, TIME_LIMIT);

        } catch (error) {
            console.error('✗ خطأ في أمر حروف:', error);
            await sendMessage(sock, msg.key.remoteJid, [
                '❌ حدث خطأ أثناء تنفيذ الأمر.',
                '📌 حاول مرة أخرى لاحقاً.'
            ], msg);
        }
    }
};