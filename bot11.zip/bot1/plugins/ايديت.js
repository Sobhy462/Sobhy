// ايديت.js - تحميل فيديوهات إيديت (عادي أو دائري) مع نشر في جروبات الملصقات (باستخدام نظام التبادل)

const axios = require('axios');
const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');
const ffmpeg = require('fluent-ffmpeg');

// ========== استيراد دوال نظام التبادل ==========
let loadData, getGroupName;
try {
    const exchangeModule = require('./تبادل.js');
    loadData = exchangeModule.loadData;
    getGroupName = exchangeModule.getGroupName;
} catch (e) {
    console.error('❌ فشل استيراد دوال التبادل:', e.message);
    loadData = () => ({});
    getGroupName = async () => 'جروب غير معروف';
}

const commandPrice = 200;
const APIFY_TOKEN = 'apify_api_Nosx6ch9Ua28pFgV1TFeurHCsbflPn21ezuh';

const pointsPath = path.join(__dirname, '../data/points.json');
const tempDir = path.join(__dirname, '..', 'temp');

if (!fs.existsSync(path.join(__dirname, '../data'))) fs.mkdirSync(path.join(__dirname, '../data'), { recursive: true });
if (!fs.existsSync(pointsPath)) fs.writeFileSync(pointsPath, JSON.stringify({}, null, 2));
if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true });

// ========== دوال النقاط ==========
function loadPoints() {
    try {
        return JSON.parse(fs.readFileSync(pointsPath));
    } catch {
        return {};
    }
}

function savePoints(data) {
    fs.writeFileSync(pointsPath, JSON.stringify(data, null, 2));
}

// ========== تنسيق النقاط ==========
function formatPoints(num) {
    if (num === undefined || num === null || isNaN(num)) return '0';
    num = Math.floor(num);
    if (num >= 1e15) return '∞';
    if (num >= 1e12) return (num / 1e12).toFixed(2) + ' تريليون';
    if (num >= 1e9) return (num / 1e9).toFixed(2) + ' مليار';
    if (num >= 1e6) return (num / 1e6).toFixed(2) + ' مليون';
    if (num >= 1e3) return (num / 1e3).toFixed(2) + ' ألف';
    return num.toString();
}

// ========== دالة الإرسال المنسقة ==========
async function sendMessage(sock, chatId, lines, quoted = null, mentions = []) {
    if (!Array.isArray(lines)) lines = [lines];
    let msg = `🎬 تـحـمـيـل إيـديـت 🎬\n━━━━━━━━━━━━━━━━━━━━\n`;
    for (const line of lines) {
        if (line && line.trim()) msg += `${line}\n`;
    }
    msg += `━━━━━━━━━━━━━━━━━━━━\n𝘽𝙔┇𝑴𝑨𝑲𝑰𝑴𝑨`;
    await sock.sendMessage(chatId, { text: msg, mentions }, { quoted: quoted });
}

// ========== جلب فيديو عبر TikWM ==========
async function fetchViaTikWM(query) {
    try {
        const apiUrl = `https://www.tikwm.com/api/feed/search?keywords=${encodeURIComponent(query)}&count=30`;
        const response = await axios.get(apiUrl, {
            timeout: 30000,
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                'Referer': 'https://www.tikwm.com/',
                'Origin': 'https://www.tikwm.com',
                'Accept': 'application/json, text/plain, */*',
                'Accept-Encoding': 'gzip, deflate, br',
                'Accept-Language': 'en-US,en;q=0.9'
            }
        });
        if (response.status === 200 && response.data?.code === 0) {
            const videos = response.data.data?.videos || [];
            return videos.filter(v => v.play && v.duration < 60);
        }
        return [];
    } catch (error) {
        console.error('❌ فشل جلب من TikWM:', error.message);
        return [];
    }
}

// ========== جلب فيديو عبر Apify (بديل) ==========
async function fetchViaApify(query) {
    try {
        const apiUrl = 'https://api.apify.com/v2/acts/mu0i~tiktok-search-scraper/run-sync-get-dataset-items';
        const response = await axios.post(
            apiUrl,
            {
                queries: [`${query} edit montage amv 4k`],
                resultType: 'videos',
                maxResultsPerQuery: 20,
                sortBy: 'relevance',
                includeDownloadUrls: true
            },
            {
                params: { token: APIFY_TOKEN },
                headers: { 'Content-Type': 'application/json' },
                timeout: 120000
            }
        );
        const data = Array.isArray(response.data) ? response.data : [];
        if (!data.length) return [];
        return data
            .filter(v => v && v.url && !v.isPhotoPost && (v.duration || 0) < 60)
            .map(v => ({
                play: v.noWatermarkUrl || v.url,
                title: v.description || 'إيديت',
                duration: v.duration || 0,
                author: { nickname: v.authorUsername || v.authorNickname || 'مجهول' }
            }));
    } catch (error) {
        console.error('❌ فشل جلب من Apify:', error.message);
        return [];
    }
}

// ========== تحميل الفيديو كـ Buffer ==========
async function downloadVideo(url) {
    try {
        const response = await axios.get(url, {
            responseType: 'arraybuffer',
            timeout: 60000,
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                'Referer': 'https://www.tiktok.com/'
            }
        });
        return Buffer.from(response.data);
    } catch (error) {
        console.error('❌ فشل تحميل الفيديو:', error.message);
        return null;
    }
}

// ========== التحقق من وجود ffmpeg ==========
function checkFfmpeg() {
    return new Promise((resolve) => {
        exec('which ffmpeg', (err, stdout) => {
            if (err || !stdout.trim()) {
                resolve(false);
            } else {
                resolve(true);
            }
        });
    });
}

// ========== تحويل فيديو إلى دائري (Video Note) ==========
async function convertToCircle(inputPath, outputPath) {
    return new Promise((resolve, reject) => {
        const timeout = setTimeout(() => {
            reject(new Error('انتهت مهلة التحويل (60 ثانية)'));
        }, 60000);

        ffmpeg(inputPath)
            .videoCodec('libx264')
            .size('320x320')
            .aspect('1:1')
            .videoBitrate('1000k')
            .audioBitrate('128k')
            .audioCodec('aac')
            .outputOptions([
                '-vf', 'scale=320:320:force_original_aspect_ratio=decrease,pad=320:320:(ow-iw)/2:(oh-ih)/2:black,crop=320:320',
                '-movflags', '+faststart',
                '-crf', '18',
                '-preset', 'slow'
            ])
            .on('end', () => {
                clearTimeout(timeout);
                resolve();
            })
            .on('error', (err) => {
                clearTimeout(timeout);
                reject(new Error(`ffmpeg فشل: ${err.message}`));
            })
            .save(outputPath);
    });
}

// ========== بناء رسالة جروب الملصقات ==========
function buildStickerGroupMessage(type, searchText, senderName) {
    const lines = [
        `تنفيذ طــلــب""`,
        `──꯭ׂ─꯭─ׅ─ׂ𓂃̼𝆬. ~🍃~  𓂃─ׅ──꯭ׂ─꯭──ׅ`,
        `╾ نــوع الطلـ𝅄ـب⤢ \`『${type}』\``,
        ``,
        `╾ الـــطـ  ໋֢ ـلــب ⤢ \`『${searchText}』\``,
        ``,
        `╾ صــاحـب الـطلـ𝇁𝇃𝇂ــب ⤢ \`『@${senderName}』\``,
        ``,
        `╾ المـسـ∙∙∙ــؤول ⤢ \`『𝑴𝑨𝑲𝑰𝑴𝑨』\``,
        `──꯭ׂ─꯭─ׅ─ׂ𓂃̼𝆬. ~🍃~  𓂃─ׅ──꯭ׂ─꯭──`,
        `[ 𝑴𝑨𝑲𝑰𝑴𝑨 𝑩𝑶𝑻 ]`,
        ``,
        `*⚡︎ ─── ❖ ── ✦ ── ❖ ─── ⚡︎*`,
        `*└🔱 𝑴𝑨𝑲𝑰𝑴𝑨 🔱┐*`
    ];
    return lines.join('\n');
}

// ========== النشر في جروبات الملصقات ==========
async function publishToStickerGroups(sock, sourceChatId, videoBuffer, searchText, senderName, isCircle) {
    try {
        // استخدام نظام التبادل لجلب جروبات الملصقات
        const exchangeData = loadData();
        const stickerGroups = exchangeData['ملصقات'] || [];

        if (!stickerGroups.length) {
            console.log('⚠️ لا توجد جروبات ملصقات مضبوطة، تخطي النشر');
            return;
        }

        const type = isCircle ? 'ايديت دائري' : 'ايديت';
        const caption = buildStickerGroupMessage(type, searchText, senderName);

        for (const groupJid of stickerGroups) {
            if (groupJid === sourceChatId) continue;
            try {
                if (isCircle) {
                    await sock.sendMessage(groupJid, {
                        video: videoBuffer,
                        mimetype: 'video/mp4',
                        ptv: true,
                        caption: caption
                    });
                } else {
                    await sock.sendMessage(groupJid, {
                        video: videoBuffer,
                        caption: caption,
                        mimetype: 'video/mp4'
                    });
                }
                console.log(`✅ نشر الإيديت في جروب الملصقات: ${groupJid}`);
                await new Promise(resolve => setTimeout(resolve, 500));
            } catch (e) {
                console.error(`❌ فشل النشر في ${groupJid}:`, e.message);
            }
        }
    } catch (e) {
        console.error('❌ خطأ في نشر الإيديت في جروبات الملصقات:', e.message);
    }
}

// ========== معالج الإيديت العام ==========
async function handleEdit(sock, chatId, msg, searchText, sender, isCircle) {
    const points = loadPoints();
    const userPoints = points[sender] || 0;

    if (userPoints < commandPrice) {
        const lines = [
            '❌ *نقاط غير كافية*',
            '',
            `💰 السعر: ${commandPrice} نقطة`,
            `🪙 رصيدك: ${formatPoints(userPoints)} نقطة`,
            `💔 تحتاج: ${formatPoints(commandPrice - userPoints)} نقطة إضافية`
        ];
        await sendMessage(sock, chatId, lines, msg, [sender]);
        return false;
    }

    // خصم النقاط مؤقتاً
    points[sender] = userPoints - commandPrice;
    savePoints(points);

    await sock.sendMessage(chatId, { react: { text: '⏳', key: msg.key } });

    try {
        // تحسين البحث
        const searchQuery = `${searchText} edit montage amv 4k`;
        let videos = await fetchViaTikWM(searchQuery);
        if (!videos.length) {
            console.log('⚠️ TikWM فشل، نحاول عبر Apify...');
            videos = await fetchViaApify(searchText);
        }

        if (!videos.length) {
            points[sender] = (points[sender] || 0) + commandPrice;
            savePoints(points);
            await sock.sendMessage(chatId, { react: { text: '❌', key: msg.key } });
            await sendMessage(sock, chatId, [
                '❌ لا توجد نتائج',
                '💡 تم استرجاع نقاطك'
            ], msg);
            return false;
        }

        // اختيار فيديو عشوائي
        const video = videos[Math.floor(Math.random() * videos.length)];
        const videoUrl = video.play || video.video_url;
        if (!videoUrl) {
            points[sender] = (points[sender] || 0) + commandPrice;
            savePoints(points);
            await sock.sendMessage(chatId, { react: { text: '❌', key: msg.key } });
            await sendMessage(sock, chatId, [
                '❌ لا يوجد فيديو متاح',
                '💡 تم استرجاع نقاطك'
            ], msg);
            return false;
        }

        // تحميل الفيديو
        let videoBuffer = await downloadVideo(videoUrl);
        if (!videoBuffer || videoBuffer.length < 1000) {
            points[sender] = (points[sender] || 0) + commandPrice;
            savePoints(points);
            await sock.sendMessage(chatId, { react: { text: '❌', key: msg.key } });
            await sendMessage(sock, chatId, [
                '❌ فشل تحميل الفيديو',
                '💡 تم استرجاع نقاطك'
            ], msg);
            return false;
        }

        let finalBuffer = videoBuffer;
        let isCircleSent = false;

        // إذا كان دائرياً، نحول الفيديو
        if (isCircle) {
            const hasFfmpeg = await checkFfmpeg();
            if (!hasFfmpeg) {
                await sendMessage(sock, chatId, [
                    '⚠️ *ffmpeg غير مثبت على النظام*',
                    '📌 يرجى تثبيته لتشغيل خاصية الدائري:',
                    '`pkg install ffmpeg`',
                    '📌 سيتم إرسال الفيديو العادي بدلاً من ذلك.'
                ], msg);
                isCircleSent = false;
                finalBuffer = videoBuffer;
            } else {
                const inputPath = path.join(tempDir, `input_${Date.now()}.mp4`);
                const outputPath = path.join(tempDir, `output_${Date.now()}.mp4`);
                try {
                    fs.writeFileSync(inputPath, videoBuffer);
                    await convertToCircle(inputPath, outputPath);
                    if (fs.existsSync(outputPath) && fs.statSync(outputPath).size > 1000) {
                        finalBuffer = fs.readFileSync(outputPath);
                        isCircleSent = true;
                    } else {
                        throw new Error('فشل إنشاء الفيديو الدائري');
                    }
                } catch (convError) {
                    console.error('❌ فشل التحويل إلى دائري، نرسل عادي:', convError.message);
                    isCircleSent = false;
                    finalBuffer = videoBuffer;
                    await sendMessage(sock, chatId, [
                        '⚠️ تعذر تحويل الفيديو إلى دائري، سيتم إرساله كفيديو عادي',
                        `💡 سبب الخطأ: ${convError.message}`
                    ], msg);
                } finally {
                    try {
                        if (fs.existsSync(inputPath)) fs.unlinkSync(inputPath);
                        if (fs.existsSync(outputPath)) fs.unlinkSync(outputPath);
                    } catch (e) {}
                }
            }
        }

        const newBalance = points[sender];
        const senderName = msg.pushName || sender.split('@')[0];
        const typeLabel = isCircle && isCircleSent ? 'دائري' : 'عادي';

        const caption =
`🎬 *فيديو إيديت*

📌 *النوع:* ${typeLabel}
🔍 *البحث:* ${searchText}

✅ تم الإرسال بنجاح
💰 تم خصم ${commandPrice} نقطة
🪙 رصيدك: ${formatPoints(newBalance)} نقطة
𝘽𝙔┇𝑴𝑨𝑲𝑰𝑴𝑨`;

        // إرسال الفيديو مع محاولة إعادة الرفع
        let sent = false;
        for (let attempt = 0; attempt < 3; attempt++) {
            try {
                if (isCircle && isCircleSent) {
                    await sock.sendMessage(chatId, {
                        video: finalBuffer,
                        mimetype: 'video/mp4',
                        ptv: true,
                        caption: caption
                    }, { quoted: msg });
                } else {
                    await sock.sendMessage(chatId, {
                        video: finalBuffer,
                        caption: caption,
                        mimetype: 'video/mp4'
                    }, { quoted: msg });
                }
                sent = true;
                break;
            } catch (err) {
                console.log(`⚠️ محاولة ${attempt + 1}/3 فشلت، إعادة المحاولة...`);
                await new Promise(r => setTimeout(r, 2000));
            }
        }

        if (!sent) {
            // إرسال الرابط بدلاً من الفيديو
            await sock.sendMessage(chatId, {
                text: `⚠️ تعذر رفع الفيديو، إليك الرابط:\n${videoUrl}\n\n${caption}`
            }, { quoted: msg });
        }

        await sock.sendMessage(chatId, { react: { text: '✅', key: msg.key } });

        // نشر في جروبات الملصقات (إذا كان الإرسال ناجحاً)
        if (sent && finalBuffer) {
            try {
                await publishToStickerGroups(sock, chatId, finalBuffer, searchText, senderName, isCircle && isCircleSent);
            } catch (e) {
                console.error('⚠️ فشل النشر في جروبات الملصقات:', e.message);
            }
        }

        return true;

    } catch (error) {
        console.error('❌ خطأ في ايديت:', error);
        points[sender] = (points[sender] || 0) + commandPrice;
        savePoints(points);
        await sock.sendMessage(chatId, { react: { text: '❌', key: msg.key } });
        await sendMessage(sock, chatId, [
            `❌ حدث خطأ: ${error.message || 'خطأ غير معروف'}`,
            '💡 تم استرجاع نقاطك',
            '🔄 حاول مرة أخرى'
        ], msg);
        return false;
    }
}

// ========== الأمر الرئيسي ==========
module.exports = {
    command: ['ايديت'],
    category: 'وسائط',
    description: '🎬 تحميل فيديوهات إيديت (عادي أو دائري) مقابل نقاط',
    usage: '.ايديت <كلمة> - إيديت عادي\n.ايديت دائري <كلمة> - إيديت دائري',
    price: commandPrice,

    async execute(sock, msg, args) {
        let chatId, sender, searchText, isCircle;

        try {
            chatId = msg.key.remoteJid;
            sender = msg.key.participant || msg.key.remoteJid;

            // استخراج النص
            searchText = '';
            isCircle = false;

            if (args && args.length) {
                const firstArg = args[0].toLowerCase();
                if (firstArg === 'دائري') {
                    isCircle = true;
                    searchText = args.slice(1).join(' ').trim();
                } else {
                    searchText = args.join(' ').trim();
                }
            }

            // محاولة استخراج من الرسالة
            if (!searchText && msg.message?.conversation) {
                const text = msg.message.conversation.replace(/^\.ايديت\s*/i, '').trim();
                if (text.toLowerCase().startsWith('دائري ')) {
                    isCircle = true;
                    searchText = text.replace(/^دائري\s*/i, '').trim();
                } else {
                    searchText = text;
                }
            }

            if (!searchText && msg.message?.extendedTextMessage?.text) {
                const text = msg.message.extendedTextMessage.text.replace(/^\.ايديت\s*/i, '').trim();
                if (text.toLowerCase().startsWith('دائري ')) {
                    isCircle = true;
                    searchText = text.replace(/^دائري\s*/i, '').trim();
                } else {
                    searchText = text;
                }
            }

            // عرض المساعدة
            if (!searchText) {
                const lines = [
                    '🎬 *أمر الإيديت*',
                    '',
                    '📌 *الاستخدام:*',
                    '.ايديت <كلمة> - إيديت عادي',
                    '.ايديت دائري <كلمة> - إيديت دائري',
                    '',
                    '📌 *مثال:*',
                    '.ايديت انمي',
                    '.ايديت دائري انمي',
                    '',
                    `💰 *السعر:* ${commandPrice} نقطة`
                ];
                await sendMessage(sock, chatId, lines, msg);
                return;
            }

            // تنفيذ المعالج
            await handleEdit(sock, chatId, msg, searchText, sender, isCircle);

        } catch (error) {
            console.error('❌ خطأ في ايديت:', error);
            if (!chatId) chatId = msg.key?.remoteJid || 'unknown';
            await sock.sendMessage(chatId, {
                text: `❌ حدث خطأ: ${error.message || 'خطأ غير معروف'}`
            }, { quoted: msg });
        }
    }
};