// قوانين.js - عرض قوانين النقابة (نسخة محسنة بدون خطوط)
module.exports = {
    command: ['قوانين'],
    description: '📜 عرض قوانين النقابة',
    usage: '.قوانين',
    category: 'عام',

    async execute(sock, msg) {
        try {
            const chatId = msg.key.remoteJid;

            // خاص بالجروبات فقط
            if (!chatId.endsWith('@g.us')) {
                await sock.sendMessage(
                    chatId,
                    { text: '❌ هذا الأمر خاص بالمجموعات فقط.' },
                    { quoted: msg }
                );
                return;
            }

            const lines = [
                '📜 قـوانـيـن الـنـقـابـة 📜',
                '━━━━━━━━━━━━━━━━━━━━',
                '',
                '❌ *ممنوعات:*',
                '   • تعكير مزاج الأعضاء',
                '   • السب والتطاول والتهايط',
                '   • نشر روابط غير مصرح بها',
                '   • محتوى +18 أو غير لائق',
                '   • رسائل غير محترمة',
                '   • الدخول خاص بدون إذن',
                '   • طلب إشراف أو صلاحيات',
                '',
                '⚖️ *العقوبة:*',
                '   • إنذار أولي للمخالفات البسيطة',
                '   • طرد فوري للمخالفات الخطيرة',
                '   • حظر مؤبد للمخالفات المتكررة',
                '',
                '🛡️ *للتبليغ:*',
                '   • تواصل مع المشرفين',
                '   • أرسل .تبليغ [السبب]',
                '━━━━━━━━━━━━━━━━━━━━',
                '𝘽𝙔┇𝑴𝑨𝑲𝑰𝑴𝑨'
            ];

            await sock.sendMessage(
                chatId,
                { text: lines.join('\n') },
                { quoted: msg }
            );

        } catch (error) {
            console.error('✗ خطأ في أمر القوانين:', error);
            await sock.sendMessage(
                msg.key.remoteJid,
                { text: '❌ حدث خطأ أثناء تنفيذ الأمر.' },
                { quoted: msg }
            );
        }
    }
};