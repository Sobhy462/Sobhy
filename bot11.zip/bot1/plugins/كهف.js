// كهف.js - استكشاف الكهوف (100 كهف، كل كهف يحتاج مستوى محدد، مكافآت متزايدة، استكشاف مرة واحدة لكل كهف)
const fs = require('fs');
const path = require('path');

const pointsPath = path.join(__dirname, '../data/points.json');

// ===== مسارات التخزين المنفصل =====
const dataDir = path.join(__dirname, '../data/kingdom');
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

const MAIN_PATH = path.join(dataDir, 'main.json');
const RESOURCES_PATH = path.join(dataDir, 'resources.json');
const WEAPONS_PATH = path.join(dataDir, 'weapons.json');
const SOLDIERS_PATH = path.join(dataDir, 'soldiers.json');
const ACCESSORIES_PATH = path.join(dataDir, 'accessories.json');
const POTIONS_PATH = path.join(dataDir, 'potions.json');
const SPELLS_PATH = path.join(dataDir, 'spells.json');
const SOULBOOK_PATH = path.join(dataDir, 'soulbook.json');
const COMPANION_PATH = path.join(dataDir, 'companion.json');
const ACTIVE_PATH = path.join(dataDir, 'active.json');
const EXPLORED_CAVES_PATH = path.join(dataDir, 'explored_caves.json'); // ملف منفصل للكهوف المستكشفة

// ===== التأكد من وجود جميع الملفات =====
const allPaths = [MAIN_PATH, RESOURCES_PATH, WEAPONS_PATH, SOLDIERS_PATH, ACCESSORIES_PATH, POTIONS_PATH, SPELLS_PATH, SOULBOOK_PATH, COMPANION_PATH, ACTIVE_PATH, EXPLORED_CAVES_PATH];
for (const p of allPaths) {
    if (!fs.existsSync(p)) fs.writeFileSync(p, JSON.stringify({}, null, 2));
}
if (!fs.existsSync(pointsPath)) fs.writeFileSync(pointsPath, JSON.stringify({}, null, 2));

function loadJSON(file) { try { return JSON.parse(fs.readFileSync(file)); } catch { return {}; } }
function saveJSON(file, data) {
    try {
        if (fs.existsSync(file)) fs.writeFileSync(file + '.bak', fs.readFileSync(file));
        fs.writeFileSync(file, JSON.stringify(data, null, 2));
        return true;
    } catch (e) {
        console.error('❌ فشل حفظ:', file, e.message);
        return false;
    }
}

// ========== دوال التخزين المنفصل ==========
function loadUserData(jid) {
    const main = loadJSON(MAIN_PATH)[jid] || {};
    const resources = loadJSON(RESOURCES_PATH)[jid] || {};
    const soldiers = loadJSON(SOLDIERS_PATH)[jid] || {};
    const weapons = loadJSON(WEAPONS_PATH)[jid] || {};
    const accessories = loadJSON(ACCESSORIES_PATH)[jid] || {};
    const potions = loadJSON(POTIONS_PATH)[jid] || {};
    const spells = loadJSON(SPELLS_PATH)[jid] || {};
    const soulBook = loadJSON(SOULBOOK_PATH)[jid] || {};
    const companion = loadJSON(COMPANION_PATH)[jid] || null;
    const active = loadJSON(ACTIVE_PATH)[jid] || {};

    return {
        level: main.level || 1,
        prosperity: main.prosperity || 0,
        lands: main.lands || 0,
        gold: main.gold || 0,
        name: main.name || `مملكة @${jid.split('@')[0]}`,
        owner: main.owner || jid,
        nameChangesUsed: main.nameChangesUsed || 0,
        resources: resources,
        soldiers: soldiers,
        weapons: weapons,
        accessories: accessories,
        potions: potions,
        spellsUsed: spells,
        soulBook: soulBook,
        companion: companion,
        exploredCaves: active.exploredCaves || [], // للحفاظ على التوافق مع الإصدارات القديمة
        lastActive: active.lastActive || 0
    };
}

function saveUserData(jid, data) {
    const main = loadJSON(MAIN_PATH);
    main[jid] = {
        level: data.level || 1,
        prosperity: data.prosperity || 0,
        lands: data.lands || 0,
        gold: data.gold || 0,
        name: data.name || `مملكة @${jid.split('@')[0]}`,
        owner: data.owner || jid,
        nameChangesUsed: data.nameChangesUsed || 0
    };
    saveJSON(MAIN_PATH, main);

    const resources = loadJSON(RESOURCES_PATH);
    resources[jid] = data.resources || { wood: 0, stone: 0, iron: 0 };
    saveJSON(RESOURCES_PATH, resources);

    const soldiers = loadJSON(SOLDIERS_PATH);
    soldiers[jid] = data.soldiers || {};
    saveJSON(SOLDIERS_PATH, soldiers);

    const weapons = loadJSON(WEAPONS_PATH);
    weapons[jid] = data.weapons || {};
    saveJSON(WEAPONS_PATH, weapons);

    const accessories = loadJSON(ACCESSORIES_PATH);
    accessories[jid] = data.accessories || {};
    saveJSON(ACCESSORIES_PATH, accessories);

    const potions = loadJSON(POTIONS_PATH);
    potions[jid] = data.potions || {};
    saveJSON(POTIONS_PATH, potions);

    const spells = loadJSON(SPELLS_PATH);
    spells[jid] = data.spellsUsed || {};
    saveJSON(SPELLS_PATH, spells);

    const soulBook = loadJSON(SOULBOOK_PATH);
    soulBook[jid] = data.soulBook || { pages: 0, spirits: [] };
    saveJSON(SOULBOOK_PATH, soulBook);

    const companion = loadJSON(COMPANION_PATH);
    companion[jid] = data.companion || null;
    saveJSON(COMPANION_PATH, companion);

    const active = loadJSON(ACTIVE_PATH);
    active[jid] = {
        exploredCaves: data.exploredCaves || [],
        lastActive: data.lastActive || Date.now()
    };
    saveJSON(ACTIVE_PATH, active);
}

function userExists(jid) {
    const main = loadJSON(MAIN_PATH);
    return !!main[jid];
}

// ========== دوال الكهوف المستكشفة (ملف منفصل للحماية) ==========
function loadExploredCaves() {
    return loadJSON(EXPLORED_CAVES_PATH, {});
}

function saveExploredCaves(data) {
    saveJSON(EXPLORED_CAVES_PATH, data);
}

function isCaveExplored(jid, caveNumber) {
    const data = loadExploredCaves();
    const userData = data[jid] || { caves: [] };
    return userData.caves.includes(caveNumber);
}

function markCaveExplored(jid, caveNumber) {
    const data = loadExploredCaves();
    if (!data[jid]) data[jid] = { caves: [] };
    if (!data[jid].caves.includes(caveNumber)) {
        data[jid].caves.push(caveNumber);
        saveExploredCaves(data);
        return true;
    }
    return false;
}

function getExploredCaves(jid) {
    const data = loadExploredCaves();
    return data[jid] ? data[jid].caves : [];
}

// ========== قوائم المكافآت ==========
const WEAPON_KEYS = ['ironSword', 'goldenShield', 'legendaryBow', 'lightningSword', 'giantHammer', 'deathBow', 'destructionAxe', 'heroSword', 'timeBow', 'eternalBlade', 'fireShield', 'godShield'];
const SOLDIER_KEYS = ['normal', 'knight', 'archer', 'eliteGuard', 'dragonSpearman', 'legendaryCommander'];
const ACCESSORY_KEYS = ['powerRing', 'protectionRing', 'kingsCrown', 'shadowMask', 'heroMask'];
const POTION_KEYS = ['smallHeal', 'largeHeal', 'energyPotion', 'craftedHeal'];

function getCaveRewards(caveNumber) {
    const multiplier = caveNumber;

    const points = Math.floor(Math.random() * (150 * multiplier - 50 * multiplier + 1)) + 50 * multiplier;
    const gold = Math.floor(Math.random() * (80 * multiplier - 20 * multiplier + 1)) + 20 * multiplier;
    const wood = Math.floor(Math.random() * (30 * multiplier)) + 5 * multiplier;
    const stone = Math.floor(Math.random() * (20 * multiplier)) + 5 * multiplier;
    const iron = Math.floor(Math.random() * (15 * multiplier)) + 3 * multiplier;

    let weaponReward = null;
    if (Math.random() < 0.3 + (caveNumber / 300)) {
        const tier = Math.min(Math.floor(caveNumber / 10), WEAPON_KEYS.length - 1);
        const weaponKey = WEAPON_KEYS[Math.floor(Math.random() * (tier + 1))];
        const count = Math.floor(Math.random() * 3) + 1;
        weaponReward = { key: weaponKey, count };
    }

    let soldierReward = null;
    if (Math.random() < 0.2 + (caveNumber / 400)) {
        const tier = Math.min(Math.floor(caveNumber / 15), SOLDIER_KEYS.length - 1);
        const soldierKey = SOLDIER_KEYS[Math.floor(Math.random() * (tier + 1))];
        const count = Math.floor(Math.random() * 5) + 1;
        soldierReward = { key: soldierKey, count };
    }

    let accessoryReward = null;
    if (Math.random() < 0.15 + (caveNumber / 500)) {
        const tier = Math.min(Math.floor(caveNumber / 20), ACCESSORY_KEYS.length - 1);
        const accessoryKey = ACCESSORY_KEYS[Math.floor(Math.random() * (tier + 1))];
        accessoryReward = { key: accessoryKey, count: 1 };
    }

    let potionReward = null;
    if (Math.random() < 0.25 + (caveNumber / 300)) {
        const tier = Math.min(Math.floor(caveNumber / 10), POTION_KEYS.length - 1);
        const potionKey = POTION_KEYS[Math.floor(Math.random() * (tier + 1))];
        const count = Math.floor(Math.random() * 3) + 1;
        potionReward = { key: potionKey, count };
    }

    let companionReward = null;
    if (Math.random() < 0.02 + (caveNumber / 2000)) {
        const companions = ['dragon', 'darkWolf', 'iceEagle', 'otherworldDragon'];
        const companionKey = companions[Math.floor(Math.random() * companions.length)];
        companionReward = { key: companionKey };
    }

    let soulPageReward = 0;
    if (Math.random() < 0.1 + (caveNumber / 500)) {
        soulPageReward = Math.floor(Math.random() * 3) + 1;
    }

    const prosperity = Math.floor(Math.random() * (5 * multiplier)) + 2 * multiplier;
    const lands = Math.floor(Math.random() * (3 * multiplier)) + 1 * multiplier;

    return {
        points,
        gold,
        wood,
        stone,
        iron,
        prosperity,
        lands,
        weaponReward,
        soldierReward,
        accessoryReward,
        potionReward,
        companionReward,
        soulPageReward
    };
}

// ========== دالة الإرسال ==========
async function sendMessage(sock, chatId, lines, quoted = null, mentions = []) {
    if (!Array.isArray(lines)) lines = [lines];
    let msg = `🏔️ اسـتـكـشـاف الـكـهـف 🏔️\n`;
    msg += `━━━━━━━━━━━━━━━━━━━━\n`;
    for (const line of lines) {
        msg += `${line}\n`;
    }
    msg += `━━━━━━━━━━━━━━━━━━━━\n`;
    msg += `𝘽𝙔┇𝑴𝑨𝑲𝑰𝑴𝑨`;
    await sock.sendMessage(chatId, { text: msg, mentions }, { quoted: quoted });
}

// ========== الأمر الرئيسي ==========
module.exports = {
    command: ['كهف'],
    description: '🏔️ استكشاف كهف (1-100) مع مكافآت ومتطلبات مستوى',
    category: 'مملكة',
    usage: '.كهف [رقم]  أو  .كهف (لعرض الكهوف المتاحة)',

    async execute(sock, msg) {
        try {
            const chatId = msg.key.remoteJid;
            const sender = msg.key.participant || msg.participant || msg.key.remoteJid;

            // ===== تحقق من وجود مملكة =====
            if (!userExists(sender)) {
                await sendMessage(sock, chatId, [
                    '❌ ليس لديك مملكة!',
                    '📌 استخدم .لاعب جديد لتأسيس مملكتك.'
                ], msg, [sender]);
                return;
            }

            // ===== تحميل بيانات المستخدم =====
            let user = loadUserData(sender);
            const points = loadJSON(pointsPath);

            const fullText = msg.message?.conversation || msg.message?.extendedTextMessage?.text || '';
            const args = fullText.trim().split(/\s+/);

            // إذا لم يوجد رقم، عرض قائمة الكهوف
            if (args.length < 2) {
                // جلب الكهوف المستكشفة من الملف المنفصل
                const explored = getExploredCaves(sender);
                const level = user.level;

                let lines = [
                    `👤 @${sender.split('@')[0]}`,
                    `📈 مستواك: ${level}`,
                    `🗺️ الكهوف المستكشفة: ${explored.length}/100`,
                    '',
                    '📌 *الكهوف المتاحة:*'
                ];

                let count = 0;
                for (let i = 1; i <= 100; i++) {
                    if (explored.includes(i)) continue;
                    const requiredLevel = i * 500;
                    if (level >= requiredLevel) {
                        lines.push(`   🏔️ كهف ${i} (مطلوب ${requiredLevel})`);
                        count++;
                        if (count >= 10) break;
                    }
                }

                if (count === 0) {
                    lines.push('   ❌ لا توجد كهوف متاحة حالياً.');
                    lines.push('   💡 ارفع مستواك لاكتشاف كهوف جديدة.');
                }

                lines.push('');
                lines.push('📝 استخدم: .كهف [رقم] لاستكشاف كهف معين.');
                lines.push('📌 مثال: .كهف 1');

                await sendMessage(sock, chatId, lines, msg, [sender]);
                return;
            }

            // ===== استخراج رقم الكهف =====
            const caveNumber = parseInt(args[1]);
            if (isNaN(caveNumber) || caveNumber < 1 || caveNumber > 100) {
                await sendMessage(sock, chatId, [
                    '❌ رقم الكهف يجب أن يكون بين 1 و 100.',
                    '📌 مثال: .كهف 5'
                ], msg, [sender]);
                return;
            }

            // ===== التحقق من المستوى المطلوب =====
            const requiredLevel = caveNumber * 500;
            if (user.level < requiredLevel) {
                await sendMessage(sock, chatId, [
                    `❌ تحتاج مستوى ${requiredLevel} لاستكشاف كهف ${caveNumber}.`,
                    `📈 مستواك الحالي: ${user.level}`,
                    `💪 تحتاج ${requiredLevel - user.level} مستوى إضافي.`
                ], msg, [sender]);
                return;
            }

            // ===== التحقق من أنه لم يستكشف هذا الكهف من قبل (الملف المنفصل) =====
            if (isCaveExplored(sender, caveNumber)) {
                await sendMessage(sock, chatId, [
                    `❌ لقد استكشفت كهف ${caveNumber} بالفعل!`,
                    '📌 يمكنك استكشاف كل كهف مرة واحدة فقط.'
                ], msg, [sender]);
                return;
            }

            // ===== الحصول على المكافآت =====
            const rewards = getCaveRewards(caveNumber);

            // ===== تطبيق المكافآت =====
            points[sender] = (points[sender] || 0) + rewards.points;
            user.gold = (user.gold || 0) + rewards.gold;

            if (!user.resources) user.resources = { wood: 0, stone: 0, iron: 0 };
            user.resources.wood = (user.resources.wood || 0) + rewards.wood;
            user.resources.stone = (user.resources.stone || 0) + rewards.stone;
            user.resources.iron = (user.resources.iron || 0) + rewards.iron;

            user.prosperity = (user.prosperity || 0) + rewards.prosperity;
            user.lands = (user.lands || 0) + rewards.lands;

            if (rewards.weaponReward) {
                if (!user.weapons) user.weapons = {};
                user.weapons[rewards.weaponReward.key] = (user.weapons[rewards.weaponReward.key] || 0) + rewards.weaponReward.count;
            }

            if (rewards.soldierReward) {
                if (!user.soldiers) user.soldiers = {};
                user.soldiers[rewards.soldierReward.key] = (user.soldiers[rewards.soldierReward.key] || 0) + rewards.soldierReward.count;
            }

            if (rewards.accessoryReward) {
                if (!user.accessories) user.accessories = {};
                user.accessories[rewards.accessoryReward.key] = (user.accessories[rewards.accessoryReward.key] || 0) + 1;
            }

            if (rewards.potionReward) {
                if (!user.potions) user.potions = {};
                user.potions[rewards.potionReward.key] = (user.potions[rewards.potionReward.key] || 0) + rewards.potionReward.count;
            }

            if (rewards.companionReward) {
                user.companion = rewards.companionReward.key;
            }

            if (rewards.soulPageReward > 0) {
                if (!user.soulBook) user.soulBook = { pages: 0, spirits: [] };
                user.soulBook.pages = (user.soulBook.pages || 0) + rewards.soulPageReward;
            }

            // ===== تسجيل الكهف كمستكشف (الملف المنفصل) =====
            const marked = markCaveExplored(sender, caveNumber);
            if (!marked) {
                await sendMessage(sock, chatId, [
                    '⚠️ حدث خطأ أثناء تسجيل الكهف، حاول مرة أخرى.'
                ], msg, [sender]);
                return;
            }

            // تحديث exploredCaves في user للتأكد من التزامن
            user.exploredCaves = getExploredCaves(sender);

            // ===== حفظ التغييرات =====
            saveJSON(pointsPath, points);
            saveUserData(sender, user);

            // ===== بناء رسالة النتيجة =====
            const lines = [
                `🎉 استكشف كهف *${caveNumber}* بنجاح! 🎉`,
                ``,
                `📈 المكافآت:`,
                `   💰 نقاط: +${rewards.points}`,
                `   🪙 ذهب: +${rewards.gold}`,
                `   🪵 خشب: +${rewards.wood}`,
                `   🪨 حجر: +${rewards.stone}`,
                `   ⛏️ حديد: +${rewards.iron}`,
                `   📈 ازدهار: +${rewards.prosperity}`,
                `   🌍 أراضي: +${rewards.lands}`,
            ];

            if (rewards.weaponReward) {
                const weaponName = rewards.weaponReward.key.replace(/([A-Z])/g, ' $1').trim();
                lines.push(`   🗡️ سلاح: ${weaponName} ×${rewards.weaponReward.count}`);
            }
            if (rewards.soldierReward) {
                const soldierName = rewards.soldierReward.key.replace(/([A-Z])/g, ' $1').trim();
                lines.push(`   👥 جنود: ${soldierName} ×${rewards.soldierReward.count}`);
            }
            if (rewards.accessoryReward) {
                const accessoryName = rewards.accessoryReward.key.replace(/([A-Z])/g, ' $1').trim();
                lines.push(`   💍 إكسسوار: ${accessoryName}`);
            }
            if (rewards.potionReward) {
                const potionName = rewards.potionReward.key.replace(/([A-Z])/g, ' $1').trim();
                lines.push(`   🧪 جرعة: ${potionName} ×${rewards.potionReward.count}`);
            }
            if (rewards.companionReward) {
                const companionName = rewards.companionReward.key.replace(/([A-Z])/g, ' $1').trim();
                lines.push(`   🐦 رفيق: ${companionName}`);
            }
            if (rewards.soulPageReward > 0) {
                lines.push(`   📖 صفحات روح: +${rewards.soulPageReward}`);
            }

            const exploredCount = getExploredCaves(sender).length;
            lines.push(``);
            lines.push(`📊 مجموع الكهوف المستكشفة: ${exploredCount}/100`);
            lines.push(`💰 رصيدك الحالي: ${points[sender] || 0} نقطة`);

            await sendMessage(sock, chatId, lines, msg, [sender]);

        } catch (error) {
            console.error('✗ خطأ في أمر كهف:', error);
            await sendMessage(sock, msg.key.remoteJid, [
                '❌ حدث خطأ أثناء استكشاف الكهف.',
                '📌 حاول مرة أخرى لاحقاً.'
            ], msg);
        }
    }
};