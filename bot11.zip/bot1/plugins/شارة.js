// شارة.js - تحميل شارات أنمي / مسلسلات / أفلام (نسخة محسنة بدون خطوط)
const axios = require('axios');
const fs = require('fs');
const path = require('path');

const commandPrice = 50;
const APIFY_TOKEN = 'apify_api_Nosx6ch9Ua28pFgV1TFeurHCsbflPn21ezuh';

const pointsPath = path.join(__dirname, '../data/points.json');

if (!fs.existsSync(path.join(__dirname, '../data'))) fs.mkdirSync(path.join(__dirname, '../data'), { recursive: true });
if (!fs.existsSync(pointsPath)) fs.writeFileSync(pointsPath, JSON.stringify({}, null, 2));

function loadPoints() {
    try {
        return JSON.parse(fs.readFileSync(pointsPath));
    } catch {
        return {};
    }
}

function savePoints(data) {
    fs.writeFileSync(pointsPath, JSON.stringify(data, null, 2));
}

// ========== تنسيق النقاط ==========
function formatPoints(num) {
    if (num === undefined || num === null || isNaN(num)) return '0';
    num = Math.floor(num);
    if (num >= 1e15) return '∞';
    if (num >= 1e12) return (num / 1e12).toFixed(2) + ' تريليون';
    if (num >= 1e9) return (num / 1e9).toFixed(2) + ' مليار';
    if (num >= 1e6) return (num / 1e6).toFixed(2) + ' مليون';
    if (num >= 1e3) return (num / 1e3).toFixed(2) + ' ألف';
    return num.toString();
}

// ========== تحديد النوع ==========
function detectType(text) {
    const t = text.toLowerCase();
    if (t.includes('انمي') || t.includes('anime') || t.includes('شارة') || t.includes('اوست') || t.includes('opening')) {
        return { type: '🎌 أنمي', suffix: 'anime opening OST official' };
    }
    if (t.includes('مسلسل') || t.includes('series') || t.includes('netflix') || t.includes('drama')) {
        return { type: '📺 مسلسل', suffix: 'series theme song opening' };
    }
    if (t.includes('فيلم') || t.includes('movie') || t.includes('cinema') || t.includes('film')) {
        return { type: '🎬 فيلم', suffix: 'movie soundtrack OST theme' };
    }
    return { type: '🎵 عام', suffix: '' };
}

// ========== دالة الإرسال المنسقة ==========
async function sendMessage(sock, chatId, lines, quoted = null, mentions = []) {
    if (!Array.isArray(lines)) lines = [lines];
    let msg = `🎵 تـحـمـيـل شـارات 🎵\n━━━━━━━━━━━━━━━━━━━━\n`;
    for (const line of lines) {
        if (line && line.trim()) msg += `${line}\n`;
    }
    msg += `━━━━━━━━━━━━━━━━━━━━\n𝘽𝙔┇𝑴𝑨𝑲𝑰𝑴𝑨`;
    await sock.sendMessage(chatId, { text: msg, mentions }, { quoted: quoted });
}

// ========== جلب البيانات عبر TikWM ==========
async function fetchViaTikWM(query) {
    try {
        const apiUrl = `https://www.tikwm.com/api/feed/search?keywords=${encodeURIComponent(query)}`;
        const response = await axios.get(apiUrl, {
            timeout: 30000,
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                'Referer': 'https://www.tikwm.com/',
                'Origin': 'https://www.tikwm.com',
                'Accept': 'application/json, text/plain, */*',
                'Accept-Encoding': 'gzip, deflate, br',
                'Accept-Language': 'en-US,en;q=0.9'
            }
        });
        if (response.status === 200 && response.data?.code === 0) {
            const videos = response.data.data?.videos || [];
            if (videos.length) {
                // اختيار أفضل فيديو (ذو موسيقى واضحة)
                const video = videos.find(v => v.music || v.music_info?.play || v.music_info?.url) || videos[0];
                return {
                    title: video.music_info?.title || video.title || 'شارة',
                    audio_url: video.music || video.music_info?.play || video.music_info?.url,
                    author: video.author?.nickname || 'مجهول',
                    videoUrl: `https://www.tiktok.com/@${video.author?.unique_id}/video/${video.video_id}`
                };
            }
        }
        return null;
    } catch (error) {
        console.error('❌ فشل جلب من TikWM:', error.message);
        return null;
    }
}

// ========== جلب البيانات عبر Apify (بديل) ==========
async function fetchViaApify(query) {
    try {
        const apiUrl = 'https://api.apify.com/v2/acts/mu0i~tiktok-search-scraper/run-sync-get-dataset-items';
        const response = await axios.post(
            apiUrl,
            {
                queries: [query],
                resultType: 'videos',
                maxResultsPerQuery: 10,
                sortBy: 'relevance',
                includeDownloadUrls: true
            },
            {
                params: { token: APIFY_TOKEN },
                headers: { 'Content-Type': 'application/json' },
                timeout: 120000
            }
        );
        const data = Array.isArray(response.data) ? response.data : [];
        const videos = data
            .filter(v => v && v.url && !v.isPhotoPost)
            .map(v => ({
                title: v.description || 'شارة',
                audio_url: v.music_url || v.audio_url || v.noWatermarkUrl || v.url,
                author: v.authorUsername || v.authorNickname || 'مجهول',
                videoUrl: v.url
            }))
            .filter(v => v.audio_url);
        return videos.length ? videos[0] : null;
    } catch (error) {
        console.error('❌ فشل جلب من Apify:', error.message);
        return null;
    }
}

// ========== تحميل الصوت ==========
async function downloadAudio(url) {
    try {
        const response = await axios.get(url, {
            responseType: 'arraybuffer',
            timeout: 60000,
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                'Referer': 'https://www.tiktok.com/'
            }
        });
        return Buffer.from(response.data);
    } catch (error) {
        console.error('❌ فشل تحميل الصوت:', error.message);
        return null;
    }
}

module.exports = {
    command: ['شارة'],
    category: 'وسائط',
    description: '🎵 تحميل شارات أنمي / مسلسلات / أفلام مقابل نقاط',
    usage: '.شارة [اسم]',
    price: commandPrice,

    async execute(sock, msg, args) {
        let chatId, sender, points, userPoints, searchText;

        try {
            chatId = msg.key.remoteJid;
            sender = msg.key.participant || msg.key.remoteJid;

            points = loadPoints();
            userPoints = points[sender] || 0;

            // استخراج النص
            searchText = '';
            if (args && Array.isArray(args)) {
                searchText = args.join(' ').trim();
            }
            if (!searchText && msg.message?.conversation) {
                searchText = msg.message.conversation.replace(/^\.شارة\s*/i, '').trim();
            }
            if (!searchText && msg.message?.extendedTextMessage?.text) {
                searchText = msg.message.extendedTextMessage.text.replace(/^\.شارة\s*/i, '').trim();
            }

            // عرض المساعدة
            if (!searchText) {
                const lines = [
                    '🎵 *تحميل شارات*',
                    '',
                    `💰 السعر: ${commandPrice} نقطة`,
                    `🪙 رصيدك: ${formatPoints(userPoints)} نقطة`,
                    '',
                    '📖 الاستخدام:',
                    '.شارة [اسم الشارة]',
                    '',
                    '📝 أمثلة:',
                    '.شارة دراغون بول',
                    '.شارة ون بيس',
                    '.شارة مسلسل قيامة عثمان',
                    '.شارة فيلم تيتانيك'
                ];
                await sendMessage(sock, chatId, lines, msg, [sender]);
                return;
            }

            // التحقق من الرصيد
            if (userPoints < commandPrice) {
                const lines = [
                    '❌ *نقاط غير كافية*',
                    '',
                    `💰 السعر: ${commandPrice} نقطة`,
                    `🪙 رصيدك: ${formatPoints(userPoints)} نقطة`,
                    `💔 تحتاج: ${formatPoints(commandPrice - userPoints)} نقطة إضافية`
                ];
                await sendMessage(sock, chatId, lines, msg, [sender]);
                return;
            }

            // خصم النقاط مؤقتاً
            points[sender] = userPoints - commandPrice;
            savePoints(points);

            await sock.sendMessage(chatId, { react: { text: '⏳', key: msg.key } });

            // تحديد النوع وتحسين البحث
            const { type, suffix } = detectType(searchText);
            let finalSearch = searchText;
            if (suffix) finalSearch = `${searchText} ${suffix}`;

            // جلب البيانات
            let audioData = await fetchViaTikWM(finalSearch);
            if (!audioData) {
                console.log('⚠️ TikWM فشل، نحاول عبر Apify...');
                audioData = await fetchViaApify(finalSearch);
            }

            if (!audioData || !audioData.audio_url) {
                points[sender] = (points[sender] || 0) + commandPrice;
                savePoints(points);
                await sock.sendMessage(chatId, { react: { text: '❌', key: msg.key } });
                await sendMessage(sock, chatId, [
                    '❌ لا توجد نتائج أو لا يوجد صوت',
                    '💡 تم استرجاع نقاطك'
                ], msg);
                return;
            }

            // تحميل الصوت
            let audioBuffer = await downloadAudio(audioData.audio_url);
            if (!audioBuffer || audioBuffer.length < 1000) {
                // إرسال الرابط بدلاً من الصوت
                const lines = [
                    '⚠️ تعذر تحميل الصوت، إليك الرابط:',
                    '',
                    `${audioData.audio_url}`,
                    '',
                    `🎵 الاسم: ${audioData.title}`,
                    `🎬 النوع: ${type}`,
                    `👤 المؤلف: ${audioData.author}`,
                    '',
                    `💰 تم خصم ${commandPrice} نقطة`,
                    `🪙 رصيدك: ${formatPoints(points[sender])} نقطة`
                ];
                await sendMessage(sock, chatId, lines, msg);
                await sock.sendMessage(chatId, { react: { text: '⚠️', key: msg.key } });
                return;
            }

            // إرسال الصوت
            const title = audioData.title || searchText;
            const author = audioData.author || 'غير معروف';
            const newBalance = points[sender];

            // كابتشن الصوت
            const caption =
`🎵 *${title}*

🎬 النوع: ${type}
👤 المؤلف: ${author}

✅ تم التحميل بنجاح
💰 تم خصم ${commandPrice} نقطة
🪙 رصيدك: ${formatPoints(newBalance)} نقطة`;

            try {
                await sock.sendMessage(chatId, {
                    audio: audioBuffer,
                    mimetype: 'audio/mpeg',
                    ptt: false,
                    fileName: `${title}.mp3`,
                    caption: caption
                }, { quoted: msg });
            } catch (audioError) {
                console.error('❌ فشل إرسال الصوت، نحاول كوثيقة:', audioError.message);
                try {
                    await sock.sendMessage(chatId, {
                        document: audioBuffer,
                        mimetype: 'audio/mpeg',
                        fileName: `${title}.mp3`,
                        caption: caption
                    }, { quoted: msg });
                } catch (docError) {
                    console.error('❌ فشل إرسال كوثيقة، نرسل الرابط:', docError.message);
                    await sock.sendMessage(chatId, {
                        text: `⚠️ تعذر رفع الصوت، إليك الرابط:\n${audioData.audio_url}\n\n${caption}`
                    }, { quoted: msg });
                }
            }

            await sock.sendMessage(chatId, { react: { text: '✅', key: msg.key } });

        } catch (error) {
            console.error('❌ خطأ في شارة:', error);

            try {
                points = loadPoints();
                points[sender] = (points[sender] || 0) + commandPrice;
                savePoints(points);
            } catch (e) {}

            if (!chatId) chatId = msg.key?.remoteJid || 'unknown';
            if (!sender) sender = msg.key?.participant || msg.key?.remoteJid || 'unknown';

            await sock.sendMessage(chatId, { react: { text: '❌', key: msg.key } });

            let errorMsg = '❌ حدث خطأ أثناء التحميل';
            if (error.code === 'ECONNABORTED') errorMsg = '⏰ انتهت المهلة';
            else if (error.response?.status === 403) errorMsg = '🚫 تم رفض الطلب';
            else if (error.response?.status === 404) errorMsg = '🔍 لا توجد نتائج';
            else if (error.response?.status >= 500) errorMsg = '🚫 الخدمة غير متاحة';

            await sendMessage(sock, chatId, [
                `${errorMsg}`,
                '💡 تم استرجاع نقاطك',
                '🔄 حاول مرة أخرى لاحقاً'
            ], msg);
        }
    }
};