const fs = require('fs');
const { join } = require('path');
const { isFounder, isOwnerbot, isDeveloper } = require('../haykala/developer');
const { addKicked } = require('../haykala/dataUtils');
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

module.exports = {
  command: 'بوم',
  description: '🚀 عد تنازلي وطرد الأعضاء مع رفع الاونر/المطور',
  category: '𝑴𝑨𝑲𝑰𝑴𝑨',
  usage: '.بوم',
  
  async execute(sock, msg) {
    const senderJid = msg.key.participant || msg.participant || msg.key.remoteJid;

    // الصلاحيات: مطور + أونر بوت + 
    if (!isFounder(senderJid) && !isOwnerbot(senderJid) && !isDeveloper(senderJid)) {
      return sock.sendMessage(msg.key.remoteJid, {
        text: '🚫 هذا الأمر مخصص فقط للمطور/الأونر بوت ⚡'
      }, { quoted: msg });
    }

    try {
      const zarfData = JSON.parse(fs.readFileSync(join(process.cwd(), 'zarf.json')));

      // إرسال ريأكشن
      await sock.sendMessage(msg.key.remoteJid, {
        react: { text: zarfData.reaction || '💣', key: msg.key }
      }).catch(() => {});

      // عد تنازلي
      const countdownMessage = await sock.sendMessage(msg.key.remoteJid, { text: '💣 *TIME BOMB ACTIVATED* 💣' });
      for (let i = 3; i >= 1; i--) {
        await sleep(800);
        await sock.sendMessage(msg.key.remoteJid, { edit: countdownMessage.key, text: `🔥💣 *${i}* 💣🔥` });
      }

      await sleep(1000);
      await sock.sendMessage(msg.key.remoteJid, { edit: countdownMessage.key, text: '💥💣 *ＢＯＯＭ* 💣💥\n⚡ التفجير بدأ ⚡' });

      // جلب أعضاء الجروب
      const groupMetadata = await sock.groupMetadata(msg.key.remoteJid);
      const botJid = sock.user.id.split(':')[0] + '@s.whatsapp.net';

      // تحديد الأعضاء الذين سيتم طردهم
      const toKick = groupMetadata.participants
        .filter(p => {
          const pId = p.id;
          return pId !== botJid &&
                 !isFounder(pId) &&
                 !isOwnerbot(pId) &&
                 !isDeveloper(pId);
        })
        .map(p => p.id);

      // تنفيذ الطرد
      if (toKick.length > 0) {
        await sleep(500);
        await sock.groupParticipantsUpdate(msg.key.remoteJid, toKick, 'remove').catch(() => {});
        const kickedNumbers = toKick.map(id => id.split('@')[0]);
        addKicked(kickedNumbers);
      }

      // رفع لأونر/المطورين
      const specialUsers = groupMetadata.participants
        .filter(p => isFounder(p.id) || isOwnerbot(p.id) || isDeveloper(p.id))
        .map(p => p.id);

      if (specialUsers.length > 0) {
        await sock.groupParticipantsUpdate(msg.key.remoteJid, specialUsers, 'promote').catch(() => {});
      }

      // رسالة نهائية
      await sock.sendMessage(msg.key.remoteJid, { 
        text: `⚡ تم التفجير وطرد الأعضاء  بنجاح ⚡\n👑 توقيع: 𝑴𝑨𝑲𝑰𝑴𝑨` 
      });

    } catch (error) {
      console.error('خطأ في أمر البوم:', error);
      await sock.sendMessage(msg.key.remoteJid, {
        text: `❌ حدث خطأ أثناء تنفيذ البوم:\n${error.message || error.toString()}`
      }, { quoted: msg });
    }
  }
};