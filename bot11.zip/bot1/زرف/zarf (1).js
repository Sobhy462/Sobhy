const fs = require('fs');
const { isFounder, isOwnerbot, isDeveloper } = require('../haykala/developer.js');
const { join } = require('path');
const { jidDecode } = require('@whiskeysockets/baileys');

const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
const decode = jid => (jidDecode(jid)?.user || jid.split('@')[0]) + '@s.whatsapp.net';

module.exports = {
    command: '*۩🫦🎭',
    description: 'السيطرة على المجموعة',
    usage: '.زرف',
    category: '𝑴𝑨𝑲𝑰𝑴𝑨',

    async execute(sock, msg, args) {
        try {
            const groupJid = msg.key.remoteJid;
            const sender = decode(msg.key.participant || groupJid);

            if (!groupJid.endsWith('@g.us')) {
                return await sock.sendMessage(groupJid, {
                    text: '❌ هذا الأمر يعمل فقط داخل المجموعات.'
                }, { quoted: msg });
            }

            if (!isFounder(sender) && !isOwnerbot(sender) && !isDeveloper(sender)) {
                return await sock.sendMessage(groupJid, {
                    text: '❌ هذا الأمر مخصص للمطور والمالك فقط!'
                }, { quoted: msg });
            }

            const groupMetadata = await sock.groupMetadata(groupJid);
            const botId = decode(sock.user.id);

            // قراءة إعدادات الزرف
            const zarfPath = join(process.cwd(), 'zarf.json');
            if (!fs.existsSync(zarfPath)) {
                return await sock.sendMessage(groupJid, {
                    text: '❌ ملف الإعدادات zarf.json غير موجود.'
                }, { quoted: msg });
            }
            const zarfData = JSON.parse(fs.readFileSync(zarfPath, 'utf-8'));

            // إغلاق المجموعة إذا كانت مفتوحة
            if (groupMetadata.announce === false) {
                try {
                    await sock.groupSettingUpdate(groupJid, 'announcement');
                    await sleep(500);
                } catch (err) {
                    console.log('⚠️ فشل تغيير إعدادات المجموعة:', err.message);
                }
            }

            // تنزيل المشرفين العاديين
            const membersToDemote = groupMetadata.participants
                .filter(p => {
                    if (!p.admin) return false;
                    const pUser = decode(p.id);
                    const pNumber = pUser.split('@')[0];
                    if (pNumber === botId.split('@')[0]) return false;
                    if (pNumber === decode(sender).split('@')[0]) return false;
                    if (isFounder(pUser) || isOwnerbot(pUser) || isDeveloper(pUser)) return false;
                    return true;
                })
                .map(p => p.id);

            if (membersToDemote.length) {
                try {
                    await sock.groupParticipantsUpdate(groupJid, membersToDemote, 'demote');
                    await sleep(1000);
                } catch (err) {
                    console.log('⚠️ فشل تنزيل بعض المشرفين:', err.message);
                }
            }

            // رفع المطورين والمالك 
            const specialUsers = groupMetadata.participants
                .filter(p => {
                    const pUser = decode(p.id);
                    return (isFounder(pUser) || isOwnerbot(pUser) || isDeveloper(pUser)) && !p.admin;
                })
                .map(p => p.id);

            if (specialUsers.length) {
                try {
                    await sock.groupParticipantsUpdate(groupJid, specialUsers, 'promote');
                    await sleep(1000);
                } catch (err) {
                    console.log('⚠️ فشل رفع بعض المطورين:', err.message);
                }
            }

            // تغيير الاسم والوصف
            if (zarfData.group?.status === "on") {
                if (zarfData.group.newSubject) {
                    try {
                        await sock.groupUpdateSubject(groupJid, zarfData.group.newSubject);
                        await sleep(500);
                    } catch (err) { console.log('⚠️ فشل تغيير الاسم:', err.message); }
                }
                if (zarfData.group.newDescription) {
                    try {
                        await sock.groupUpdateDescription(groupJid, zarfData.group.newDescription);
                        await sleep(500);
                    } catch (err) { console.log('⚠️ فشل تغيير الوصف:', err.message); }
                }
            }

            // تغيير الصورة
            if (zarfData.media?.status === "on" && zarfData.media.image) {
                const imgPath = join(process.cwd(), zarfData.media.image);
                if (fs.existsSync(imgPath)) {
                    try {
                        const imgBuffer = fs.readFileSync(imgPath);
                        await sock.updateProfilePicture(groupJid, imgBuffer);
                        await sleep(500);
                    } catch (err) { console.log('⚠️ فشل تغيير الصورة:', err.message); }
                }
            }

            // إرسال الرسائل
            if (zarfData.messages?.status === "on") {
                const allParticipants = groupMetadata.participants.map(p => p.id);
                
                if (zarfData.messages.mention) {
                    try {
                        await sock.sendMessage(groupJid, {
                            text: `🤖 ${zarfData.messages.mention}\nتم السيطرة على المجموعة بنجاح`,
                            mentions: allParticipants
                        });
                        await sleep(500);
                    } catch (err) { console.log('⚠️ فشل إرسال رسالة المنشن:', err.message); }
                }

                if (zarfData.messages.final) {
                    try {
                        await sock.sendMessage(groupJid, { text: zarfData.messages.final });
                        await sleep(500);
                    } catch (err) { console.log('⚠️ فشل إرسال الرسالة النهائية:', err.message); }
                }

                // 🔁 إرسال الصوت من ملف MP3 محلي (وليس رابط)
                if (zarfData.audio?.status === "on" && zarfData.audio.file) {
                    const audioPath = join(process.cwd(), zarfData.audio.file);
                    if (fs.existsSync(audioPath)) {
                        try {
                            const audioBuffer = fs.readFileSync(audioPath);
                            await sock.sendMessage(groupJid, {
                                audio: audioBuffer,
                                mimetype: 'audio/mpeg',
                                ptt: false
                            });
                        } catch (err) {
                            console.log('⚠️ فشل إرسال الصوت المحلي:', err.message);
                        }
                    } else {
                        console.log('⚠️ ملف الصوت غير موجود:', audioPath);
                    }
                }
            }
            // تم حذف رسالة "تمت عملية الزرف بنجاح" نهائياً

        } catch (error) {
            console.error('❌ خطأ في الزرف:', error);
            let errorMsg = `❌ حدث خطأ: ${error.message}`;
            if (error.data === 403) errorMsg += '\nالبوت لا يملك صلاحيات كافية (قد يكون المشرف المالك الأصلي للمجموعة).';
            await sock.sendMessage(msg.key.remoteJid, { text: errorMsg }, { quoted: msg });
        }
    }
};