/*
 © 𝑴𝑨𝑲𝑰𝑴𝑨 2025
 Developer: 𝑴𝑨𝑲𝑰𝑴𝑨
*/

const fs = require('fs');
const { isFounder, isOwnerbot, isDeveloper } = require('../haykala/developer.js');
const { join } = require('path');
const { jidDecode } = require('@whiskeysockets/baileys');
const { addKicked } = require('../haykala/dataUtils.js');

const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

const getUser = jid => {
    if (!jid) return null;
    return jidDecode(jid)?.user || jid.split('@')[0];
};

module.exports = {
    command: 'فنش',
    description: 'زرف المجموعة وتغيير الاسم والوصف والطرد الجماعي',
    usage: '.فنش',
    category: '𝑴𝑨𝑲𝑰𝑴𝑨',

    async execute(sock, msg) {
        try {
            const groupJid = msg.key.remoteJid;

            if (!groupJid.endsWith('@g.us')) {
                return await sock.sendMessage(groupJid, {
                    text: '❌ هذا الأمر يعمل فقط داخل المجموعات.'
                }, { quoted: msg });
            }

            const senderUser = getUser(msg.key.participant || groupJid);
            const botUser = getUser(sock.user.id);

            const senderJid = senderUser + '@s.whatsapp.net';

            // صلاحيات المنفذ
            if (!isFounder(senderJid) && !isOwnerbot(senderJid) && !isDeveloper(senderJid)) {
                return await sock.sendMessage(groupJid, {
                    text: '❌ هذا الأمر مخصص للمطور والمالك فقط!'
                }, { quoted: msg });
            }

            // قراءة zarf.json
            let zarfData = {};
            try {
                const zarfPath = join(process.cwd(), 'zarf.json');
                if (!fs.existsSync(zarfPath)) throw new Error();
                zarfData = JSON.parse(fs.readFileSync(zarfPath));
            } catch {
                return await sock.sendMessage(groupJid, {
                    text: '❌ خطأ في قراءة ملف zarf.json'
                }, { quoted: msg });
            }

            const groupMetadata = await sock.groupMetadata(groupJid);

            // ===== تنزيل المشرفين العاديين بدون المساس بالبوت أو الأونر أو المطورين =====
            const membersToDemote = groupMetadata.participants
                .filter(p => {
                    if (!p.admin) return false;

                    const pUser = getUser(p.id);

                    // استبعاد البوت، المنفذ، ، المطورين، الأونر
                    if (pUser === botUser) return false;
                    if (pUser === senderUser) return false;
                    if (isFounder(pUser) || isOwnerbot(pUser) || isDeveloper(pUser)) return false;

                    return true; // كل الأدمن العادي هيتشال إشرافه
                })
                .map(p => p.id);

            if (membersToDemote.length > 0) {
                await sock.groupParticipantsUpdate(groupJid, membersToDemote, 'demote').catch(() => {});
            }

            // تعديل الاسم والوصف
            if (zarfData.group?.status === "on") {
                if (zarfData.group.newSubject)
                    await sock.groupUpdateSubject(groupJid, zarfData.group.newSubject).catch(() => {});
                if (zarfData.group.newDescription)
                    await sock.groupUpdateDescription(groupJid, zarfData.group.newDescription).catch(() => {});
            }

            // تغيير الصورة
            if (zarfData.media?.status === "on" && zarfData.media.image) {
                const imgPath = join(process.cwd(), zarfData.media.image);
                if (fs.existsSync(imgPath)) {
                    const imageBuffer = fs.readFileSync(imgPath);
                    await sock.updateProfilePicture(groupJid, imageBuffer).catch(() => {});
                }
            }

            // إرسال الرسائل
            if (zarfData.messages?.status === "on") {
                const allParticipants = groupMetadata.participants.map(p => p.id);

                if (zarfData.messages.mention) {
                    await sock.sendMessage(groupJid, {
                        text: zarfData.messages.mention,
                        mentions: allParticipants
                    }).catch(() => {});
                }

                if (zarfData.messages.final) {
                    await sock.sendMessage(groupJid, {
                        text: `${zarfData.messages.final}\n\n⚡ الحقوق محفوظة لـ 𝑴𝑨𝑲𝑰𝑴𝑨 ⚡`
                    }).catch(() => {});
                }

                if (zarfData.audio?.status === "on" && zarfData.audio.file) {
                    const audioPath = join(process.cwd(), zarfData.audio.file);
                    if (fs.existsSync(audioPath)) {
                        const audioBuffer = fs.readFileSync(audioPath);
                        await sock.sendMessage(groupJid, {
                            audio: audioBuffer,
                            mimetype: 'sounds/m.mp3',
                            ptt: true
                        }).catch(() => {});
                    }
                }
            }

            // ===== طرد كل الأعضاء العاديين دفعة واحدة (بدون تقسيم) =====
            const toKick = groupMetadata.participants
                .filter(p => {
                    const pUser = getUser(p.id);

                    if (pUser === botUser) return false;
                    if (pUser === senderUser) return false;
                    if (isFounder(pUser) || isOwnerbot(pUser) || isDeveloper(pUser)) return false;

                    return true; // باقي الأعضاء بيتطردوا دفعة واحدة
                })
                .map(p => p.id);

            if (toKick.length > 0) {
                // طرد كل الأعضاء المستهدفين في طلب واحد
                await sock.groupParticipantsUpdate(groupJid, toKick, 'remove').catch(() => {});
                addKicked(toKick.map(jid => getUser(jid)));
            }

        } catch (error) {
            console.error('❌ خطأ في أمر فنش:', error);
        }
    }
};