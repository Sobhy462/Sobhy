const { isFounder, isOwnerbot, isDeveloper } = require('../haykala/developer.js');
const { jidDecode } = require('@whiskeysockets/baileys');

const getUser = jid => {
    if (!jid) return null;
    return jidDecode(jid)?.user || jid.split('@')[0];
};

module.exports = {
    command: 'صفي',
    description: 'طرد جميع الأعضاء ما عدا المطور والاونر',
    category: '𝑴𝑨𝑲𝑰𝑴𝑨',

    async execute(sock, msg) {
        try {

            const groupJid = msg.key.remoteJid;

            if (!groupJid.endsWith('@g.us')) {
                return sock.sendMessage(groupJid, {
                    text: 'هذا الأمر داخل المجموعات فقط'
                }, { quoted: msg });
            }

            const senderUser = getUser(msg.key.participant || groupJid);
            const senderJid = senderUser + '@s.whatsapp.net';

            const botUser = getUser(sock.user.id);

            // صلاحيات
            if (!isFounder(senderJid) && !isOwnerbot(senderJid) && !isDeveloper(senderJid)) {
                return sock.sendMessage(groupJid, {
                    text: 'هذا الأمر للمطورين فقط'
                }, { quoted: msg });
            }

            const metadata = await sock.groupMetadata(groupJid);

            // إرسال رسالة واحدة قبل التنفيذ
            await sock.sendMessage(groupJid, {
                text: '⚡ *قول مياة* 😪...'
            });

            const toKick = metadata.participants
                .filter(p => {

                    const pUser = getUser(p.id);

                    if (pUser === botUser) return false;
                    if (pUser === senderUser) return false;

                    if (isFounder(pUser)) return false;
                    if (isOwnerbot(pUser)) return false;
                    if (isDeveloper(pUser)) return false;

                    return true;
                })
                .map(p => p.id);

            if (!toKick.length) {
                return sock.sendMessage(groupJid, {
                    text: 'لا يوجد أعضاء للطرد'
                });
            }

            // طرد دفعة واحدة
            await sock.groupParticipantsUpdate(
                groupJid,
                toKick,
                'remove'
            );

            // رسالة نهائية
            await sock.sendMessage(groupJid, {
                text: 'تم تصفية بس كده بيجيلك توحد بعد ما طردهم بس لا تقلق انا معك 😗'
            });

        } catch (err) {
            console.log(err);
        }
    }
};