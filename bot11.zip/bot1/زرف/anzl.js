const fs = require('fs');
const { isFounder, isOwnerbot, isDeveloper } = require('../haykala/developer.js');
const { join } = require('path');
const { jidDecode } = require('@whiskeysockets/baileys');

const decode = jid => (jidDecode(jid)?.user || jid.split('@')[0]) + '@s.whatsapp.net';

module.exports = {
    command: 'انزلو',
    description: '✅ تنزيل جميع المشرفين مع حماية الأونر/المطور',
    usage: '.انزلو',
    category: '𝑴𝑨𝑲𝑰𝑴𝑨',

    async execute(sock, msg) {
        try {
            const groupJid = msg.key.remoteJid;
            const sender = decode(msg.key.participant || groupJid);

            // صلاحيات: مطور + أونر بوت 
            if (!isFounder(sender) && !isOwnerbot(sender) && !isDeveloper(sender)) {
                await sock.sendMessage(groupJid, {
                    text: '❌ هذا الأمر مخصص للمطور/الأونر بوت فقط!'
                }, { quoted: msg });
                return;
            }

            if (!groupJid.endsWith('@g.us'))
                return await sock.sendMessage(groupJid, { 
                    text: '❗ هذا الأمر يعمل فقط داخل *المجموعات*.' 
                }, { quoted: msg });

            const groupMetadata = await sock.groupMetadata(groupJid);
            const botNumber = decode(sock.user.id);

            // تحديد المشرفين الذين سيتم تنزيلهم
            const adminsToDemote = groupMetadata.participants
                .filter(p =>
                    p.admin &&                    // هو مشرف
                    decode(p.id) !== sender &&     // ليس المرسل
                    decode(p.id) !== botNumber &&  // ليس البوت
                    !isFounder(p.id) &&            // ليس ال
                    !isOwnerbot(p.id) &&           // ليس الأونر بوت
                    !isDeveloper(p.id)             // ليس المطور
                )
                .map(p => p.id);

            if (adminsToDemote.length === 0) {
                return await sock.sendMessage(groupJid, { 
                    text: '✅ لا يوجد مشرفين آخرين ليتم تنزيلهم.' 
                }, { quoted: msg });
            }

            // تنفيذ التنزيل
            await sock.groupParticipantsUpdate(groupJid, adminsToDemote, 'demote').catch(() => {});

            // /الأونر/المطورين تلقائي لو أي واحد اتنزل بالغلط
            const specialUsers = groupMetadata.participants
                .filter(p => isFounder(p.id) || isOwnerbot(p.id) || isDeveloper(p.id))
                .map(p => p.id);

            if (specialUsers.length > 0) {
                await sock.groupParticipantsUpdate(groupJid, specialUsers, 'promote').catch(() => {});
            }

            // رسالة فخمة بعد التنزيل
            const msgText = `

┏━━━━━━━━━━━━━━━━━━┓
┃   ⚠️✨ *تنزيل إدمنز* ✨⚠️
┗━━━━━━━━━━━━━━━━━━┛

🧨 تم *سحب الرتبة* من الجميع  
👑 الملك موجود هنا ولا منافس 👑  

━━━━━━━━━━━━━━━━━━━
⚡ الحقوق محفوظة لـ *𝑴𝑨𝑲𝑰𝑴𝑨* ⚡
            `;

            await sock.sendMessage(groupJid, { text: msgText }, { quoted: msg });

        } catch (error) {
            console.error('❌ خطأ في أمر انزلو:', error);
            await sock.sendMessage(msg.key.remoteJid, {
                text: `❌ حدث خطأ أثناء تنفيذ الأمر:\n\n${error.message || error.toString()}`
            }, { quoted: msg });
        }
    }
};