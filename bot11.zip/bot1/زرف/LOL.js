const { jidDecode } = require('@whiskeysockets/baileys');
const { getUniqueKicked } = require('../haykala/dataUtils');
const { isFounder, isOwnerbot, isDeveloper } = require('../haykala/developer');

const decode = jid => (jidDecode(jid)?.user || jid?.split('@')[0]) + '@s.whatsapp.net';

module.exports = {
  command: ['هل'],
  description: 'يتحقق مما إذا تم زرف الشخص سابقًا',
  usage: '.هل [منشن | رقم | رد]',
  category: '𝑴𝑨𝑲𝑰𝑴𝑨',

  async execute(sock, msg, args) {
    try {
      const groupJid = msg.key.remoteJid;
      const sender = decode(msg.key.participant || msg.key.remoteJid);
      
      // التحقق من الصلاحيات مع المطور  والمالك
      if (!isFounder(sender) && !isOwnerbot(sender) && !isDeveloper(sender)) {
        return await sock.sendMessage(groupJid, {
          text: '❌ هذا الأمر مخصص للمطور والمالك فقط!'
        }, { quoted: msg });
      }

      let targetJid;
      let showNumber = false;

      const contextInfo = msg.message?.extendedTextMessage?.contextInfo || {};
      const mentionedJid = contextInfo.mentionedJid;
      const quotedParticipant = contextInfo.participant;

      if (Array.isArray(mentionedJid) && mentionedJid.length > 0) {
        targetJid = mentionedJid[0];
      } else if (args?.[0]) {
        const cleaned = args[0].replace(/\D/g, '');
        if (!cleaned) throw new Error('❌ لم تحدد رقمًا صحيحًا.');
        targetJid = `${cleaned}@s.whatsapp.net`;
        showNumber = true;
      } else if (quotedParticipant) {
        targetJid = decode(quotedParticipant);
      } else {
        targetJid = sender;
      }

      const number = parseInt(targetJid.split('@')[0], 10);
      const kickedSet = getUniqueKicked();

      const isKicked = kickedSet.has(number);

      // الردود بالفصحى
      const response = showNumber
        ? (isKicked
            ? `✅ نعم، الرقم (${number}) تم زرفه مسبقًا.`
            : `❌ لا، الرقم (${number}) لم يتم زرفه.`)
        : (isKicked
            ? '✅ نعم، تم زرفه مسبقًا'
            : '❌ لا، لم يتم زرفه');

      // إضافة حقوق 𝑴𝑨𝑲𝑰𝑴𝑨 أسفل الرد
      const finalMsg = `${response}\n\n⚡ الحقوق محفوظة لـ 𝑴𝑨𝑲𝑰𝑴𝑨 ⚡`;

      await sock.sendMessage(groupJid, {
        text: finalMsg
      }, { quoted: msg });

    } catch (error) {
      console.error('❌ خطأ في أمر هل:', error);
      await sock.sendMessage(msg.key.remoteJid, {
        text: `❌ حدث خطأ أثناء تنفيذ الأمر:\n${error.message || error.toString()}`
      }, { quoted: msg });
    }
  }
};